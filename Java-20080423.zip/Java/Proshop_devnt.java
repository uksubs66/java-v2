/***************************************************************************************
 *   Proshop_devnt:   This servlet will process the event signups
 *
 *
 *   called by:  
 *
 *
 *   parms passed (on doGet):  
 *
 *
 *   created: 6/26/2007   Paul S.
 *
 *   last updated:
 *  
 *         1/10/07  Fixed bug with 9 hole events that use
 *         1/08/07  Fixed bug with events that use -ALL- courses
 *        10/01/07  Added copying of memNum to teecurr2 when moving signups
 *        09/18/07  Fixed convert method to maintain orig_by value properly (case 1195) - REMOVED
 *        08/21/07  Updated the instructions
 *        07/26/07  Don't inticate shotguns in the F/B column
 *
 *
 *
 ***************************************************************************************
 */


import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.util.zip.*;
import java.sql.*;
import java.lang.Math;
import javax.mail.internet.*;
import javax.mail.*;
import javax.activation.*;

// foretees imports
import com.foretees.common.parmSlot;
import com.foretees.common.parmClub;
import com.foretees.common.verifySlot;
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.getClub;
import com.foretees.common.parmEmail;
import com.foretees.common.sendEmail;


public class Proshop_devnt extends HttpServlet {


   String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)
   String delim = "_";

   
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    resp.setHeader("Pragma", "no-cache");      // these 3 added to fix 'blank screen' problem
    resp.setHeader("Cache-Control", "no-cache");
    resp.setDateHeader("Expires", 0);
    resp.setContentType("text/html");
    PrintWriter out;

    PreparedStatement pstmtc = null;
    Statement stmt = null;
    Statement stmtc = null;
    ResultSet rs = null;
    ResultSet rs2 = null;

    //
    //  use GZip (compression) if supported by browser
    //
    String encodings = req.getHeader("Accept-Encoding");               // browser encodings
/*
    if ((encodings != null) && (encodings.indexOf("gzip") != -1)) {    // if browser supports gzip

      OutputStream out1 = resp.getOutputStream();
      out = new PrintWriter(new GZIPOutputStream(out1), false);       // use compressed output stream
      resp.setHeader("Content-Encoding", "gzip");                     // indicate gzip

    } else {

      out = resp.getWriter();                                         // normal output stream
    }
*/
      out = resp.getWriter(); 
    HttpSession session = SystemUtils.verifyPro(req, out);             // check for intruder

    if (session == null) {

      out.println(SystemUtils.HeadTitle("Access Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>System Access Error</H3>");
      out.println("<BR><BR>You have entered this site incorrectly or have lost your session cookie.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
    }

    Connection con = SystemUtils.getCon(session);                     // get DB connection

    if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
    }

    //
    //  Check for 'Insert' or 'Delete' request
    //
    if (req.getParameter("insert") != null) {

      doInsert(req, out, con, session);          // process insert request
      return;
      
    } else if (req.getParameter("delete") != null) {

      if (req.getParameter("eventId") != null) {
        doDeleteEvent(req, out, con, session);
      } else {
        doDelete(req, out, con, session);
      }
      return;
      
    }
    
   //
   //   get name of club for this user
   //
   String club = (String)session.getAttribute("club");
   
   //
   //  Get the hide option
   //
   String hideUnavail = req.getParameter("hide");
   if (hideUnavail == null) hideUnavail = "";
   
   
   //
   //  Get the jump value
   //
   int jump = 0;
   try {
      jump = Integer.parseInt(req.getParameter("jump"));
   }
   catch (NumberFormatException e) { }
   
   //
   //  Get the hide option
   //
   int limit = -1;
   String slimit = req.getParameter("limit");
   //if (slimit == null || slimit.equals("ALL")) limit = -1;
   try {
      limit = Integer.parseInt(slimit);
   }
   catch (NumberFormatException e) { }
   
   //
   //  Get the golf course name requested (changed to use the course specified for this event)
   //
   String course = req.getParameter("course");
   if (course == null) course = "";
   
   //
   //  Get the name of the event requested
   //
   String event_name = req.getParameter("name");
   if (event_name == null) event_name = "";
   
   //
   //    'index' contains an index value representing the date selected
   //    (0 = today, 1 = tomorrow, etc.)
   //
   int index = 0;
   String num = req.getParameter("index");         // get the index value of the day selected
   if (num == null) num = "0";
   
   //
   //  Convert the index value from string to int
   //
   try {
      index = Integer.parseInt(num);
   }
   catch (NumberFormatException e) { }
   
   
   if (req.getParameter("doEmails") != null) {
       
       int event_date = 0;
       
       String sevent_date = req.getParameter("event_date");
       try {
          event_date = Integer.parseInt(sevent_date);
       }
       catch (NumberFormatException ignore) { }
       
       String clubName = SystemUtils.getClubName(con);
       
       // call the send email routine
       sendEventEmails(clubName, event_name, event_date, index, course, out, con);
       
       //
       // Completed update - reload page
       //
       //out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_dlott?index=" + index + "&course=" + course + "&lott_name=" + lott_name + "&hide="+hideUnavail+"&backToSheet\">");
       
       return;
   }
   
   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
   
   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   //  parm block to hold the course parameters
   //
   parmCourse parmc = new parmCourse();          // allocate a parm block
   
   String event = "";
   String ecolor = "";
   String rest = "";
   String rcolor = "";
   String rest_recurr = "";
   String rest5 = "";
   String bgcolor5 = "";
   String player = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String user1 = "";
   String user2 = "";
   String user3 = "";
   String user4 = "";
   String user5 = "";
   String p1 = "";
   String p2 = "";
   String p3 = "";
   String p4 = "";
   String p5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String ampm = "";
   String event_rest = "";
   String bgcolor = "";
   String stime = "";
   String sshow = "";
   String sfb = "";
   String submit = "";
   String jumps = "";
   String hole = "";
   
   String event1 = "";       // for legend - max 2 events, 4 rest's, 2 lotteries
   String ecolor1 = "";
   String rest1 = "";
   String rcolor1 = "";
   String event2 = "";
   String ecolor2 = "";
   String rest2 = "";
   String rcolor2 = "";
   String rest3 = "";
   String rcolor3 = "";
   String rest4 = "";
   String rcolor4 = "";
   String blocker = "";
   String bag = "";
   String conf = "";
   String orig_by = "";
   String orig_name = "";
   String errMsg = "";
   String emailOpt = "";
   String lottery_color = "";
   String lottery = "";
   String lottery_recurr = "";
   String lott = "";
   String lott1 = "";
   String lott2 = "";
   String lott3 = "";
   String lott_color = "";
   String lott_color2 = "";
   String lott_recurr = "";
   String lcolor1 = "";
   String lcolor2 = "";
   String lcolor3 = "";
   
   int j = 0;
   int i = 0;
   int hr = 0;
   int min = 0;
   int time = 0;
   int year = 0;
   int month = 0;
   int day = 0;
   int day_num = 0;
   int type = 0;
   int in_use = 0;
   int fives = 0;
   int fivesALL = 0;
   int teecurr_id = 0;
   int shotgun = 1;
   int g1 = 0;
   int g2 = 0;
   int g3 = 0;
   int g4 = 0;
   int g5 = 0;
   int p91 = 0;
   int p92 = 0;
   int p93 = 0;
   int p94 = 0;
   int p95 = 0;
   
   short fb = 0;
   
   int event_start_time = 0;
   int event_end_time = 0;
   
   //
   //  Array to hold the course names
   //
   int cMax = 21;  
   String [] courseA = new String [cMax];               // max of 20 courses per club
   String courseName = "";                              // max of 20 courses per club
   String courseName1 = "";
   String courseT = "";
   int tmp_i = 0;

   int [] fivesA = new int [cMax];                      // array to hold 5-some option for each course

   String [] course_color = new String [cMax];
   
   // set default course colors  // NOTE: CHANES TO THIS ARRAY NEED TO BE DUPLICATED IN Proshop_sheet.java
   course_color[0] = "#F5F5DC";   // beige shades
   course_color[1] = "#DDDDBE";
   course_color[2] = "#B3B392";
   course_color[3] = "#8B8970";
   course_color[4] = "#E7F0E7";   // greens shades
   course_color[5] = "#C6D3C6";
   course_color[6] = "#648A64";
   course_color[7] = "#407340";
   course_color[8] = "#FFE4C4";   // bisque
   course_color[9] = "#95B795";
   course_color[10] = "#66CDAA";  // medium aquamarine
   course_color[11] = "#20B2AA";  // light seagreen
   course_color[12] = "#3CB371";  // medium seagreen
   course_color[13] = "#F5DEB3";  // wheat
   course_color[14] = "#D2B48C";  // tan
   course_color[15] = "#999900";  //
   course_color[16] = "#FF9900";  // red-orange??
   course_color[17] = "#33FF66";  //
   course_color[18] = "#7FFFD4";  // aquamarine
   course_color[19] = "#33FFFF";  //
   course_color[20] = "#FFFFFF";  // white
   
   
   //
   //  Get today's date and then use the value passed to locate the requested date
   //
   Calendar cal = new GregorianCalendar();       // get todays date

   cal.add(Calendar.DATE,index);                 // roll ahead 'index' days
   int cal_hour = cal.get(Calendar.HOUR_OF_DAY); // 24 hr clock (0 - 23)
   int cal_min = cal.get(Calendar.MINUTE);
   int cal_time = (cal_hour * 100) + cal_min;    // get time in hhmm format
   cal_time = SystemUtils.adjustTime(con, cal_time);

   year = cal.get(Calendar.YEAR);
   month = cal.get(Calendar.MONTH);
   day = cal.get(Calendar.DAY_OF_MONTH);
   day_num = cal.get(Calendar.DAY_OF_WEEK);     // day of week (01 - 07)

   month = month + 1;                               // month starts at zero

   String day_name = day_table[day_num];            // get name for day

   long date = (year * 10000) + (month * 100) + day;  // create a date field of yyyymmdd
   
   String date_mysql = year + "-" + SystemUtils.ensureDoubleDigit(month) + "-" + SystemUtils.ensureDoubleDigit(day);
   String time_mysql = (cal_time / 100) + ":" + SystemUtils.ensureDoubleDigit(cal_time % 100) + ":00"; // current time for 
   
   //out.println("<!-- date_mysql=" + date_mysql + " -->");
   //out.println("<!-- cal_time=" + cal_time + " -->");
   
   
   if (req.getParameter("backToSheet") != null) {

       int count = 0;
       
       try {

           PreparedStatement pstmt = con.prepareStatement ("" +
                    "SELECT COUNT(*) " +
                    "FROM teecurr2 " +
                    "WHERE date = ? AND lottery_email = 2;"); // was <> 0

           pstmt.clearParameters();
           pstmt.setLong(1, date);
           rs = pstmt.executeQuery();

           if ( rs.next() ) count = rs.getInt(1);
            
       } catch (Exception exp) {
           SystemUtils.buildDatabaseErrMsg("Fatal error check for event emails.", exp.toString(), out, false);  
       }
       
       if (count == 0) {
           
           out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_jump?index=" + index + "&course=" + course + "\">");
       
       } else {
           
            out.println("<center>");
            out.println("<h2>Send Event Emails</h2>");
            out.println("<p>There are " + count + " event signups that need to have emails sent.</p>");
            out.println("<p>Do you want to send them now or later?</p>");
            out.println("<form>");
            
            out.println("<input type=hidden name=doEmails value=\"1\">");
            out.println("<input type=hidden name=event_date value=\"" + date + "\">");
            out.println("<input type=hidden name=index value=\"" + index + "\">");
            out.println("<input type=hidden name=course value=\"" + course + "\">");
            
            out.println("<input type=submit value=\"Send Now\">");
            out.println("</form>");
            
            out.println("<form method=get action=/" + rev + "/servlet/Proshop_jump>");
            out.println("<input type=hidden name=index value=\"" + index + "\">");
            out.println("<input type=hidden name=course value=\"" + course + "\">");
            out.println("<input type=submit value=\"Send Later\">");
            
            out.println("</form>");
            
            out.println("<p>Note:&nbsp; <i>If players do not have email addresses or have choosen not to receive emails, no emails will be sent to them.</i></p>");
            
            out.println("</center>");
            
       }
       
       return;
       
   }
   
   
   // huge try/catch that spans entire method
   try {
      
      errMsg = "Get course names.";
      
      //
      // Get the Guest Types from the club db
      //
      getClub.getParms(con, parm);        // get the club parms
      
      //
      //   Remove any guest types that are null - for tests below
      //
      i = 0;
      while (i < parm.MAX_Guests) {

         if (parm.guest[i].equals( "" )) {

            parm.guest[i] = "$@#!^&*";      // make so it won't match player name
         }
         i++;
      }         // end of while loop
      
      //
      //   Get course names if multi-course facility so we can determine if any support 5-somes
      //
      i = 0;
      int courseCount = 0;
      int group_size = 0;
      
      //if (course.equals("")) {
          PreparedStatement pstmt = con.prepareStatement ("" +
                "SELECT courseName, stime, etime, size " +
                "FROM events2b " +
                "WHERE name = ?");

          pstmt.clearParameters();
          pstmt.setString(1, event_name);
          rs = pstmt.executeQuery();

          if (rs.next()) {

              if (parm.multi != 0 && course.equals("")) course = rs.getString(1);  // if no course was specified (default) then set the course variable to the course this event is for
              event_start_time = rs.getInt(2);
              event_end_time = rs.getInt(3);
              group_size = rs.getInt(4);
          }

      //}
      
      if (parm.multi != 0) {           // if multiple courses supported for this club
         
         // init the course array
         while (i < cMax) {
            
            courseA[i] = "";
            i++;
         }
         i = 0;
         int total = 0;
         //
         //  Get the names of all courses for this club
         //
         pstmt = con.prepareStatement("SELECT courseName FROM clubparm2;");
         pstmt.clearParameters();
         rs = pstmt.executeQuery();

         while (rs.next() && i < cMax) {

            courseName = rs.getString(1);
            courseA[i] = courseName;      // add course name to array
            i++;
         }
         pstmt.close();
         
         if (i > cMax) {               // make sure we didn't go past max

            courseCount = cMax;
              
         } else {

            courseCount = i;              // save number of courses
         }
 
         if (i > 1 && i < cMax) {
             
            courseA[i] = "-ALL-";        // add '-ALL-' option
         }
         
         //
         //  Make sure we have a course (in case we came directly from the Today's Tee Sheet menu)
         //
         if (courseName1.equals( "" )) {
           
            courseName1 = courseA[0];    // grab the first one
         }
         
      } // end if multiple courses supported

      //
      //  Get the walk/cart options available and 5-some support
      //
      i = 0;
      if (course.equals( "-ALL-" )) {

         //
         //  Check all courses for 5-some support
         //
         loopc:
         while (i < cMax) {

            courseName = courseA[i];       // get a course name

            if (!courseName.equals( "-ALL-" )) {   // skip if -ALL-

               if (courseName.equals( "" )) {      // done if null
                  break loopc;
               }
               getParms.getCourse(con, parmc, courseName);
            
               fivesA[i] = parmc.fives;      // get fivesome option
               if (fivesA[i] == 1) {
                  fives = 1;
               }
            }
            i++;
         }

      } else {       // single course requested

         getParms.getCourse(con, parmc, course);

         fives = parmc.fives;      // get fivesome option
      }
        
      fivesALL = fives;            // save 5-somes option for table display below

      i = 0;

      //
      //   Statements to find any restrictions, events or lotteries for today
      //
      String string7b = "";
      String string7c = "";
      String string7d = "";

      if (course.equals( "-ALL-" )) {
         string7b = "SELECT name, recurr, color FROM restriction2 WHERE sdate <= ? AND edate >= ? " +
                    "AND showit = 'Yes'";
      } else {
         string7b = "SELECT name, recurr, color FROM restriction2 WHERE sdate <= ? AND edate >= ? " +
                    "AND (courseName = ? OR courseName = '-ALL-') AND showit = 'Yes'";
      }

      if (course.equals( "-ALL-" )) {
         string7c = "SELECT name, color FROM events2b WHERE date = ?";
      } else {
         string7c = "SELECT name, color FROM events2b WHERE date = ? " +
                    "AND (courseName = ? OR courseName = '-ALL-')";
      }

      if (course.equals( "-ALL-" )) {
         string7d = "SELECT name, recurr, color, sdays, sdtime, edays, edtime, pdays, ptime, slots " +
                    "FROM lottery3 WHERE sdate <= ? AND edate >= ?";
      } else {
         string7d = "SELECT name, recurr, color, sdays, sdtime, edays, edtime, pdays, ptime, slots " +
                    "FROM lottery3 WHERE sdate <= ? AND edate >= ? " +
                    "AND (courseName = ? OR courseName = '-ALL-')";
      }

      PreparedStatement pstmt7b = con.prepareStatement (string7b);
      PreparedStatement pstmt7c = con.prepareStatement (string7c);
      PreparedStatement pstmt7d = con.prepareStatement (string7d);

      errMsg = "Scan Restrictions.";

      //
      //  Scan the events, restrictions and lotteries to build the legend
      //
      pstmt7b.clearParameters();          // clear the parms
      pstmt7b.setLong(1, date);
      pstmt7b.setLong(2, date);
      if (!course.equals( "-ALL-" )) {
         pstmt7b.setString(3, course);
      }

      rs = pstmt7b.executeQuery();      // find all matching restrictions, if any

      while (rs.next()) {

         rest = rs.getString(1);
         rest_recurr = rs.getString(2);
         rcolor = rs.getString(3);

         //
         //  We must check the recurrence for this day (Monday, etc.)
         //
         if ((rest_recurr.equals( "Every " + day_name )) ||          // if this day
             (rest_recurr.equalsIgnoreCase( "every day" )) ||        // or everyday
             ((rest_recurr.equalsIgnoreCase( "all weekdays" )) &&    // or all weekdays (and this is one)
               (!day_name.equalsIgnoreCase( "saturday" )) &&
               (!day_name.equalsIgnoreCase( "sunday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&    // or all weekends (and this is one)
              (day_name.equalsIgnoreCase( "saturday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&
              (day_name.equalsIgnoreCase( "sunday" )))) {


            if ((!rest.equals( rest1 )) && (rest1.equals( "" ))) {

               rest1 = rest;
               rcolor1 = rcolor;

               if (rcolor.equalsIgnoreCase( "default" )) {

                  rcolor1 = "#F5F5DC";
               }

            } else {

               if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (rest2.equals( "" ))) {

                  rest2 = rest;
                  rcolor2 = rcolor;

                  if (rcolor.equalsIgnoreCase( "default" )) {

                     rcolor2 = "#F5F5DC";
                  }

               } else {

                  if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (!rest.equals( rest3 )) && (rest3.equals( "" ))) {

                     rest3 = rest;
                     rcolor3 = rcolor;

                     if (rcolor.equalsIgnoreCase( "default" )) {

                        rcolor3 = "#F5F5DC";
                     }

                  } else {

                     if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (!rest.equals( rest3 )) &&
                         (!rest.equals( rest4 )) && (rest4.equals( "" ))) {

                        rest4 = rest;
                        rcolor4 = rcolor;

                        if (rcolor.equalsIgnoreCase( "default" )) {

                           rcolor4 = "#F5F5DC";
                        }
                     }
                  }
               }
            }
         }
      }  // end of while
      pstmt7b.close();

      errMsg = "Scan Events.";

      pstmt7c.clearParameters();          // clear the parms
      pstmt7c.setLong(1, date);
      if (!course.equals( "-ALL-" )) {
         pstmt7c.setString(2, course);
      }

      rs = pstmt7c.executeQuery();      // find all matching events, if any

      while (rs.next()) {

         event = rs.getString(1);
         ecolor = rs.getString(2);

         if ((!event.equals( event1 )) && (event1.equals( "" ))) {

            event1 = event;
            ecolor1 = ecolor;

            if (ecolor.equalsIgnoreCase( "default" )) {

               ecolor1 = "#F5F5DC";
            }

          } else {

            if ((!event.equals( event1 )) && (!event.equals( event2 )) && (event2.equals( "" ))) {

               event2 = event;
               ecolor2 = ecolor;

               if (ecolor.equalsIgnoreCase( "default" )) {

                  ecolor2 = "#F5F5DC";
               }
            }
         }

      }                  // end of while
      pstmt7c.close();


      //****************************************************
      // Define tee sheet size and build it
      //****************************************************

      // define our two arrays that describe the column sizes
      // index = column number, value = size in pixels
      int [] col_width = new int [15];
      int col_start[] = new int[15];                    // total width = 962 px (in dts-styles.css)
      int [] lcol_width = new int [7];
      int lcol_start[] = new int[7];
      
      if (group_size > 1) {
      
          lcol_width[0] = 0;                                        // unused
          lcol_width[1] = 160;                                      // player 1
          lcol_width[2] = 160;                                      // player 2
          lcol_width[3] = 160;                                      // player 3
          lcol_width[4] = 160;                                      // player 4
          lcol_width[5] = 160;                                      // player 5
          lcol_width[6] = 20;                                       // notes
          
      } else {
          
          lcol_width[0] = 0;                                        // unused
          lcol_width[1] = 180;                                      // player 1
          lcol_width[2] = 0;                                        // unused
          lcol_width[3] = 0;                                        // unused
          lcol_width[4] = 0;                                        // unused
          lcol_width[5] = 0;                                        // unused
          lcol_width[6] = 0;                                        // notes
          
      }
      
      lcol_start[1] = 0;
      lcol_start[2] = lcol_start[1] + lcol_width[1];
      lcol_start[3] = lcol_start[2] + lcol_width[2];
      lcol_start[4] = lcol_start[3] + lcol_width[3];
      lcol_start[5] = lcol_start[4] + lcol_width[4];
      lcol_start[6] = lcol_start[5] + lcol_width[5];
      
      //lcol_start[7] = lcol_start[6] + lcol_width[6];
      //lcol_start[8] = lcol_start[7] + lcol_width[7];
      //lcol_start[9] = lcol_start[8] + lcol_width[8];
      
      if (course.equals( "-ALL-" )) {
         col_width[0] = 0;        // unused
         col_width[1] = 40;       // +/-
         col_width[2] = 71;       // time
         col_width[3] = 90;       // course name col 69
         col_width[4] = 31;       // f/b
         col_width[5] = 111;      // player 1
         col_width[6] = 39;       // player 1 trans opt
         col_width[7] = 111;      // player 2
         col_width[8] = 39;       // player 2 trans opt
         col_width[9] = 111;      // player 3
         col_width[10] = 39;      // player 3 trans opt
         col_width[11] = 111;     // player 4
         col_width[12] = 39;      // player 4 trans opt
         col_width[13] = 111;     // player 5
         col_width[14] = 39;      // player 5 trans opt
      } else {
         col_width[0] = 0;        // unused
         col_width[1] = 40;       // +/-
         col_width[2] = 80;       // time
         col_width[3] = 0;        // empty if no course name
         col_width[4] = 40;       // f/b
         col_width[5] = 120;      // player 1
         col_width[6] = 40;       // player 1 trans opt
         col_width[7] = 120;      // player 2
         col_width[8] = 40;       // player 2 trans opt
         col_width[9] = 120;      // player 3
         col_width[10] = 40;      // player 3 trans opt
         col_width[11] = 120;     // player 4
         col_width[12] = 40;      // player 4 trans opt
         col_width[13] = 120;     // player 5
         col_width[14] = 40;      // player 5 trans opt
      }
      col_start[1] = 0;
      col_start[2] = col_start[1] + col_width[1];
      col_start[3] = col_start[2] + col_width[2];
      col_start[4] = col_start[3] + col_width[3];
      col_start[5] = col_start[4] + col_width[4];
      col_start[6] = col_start[5] + col_width[5];
      col_start[7] = col_start[6] + col_width[6];
      col_start[8] = col_start[7] + col_width[7];
      col_start[9] = col_start[8] + col_width[8];
      col_start[10] = col_start[9] + col_width[9];
      col_start[11] = col_start[10] + col_width[10];
      col_start[12] = col_start[11] + col_width[11];
      col_start[13] = col_start[12] + col_width[12];
      col_start[14] = col_start[13] + col_width[13];

      int total_col_width = col_start[14] + col_width[14];
      
      // temp variable
      String dts_tmp = "";

      //
      //  Build the HTML page
      //
      out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
      out.println("<html>\n<!--Copyright notice:  This software (including any images, servlets, applets, photographs, animations, video, music and text incorporated into the software) ");
      out.println("is the proprietary property of ForeTees, LLC or its suppliers and its use, modification and distribution are protected ");
      out.println("and limited by United States copyright laws and international treaty provisions and all other applicable national laws. ");
      out.println("\nReproduction is strictly prohibited.-->");
      out.println("<head>");
      out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
      out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
      out.println("<meta http-equiv=\"Content-Style-Type\" content=\"text/css\">");

      out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/dts-styles.css\">");

      out.println("<title>Proshop Tee Sheet Management Page</title>");

      out.println("<script language=\"javascript\">");          // Jump script
      out.println("<!--");
      out.println("function jumpToHref(anchorstr) {");
      out.println("if (location.href.indexOf(anchorstr)<0) {");
      out.println(" location.href=anchorstr; }");
      out.println("}");
      out.println("// -->");
      out.println("</script>");                               // End of script

      // include dts javascript source file
      out.println("<script language=\"javascript\" src=\"/" +rev+ "/dts-scripts.js\"></script>");

      out.println("</head>");

      out.println("<body onLoad='jumpToHref(\"#jump" + jump + "\");' bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

      out.println("<a name=\"jump0\"></a>");     // create a default jump label (start of page)

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");        // whole page
      out.println("<tr><td align=\"center\">");

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");        // table for cmd tbl & instructions
      out.println("<tr><td align=\"left\" valign=\"middle\">");

         //
         //  Build Control Panel
         //
         out.println("<table border=\"1\" width=\"130\" cellspacing=\"3\" cellpadding=\"3\" bgcolor=\"8B8970\" align=\"left\">");
         out.println("<tr>");
         out.println("<td align=\"center\"><font size=\"3\"><b>Control Panel</b><br>");
         out.println("</font></td></tr><tr><td align=\"center\"><font size=\"2\">");
         
         out.println("</font></td></tr><tr><td align=\"center\" nowrap><font size=\"2\">");
         out.println("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +course+ "&name=" + event_name + "&hide=" + hideUnavail + "\" title=\"Refresh Sheet\" alt=\"Refresh Sheet\">");
         out.println("Refresh Sheet</a><br>");
         
         out.println("</font></td></tr><tr><td align=\"center\" nowrap><font size=\"2\">");
         out.println("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +course+ "&name=" + event_name + ((hideUnavail.equals("1") ? "" : "&hide=1")) + "\" title=\"Event Times Only\" alt=\"Lottery Times Only\">");
         out.println((hideUnavail.equals("1") ? "Show All Tee Times" : "Show Event Times Only") + "</a><br>");
         
         //out.println("</font></td></tr><tr><td align=\"center\" nowrap><font size=\"2\">");
         //out.println("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&event_date=" + date + "&course=" +course+ "&name=" + event_name + "&hide=" + hideUnavail + "&convert=all\" title=\"Convert All Signups\" alt=\"Convert All Signups\">");
         //out.println("Convert All Signups</a><br>");
         
         out.println("</font></td></tr><tr><td align=\"center\" nowrap><font size=\"2\">");
         //out.println("<a href=\"/" +rev+ "/servlet/Proshop_jump?index=" +index+ "&course=" +course+ "\" title=\"Return to Tee Sheet\" alt=\"Return\">");
         out.println("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +course+ "&name=" + event_name + "&event_date=" + date + "&backToSheet\" title=\"Return to Tee Sheet\" alt=\"Return\">");
         out.println("Return to Tee Sheet</a><br>");
         
         out.println("</font></td></tr></table>"); // end Control Panel table

      out.println("</td>");                                 // end of column for control panel
      out.println("<td align=\"center\" width=\"20\">&nbsp;");     // empty column for spacer

      out.println("</td>");
      out.println("<td align=\"left\" valign=\"top\">");     // column for instructions, course selector, calendars??

         //**********************************************************
         //  Continue with instructions and tee sheet
         //**********************************************************

         out.println("<table cellpadding=\"5\" cellspacing=\"3\" width=\"80%\">");
         out.println("<tr><td align=\"center\">");
         out.println("<p align=\"center\"><font size=\"5\">Golf Shop Event Management</font></p>");
         out.println("</td></tr></table>");
         
         
        out.println("<table cellpadding=\"3\" width=\"80%\">");
        out.println("<tr><td bgcolor=\"#336633\"><font color=\"#FFFFFF\" size=\"2\">");
        out.println("<b>Instructions:</b>&nbsp;");
        out.println("To convert an event signup in to a tee time, click and drag on the first players name and drag it down to the tee sheet releasing it over the desired tee time.");
        out.println("<br>");
        out.println("To <b>insert</b> a new tee time, click on the plus icon <img src=/v5/images/dts_newrow.gif width=13 height=13 border=0> in the tee time you wish to insert <i>after</i>.&nbsp; ");
        out.println("To <b>delete</b> a tee time, click on the trash can icon <img src=/v5/images/dts_trash.gif width=13 height=13 border=0> in the tee time you wish to delete.&nbsp; ");
        out.println("To <b>move an entire tee time</b>, click on the 'Time' value and drag the tee time to the new position.&nbsp; ");
        out.println("To <b>move an individual player</b>, click on the Player and drag the name to the new position.&nbsp; ");
        out.println("To <b>change</b> the F/B value or the C/W value, just click on it and make the selection.&nbsp; ");
        out.println("Empty 'player' cells indicate available positions.&nbsp; ");
        out.println("Special Events and Restrictions, if any, are colored (see legend below).");
        out.println("</font></td></tr></table>");
         
        out.println("</td></tr></table>"); // end tbl for instructions         

      out.println("<p><font size=\"2\">");
      out.println("Date:&nbsp;&nbsp;<b>" + day_name + "&nbsp;&nbsp;" + month + "/" + day + "/" + year + "</b>");
      
    if (!course.equals( "" )) {

        out.println("&nbsp;&nbsp;&nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + course + "</b></p>");
    }
      
      //
      //  If multiple courses, then add a drop-down box for course names
      //
      String tmp_ncount = "";
      //out.println("<!-- courseCount=" + courseCount + " -->");
      
      if (parm.multi != 0) {           // if multiple courses supported for this club

         //
         //  use 2 forms so you can switch by clicking either a course or a date
         //
         if (courseCount < 5) {        // if < 5 courses, use buttons

            i = 0;
            courseName = courseA[i];      // get first course name from array
            
            out.println("<p><font size=\"2\">");
            out.println("<b>Select Course:</b>&nbsp;&nbsp;");

            while ((!courseName.equals( "" )) && (i < 6)) {    // allow one more for -ALL-

               out.println("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +courseName+ "&hide=" + hideUnavail + "&name=" + event_name + "\" style=\"color:blue\" target=\"_top\" title=\"Switch to new course\" alt=\"" +courseName+ "\">");
               out.print(courseName + "</a>");
               out.print("&nbsp;&nbsp;&nbsp;");

               i++;
               courseName = courseA[i];      // get course name from array
            }
            out.println("</p>");

         }
         else 
         {     // use drop-down menu

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" name=\"cform\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");   // use current date
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"select\">");

            i = 0;
            courseName = courseA[i];      // get first course name from array

            out.println("<b>Course:</b>&nbsp;&nbsp;");
            out.println("<select size=\"1\" name=\"course\" onchange=\"document.cform.submit()\">");

            while ((!courseName.equals( "" )) && (i < cMax)) {

               out.println("<option " + ((courseName.equals( course )) ? "selected " : "") + "value=\"" + courseName + "\">" + courseName + "</option>");
               i++;
               if (i < cMax) courseName = courseA[i];      // get course name from array
               
            }
            
            out.println("</select>");
            out.println("</form>");
            
         } // end either display href links or drop down select
         
      } // end if multi course
      

      if (!event1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + ecolor1 + "\">" + event1 + "</button>");
         out.println("&nbsp;&nbsp;&nbsp;&nbsp;");

         if (!event2.equals( "" )) {

            out.println("<button type=\"button\" style=\"background:" + ecolor2 + "\">" + event2 + "</button>");
            out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
         }
      }

      if (!rest1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + rcolor1 + "\">" + rest1 + "</button>");

         if (!rest2.equals( "" )) {

            out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
            out.println("<button type=\"button\" style=\"background:" + rcolor2 + "\">" + rest2 + "</button>");

            if (!rest3.equals( "" )) {

               out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
               out.println("<button type=\"button\" style=\"background:" + rcolor3 + "\">" + rest3 + "</button>");

               if ((!rest4.equals( "" )) && (event1.equals( "" ))) {   // do 4 rest's if no events

                  out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                  out.println("<button type=\"button\" style=\"background:" + rcolor4 + "\">" + rest4 + "</button>");
               }
            }
         }
      }

      if (!lott1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + lcolor1 + "\">Lottery Times</button>");
         out.println("&nbsp;&nbsp;&nbsp;&nbsp;");

         if (!lott2.equals( "" )) {

            out.println("<button type=\"button\" style=\"background:" + lcolor2 + "\">Lottery Times</button>");
            out.println("&nbsp;&nbsp;&nbsp;&nbsp;");

            if (!lott3.equals( "" )) {

               out.println("<button type=\"button\" style=\"background:" + lcolor3 + "\">Lottery Times</button>");
               out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
            }
         }
      }

      if (!event1.equals( "" ) || !rest1.equals( "" ) || !lott1.equals( "" )) {
         out.println("<br>");
      }

      // *** these two lines came up from after tee sheet
      out.println("</td></tr>");
      out.println("</table>");                            // end of main page table

    
    out.println("<br>");
    out.println("<center>");
    out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" name=\"lform\" target=\"_top\">");
    out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");   // use current date
    out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
    out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
    
    out.println("Number of signups to show at a time: &nbsp;");
    out.println("<select name=limit size=1 onchange=\"document.getElementById('lform').submit()\">");
        out.println("<option>ALL");
        out.println("<option"+ ((limit == 5) ? " selected" : "") +">5");
        out.println("<option"+ ((limit == 10) ? " selected" : "") +">10");
        out.println("<option"+ ((limit == 20) ? " selected" : "") +">20");
    out.println("</select>");
    out.println("</form>");
    
    out.println("</center>");
    out.println("<br>");
    
    
    out.println("<br>");
/*    
    out.println("<font size=\"2\">");
    out.println("<b>Event Signup Legend</b>");
    out.println("</font><br><font size=\"1\">");
    out.println("<b>m/-:</b>&nbsp;&nbsp;&nbsp;&nbsp;c = Move to Tee Sheet,&nbsp;&nbsp;&nbsp;minus = Delete Request,&nbsp;&nbsp;&nbsp;");
    out.println("<b>Desired:</b> Desired Time,&nbsp;&nbsp;&nbsp;<b>Assigned:</b> System Assigned Time<br>");
    out.println("<b>Acceptable:</b> Range of Acceptable Times&nbsp;&nbsp;&nbsp;<b>W:</b> Weight");
    out.println("</font>");
*/
    out.println("</center>");
    
    // default location to jump to after converting
    out.println("<a name=\"jump777\"></a>"); 
    
    
    //****************************************************************************
    //
    // start html for display of event signups
    //
    //****************************************************************************
    //
      
    
    // IMAGE MARKER FOR POSITIONING
    out.println("<img src=\"/"+rev+"/images/shim.gif\" width=1 height=1 border=0 id=imgMarker name=imgMarker>");
    
    out.println("\n<!-- START OF EVENT REGISTRATION SHEET HEADER -->");
    out.println(""); //  width=" + total_col_width + " align=center
    out.println("<div id=\"elHContainer2\">");
/*    
    out.println("<span class=header style=\"left: " +lcol_start[1]+ "px; width: " +lcol_width[1]+ "px\">Submitted</span><span");
    if (course.equals( "-ALL-" )) {
        out.println(" class=header style=\"left: " +lcol_start[2]+ "px; width: " +lcol_width[2]+ "px\">Course</span><span ");
    }
*/    
    if (group_size > 1) {
    
        out.println("<span");
        out.println(" class=header style=\"left: " +lcol_start[1]+ "px; width: " +lcol_width[1]+ "px\">Player 1</span><span");
        out.println(" class=header style=\"left: " +lcol_start[2]+ "px; width: " +lcol_width[2]+ "px\">Player 2</span><span");
        out.println(" class=header style=\"left: " +lcol_start[3]+ "px; width: " +lcol_width[3]+ "px\">Player 3</span><span"); 
        out.println(" class=header style=\"left: " +lcol_start[4]+ "px; width: " +lcol_width[4]+ "px\">Player 4</span><span");
    
        if (fivesALL != 0) {
            out.println(" class=header style=\"left: " +lcol_start[5]+ "px; width: " +lcol_width[5]+ "px\">Player 5</span><span");
        }

        out.println(" class=header style=\"left: " +lcol_start[6]+ "px; width: " +lcol_width[6]+ "px\" id=widthMarker2>N</span>");
    
    } else {
        
        out.println("<span class=header style=\"left: " +lcol_start[1]+ "px; width: " +lcol_width[1]+ "px\" id=widthMarker2>Player</span>");
    }
    
    out.print("</div>\n");
    out.println("<!-- END OF EVENT REQ HEADER -->\n");
    
    
    out.println("\n<!-- START OF EVENT REQ SHEET BODY -->");
    out.println("<div id=\"elContainer2\">");
    
    errMsg = "Reading Event Signups";
    
    out.println("<!-- event_name=" + event_name + " -->");
    out.println("<!-- date=" + date + " -->");
    
    /*
    pstmt = con.prepareStatement ("" +
            "SELECT c.fives, e.* , DATE_FORMAT(e.r_date, '%b %D') AS d " +
            "FROM evntsup2b e, clubparm2 c " +
            "WHERE e.moved = 0 AND e.name = ? AND c.courseName = e.courseName " + 
            (course.equals("-ALL-") ? "" : " AND e.courseName = ? ") + " " +
            "ORDER BY r_date ASC, r_time ASC;");
    */
    
    pstmt = con.prepareStatement ("" +
            "SELECT *, DATE_FORMAT(r_date, '%b %D') AS d " +
            "FROM evntsup2b " +
            "WHERE moved = 0 AND name = ? AND player1 <> '' " + 
            (course.equals("-ALL-") ? "" : " AND courseName = ? ") + " " +
            "ORDER BY r_date ASC, r_time ASC" + 
            (limit > 0 ? " LIMIT " + limit : ";"));
    
    pstmt.clearParameters();
    pstmt.setString(1, event_name);
    //pstmt.setLong(2, date);
    if (!course.equals("-ALL-")) pstmt.setString(2, course);
    
    rs = pstmt.executeQuery();
    
    boolean tmp_found = false;
    boolean tmp_found2 = false;
    
    int event_id = 0;
    int nineHole = 0;
    int eighteenHole = 0;
    int friends = 0;
    int groups = 0;
    int max_players = 0;
    int sum_players = 0;
    int req_time = 0;
    int tmp_groups = 1;
    int dts_slot_index = 0; // slot index number
    int request_color = 10;
    int wait = 0;
    
    String fullName = "";
    String cw = "";
    String notes = "";
    String in_use_by = "";
    String time_color = "";
    String dts_defaultF3Color = "#FFFFFF"; // default
    String groupColor = "";
    boolean blnGroupColor = false;
    
    String drag = "drag=true ";
    String cursor = "";
    if (group_size > 1) {
        drag = "";
        cursor = "cursor: default; ";
    }
    
    while (rs.next()) {
        
        tmp_found = true;
        sum_players = 0;
        nineHole = 0;
        eighteenHole = 0;
        in_use_by = "";
        wait = 0;
        
        event_id = rs.getInt("id");
        courseName = rs.getString("courseName");
        player1 = rs.getString("player1");
        player2 = rs.getString("player2");
        player3 = rs.getString("player3");
        player4 = rs.getString("player4");
        player5 = rs.getString("player5");
        in_use = rs.getInt("in_use");
        wait = rs.getInt("wait");
        if (in_use == 1) in_use_by = rs.getString("in_use_by");
        
        int tmp_time = rs.getInt("r_time");
        int tmp_hr = tmp_time / 100;
        int tmp_min = tmp_time - (tmp_hr * 100);
        int tmp_date = rs.getInt("r_date");
        
        // only show this entry if there is a player in player1 position
        if (!player1.equals("")) {

            j++; // increment the jump label index (where to jump on page)

            // set tmp_i to the appropriate course color index
            if (course.equals( "-ALL-" )) { // only display this col if multi course club

                for (tmp_i = 0; tmp_i < courseCount; tmp_i++) {
                    if (courseName.equals(courseA[tmp_i])) break;
                }
            }

            bgcolor = "#FFFFFF";  // default
            if (wait != 0) bgcolor = "yellow";

            //
            // Start Row
            //
            out.print("<div id=event_slot_"+ dts_slot_index +" time=\"0\" course=\"" + rs.getString("courseName") + "\" startX=0 startY=0 eventId=\"" + rs.getInt("id") + "\" ");
            if (in_use == 0) {
                // not in use
                out.println("class=eventSlot drag=true style=\"background-color: "+ bgcolor +"\" bgc=\""+ bgcolor +"\">");
            } else {
                // in use
                out.println("class=timeSlotInUse>");
            }

    /*        
            //
            // Time Event Registration was Submitted
            //
            if (in_use == 0) {
                out.print(" <span id=event_slot_" + dts_slot_index + "_submitTime hollow=true class=cellData style=\"left: " + lcol_start[1] + "px; width: " + lcol_width[1] + "px; background-color: " +dts_defaultF3Color+ "\">");
            } else {
                out.print(" <span id=event_slot_" + dts_slot_index + "_submitTime class=cellData style=\"cursor: default; left: " + lcol_start[1] + "px; width: " + lcol_width[1] + "px; background-color: " +dts_defaultF3Color+ "\">");
            }
            out.print(rs.getString("d") + " " + SystemUtils.getSimpleTime(tmp_hr, tmp_min));
            out.print("</span>");


            //
            // Course
            //
            if (course.equals( "-ALL-" )) { // only display this col if multi course club

                out.print("<span id=event_slot_" + dts_slot_index + "_course class=cellDataC style=\"cursor: default; left: " + lcol_start[2] + "px; width: " + lcol_width[2] + "px; background-color:" + course_color + "\">");
                if (!rs.getString("courseName").equals("")) { out.print(fitName(rs.getString("courseName"))); }
                out.print("</span>");
            }
    */        

            //
            //  Add Player 1
            //
            out.print(" <span id=event_slot_" + dts_slot_index + "" + ((group_size > 1) ? "_player_1 " : "_player") + " hollow=true class=cellData " + drag + "startX="+lcol_start[1]+" playerSlot=1 style=\"" + cursor + "left: " + lcol_start[1] + "px; width: " + lcol_width[1] + "px\">");
            if (!player1.equals("")) { out.print(fitName(player1)); }
            out.println("</span>");


            if (group_size > 1) {

                //
                //  Add Player 2
                //
                out.print(" <span id=event_slot_" + dts_slot_index + "_player_2 class=cellData " + drag + "startX="+lcol_start[2]+" playerSlot=2 style=\"" + cursor + "left: " + lcol_start[2] + "px; width: " + lcol_width[2] + "px\">");
                if (!player2.equals("")) { out.print(fitName(player2)); }
                out.println(" </span>");


                //
                //  Add Player 3
                //
                out.print(" <span id=event_slot_" + dts_slot_index + "_player_3 class=cellData " + drag + "startX="+lcol_start[3]+" playerSlot=3 style=\"" + cursor + "left: " + lcol_start[3] + "px; width: " + lcol_width[3] + "px\">");
                if (!player3.equals("")) { out.print(fitName(player3)); }
                out.println("</span>");


                //
                //  Add Player 4
                //
                out.print(" <span id=event_slot_" + dts_slot_index + "_player_4 class=cellData " + drag + "startX="+lcol_start[4]+" playerSlot=4 style=\"" + cursor + "left: " + lcol_start[4] + "px; width: " + lcol_width[4] + "px\">");
                if (!player4.equals("")) { out.print(fitName(player4)); }
                out.println("</span>");


                //
                //  Add Player 5 if supported
                //
                if (fivesALL != 0) {        // if 5-somes on any course
                   if (fives != 0) {        // if 5-somes on this course

                     out.print(" <span id=event_slot_" + dts_slot_index + "_player_5 class=cellData " + drag + "startX="+lcol_start[5]+" playerSlot=5 style=\"" + cursor + "left: " + lcol_start[5] + "px; width: " + lcol_width[5] + "px\">");
                     if (!player5.equals("")) { out.print(fitName(player5)); }
                     out.println("</span>");

                   } else {       // 5-somes on at least 1 course, but not this one

                     out.print(" <span id=event_slot_" + dts_slot_index + "_player_5 class=cellData " + drag + "startX="+lcol_start[5]+" playerSlot=5 style=\"" + cursor + "left: " + lcol_start[5] + "px; width: " + lcol_width[5] + "px;  background-image: url('/v5/images/shade1.gif')\">");
                     out.println("</span>");

                   } // end if fives
                } // end if fivesALL

            } // end players 2-5


            //
            // Notes
            //
            out.print(" <span id=event_slot_" + dts_slot_index + "_notes class=cellDataC drag=false style=\"cursor: default; background-color: white; left: " + lcol_start[6] + "px; width: " + lcol_width[6] + "px\">");
            //out.print(notes);
            if (!rs.getString("notes").equals("")) out.println("<img src=\"/"+rev+"/images/notes.gif\" width=10 height=12 border=0 alt=\"" + rs.getString("notes") + "\">");
            out.println("</span>");

            dts_slot_index++;
            blnGroupColor = blnGroupColor == false;
            request_color++;

            // end row
            out.println("</div>"); 
        
        } // end if player1 empty
        
    } // end rs loop of event signups
    
    out.println("<!-- total_event_slots=" + dts_slot_index + " -->");
    
    out.println("</div>"); // end container
    out.println("\n<!-- END OF EVENT REQ SHEET BODY -->");
    out.println("<p>&nbsp;</p>");
    
    int total_event_slots = dts_slot_index;
    dts_slot_index = 0;
    in_use = 0;
    //
    // End display event signups
    //
    
    out.println("<div id=tblLegend style=\"position:absolute\"></div>");
    
/*    
    out.println("<div id=tblLegend style=\"position:absolute\"><p align=center><font size=\"2\">");
    out.println("<b>" + ((index < 0) ? "Old " : "") + "Tee Sheet Legend</b>");
    out.println("</font><br><font size=\"1\">");
    out.println("<b>F/B:</b>&nbsp;&nbsp;&nbsp;&nbsp;F = Front Nine,&nbsp;&nbsp;&nbsp;B = Back Nine,&nbsp;&nbsp;&nbsp;");
    out.println("O = Open (for cross-overs),&nbsp;&nbsp;&nbsp;S = Shotgun Event");
    out.println("</font></p></div>");
*/
    
    //****************************************************************************
    //
    // start html for tee sheet
    //
    //****************************************************************************
    //
    //  To change the position of the tee sheet (static position from top):
    //
    //   Edit file 'dts-styles.css'
    //                     "top" property for elHContainer (header for the main container)
    //                     "top" property for elContainer (main container that holds the tee sheet elements)
    //                     Increment both numbers equally!!!!!!!!!!!!
    //
    //****************************************************************************
    
    String tmpCW = "C/W";
    out.println("<br>");
    out.println("\n<!-- START OF TEE SHEET HEADER -->");
    out.println(""); //  width=" + total_col_width + " align=center
    out.println("<div id=\"elHContainer\">");
    out.println("<span class=header style=\"left: " +col_start[1]+ "px; width: " +col_width[1]+ "px\">+/-</span><span");
    out.println(" class=header style=\"left: " +col_start[2]+ "px; width: " +col_width[2]+ "px\">Time</span><span");
    if (course.equals( "-ALL-" )) {
       out.println(" class=header style=\"left: " +col_start[3]+ "px; width: " +col_width[3]+ "px\">Course</span><span ");
    }
    out.println(" class=header style=\"left: " +col_start[4]+ "px; width: " +col_width[4]+ "px\">F/B</span><span ");
    out.println(" class=header style=\"left: " +col_start[5]+ "px; width: " +col_width[5]+ "px\">Player 1</span><span ");
    out.println(" class=header style=\"left: " +col_start[6]+ "px; width: " +col_width[6]+ "px\">" +tmpCW+ "</span><span ");
    out.println(" class=header style=\"left: " +col_start[7]+ "px; width: " +col_width[7]+ "px\">Player 2</span><span ");
    out.println(" class=header style=\"left: " +col_start[8]+ "px; width: " +col_width[8]+ "px\">" +tmpCW+ "</span><span ");
    out.println(" class=header style=\"left: " +col_start[9]+ "px; width: " +col_width[9]+ "px\">Player 3</span><span ");
    out.println(" class=header style=\"left: " +col_start[10]+ "px; width: " +col_width[10]+ "px\">" +tmpCW+ "</span><span ");
    out.println(" class=header style=\"left: " +col_start[11]+ "px; width: " +col_width[11]+ "px\">Player 4</span><span ");
    out.print(" class=header style=\"left: " +col_start[12]+ "px; width: " +col_width[12]+ "px\"");
  
    if (fivesALL == 0)
    {
       out.print(" id=widthMarker>" +tmpCW+"</span>");
    } else {
       out.print(">" +tmpCW+ "</span><span \n class=header style=\"left: " +col_start[13]+ "px; width: " +col_width[13]+ "px\">Player 5</span><span ");
       out.print(" \n class=header style=\"left: " +col_start[14]+ "px; width: " +col_width[14]+ "px\" id=widthMarker>" +tmpCW+ "</span>");
    }
    
    out.print("</div>\n");
    out.println("<!-- END OF TEE SHEET HEADER -->\n");
    
    String first = "yes";
    
    errMsg = "Get tee times.";
    
    //
    //  Get the tee sheet for this date
    //
    String stringTee = "";
    
    stringTee = "SELECT * " + 
                "FROM teecurr2 " + 
                "WHERE date = ? " + 
                ((course.equals( "-ALL-" )) ? "" : "AND courseName = ? ") + 
                ((hideUnavail.equals("1")) ? "AND time >= ? AND time <= ? " : "") + 
                "ORDER BY time, courseName, fb";
    
    out.println("<!-- index=" + index + " -->");
    out.println("<!-- date=" + date + " -->");
    out.println("<!-- event_start_time=" + event_start_time + " -->");
    out.println("<!-- event_end_time=" + event_end_time + " -->");
    out.println("<!-- course=" + course + " -->");
    out.println("<!-- stringTee=" + stringTee + " -->");
    
    pstmt = con.prepareStatement (stringTee);
    
    int parm_index = 2;
    int teepast_id = 0;
    
    pstmt.clearParameters();
    pstmt.setLong(1, date);
    if (!course.equals( "-ALL-" )) {
        pstmt.setString(2, course);
        parm_index = 3;
    }
    
    if (hideUnavail.equals("1")) {
        pstmt.setInt(parm_index, event_start_time); 
        parm_index++;
        pstmt.setInt(parm_index, event_end_time);
    }
    
    rs = pstmt.executeQuery();
    
    out.println("\n<!-- START OF TEE SHEET BODY -->");
    out.println("<div id=\"elContainer\">\n");
    
    // loop thru each of the tee times
    while (rs.next()) {
    
        player1 = rs.getString("player1");
        player2 = rs.getString("player2");
        player3 = rs.getString("player3");
        player4 = rs.getString("player4");
        player5 = rs.getString("player5");
        p1cw = rs.getString("p1cw");
        p2cw = rs.getString("p2cw");
        p3cw = rs.getString("p3cw");
        p4cw = rs.getString("p4cw");
        p5cw = rs.getString("p5cw");
        p91 = rs.getInt("p91");
        p92 = rs.getInt("p92");
        p93 = rs.getInt("p93");
        p94 = rs.getInt("p94");
        p95 = rs.getInt("p95");
        time = rs.getInt("time");
        fb = rs.getShort("fb");
        courseT = rs.getString("courseName");
        
        teecurr_id = rs.getInt("teecurr_id");
        hr = rs.getInt("hr");
        min = rs.getInt("min");
        event = rs.getString("event");
        ecolor = rs.getString("event_color");
        rest = rs.getString("restriction");
        rcolor = rs.getString("rest_color");
        conf = rs.getString("conf");
        in_use = rs.getInt("in_use");
        type = rs.getInt("event_type");
        hole = rs.getString("hole");
        blocker = rs.getString("blocker");
        rest5 = rs.getString("rest5");
        bgcolor5 = rs.getString("rest5_color");
        lottery = rs.getString("lottery");
        lottery_color = rs.getString("lottery_color");


        //
        //  If course=ALL requested, then set 'fives' option according to this course
        //
        if (course.equals( "-ALL-" )) {
            i = 0;
            loopall:
            while (i < 20) {
               if (courseT.equals( courseA[i] )) {
                  fives = fivesA[i];          // get the 5-some option for this course
                  break loopall;              // exit loop
               }
               i++;
            }
        }

        boolean blnHide = false;

// REMOVED HIDING OF FULL TEE TIMES
/*
         if (hideUnavail.equals("1")) {
             if (fives == 0 || !rest5.equals("") ) {

                 if ( !player1.equals("") && !player2.equals("") && !player3.equals("") && !player4.equals("") ) blnHide = true;

             } else {

                 if ( !player1.equals("") && !player2.equals("") && !player3.equals("") && !player4.equals("")  && !player5.equals("")) blnHide = true;

             }
         }
*/
         // only show this slot if it is NOT blocked
         // and hide it if fives are disallowed and player1-4 full (all slots full already excluded in sql)
         if ( blocker.equals( "" ) && blnHide == false) {      // continue if tee time not blocked - else skip

            ampm = " AM";
            if (hr == 12) {
               ampm = " PM";
            }
            if (hr > 12) {
               ampm = " PM";
               hr = hr - 12;    // convert to conventional time
            }

            bgcolor = "#FFFFFF";               //default

            if (!event.equals("")) {
               bgcolor = ecolor;
            } else {

               if (!rest.equals("")) {
                  bgcolor = rcolor;
               } else {

                  if (!lottery_color.equals("")) {
                     bgcolor = lottery_color;
                  }
               }
            }

            if (bgcolor.equals("Default")) {
               bgcolor = "#FFFFFF";              //default
            }

            if (bgcolor5.equals("")) {
               bgcolor5 = bgcolor;               // player5 bgcolor = others if 5-somes not restricted
            }

            if (p91 == 1) {          // if 9 hole round
               p1cw = p1cw + "9";
            }
            if (p92 == 1) {
               p2cw = p2cw + "9";
            }
            if (p93 == 1) {
               p3cw = p3cw + "9";
            }
            if (p94 == 1) {
               p4cw = p4cw + "9";
            }
            if (p95 == 1) {
               p5cw = p5cw + "9";
            }

            if (player1.equals("")) {
               p1cw = "";
            }
            if (player2.equals("")) {
               p2cw = "";
            }
            if (player3.equals("")) {
               p3cw = "";
            }
            if (player4.equals("")) {
               p4cw = "";
            }
            if (player5.equals("")) {
               p5cw = "";
            }

            g1 = 0;     // init guest indicators
            g2 = 0;
            g3 = 0;
            g4 = 0;
            g5 = 0;

            //
            //  Check if any player names are guest names
            //
            if (!player1.equals( "" )) {

               i = 0;
               ploop1:
               while (i < parm.MAX_Guests) {
                  if (player1.startsWith( parm.guest[i] )) {

                     g1 = 1;       // indicate player1 is a guest name
                     break ploop1;
                  }
                  i++;
               }
            }
            if (!player2.equals( "" )) {

               i = 0;
               ploop2:
               while (i < parm.MAX_Guests) {
                  if (player2.startsWith( parm.guest[i] )) {

                     g2 = 1;       // indicate player2 is a guest name
                     break ploop2;
                  }
                  i++;
               }
            }
            if (!player3.equals( "" )) {

               i = 0;
               ploop3:
               while (i < parm.MAX_Guests) {
                  if (player3.startsWith( parm.guest[i] )) {

                     g3 = 1;       // indicate player3 is a guest name
                     break ploop3;
                  }
                  i++;
               }
            }
            if (!player4.equals( "" )) {

               i = 0;
               ploop4:
               while (i < parm.MAX_Guests) {
                  if (player4.startsWith( parm.guest[i] )) {

                     g4 = 1;       // indicate player4 is a guest name
                     break ploop4;
                  }
                  i++;
               }
            }
            if (!player5.equals( "" )) {

               i = 0;
               ploop5:
               while (i < parm.MAX_Guests) {
                  if (player5.startsWith( parm.guest[i] )) {

                     g5 = 1;       // indicate player5 is a guest name
                     break ploop5;
                  }
                  i++;
               }
            }

            //
            //  Process the F/B parm    0 = Front 9, 1 = Back 9, 9 = none (open for cross-over)
            //
            sfb = "F";       // default Front 9

            if (fb == 1) {

               sfb = "B";
            }

            if (fb == 9) {

               sfb = "O";
            }
            
            /*       *** Don't inticate shotguns!
            if (type == shotgun) {

               sfb = (!hole.equals("")) ? hole : "S";            // there's an event and its type is 'shotgun'
            }
            */
            
            // set default color for first three columns
            if (in_use != 0) dts_defaultF3Color = "";
      
            //
            //**********************************
            //  Build the tee time rows
            //**********************************
            //

            if (min < 10) {
               dts_tmp = hr + ":0" + min + ampm;
            } else {
               dts_tmp = hr + ":" + min + ampm;
            }

            out.print("<div id=time_slot_"+ dts_slot_index +" time=\"" + time + "\" course=\"" + courseT + "\" startX=0 startY=0 tid="+((teecurr_id == 0) ? teepast_id : teecurr_id)+" ");
            if (in_use == 0 && index >= 0) {
              // not in use
              out.println("class=timeSlot drag=true style=\"background-color: "+ bgcolor +"\" bgc=\""+ bgcolor +"\">");
            } else {
              // in use
              out.println("class=timeSlotInUse>");
            }


            // col for 'insert' and 'delete' requests
            out.print(" <span id=time_slot_" + dts_slot_index + "_A class=cellDataB style=\"cursor: default; left: " + col_start[1] + "px; width: " + col_width[1] + "px; background-color: #FFFFFF\">");
            j++;                                           // increment the jump label index (where to jump on page)
            out.print("<a name=\"jump" + j + "\"></a>");     // create a jump label for returns
           
            if (in_use == 0 && index >= 0) {
                
                // not in use 
                out.print("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +courseT+ "&returnCourse=" +course+ "&time=" +time+ "&fb=" +fb+ "&jump=" +j+ "&email=" +emailOpt+ "&first=" +first+ "&name=" + event_name + "&hide=" + hideUnavail + "&insert=yes\" title=\"Insert a time slot\" alt=\"Insert a time slot\">");
                out.print("<img src=/" +rev+ "/images/dts_newrow.gif width=13 height=13 border=0></a>");
                out.print("<img src=/" +rev+ "/images/shim.gif width=5 height=1 border=0>");
                out.print("<a href=\"/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +courseT+ "&returnCourse=" +course+ "&time=" +time+ "&fb=" +fb+ "&jump=" +j+ "&email=" +emailOpt+ "&name=" + event_name + "&hide=" + hideUnavail + "&delete=yes\" title=\"Delete time slot\" alt=\"Remove time slot\">");
                out.print("<img src=/" +rev+ "/images/dts_trash.gif width=13 height=13 border=0></a>");
            
            } else {
            
                // in use
                out.print("<img src=/" +rev+ "/images/busy.gif width=32 height=13 border=0 alt=\"Busy\" title=\"Busy\">");
            
            }
            out.println("</span>");

            // time column
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_time class=cellData hollow=true style=\"left: " + col_start[2] + "px; width: " + col_width[2] + "px; background-color: " +dts_defaultF3Color+ "\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_time class=cellData style=\"cursor: default; left: " + col_start[2] + "px; width: " + col_width[2] + "px; background-color: " +dts_defaultF3Color+ "\">");
            }
              if (min < 10) {
                 out.print(hr + ":0" + min + ampm);
              } else {
                 out.print(hr + ":" + min + ampm);
              }
            out.println("</span>");

            //
            //  Name of Course
            //
            if (course.equals( "-ALL-" )) { // only display this col if this tee sheet is showing more than one course
                
                for (tmp_i = 0; tmp_i < courseCount; tmp_i++) {
                    if (courseT.equals(courseA[tmp_i])) break;
                }
            
                out.print(" <span id=time_slot_" + dts_slot_index + "_course class=cellDataC style=\"cursor: default; left: " + col_start[3] + "px; width: " + col_width[3] + "px; background-color:" + course_color[tmp_i] + "\">");
                if (!courseT.equals("")) { out.print(fitName(courseT)); }
                out.println("</span>");
            }

            //
            //  Front/Back Indicator  (note:  do we want to display the FBO popup if it's a shotgun event)
            //
            if (in_use == 0 && hole.equals("") && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_FB class=cellData onclick=\"showFBO(this)\" value=\""+sfb+"\" style=\"cursor: hand; left: " + col_start[4] + "px; width: " + col_width[4] + "px\">"); //  background-color: " +dts_defaultF3Color+ "
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_FB class=cellDataB value=\""+sfb+"\" style=\"cursor: default; left: " + col_start[4] + "px; width: " + col_width[4] + "px\">");
            }
            out.print(sfb);
            out.println("</span>");


            //
            //  Add Player 1
            //
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_1 class=cellData drag=true startX="+col_start[5]+" playerSlot=1 style=\"left: " + col_start[5] + "px; width: " + col_width[5] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_1 class=cellData startX="+col_start[5]+" playerSlot=1 style=\"cursor: default; left: " + col_start[5] + "px; width: " + col_width[5] + "px\">");
            }
            if (!player1.equals("")) { out.print(fitName(player1)); }
            out.println("</span>");

            // Player 1 CW
            if ((!player1.equals("")) && (!player1.equalsIgnoreCase( "x" ))) {
               dts_tmp = p1cw;
            } else {
               dts_tmp = "";
            }
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_1_CW class=cellDataB onclick=\"showTOPopup(this)\" value=\"" + dts_tmp + "\" style=\"left: " + col_start[6] + "px; width: " + col_width[6] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_1_CW class=cellDataB style=\"cursor: default; left: " + col_start[6] + "px; width: " + col_width[6] + "px\">");
            }
            out.print(dts_tmp);
            out.println("</span>");


            //
            //  Add Player 2
            //
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_2 class=cellData drag=true startX="+col_start[7]+" playerSlot=2 style=\"left: " + col_start[7] + "px; width: " + col_width[7] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_2 class=cellData startX="+col_start[7]+" playerSlot=2 style=\"cursor: default; left: " + col_start[7] + "px; width: " + col_width[7] + "px\">");
            }
            if (!player2.equals("")) { out.print(fitName(player2)); }
            out.println(" </span>");

            // Player 2 CW
            if ((!player2.equals("")) && (!player2.equalsIgnoreCase( "x" ))) {
               dts_tmp = p2cw;
            } else {
               dts_tmp = "";
            }
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_2_CW class=cellDataB onclick=\"showTOPopup(this)\" value=\"" + dts_tmp + "\" style=\"left: " + col_start[8] + "px; width: " + col_width[8] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_2_CW class=cellDataB style=\"cursor: default; left: " + col_start[8] + "px; width: " + col_width[8] + "px\">");
            }
            out.print(dts_tmp);
            out.println("</span>");


            //
            //  Add Player 3
            //
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_3 class=cellData drag=true startX="+col_start[9]+" playerSlot=3 style=\"left: " + col_start[9] + "px; width: " + col_width[9] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_3 class=cellData startX="+col_start[9]+" playerSlot=3 style=\"cursor: default; left: " + col_start[9] + "px; width: " + col_width[9] + "px\">");
            }
            if (!player3.equals("")) { out.print(fitName(player3)); }
            out.println("</span>");

            // Player 3 CW
            if ((!player3.equals("")) && (!player3.equalsIgnoreCase( "x" ))) {
               dts_tmp = p3cw;
            } else {
               dts_tmp = "";
            }
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_3_CW class=cellDataB onclick=\"showTOPopup(this)\" value=\"" + dts_tmp + "\" style=\"left: " + col_start[10] + "px; width: " + col_width[10] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_3_CW class=cellDataB style=\"cursor: default; left: " + col_start[10] + "px; width: " + col_width[10] + "px\">");
            }
            out.print(dts_tmp);
            out.println("</span>");

            //
            //  Add Player 4
            //
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_4 class=cellData drag=true startX="+col_start[11]+" playerSlot=4 style=\"left: " + col_start[11] + "px; width: " + col_width[11] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_4 class=cellData startX="+col_start[11]+" playerSlot=4 style=\"cursor: default; left: " + col_start[11] + "px; width: " + col_width[11] + "px\">");
            }
            if (!player4.equals("")) { out.print(fitName(player4)); }
            out.println("</span>");

            // Player 4 CW
            if ((!player4.equals("")) && (!player4.equalsIgnoreCase( "x" ))) {
               dts_tmp = p4cw;
            } else {
               dts_tmp = "";
            }
            if (in_use == 0 && index >= 0) {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_4_CW class=cellDataB onclick=\"showTOPopup(this)\" value=\"" + dts_tmp + "\" style=\"left: " + col_start[12] + "px; width: " + col_width[12] + "px\">");
            } else {
              out.print(" <span id=time_slot_" + dts_slot_index + "_player_4_CW class=cellDataB style=\"cursor: default; left: " + col_start[12] + "px; width: " + col_width[12] + "px\">");
            }
            out.print(dts_tmp);
            out.println("</span>");

            //
            //  Add Player 5 if supported
            //
            if (fivesALL != 0) {        // if 5-somes on any course        (Paul - this is a new flag!!!!)
               if (fives != 0) {        // if 5-somes on this course
                 if (in_use == 0 && index >= 0) {
                   out.print(" <span id=time_slot_" + dts_slot_index + "_player_5 class=cellData drag=true startX="+col_start[13]+" playerSlot=5 style=\"left: " + col_start[13] + "px; width: " + col_width[13] + "px; background-color: " +bgcolor5+ "\">");
                 } else {
                   out.print(" <span id=time_slot_" + dts_slot_index + "_player_5 class=cellData startX="+col_start[13]+" playerSlot=5 style=\"cursor: default; left: " + col_start[13] + "px; width: " + col_width[13] + "px\">");
                 }
                 if (!player5.equals("")) { out.print(fitName(player5)); }
                 out.println("</span>");

                 // Player 5 CW
                 if ((!player5.equals("")) && (!player5.equalsIgnoreCase( "x" ))) {
                    dts_tmp = p5cw;
                 } else {
                    dts_tmp = "";
                 }
                 if (in_use == 0 && index >= 0) {
                   out.print(" <span id=time_slot_" + dts_slot_index + "_player_5_CW class=cellDataB onclick=\"showTOPopup(this)\" value=\"" + dts_tmp + "\" style=\"left: " + col_start[14] + "px; width: " + col_width[14] + "px; background-color: " +bgcolor5+ "\">");
                 } else {
                   out.print(" <span id=time_slot_" + dts_slot_index + "_player_5_CW class=cellDataB style=\"cursor: default; left: " + col_start[14] + "px; width: " + col_width[14] + "px\">");
                 }
                 out.print(dts_tmp);
                 out.println("</span>");

               } else {       // 5-somes on at least 1 course, but not this one

                 out.print(" <span id=time_slot_" + dts_slot_index + "_player_5 class=cellData startX="+col_start[13]+" playerSlot=5 style=\"cursor: default; left: " + col_start[13] + "px; width: " + col_width[13] + "px;  background-image: url('/v5/images/shade1.gif')\">");
                 out.println("</span>");

                 // Player 5 CW
                 dts_tmp = "";
                 out.print(" <span id=time_slot_" + dts_slot_index + "_player_5_CW class=cellDataB style=\"cursor: default; left: " + col_start[14] + "px; width: " + col_width[14] + "px; background-image: url('/v5/images/shade1.gif')\">");
                 out.print(dts_tmp);
                 out.println("</span>");

               } // end if fives
            } // end if fivesALL

            out.println("</div>"); // end timeslot container div

            dts_slot_index++;    // increment timeslot index counter
            first = "no";        // no longer first time displayed

         }  // end of IF Blocker that escapes building and displaying a particular tee time slot in the sheet

      }  // end of while

      out.println("<br>"); // spacer at bottom of tee sheet
      out.println("\n</div>"); // end main container div holding entire tee sheet
      out.println("<!-- END OF TEE SHEET BODY -->\n");
      out.println("<br><br>\n");

      pstmt.close();

    // write out form for posting tee sheet actions to the server for processing
    out.println("<form name=frmSendAction method=POST action=/" +rev+ "/servlet/Proshop_devnt>");
    out.println("<input type=hidden name=convert value=\"\">");
    out.println("<input type=hidden name=index value=\"" + index + "\">");
    out.println("<input type=hidden name=returnCourse value=\"" + course + "\">");
    out.println("<input type=hidden name=email value=\"" + emailOpt + "\">");
    out.println("<input type=hidden name=hide value=\"" + hideUnavail + "\">");
    
    out.println("<input type=hidden name=name value=\"" + event_name + "\">");
    out.println("<input type=hidden name=limit value=\"" + limit + "\">");
    out.println("<input type=hidden name=eventId value=\"\">");
    out.println("<input type=hidden name=group value=\"\">");
    
    out.println("<input type=hidden name=from_tid value=\"\">");
    out.println("<input type=hidden name=to_tid value=\"\">");
    
    out.println("<input type=hidden name=from_course value=\"\">");
    out.println("<input type=hidden name=to_course value=\"\">");
    
    out.println("<input type=hidden name=jump value=\"\">");                  // needs to be set in ....js !!!!!
    out.println("<input type=hidden name=from_time value=\"\">");
    out.println("<input type=hidden name=from_fb value=\"\">");
    out.println("<input type=hidden name=to_time value=\"\">");
    out.println("<input type=hidden name=to_fb value=\"\">");
    out.println("<input type=hidden name=from_player value=\"\">");
    out.println("<input type=hidden name=to_player value=\"\">");
    out.println("<input type=hidden name=to_from value=\"\">");
    out.println("<input type=hidden name=to_to value=\"\">");
    out.println("<input type=hidden name=changeAll value=\"\">");
    out.println("<input type=hidden name=ninehole value=\"\">");
    out.println("</form>");
    
    
    // START OF FBO POPUP WINDOW //
    out.println("<div id=elFBOPopup defaultValue=\"\" style=\"visibility: hidden\" jump=\"\">");
    out.println("<table width=100% height=100% border=0 cellpadding=0 cellspacing=2>");
    out.println("<form name=frmFBO>");
    out.println("<input type=hidden name=jump value=\"\">");
    out.println("<tr><td align=center class=smtext><b><u>Make Selection</u></b></td></tr>");
    out.println("<tr><td class=smtext><input type=radio value=F name=FBO id=FBO_1><label for=\"FBO_1\">Front</label></td></tr>");
    out.println("<tr><td class=smtext><input type=radio value=B name=FBO id=FBO_2><label for=\"FBO_2\">Back</label></td></tr>");
    out.println("<tr><td class=smtext><input type=radio value=O name=FBO id=FBO_3><label for=\"FBO_3\">Crossover</label></td></tr>");
    out.println("<tr><td align=right><a href=\"javascript: cancelFBOPopup()\" class=smtext>cancel</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href=\"javascript: saveFBOPopup()\" class=smtext>save</a>&nbsp;</td></tr>");
    out.println("</form>");
    out.println("</table>");
    out.println("</div>");


    // START OF TRANSPORTATION POPUP WINDOW //
    //
    //  Note:  There can now be up to 16 dynamic Modes of Transportation (proshop can config).
    //         Both the Full Name/Description and the Acronym are specified by the pro.
    //         These names and acronyms will not contain the '9' to indicate 9 holes.
    //         These values can be found in:
    //
    //               parmc.tmode[i]   =  full name description   
    //               parmc.tmodea[i]  =  1 to 3 character acronym  (i = index of 0 - 15)
    //
    //
    out.println("<div id=elTOPopup defaultValue=\"\" fb=\"\" nh=\"\" jump=\"\">");
    out.println("<table width=100% height=100% border=0 cellpadding=0 cellspacing=2>");
    out.println("<form name=frmTransOpt>");
    out.println("<input type=hidden name=jump value=\"\">");
    // loop thru the array and write out a table row for each option
  
    // set tmp_cols to the # of cols this table will have
    // if the # of trans opts is less then 4 then that's the #, otherwise the max is 4
    //   tmode_limit = max number of tmodes available
    //   tmode_count = actual number of tmodes specified for this course
    int tmp_cols = 0;
    if (parmc.tmode_count < 4) {
       tmp_cols = parmc.tmode_count;
    } else {
       tmp_cols = 4;
    }
    int tmp_count = 0;

    out.println("<tr><td align=center class=smtext colspan="+tmp_cols+"><b><u>Make Selection</u></b></td></tr>");

    out.println("<tr>");
    for (int tmp_loop = 0; tmp_loop < parmc.tmode_limit; tmp_loop++) {
      if (!parmc.tmodea[tmp_loop].equals( "" ) && !parmc.tmodea[tmp_loop].equals( null )) {
        out.println("<td nowrap class=smtext><input type=radio value="+parmc.tmodea[tmp_loop]+" name=to id=to_"+tmp_loop+"><label for=\"to_"+tmp_loop+"\">"+parmc.tmode[tmp_loop]+"</label></td>");
        if (tmp_count == 3 || tmp_count == 7 || tmp_count == 11) {
          out.println("</tr><tr>");         // new row
        }
        tmp_count++;
      }
    }
    out.println("</tr>");
  
    out.println("<tr><td bgcolor=black colspan="+tmp_cols+"><img src=/" +rev+ "/images/shim.gif width=100 height=1 border=0></td></tr>");
    out.println("<tr><td class=smtext colspan="+tmp_cols+"><input type=checkbox value=yes name=9hole id=nh><label for=\"nh\">9 Hole</label></td></tr>");
    out.println("<tr><td bgcolor=black colspan="+tmp_cols+"><img src=/" +rev+ "/images/shim.gif width=100 height=1 border=0></td></tr>");
    // "CHANGE ALL" DEFAULT OPTION COULD BE SET HERE
    out.println("<tr><td class=smtext colspan="+tmp_cols+"><input type=checkbox value=yes name=changeAll id=ca><label for=\"ca\">Change All</label></td></tr>");
    out.println("<tr><td align=right colspan="+tmp_cols+"><a href=\"javascript: cancelTOPopup()\" class=smtext>cancel</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href=\"javascript: saveTOPopup()\" class=smtext>save</a>&nbsp;</td></tr>");
    out.println("</form>");
    out.println("</table>");
    out.println("</div>");

    // FINAL JAVASCRIPT FOR THE PAGE, SET VARIABLES THAT WE DIDN'T KNOW TILL AFTER PROCESSING
    out.println("<script type=\"text/javascript\">");
    out.println("document.getElementById(\"elHContainer2\").style.zIndex = 0;");
    //out.println("/*if (document.getElementById(\"time_slot_0\")) {");
    //out.println(" slotHeight = document.getElementById(\"time_slot_0\").offsetHeight;");
    //out.println("} else if (document.getElementById(\"time_slot_0\")) {");
    //out.println(" slotHeight = document.getElementById(\"lottery_slot_0\").offsetHeight;");
    //out.println("}*/");
    out.println("var slotHeight = 20;");
    out.println("var g_markerY = document.getElementById(\"imgMarker\").offsetTop;");
    out.println("var g_markerX = document.getElementById(\"imgMarker\").offsetLeft;");
    out.println("var totalTimeSlots = " + (dts_slot_index) + ";");
    out.println("var totalEventSlots = " + (total_event_slots) + ";");
    out.println("var g_transOptTotal = " + tmp_count + ";");
    out.println("var g_pslot1s = " + col_start[5] + ";");
    out.println("var g_pslot1e = " + col_start[6] + ";");
    out.println("var g_pslot2s = " + col_start[7] + ";");
    out.println("var g_pslot2e = " + col_start[8] + ";");
    out.println("var g_pslot3s = " + col_start[9] + ";");
    out.println("var g_pslot3e = " + col_start[10] + ";");
    out.println("var g_pslot4s = " + col_start[11] + ";");
    out.println("var g_pslot4e = " + col_start[12] + ";");
    out.println("var g_pslot5s = " + col_start[13] + ";");
    out.println("var g_pslot5e = " + col_start[14] + ";");
  
    // SIZE UP THE CONTAINER ELEMENTS AND THE TIME SLOTS
    out.println("var e = document.getElementById('widthMarker');");
    out.println("var g_slotWidth = e.offsetLeft + e.offsetWidth;");
    out.println("var e2 = document.getElementById('widthMarker2');");
    out.println("var g_eventSlotWidth = e2.offsetLeft + e2.offsetWidth;");
    out.println("document.styleSheets[0].rules(0).style.width = (g_slotWidth + 2) + 'px';");            // elHContainer
    out.println("document.styleSheets[0].rules(1).style.width = (g_slotWidth + 2) + 'px';");            // elContainer
    out.println("document.styleSheets[0].rules(7).style.width = g_slotWidth + 'px';");                  // header 
    out.println("document.styleSheets[0].rules(8).style.width = g_slotWidth + 'px';");                  // timeslot
    out.println("document.styleSheets[0].rules(15).style.width = g_eventSlotWidth + 'px';");            // eventSlot
    out.println("document.styleSheets[0].rules(12).style.width = (g_eventSlotWidth + 2) + 'px';");      // elHContainer2
    out.println("document.styleSheets[0].rules(13).style.width = (g_eventSlotWidth + 2) + 'px';");      // elContainer2
        
    int tmp_offset1 = (total_event_slots == 0) ? 0 : (total_event_slots * 20) + 2;   // height of event container
    int tmp_offset2 = (dts_slot_index == 0) ? 0 : (dts_slot_index * 20) + 2;         // height of tee sheet container
    int tmp_offset3 = (total_event_slots == 0) ? 0 : 24; // 24 is height of header
    int tmp_offset4 = 24; // 24 is height of header
    int tmp_offset5 = (total_event_slots == 0) ? 40 : 80;
    
    // REPOSITION THE CONTAINERS TO THE MARKER
    out.println("document.getElementById(\"elHContainer2\").style.top=g_markerY;");
    out.println("document.getElementById(\"elHContainer2\").style.left=g_markerX;");
    out.println("document.getElementById(\"elContainer2\").style.top=g_markerY+22;");
    out.println("document.getElementById(\"elContainer2\").style.left=g_markerX;");
    
    if (total_event_slots == 0) {
        out.println("document.getElementById(\"elContainer2\").style.visibility = \"hidden\";");
        out.println("document.getElementById(\"elHContainer2\").style.visibility = \"hidden\";");
        out.println("document.getElementById(\"elContainer2\").style.height = \"0px\";");
        out.println("document.getElementById(\"elHContainer2\").style.height = \"0px\";");
    } else {
        // CALL THE POSITIONING CODE FOR EACH OF EVENT SLOTS WE CREATED
        out.println("for(x=0;x<=totalEventSlots-1;x++) eval(\"positionElem('event_slot_\" + x + \"', \"+ x +\")\");");
        out.println("document.getElementById(\"elContainer2\").style.height=\"" + tmp_offset1 + "px\";");
    }
    
    // POSITION THE LEGENDS
    out.println("document.getElementById(\"tblLegend\").style.top=g_markerY + " + (tmp_offset1 + (tmp_offset3 * 2)) + ";");
    out.println("document.getElementById(\"tblLegend\").style.width=g_slotWidth;");
    //out.println("document.getElementById(\"tblLottLegend\").style.top=g_markerY;");
    //out.println("document.getElementById(\"tblLottLegend\").style.width=g_slotWidth;");
    
    // POSITION THE TEE SHEET CONTAINER
    out.println("document.getElementById(\"elContainer\").style.top=(g_markerY + " + (tmp_offset1 + tmp_offset4 + tmp_offset5) + ");");
    out.println("document.getElementById(\"elHContainer\").style.top=(g_markerY + " + (tmp_offset1 + tmp_offset5) + ");");
    
    if (dts_slot_index == 0) {
        out.println("document.getElementById(\"elContainer\").style.visibility = \"hidden\";");
    } else {
        // CALL THE POSITIONING CODE FOR EACH OF THE TIME SLOTS WE CREATED
        out.println("for(x=0;x<=totalTimeSlots-1;x++) eval(\"positionElem('time_slot_\" + x + \"', \"+ x +\")\");");
        out.println("document.getElementById(\"elContainer\").style.height=\"" + tmp_offset2 + "px\";");
    }
    out.println("</script>");
    
    out.println("<script type=\"text/javascript\">");
    out.println("function checkCourse() {");
    out.println(" var f = document.getElementById(\"frmSendAction\").returnCourse;");
    out.println(" if (f.value == \"-ALL-\") {");
    out.println("  alert(\"You must select a specific course before going back.\\nYou are currently viewing ALL courses for this day.\");");
    out.println("  return false;");
    out.println(" }");
    out.println(" return true;");
    out.println("}");
/*    
    out.println("function convert(event_id) {");
    out.println(" f = document.getElementById('frmSendAction');");
    out.println(" f.eventId.value = event_id;");
    out.println(" f.convert.value = 'auto';");
    out.println(" f.submit();");
    out.println("}");
*/    
    out.println("</script>");
    // END OF OUT FINAL CLIENT SIDE SCRIPT WRITING
    
    }
    catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<center><BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>Location = " +errMsg);
      out.println("<BR><BR>Error = " +e1.toString());
      out.println("<BR><BR>Exception = " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</center></BODY></HTML>");
      out.close();
      return;
   }

   //
   //  End of HTML page
   //
   out.println("<p>&nbsp;</p>");
   out.println("</body>\n</html>");
   out.close();

 }   // end of doGet


 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

     
   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   HttpSession session = SystemUtils.verifyPro(req, out);           // check for intruder
   if (session == null) return;
   
   Connection con = SystemUtils.getCon(session);                    // get DB connection
   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   
   //
   // Handle the conversion of event signups to teecurr2 entries
   //
   if (req.getParameter("convert") != null && req.getParameter("convert").equals("yes")) {
       
       convert(req, out, con, session, resp);
       return;
   }
   
   
   //
   //  parm block to hold the tee time parms
   //
   parmSlot slotParms = new parmSlot();          // allocate a parm block

   String changeAll = "";
   String ninehole = "";
   String dts_tmp = "";
   String prompt = "";
     
   int skip = 0;

   long date = 0;

   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

   //
   //  Get this session's username (to be saved in teecurr)
   //
   slotParms.user = (String)session.getAttribute("user");
   slotParms.club = (String)session.getAttribute("club");

try {
    
   //
   //  Get the parms passed
   //
   slotParms.jump = req.getParameter("jump");           // anchor link for page loading
   String indexs = req.getParameter("index");           // # of days ahead of current day
   slotParms.ind = Integer.parseInt(indexs);            // save index value in parm block
   String event_name = req.getParameter("name");        // event name
   slotParms.event = event_name;
   
   //
   //  Get the optional parms
   //
   if (req.getParameter("email") != null) {

      slotParms.sendEmail = req.getParameter("email");
   } else {
      slotParms.sendEmail = "yes";
   }

   if (req.getParameter("returnCourse") != null) {

      slotParms.returnCourse = req.getParameter("returnCourse");
   } else {
      slotParms.returnCourse = "";
   }

   if (req.getParameter("from_course") != null) {

      slotParms.from_course = req.getParameter("from_course");
   } else {
      slotParms.from_course = "";
   }

   if (req.getParameter("to_course") != null) {

      slotParms.to_course = req.getParameter("to_course");
   } else {
      slotParms.to_course = "";
   }

   if (req.getParameter("from_player") != null) {
     
      dts_tmp = req.getParameter("from_player");
        
      if (!dts_tmp.equals( "" )) {
         slotParms.from_player = Integer.parseInt(dts_tmp);
      }
   }
   if (req.getParameter("to_player") != null) {

      dts_tmp = req.getParameter("to_player");

      if (!dts_tmp.equals( "" )) {
         slotParms.to_player = Integer.parseInt(dts_tmp);
      }
   }
   if (req.getParameter("from_time") != null) {

      dts_tmp = req.getParameter("from_time");

      if (!dts_tmp.equals( "" )) {
         slotParms.from_time = Integer.parseInt(dts_tmp);
      }
   }
   if (req.getParameter("to_time") != null) {

      dts_tmp = req.getParameter("to_time");

      if (!dts_tmp.equals( "" )) {
         slotParms.to_time = Integer.parseInt(dts_tmp);
      }
   }
   if (req.getParameter("to_from") != null) {

      slotParms.to_from = req.getParameter("to_from");
   }
   if (req.getParameter("to_to") != null) {

      slotParms.to_to = req.getParameter("to_to");
   }
   if (req.getParameter("changeAll") != null) {

      changeAll = req.getParameter("changeAll");
   }
   if (req.getParameter("ninehole") != null) {

      ninehole = req.getParameter("ninehole");
   }
     
   if (req.getParameter("prompt") != null) {        // if 2nd entry (return from prompt)

      prompt = req.getParameter("prompt");
        
      dts_tmp = req.getParameter("date");

      if (!dts_tmp.equals( "" )) {
         date = Integer.parseInt(dts_tmp);
      }
        
      dts_tmp = req.getParameter("to_fb");

      if (!dts_tmp.equals( "" )) {
         slotParms.to_fb = Integer.parseInt(dts_tmp);
      }

      dts_tmp = req.getParameter("from_fb");

      if (!dts_tmp.equals( "" )) {
         slotParms.from_fb = Integer.parseInt(dts_tmp);
      }

      if (req.getParameter("skip") != null) {        // if 2nd entry and skip returned

         dts_tmp = req.getParameter("skip");

         if (!dts_tmp.equals( "" )) {
            skip = Integer.parseInt(dts_tmp);
         }
      }

   } else {
     
      if (req.getParameter("from_fb") != null) {

         dts_tmp = req.getParameter("from_fb");

         slotParms.from_fb = 0;

         if (dts_tmp.equals( "B" )) {

            slotParms.from_fb = 1;
         }
         if (dts_tmp.equals( "O" )) {

            slotParms.from_fb = 9;
         }
      }
      if (req.getParameter("to_fb") != null) {

         dts_tmp = req.getParameter("to_fb");

         slotParms.to_fb = 0;

         if (dts_tmp.equals( "B" )) {

            slotParms.to_fb = 1;
         }
         if (dts_tmp.equals( "O" )) {

            slotParms.to_fb = 9;
         }
      }
   }

 } catch (Exception e) {
     out.println("Error parsing input variables. " + e.toString());
 }
   if (date == 0) {
      //
      //  Get today's date and then use the value passed to locate the requested date
      //
      Calendar cal = new GregorianCalendar();       // get todays date

      if (slotParms.ind > 0) {
         cal.add(Calendar.DATE,slotParms.ind);         // roll ahead 'index' days
      }

      int year = cal.get(Calendar.YEAR);
      int month = cal.get(Calendar.MONTH);
      int day = cal.get(Calendar.DAY_OF_MONTH);
      int day_num = cal.get(Calendar.DAY_OF_WEEK);      // day of week (01 - 07)

      month = month + 1;                            // month starts at zero

      slotParms.dd = day;         
      slotParms.mm = month;
      slotParms.yy = year;
      slotParms.day = day_table[day_num];                // get name for day

      date = (year * 10000) + (month * 100) + day;  // create a date field of yyyymmdd
        
   } else {

      if (req.getParameter("day") != null) {

         slotParms.day = req.getParameter("day");
      }

      long lyy = date / 10000;                               // get year
      long lmm = (date - (lyy * 10000)) / 100;               // get month
      long ldd = (date - (lyy * 10000)) - (lmm * 100);       // get day

      slotParms.dd = (int)ldd;
      slotParms.mm = (int)lmm;
      slotParms.yy = (int)lyy;
   }

   //
   //  determine the type of call: Change F/B, Change C/W, Single Player Move, Whole Tee Time Move
   //
   if (!slotParms.to_from.equals( "" ) && !slotParms.to_to.equals( "" )) {

      changeCW(slotParms, changeAll, ninehole, date, req, out, con, resp);     // process Change C/W
      return;
   }

   if (slotParms.to_time == 0) {  // if not C/W and no 'to_time' specified

      changeFB(slotParms, date, req, out, con, resp);              // process Change F/B
      return;
   }

   if ((slotParms.to_player == 0) && (slotParms.from_player == 0)) {

      moveWhole(slotParms, date, prompt, skip, req, out, con, resp);  // process Move Whole Tee Time
      return;
   }

   if (slotParms.from_player > 0 && slotParms.to_player > 0) {

      moveSingle(slotParms, date, prompt, skip, req, out, con, resp);  // process Move Single Tee Time
      return;
   }
  
   //
   //  If we get here, there is an error
   //
   out.println(SystemUtils.HeadTitle("Error in Proshop_devnt"));
   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
   out.println("<CENTER><BR><BR><H2>Error While Editing Tee Sheet</H2>");
   out.println("<BR><BR>An error has occurred that prevents the system from completing the task.<BR>");
   out.println("<BR>Please try again.  If problem continues, contact ForeTees.");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<a href=\"/" +rev+ "/servlet/Proshop_jump?index=" +slotParms.ind+ "&course=" +slotParms.returnCourse+ "\">");
   out.println("Return to Tee Sheet</a></font>");
   out.println("</CENTER></BODY></HTML>");
   out.close();
   
 }  // end of doPost

 
 //
 // returns the player name but enforces a max length for staying in the width allowed
 // change the two positive values to control the output
 //
 private static String fitName(String pName) {
     
   return (pName.length() > 16) ? pName.substring(0, 15) + "..." : pName;
 }

 
 private static String getTime(int time) {

    try {
        
        String ampm = "AM";
        int hr = time / 100;
        int min = time % (hr * 100);

        if (hr == 12) {
            ampm = "PM";
        } else if (hr > 12) {
            hr -= 12;
            ampm = "PM";
        }

        return hr + ":" + SystemUtils.ensureDoubleDigit(min) + " " + ampm;
        
    } catch (Exception ignore) {
        return "N/A";
    }
    
 }
 
 
 private void convert(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session, HttpServletResponse resp) {
     
    Statement stmt = null;
    ResultSet rs = null;

    //
    //  Get this session's attributes
    //
    String user = "";
    String club = "";
    user = (String)session.getAttribute("user");
    club = (String)session.getAttribute("club");

    int index = 0;
    int fives = 0;      // for tee time we are dragging to
    int count = 0;
    int event_id = 0;
    int teecurr_id = 0;
    boolean overRideFives = false;
    String blocker = "";

    String hideUnavail = req.getParameter("hide");
    if (hideUnavail == null) hideUnavail = "";
    String sindex = req.getParameter("index");          //  day index value (needed by _sheet on return)
    String returnCourse = req.getParameter("returnCourse");        //  name of course to return to (multi)
    String suppressEmails = "no";
    
    String slid = "";
    String stid = "";
    String sgroup = "";
    String limit = "";
    if (req.getParameter("to_tid") != null) stid = req.getParameter("to_tid");
    if (req.getParameter("eventId") != null) slid = req.getParameter("eventId");
    if (req.getParameter("group") != null) sgroup = req.getParameter("group");
    if (req.getParameter("limit") != null) limit = req.getParameter("limit");
    
    String convert = req.getParameter("convert");
    if (convert == null) convert = "";
    
    String event_name = req.getParameter("name");
    if (event_name == null) event_name = "";
    
    if (req.getParameter("overRideFives") != null && req.getParameter("overRideFives").equals("yes")) {
        overRideFives = true;
    }
    
    if (req.getParameter("suppressEmails") != null) {             // if email parm exists
        suppressEmails = req.getParameter("suppressEmails");
    }
    
    //
    //  parm block to hold the tee time parms
    //
    parmSlot slotParms = new parmSlot();          // allocate a parm block
    
    //
    //  Convert the values from string to int
    //
    try {

        event_id = Integer.parseInt(slid);
        teecurr_id = Integer.parseInt(stid);
        index = Integer.parseInt(sindex);
    }
    catch (NumberFormatException exp) {
        SystemUtils.buildDatabaseErrMsg(exp.toString(), "Input variables", out, false); 
        return;
    }
    
    //
    // Get fives value for this course (from teecurr_id)
    //
    int group_size = 0;
    int p9 = 0;
    
    try {

        PreparedStatement pstmtc = con.prepareStatement (
            "SELECT fives, " +
            "(SELECT size FROM events2b WHERE name = ?) AS group_size, " + 
            "(SELECT holes FROM events2b WHERE name = ?) AS holes " + 
            "FROM clubparm2 c, teecurr2 t " + 
            "WHERE c.courseName = t.courseName AND t.teecurr_id = ?");

        pstmtc.clearParameters();
        pstmtc.setString(1, event_name);
        pstmtc.setString(2, event_name);
        pstmtc.setInt(3, teecurr_id);
        rs = pstmtc.executeQuery();

        if (rs.next()) {
            fives = rs.getInt("fives");
            group_size = rs.getInt("group_size");
            p9 = (rs.getInt("holes") == 18) ? 0 : 1;
        }

        pstmtc.close();
    }
    catch (Exception e) {
        SystemUtils.buildDatabaseErrMsg(e.toString(), e.getMessage(), out, false); 
        return;
    }
        
    if (overRideFives) fives = 1;
    
    slotParms.ind = index;                      // index value
    slotParms.club = club;                      // name of club
    slotParms.returnCourse = returnCourse;      // name of course for return to _sheet
    slotParms.suppressEmails = suppressEmails;
    
    //
    //  Load parameter object
    //
    try {

        PreparedStatement pstmt = con.prepareStatement("SELECT * FROM teecurr2 WHERE teecurr_id = ?");
        pstmt.clearParameters();
        pstmt.setInt(1, teecurr_id);
        rs = pstmt.executeQuery();

        if (rs.next()) {

            slotParms.player1 = rs.getString("player1");
            slotParms.player2 = rs.getString("player2");
            slotParms.player3 = rs.getString("player3");
            slotParms.player4 = rs.getString("player4");
            slotParms.player5 = rs.getString("player5");
            slotParms.user1 = rs.getString("username1");
            slotParms.user2 = rs.getString("username2");
            slotParms.user3 = rs.getString("username3");
            slotParms.user4 = rs.getString("username4");
            slotParms.user5 = rs.getString("username5");
            slotParms.p1cw = rs.getString("p1cw");
            slotParms.p2cw = rs.getString("p2cw");
            slotParms.p3cw = rs.getString("p3cw");
            slotParms.p4cw = rs.getString("p4cw");
            slotParms.p5cw = rs.getString("p5cw");
            slotParms.p91 = rs.getInt("p91");
            slotParms.p92 = rs.getInt("p92");
            slotParms.p93 = rs.getInt("p93");
            slotParms.p94 = rs.getInt("p94");
            slotParms.p95 = rs.getInt("p95");
            slotParms.in_use = rs.getInt("in_use");
            slotParms.in_use_by = rs.getString("in_use_by");
            slotParms.userg1 = rs.getString("userg1");
            slotParms.userg2 = rs.getString("userg2");
            slotParms.userg3 = rs.getString("userg3");
            slotParms.userg4 = rs.getString("userg4");
            slotParms.userg5 = rs.getString("userg5");
            slotParms.orig_by = rs.getString("orig_by");
            slotParms.pos1 = rs.getShort("pos1");
            slotParms.pos2 = rs.getShort("pos2");
            slotParms.pos3 = rs.getShort("pos3");
            slotParms.pos4 = rs.getShort("pos4");
            slotParms.pos5 = rs.getShort("pos5");
            slotParms.rest5 = rs.getString("rest5");
            
            blocker = rs.getString("blocker");
            
        }
        out.println("<!-- DONE LOADING slotParms WITH teecurr2 DATA -->");
        pstmt.close();

    }
    catch (Exception e) {

        out.println("<p>Error: "+e.toString()+"</p>");
    }

    // make sure there are enough open player slots
    int max_group_size = (fives == 0 || slotParms.p5.equalsIgnoreCase("No")) ? 4 : 5;
    int open_slots = 0;
    boolean has_players = false;
    if (slotParms.player1.equals("")) { open_slots++; } else { has_players = true; }
    if (slotParms.player2.equals("")) open_slots++;
    if (slotParms.player3.equals("")) open_slots++;
    if (slotParms.player4.equals("")) open_slots++;
    if (slotParms.player5.equals("") && slotParms.rest5.equals("") && fives == 1 && slotParms.p5.equalsIgnoreCase("Yes")) open_slots++;
    
    if (slotParms.orig_by.equals( "" )) {    // if originator field still empty (allow this person to grab this tee time again)
    
        slotParms.orig_by = user;             // set this user as the originator
    }
  
    out.println("<!-- open_slots="+open_slots+" | has_players="+has_players+" -->");
    
    //
    // Check in-use indicators
    //
    if (slotParms.in_use == 1 && !slotParms.in_use_by.equalsIgnoreCase( user )) {    // if time slot in use and not by this user
    
        out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
        out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
        out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
        out.println("<CENTER><BR><BR><H1>Reservation Timer Expired</H1>");
        out.println("<BR><BR>Sorry, but this tee time slot has been returned to the system!<BR>");
        out.println("<BR>The system timed out and released the tee time.");
        out.println("<BR><BR>");

        out.println("<font size=\"2\">");
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
        out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
        out.println("<input type=\"hidden\" name=\"index\" value=" + index + ">");
        if (!returnCourse.equals( "" )) {    // if multi course club, get course to return to (ALL?)
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
        } else {
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.course + "\">");
        }
        out.println("</form></font>");
            
        out.println("</CENTER></BODY></HTML>");
        out.close();
        return;
    }
    
    //
    // Check blocker indicator
    //
    if (!blocker.equals("")) {    // if time slot is blocked
    
        out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
        out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
        out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
        out.println("<CENTER><BR><BR><H1>Tee Time Blocked</H1>");
        out.println("<BR><BR>Sorry, but this tee time slot you've selected is blocked.<BR>");
        out.println("<BR>Please choose a different time or unblock the desired time.");
        out.println("<BR><BR>");

        out.println("<font size=\"2\">");
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
        out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
        out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
        out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
        out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
        out.println("<input type=\"submit\" value=\"Try Again\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
        out.println("</form></font>");
            
        out.println("</CENTER></BODY></HTML>");
        out.close();
        return;
    }
    
    boolean teeTimeFull = false;
    boolean allowFives = (fives == 1) ? true : false; // does the course we are dragging to allow 5-somes?
    
    String notes = "";
    int hideNotes = 0;
    
    String fields = "";
    String player1 = "";
    String player2 = "";
    String player3 = "";
    String player4 = "";
    String player5 = "";
    String p1cw = "";
    String p2cw = "";
    String p3cw = "";
    String p4cw = "";
    String p5cw = "";
    String user1 = "";
    String user2 = "";
    String user3 = "";
    String user4 = "";
    String user5 = "";
    String userg1 = "";
    String userg2 = "";
    String userg3 = "";
    String userg4 = "";
    String userg5 = "";
    String memNum1 = "";
    String memNum2 = "";
    String memNum3 = "";
    String memNum4 = "";
    String memNum5 = "";
    
    int group_players = 0; // # of players added to a group
    int tmp_added = 0;
    int players = 0;
    
    //
    // Load Event Signup data
    //
    try {
        
        PreparedStatement pstmt = con.prepareStatement ("" +
                "SELECT e.*, " +
                "IF(player1 = '', 0, IF(player2 = '', 1, IF(player3 = '', 2, IF(player4 = '', 3, IF(player5 = '', 4, 5))))) AS players " +
                "FROM evntsup2b e " +
                "WHERE name = ? AND id = ?;");
        
        pstmt.clearParameters();
        pstmt.setString(1, event_name);
        pstmt.setInt(2, event_id);
        
        rs = pstmt.executeQuery();
        
        if ( rs.next() ) {
            
            players = rs.getInt("players");
            notes = rs.getString("notes");
            hideNotes = rs.getInt("hideNotes");
            
            // if orig_by wasn't set from teecurr2 (it was if the teetime already had players)
            //if (slotParms.orig_by.equals("")) slotParms.orig_by = rs.getString("orig_by");
            
            player1 = rs.getString("player1");
            player2 = rs.getString("player2");
            player3 = rs.getString("player3");
            player4 = rs.getString("player4");
            player5 = rs.getString("player5");
            
            user1 = rs.getString("username1");
            user2 = rs.getString("username2");
            user3 = rs.getString("username3");
            user4 = rs.getString("username4");
            user5 = rs.getString("username5");
            
            p1cw = rs.getString("p1cw");
            p2cw = rs.getString("p2cw");
            p3cw = rs.getString("p3cw");
            p4cw = rs.getString("p4cw");
            p5cw = rs.getString("p5cw");
            
            userg1 = rs.getString("userg1");
            userg2 = rs.getString("userg2");
            userg3 = rs.getString("userg3");
            userg4 = rs.getString("userg4");
            userg5 = rs.getString("userg5");
            
        }
        
        if (players > open_slots) {
            
            out.println(SystemUtils.HeadTitle("Not Enough Open Player Slots"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
            out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<CENTER><BR><BR><H1>Not Enough Open Player Positions</H1>");
            out.println("<BR><BR>Sorry, but this tee time slot you've selected does not have enough open positions<BR>");
            out.println("<BR>for the event signup you tried to move.  You tried to move " +players+" on to a tee time with only " + open_slots + " open player positions available.");
            out.println("<BR>Please choose another tee time and try again.");
            out.println("<BR><BR>");

            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            if (!returnCourse.equals( "" )) {    // if multi course club, get course to return to (ALL?)
                out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
            } else {
                out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.course + "\">");
            }
            out.println("</form></font>");

            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
            
        }
        
        if (!player1.equals("")) {
            group_players++;
            memNum1 = getMemberNumber(user1, con);
            teeTimeFull = addPlayer(slotParms, player1, user1, memNum1, p1cw, p9, allowFives);
            if (!teeTimeFull) { tmp_added++; }
        }
        
        if (!player2.equals("")) {
            group_players++;
            memNum2 = getMemberNumber(user2, con);
            teeTimeFull = addPlayer(slotParms, player2, user2, memNum2, p2cw, p9, allowFives);
            if (!teeTimeFull) { tmp_added++; }
        }
        
        if (!player3.equals("")) {
            group_players++;
            memNum3 = getMemberNumber(user3, con);
            teeTimeFull = addPlayer(slotParms, player3, user3, memNum3, p3cw, p9, allowFives);
            if (!teeTimeFull) { tmp_added++; }
        }
        
        if (!player4.equals("")) {
            group_players++;
            memNum4 = getMemberNumber(user4, con);
            teeTimeFull = addPlayer(slotParms, player4, user4, memNum4, p4cw, p9, allowFives);
            if (!teeTimeFull) { tmp_added++; }
        }
        
        if (!player5.equals("") && allowFives && group_size == 5) {
            group_players++;
            memNum5 = getMemberNumber(user5, con);
            teeTimeFull = addPlayer(slotParms, player5, user5, memNum5, p5cw, p9, allowFives);
            if (!teeTimeFull) { tmp_added++; }
        }
        
    } catch(Exception exp) {
        SystemUtils.buildDatabaseErrMsg(exp.toString(), "LOAD DATA", out, false);
        //return;
    }
    
    
    // debug
    out.println("<!-- max_group_size=" + max_group_size + " -->");
    out.println("<!-- group_size=" + group_size + " | group_players=" + group_players + " -->");
    out.println("<!-- event_id="+event_id+" | teecurr_id="+teecurr_id+" | tmp_added="+tmp_added+" -->");
    out.println("<!-- teeTimeFull=" + teeTimeFull + " -->");
    out.println("<!-- allowFives=" + allowFives + " -->");
    
    // Let see if all players from this request where moved
    if ( teeTimeFull || tmp_added == 0 ) {
    
        out.println(SystemUtils.HeadTitle("Unable to Add All Players"));
        out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
        out.println("<hr width=\"40%\">");
        out.println("<BR><BR><H3>Unable to Add All Players</H3><BR>");
        out.println("<BR>Sorry we were not able to add all the players to this tee time.<br><br>");
        out.println("<BR><BR>No changes were made to the event signup or tee sheet.");
        out.println("<BR><BR>");
       
        out.println("<font size=\"2\">");
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
        out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
        out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
        out.println("<input type=\"submit\" value=\"Try Again\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
        out.println("</form></font>");
        
        out.println("</CENTER></BODY></HTML>");
        out.close();
        return;
    }
    
    
    // first lets see if they are trying to fill the 5th player slot when it is unavailable for this course
    if ( !slotParms.player5.equals("") && fives == 0 ) { // ( (!slotParms.rest5.equals("") && overRideFives == false) || fives == 0)
    
        out.println(SystemUtils.HeadTitle("5-some Restricted - Reject"));
        out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
        out.println("<hr width=\"40%\">");
        out.println("<BR><BR><H3>Member Restricted</H3><BR>");
        out.println("<BR>Sorry, <b>5-somes</b> are not allowed on this course.<br><br>");
        out.println("<BR><BR>Please move the event signup to another course.");
        out.println("<BR><BR>");
       
        out.println("<font size=\"2\">");
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
        out.println("<input type=\"submit\" value=\"Try Again\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
        out.println("</form></font>");
        
        /*
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_dlott\" method=\"post\" target=\"_top\">");
        out.println("<input type=\"hidden\" name=\"convert\" value=\"yes\">");
        out.println("<input type=\"hidden\" name=\"overRideFives\" value=\"yes\">");
        out.println("<input type=\"hidden\" name=\"lotteryId\" value=\"" + lottery_id + "\">");
        out.println("<input type=\"hidden\" name=\"to_tid\" value=\"" + teecurr_id + "\">");
        out.println("<input type=\"hidden\" name=\"group\" value=\"" + group + "\">");
        out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
        */
        
        out.println("</CENTER></BODY></HTML>");
        out.close();
        return;
        
    } // end 5-some rejection
    
    
    //
    // Update entry in teecurr2
    //
    try {

        PreparedStatement pstmt6 = con.prepareStatement (
             "UPDATE teecurr2 SET player1 = ?, player2 = ?, player3 = ?, player4 = ?, " +
             "username1 = ?, username2 = ?, username3 = ?, username4 = ?, p1cw = ?, " +
             "p2cw = ?, p3cw = ?, p4cw = ?,  in_use = 0, hndcp1 = ?, hndcp2 = ?, hndcp3 = ?, " +
             "hndcp4 = ?, player5 = ?, username5 = ?, " + 
             "p5cw = ?, hndcp5 = ?, notes = ?, hideNotes = ?, proNew = ?, proMod = ?, " +
             "mNum1 = ?, mNum2 = ?, mNum3 = ?, mNum4 = ?, mNum5 = ?, " +
             "userg1 = ?, userg2 = ?, userg3 = ?, userg4 = ?, userg5 = ?, orig_by = ?, conf = ?, " +
             "p91 = ?, p92 = ?, p93 = ?, p94 = ?, p95 = ?, pos1 = ?, pos2 = ?, pos3 = ?, pos4 = ?, pos5 = ?, lottery_email = 2, " + // was = 1
             "notes = ?, hideNotes = ? " + 
             "WHERE teecurr_id = ?");

        pstmt6.clearParameters();
        pstmt6.setString(1, slotParms.player1);
        pstmt6.setString(2, slotParms.player2);
        pstmt6.setString(3, slotParms.player3);
        pstmt6.setString(4, slotParms.player4);
        pstmt6.setString(5, slotParms.user1);
        pstmt6.setString(6, slotParms.user2);
        pstmt6.setString(7, slotParms.user3);
        pstmt6.setString(8, slotParms.user4);
        pstmt6.setString(9, slotParms.p1cw);
        pstmt6.setString(10, slotParms.p2cw);
        pstmt6.setString(11, slotParms.p3cw);
        pstmt6.setString(12, slotParms.p4cw);
        pstmt6.setFloat(13, slotParms.hndcp1);
        pstmt6.setFloat(14, slotParms.hndcp2);
        pstmt6.setFloat(15, slotParms.hndcp3);
        pstmt6.setFloat(16, slotParms.hndcp4);
        pstmt6.setString(17, slotParms.player5);
        pstmt6.setString(18, slotParms.user5);
        pstmt6.setString(19, slotParms.p5cw);
        pstmt6.setFloat(20, slotParms.hndcp5);
        pstmt6.setString(21, slotParms.notes);
        pstmt6.setInt(22, 0); // hide
        pstmt6.setInt(23, 0); // proNew
        pstmt6.setInt(24, 0); // proMod
        pstmt6.setString(25, slotParms.mNum1);
        pstmt6.setString(26, slotParms.mNum2);
        pstmt6.setString(27, slotParms.mNum3);
        pstmt6.setString(28, slotParms.mNum4);
        pstmt6.setString(29, slotParms.mNum5);
        pstmt6.setString(30, slotParms.userg1);
        pstmt6.setString(31, slotParms.userg2);
        pstmt6.setString(32, slotParms.userg3);
        pstmt6.setString(33, slotParms.userg4);
        pstmt6.setString(34, slotParms.userg5);
        pstmt6.setString(35, slotParms.orig_by);
        pstmt6.setString(36, slotParms.conf);
        pstmt6.setInt(37, slotParms.p91);
        pstmt6.setInt(38, slotParms.p92);
        pstmt6.setInt(39, slotParms.p93);
        pstmt6.setInt(40, slotParms.p94);
        pstmt6.setInt(41, slotParms.p95);
        pstmt6.setInt(42, slotParms.pos1);
        pstmt6.setInt(43, slotParms.pos2);
        pstmt6.setInt(44, slotParms.pos3);
        pstmt6.setInt(45, slotParms.pos4);
        pstmt6.setInt(46, slotParms.pos5);
        pstmt6.setString(47, notes);
        pstmt6.setInt(48, hideNotes);

        pstmt6.setInt(49, teecurr_id);

        count = pstmt6.executeUpdate();      // execute the prepared stmt
    } 
    catch (Exception exp) {
        
        SystemUtils.buildDatabaseErrMsg(exp.toString(), exp.getMessage(), out, false); 
        return;
    }
    
    // if the tee time was updated then remove the request
    if (count == 1) {
                    
        try {

            PreparedStatement pstmt = con.prepareStatement("UPDATE evntsup2b SET moved = 1 WHERE name = ? AND id = ?");
            pstmt.clearParameters();
            pstmt.setString(1, event_name);
            pstmt.setInt(2, event_id);
            pstmt.executeUpdate();
            pstmt.close();

        } catch (Exception exp) {
            SystemUtils.buildDatabaseErrMsg(exp.toString(), exp.getMessage(), out, false); 
            return;
        }
        
    } // end if updated teecurr2 entry


    out.println("<!-- count="+count+" -->");
    
    out.println("<!-- ");
    out.println("slotParms.player1=" + slotParms.player1);
    out.println("slotParms.player2=" + slotParms.player2);
    out.println("slotParms.player3=" + slotParms.player3);
    out.println("slotParms.player4=" + slotParms.player4);
    out.println("slotParms.player5=" + slotParms.player5);
    out.println("");
    out.println("slotParms.p1cw=" + slotParms.p1cw);
    out.println("slotParms.p2cw=" + slotParms.p2cw);
    out.println("slotParms.p3cw=" + slotParms.p3cw);
    out.println("slotParms.p4cw=" + slotParms.p4cw);
    out.println("slotParms.p5cw=" + slotParms.p5cw);
    out.println("");
    out.println("slotParms.p91=" + slotParms.p91);
    out.println("slotParms.p92=" + slotParms.p92);
    out.println("slotParms.p93=" + slotParms.p93);
    out.println("slotParms.p94=" + slotParms.p94);
    out.println("slotParms.p95=" + slotParms.p95);
    out.println("");
    out.println("slotParms.mNum1=" + slotParms.mNum1);
    out.println("slotParms.mNum2=" + slotParms.mNum2);
    out.println("slotParms.mNum3=" + slotParms.mNum3);
    out.println("slotParms.mNum4=" + slotParms.mNum4);
    out.println("slotParms.mNum5=" + slotParms.mNum5);
    out.println("");
    out.println(" -->");


    //
    // Completed update - reload page
    //
    out.println("<meta http-equiv=\"Refresh\" content=\"0; url=/" +rev+ "/servlet/Proshop_devnt?index=" + slotParms.ind + "&course=" + slotParms.returnCourse + "&name=" + event_name + "&hide="+hideUnavail+"&limit=" + limit + "&jump=777\">");

    out.close();
    return;
 }
 
 
 //
 // Add player to slot
 //
 private static boolean addPlayer(parmSlot slotParms, String player_name, String username, String memNum, String cw, int p9hole, boolean allowFives) {

    if (slotParms.player1.equals("")) {

        slotParms.player1 = player_name;
        slotParms.user1 = username;
        slotParms.mNum1 = memNum;
        slotParms.p1cw = cw;
        slotParms.p91 = p9hole;

    } else if (slotParms.player2.equals("")) {

        slotParms.player2 = player_name;
        slotParms.user2 = username;
        slotParms.mNum2 = memNum;
        slotParms.p2cw = cw;
        slotParms.p92 = p9hole;

    } else if (slotParms.player3.equals("")) {

        slotParms.player3 = player_name;
        slotParms.user3 = username;
        slotParms.mNum3 = memNum;
        slotParms.p3cw = cw;
        slotParms.p93 = p9hole;

    } else if (slotParms.player4.equals("")) {

        slotParms.player4 = player_name;
        slotParms.user4 = username;
        slotParms.mNum4 = memNum;
        slotParms.p4cw = cw;
        slotParms.p94 = p9hole;

    } else if (slotParms.player5.equals("") && allowFives) {

        slotParms.player5 = player_name;
        slotParms.user5 = username;
        slotParms.mNum5 = memNum;
        slotParms.p5cw = cw;
        slotParms.p95 = p9hole;

    } else {
        
        return (true);
        
    }
    
     return (false);
 }
 
 
 // *********************************************************
 //  Process delete request from above
 //
 //  parms:  index         = index value for date
 //          course        = name of course
 //          returnCourse  = name of course for return to sheet
 //          jump          = jump index for return
 //          time          = time of tee time
 //          fb            = f/b indicator
 //
 // *********************************************************

 private void doDelete(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session) {


   ResultSet rs = null;

   //
   //  variables for this class
   //
   int index = 0;
   int year = 0;
   int month = 0;
   int day = 0;
   int day_num = 0;
   int fb = 0;
   int hr = 0;
   int min = 0;
   int time = 0;

   String sampm = "AM";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";

   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };


   //
   //    The 'index' paramter contains an index value
   //    (0 = today, 1 = tomorrow, etc.)
   //
   String indexs = req.getParameter("index");        //  index value of the day
   String course = req.getParameter("course");       //  get the course name for this delete request
   String returnCourse = req.getParameter("returnCourse");   //  get the course name for this sheet
   String jump = req.getParameter("jump");           //  get the jump index
   String stime = req.getParameter("time");          //  get the time of tee time
   String sfb = req.getParameter("fb");              //  get the fb indicator
   String emailOpt = req.getParameter("email");      //  get the email indicator
   String hide = req.getParameter("hide");
   String event_name = req.getParameter("name");

   if (course == null) {

      course = "";    // change to null string
   }

   //
   //  Convert the index value from string to int
   //
   try {
      index = Integer.parseInt(indexs);
      fb = Integer.parseInt(sfb);
      time = Integer.parseInt(stime);
   }
   catch (NumberFormatException e) {
      // ignore error
   }

   //
   //  isolate hr and min values
   //
   hr = time / 100;
   min = time - (hr * 100);

   //
   //  Get today's date and then use the value passed to locate the requested date
   //
   Calendar cal = new GregorianCalendar();       // get todays date

   cal.add(Calendar.DATE,index);                  // roll ahead 'index' days

   year = cal.get(Calendar.YEAR);
   month = cal.get(Calendar.MONTH);
   day = cal.get(Calendar.DAY_OF_MONTH);
   day_num = cal.get(Calendar.DAY_OF_WEEK);      // day of week (01 - 07)

   month = month + 1;                            // month starts at zero

   String day_name = day_table[day_num];         // get name for day

   long date = year * 10000;                     // create a date field of yyyymmdd
   date = date + (month * 100);
   date = date + day;                            // date = yyyymmdd (for comparisons)

   if (req.getParameter("deleteSubmit") == null) {      // if this is the first request

      //
      //   Call is from 'edit' processing above to start a delete request
      //
      //
      //  Build the HTML page to prompt user for a confirmation
      //
      out.println(SystemUtils.HeadTitle("Proshop Delete Confirmation"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\"></font><center>");

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");        // whole page
      out.println("<tr><td align=\"center\" valign=\"top\">");

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");   // main page
      out.println("<tr><td align=\"center\">");
      out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\" color=\"#000000\"><br><br>");

         out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"8\" align=\"center\">");
         out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
         out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + returnCourse + "\">");
         out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
         out.println("<input type=\"hidden\" name=\"time\" value=\"" + time + "\">");
         out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
         out.println("<input type=\"hidden\" name=\"fb\" value=\"" + fb + "\">");
         out.println("<input type=\"hidden\" name=\"delete\" value=\"yes\">");

         out.println("<tr><td width=\"450\">");
         out.println("<font size=\"3\">");
         out.println("<p align=\"center\"><b>Delete Confirmation</b></p></font>");
         out.println("<br><font size=\"2\">");

            out.println("<font size=\"2\">");
            out.println("<p align=\"left\">");
            //
            //  Check to see if any players are in this tee time
            //
            try {

               PreparedStatement pstmt1d = con.prepareStatement (
                  "SELECT player1, player2, player3, player4, player5 " +
                  "FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

               pstmt1d.clearParameters();        // clear the parms
               pstmt1d.setLong(1, date);
               pstmt1d.setInt(2, time);
               pstmt1d.setInt(3, fb);
               pstmt1d.setString(4, course);

               rs = pstmt1d.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  player1 = rs.getString(1);
                  player2 = rs.getString(2);
                  player3 = rs.getString(3);
                  player4 = rs.getString(4);
                  player5 = rs.getString(5);

               } 

               pstmt1d.close();   // close the stmt

            }
            catch (Exception ignore) {   // this is good if no match found
            }
              
            if (!player1.equals( "" ) || !player2.equals( "" ) || !player3.equals( "" ) || !player4.equals( "" ) || !player5.equals( "" )) { 
              
               out.println("<b>Warning:</b> &nbsp;You are about to permanently remove a tee time ");
               out.println("which contains the following player(s):<br>");
                 
               if (!player1.equals( "" )) {
         
                  out.println("<br>" +player1);
               }
               if (!player2.equals( "" )) {

                  out.println("<br>" +player2);
               }
               if (!player3.equals( "" )) {

                  out.println("<br>" +player3);
               }
               if (!player4.equals( "" )) {

                  out.println("<br>" +player4);
               }
               if (!player5.equals( "" )) {

                  out.println("<br>" +player5);
               }
               out.println("<br><br>This will remove the entire tee time slot from the database. ");
               out.println(" If you wish to only remove the players, then return to the tee sheet and select the tee time to update it.");
               out.println("</p>");
            } else {
               out.println("<b>Warning:</b> &nbsp;You are about to permanently remove the following tee time.<br><br>");
               out.println("This will remove the entire tee time slot from the database. ");
               out.println(" If you wish to only remove the players, then return to the tee sheet and select the tee time to update it.");
               out.println("</p>");
            }
            //
            //  build the time string
            //
            sampm = "AM";
            if (hr > 11) {        // if PM

               sampm = "PM";
            }
            if (hr > 12) {
               hr = hr - 12;        // convert back to conventional time
            }
            out.println("<p align=\"center\">");
            if (min < 10) {
               out.println("Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":0" + min + " " + sampm + "</b>");
            } else {
               out.println("Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":" + min + " " + sampm + "</b>");
            }
              
         out.println("<BR><BR>Are you sure you want to delete this tee time?</p>");

            out.println("<p align=\"center\">");
              out.println("<input type=\"submit\" value=\"Yes - Delete It\" name=\"deleteSubmit\"></p>");
            out.println("</font></td></tr></form></table>");
            out.println("<br><br>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
         out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
         out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
      out.println("<input type=\"submit\" value=\"No - Back to Edit\" style=\"text-decoration:underline; background:#8B8970\"></form>");

      out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
         out.println("<input type=\"submit\" value=\"No - Return to Tee Sheet\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form>");

      //
      //  End of HTML page
      //
      out.println("</td></tr></table>");                           // end of main page
      out.println("</td></tr></table>");                           // end of whole page
      out.println("</center></body></html>");
      out.close();
      
   } else { 

      //
      //   Call is from self to process a delete request (final - this is the confirmation)
      //
      //  Check to make sure a slot like this already exists
      //
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "SELECT mm FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setLong(1, date);
         pstmt1.setInt(2, time);
         pstmt1.setInt(3, fb);
         pstmt1.setString(4, course);

         rs = pstmt1.executeQuery();      // execute the prepared stmt

         if (!rs.next()) {

            out.println(SystemUtils.HeadTitle("DB Error"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
            out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center><BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR>A tee time with these date, time and F/B values does not exist.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR><BR>");
            out.println("<a href=\"javascript:history.back(1)\">Return</a>");
            out.println("</center></BODY></HTML>");
            out.close();
            return;

         }    // ok if we get here - matching time slot found

         pstmt1.close();   // close the stmt

      }
      catch (Exception ignore) {   // this is good if no match found
      }

      //
      //  This slot was found - delete it from the database
      //

      try {

         PreparedStatement pstmt2 = con.prepareStatement (
            "DELETE FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt2.clearParameters();        // clear the parms
         pstmt2.setLong(1, date);
         pstmt2.setInt(2, time);
         pstmt2.setInt(3, fb);
         pstmt2.setString(4, course);

         int count = pstmt2.executeUpdate();      // execute the prepared stmt

         pstmt2.close();   // close the stmt

      }
      catch (Exception e1) {

         out.println(SystemUtils.HeadTitle("DB Error"));
         out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
         out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center><BR><BR><H3>Database Access Error</H3>");
         out.println("<BR><BR>Unable to access the Database.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact customer support.");
         out.println("<BR><BR>" + e1.getMessage());
         out.println("<BR><BR>");
         out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
            out.println("<input type=\"submit\" value=\"Return to Sheet\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form>");
         out.println("</center></BODY></HTML>");
         out.close();
         return;
      }
      //
      //  Delete complete - inform user
      //
      sampm = "AM";
      if (hr > 11) {        // if PM

         sampm = "PM";
      }
      if (hr > 12) {
         hr = hr - 12;        // convert back to conventional time
      }

      out.println("<HTML><HEAD><title>Proshop Delete Confirmation</title>");
      out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_devnt?index=" +indexs+ "&course=" +returnCourse+ "&jump=" +jump+ "&email=" +emailOpt+ "&jump=" +jump+ "&hide=" +hide+ "&name=" +event_name+ "\">");
      out.println("</HEAD>");
      out.println("<BODY bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<center>");
      out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
      out.println("><BR><BR><H3>Delete Tee Time Confirmation</H3>");
      out.println("<BR><BR>Thank you, the following tee time has been removed.");
      if (hr > 12) {
         hr = hr - 12;        // convert back to conventional time
      }
      if (min < 10) {
         out.println("<BR><BR>Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":0" + min + " " + sampm + "</b>");
      } else {
         out.println("<BR><BR>Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":" + min + " " + sampm + "</b>");
      }
      out.println("<BR><BR>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
         out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
         out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
      out.println("<input type=\"submit\" value=\"Back to Edit\" style=\"text-decoration:underline; background:#8B8970\"></form>");
      out.println("</center></BODY></HTML>");
      out.close();
   }
 }      // end of doDelete

 
 // *********************************************************
 //  Process a delete request for a event signup
 //  
 //  Parms: eventId    = uid for request to be deleted
 //
 // *********************************************************
 
 private void doDeleteEvent(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session) {

     
    String sindex = req.getParameter("index");        //  index value of the day
    String returnCourse = req.getParameter("returnCourse");   //  get the course name for this sheet
    String jump = req.getParameter("jump");           //  get the jump index
    String emailOpt = req.getParameter("email");      //  get the email indicator
    String event_name = req.getParameter("name");
    String hide = req.getParameter("hide");
    String slid = req.getParameter("eventId");
    
    int index = 0;
    int event_id = 0;
    if (slid == null) slid = "";

    //
    //  Convert the index value from string to int
    //
    try {

        index = Integer.parseInt(sindex);
        event_id = Integer.parseInt(slid);
    }
    catch (NumberFormatException e) { }
    
    try {

        PreparedStatement pstmt2 = con.prepareStatement (
        "DELETE FROM evntsup2b WHERE id = ?");

        pstmt2.clearParameters();
        pstmt2.setInt(1, event_id);
        pstmt2.executeUpdate();
        pstmt2.close();

    }
    catch (Exception e1) {

        out.println(SystemUtils.HeadTitle("DB Error"));
        out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
        out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
        out.println("<center><BR><BR><H3>Database Access Error</H3>");
        out.println("<BR><BR>Unable to access the Database.");
        out.println("<BR>Please try again later.");
        out.println("<BR><BR>If problem persists, contact customer support.");
        out.println("<BR><BR>" + e1.getMessage());
        out.println("<BR><BR>");
        out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
        out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
        out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
        out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
        out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
        out.println("<input type=\"submit\" value=\"Return to Sheet\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
        out.println("</form>");
        out.println("</center></BODY></HTML>");
        out.close();
        return;
    }

    out.println("<HTML><HEAD><title>Proshop Delete Confirmation</title>");
    out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_devnt?index=" +index+ "&course=" +returnCourse+ "&jump=" +jump+ "&email=" +emailOpt+ "&jump=" +jump+ "&hide=" +hide+ "&name=" +event_name+ "\">");
    out.println("</HEAD>");
    out.println("<BODY bgcolor=\"#FFFFFF\" text=\"#000000\">");
    out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
    out.println("<center>");
    out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
    out.println("<BR><BR><H3>Delete Event Signup Confirmation</H3>");
    out.println("<BR><BR>Thank you, the request has been removed.");
    out.println("<BR><BR>");
    out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
        out.println("<input type=\"hidden\" name=\"index\" value=" + index + ">");
        out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
        out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
        out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
        out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
        out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
        out.println("<input type=\"submit\" value=\"Back to Edit\" style=\"text-decoration:underline; background:#8B8970\">");
    out.println("</form>");
    out.println("</center></BODY></HTML>");
    out.close();
         
 }
 
 

 // *********************************************************
 //  Process insert request from above
 //
 //  parms:  index         = index value for date
 //          course        = name of course
 //          returnCourse  = name of course for return to sheet
 //          jump          = jump index for return
 //          time          = time of tee time
 //          fb            = f/b indicator
 //          insertSubmit  = if from self
 //          first         = if first tee time
 //
 // *********************************************************

 private void doInsert(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session) {


   ResultSet rs = null;

   //
   //  variables for this method
   //
   int year = 0;
   int month = 0;
   int day = 0;
   int day_num = 0;
   int hr = 0;
   int min = 0;
   int ampm = 0;
   int fb = 0;
   int time = 0;
   int otime = 0;
   int index = 0;
   int event_type = 0;
   int notify_id = 0;

   String event = "";
   String event_color = "";
   String rest = "";
   String rest2 = "";
   String rest_color = "";
   String rest_color2 = "";
   String rest_recurr = "";
   String rest5 = "";                      // default values
   String rest52 = "";
   String rest5_color = "";
   String rest5_color2 = "";
   String rest5_recurr = "";
   String lott = "";                      // lottery name
   String lott2 = "";                      // lottery name
   String lott_color = "";
   String lott_color2 = "";
   String lott_recurr = "";

   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };


   //
   //    The 'index' paramter contains an index value
   //    (0 = today, 1 = tomorrow, etc.)
   //
   String indexs = req.getParameter("index");         //  index value of the day
   String course = req.getParameter("course");        //  get the course name for this insert
   String returnCourse = req.getParameter("returnCourse");     //  get the course name for this sheet
   String jump = req.getParameter("jump");            //  get the jump index
   String sfb = req.getParameter("fb");
   String times = req.getParameter("time");            //  get the tee time selected (hhmm)
   String first = req.getParameter("first");           //  get the first tee time indicator (yes or no)
   String emailOpt = req.getParameter("email");        //  get the email option from _sheet
   String snid = req.getParameter("notifyId");
   String hide = req.getParameter("hide");
   String event_name = req.getParameter("name");

   if (course == null) course = "";
   if (snid == null) snid = "";
   if (times == null) times = "";
   if (sfb == null) sfb = "";
   
   //
   //  Convert the index value from string to int
   //
   try {
       
      time = Integer.parseInt(times);
      index = Integer.parseInt(indexs);
      fb = Integer.parseInt(sfb);
      notify_id = Integer.parseInt(snid);
   }
   catch (NumberFormatException e) { }

   //
   //  isolate hr and min values
   //
   hr = time / 100;
   min = time - (hr * 100);

   //
   //  Get today's date and then use the value passed to locate the requested date
   //
   Calendar cal = new GregorianCalendar();       // get todays date
   cal.add(Calendar.DATE,index);                  // roll ahead (or back) 'index' days

   year = cal.get(Calendar.YEAR);
   month = cal.get(Calendar.MONTH) + 1;
   day = cal.get(Calendar.DAY_OF_MONTH);
   day_num = cal.get(Calendar.DAY_OF_WEEK);      // day of week (01 - 07)

   String day_name = day_table[day_num];         // get name for day
   
   long date = year * 10000;                     // create a date field of yyyymmdd
   date = date + (month * 100) + day;            // date = yyyymmdd (for comparisons)

   if (req.getParameter("insertSubmit") == null) {      // if not an insert 'submit' request (from self)

      //
      //  Process the initial call to Insert a New Tee Time
      //
      //  Build the HTML page to prompt user for a specific time slot
      //
      out.println(SystemUtils.HeadTitle("Proshop Insert Tee Time Page"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\"></font><center>");

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");        // whole page
      out.println("<tr><td align=\"center\" valign=\"top\">");

      out.println("<table border=\"0\" align=\"center\" width=\"100%\">");   // main page
      out.println("<tr><td align=\"center\">");
      out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\" color=\"#000000\">");

      out.println("<font size=\"5\">");
      out.println("<p align=\"center\"><b>Insert Tee Sheet</b></p></font>");
      out.println("<font size=\"2\">");

      out.println("<table cellpadding=\"5\" align=\"center\" width=\"450\">");
      out.println("<tr><td colspan=\"4\" bgcolor=\"#336633\"><font color=\"#FFFFFF\" size=\"2\">");
      out.println("<b>Instructions:</b>  To insert a tee time for the date shown below, select the time");
      out.println(" and the 'front/back' values.  Select 'Insert' to add the new tee time.");
      out.println("</font></td></tr></table><br>");

      out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"8\" align=\"center\">");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
      out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
      out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + returnCourse + "\">");
      out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
      out.println("<input type=\"hidden\" name=\"insert\" value=\"yes\">");
      out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");

      out.println("<tr><td width=\"450\">");
         out.println("<font size=\"2\">");
         out.println("<p align=\"left\">");
         out.println("<b>Note:</b> &nbsp;This tee time must be unique from all others on the sheet. &nbsp;");
         out.println("Therefore, at least one of these values must be different than other tee times.");
      out.println("<p align=\"center\">Date:&nbsp;&nbsp;<b>" + day_name + "&nbsp;&nbsp;" + month + "/" + day + "/" + year + "</b></p>");
      out.println("Time:&nbsp;&nbsp;");
      out.println("<select size=\"1\" name=\"time\">");
      //
      //  Define some variables for this processing
      //
      PreparedStatement pstmt1b = null;
      String dampm = " AM";
      int dhr = hr;
      int i = 0;
      int i2 = 0;
      int mint = min;
      int hrt = hr;
      int last = 0;
      int start = 0;
      int maxtimes = 20;
        
      //
      //  Determine time values to be used for selection 
      //
      loopt:
      while (i < maxtimes) {

         mint++;               // next minute
         if (mint > 59) {

            mint = 0;          // rotate the hour
            hrt++;
         }
         if (hrt > 23) {

            hrt = 23;
            mint = 59;
            break loopt;      // done
         }
         if (i == 0) {                        // if first time
            start = (hrt * 100) + mint;       // save first time for select
         }
         i++;
      }
      last = (hrt * 100) + mint;       // last time for select

      try {

         //
         //   Find the next time - after the time selected - use as the limit for selection list
         //
         pstmt1b = con.prepareStatement (
            "SELECT time FROM teecurr2 " +
            "WHERE date = ? AND time > ? AND time < ? AND fb = ? AND courseName = ? " +
            "ORDER BY time");

         pstmt1b.clearParameters();        // clear the parms
         pstmt1b.setLong(1, date);
         pstmt1b.setInt(2, time);
         pstmt1b.setInt(3, last);
         pstmt1b.setInt(4, fb);
         pstmt1b.setString(5, course);

         rs = pstmt1b.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            last = rs.getInt(1);          // get the first time found - use as upper limit for display
         }
         pstmt1b.close();

      }
      catch (Exception e) {
      }

      i = 0;
        
      //
      //  If first tee time on sheet, then allow 20 tee times prior to this time.
      //
      if (first.equalsIgnoreCase( "yes" )) {

         mint = min;                // get original time
         hrt = hr;

         while (i < maxtimes) {           // determine the first time

            if (mint > 0) {
               mint--;
            } else {               // assume not midnight
               hrt--;
               mint = 59;
            }
            i++;
         }
         start = (hrt * 100) + mint;       // save first time for select
         maxtimes = 40;           // new max for this request
      }

      //
      //  Start with the time selected in case they want a tee time with same time, different f/b
      //
      if (dhr > 11) {

         dampm = " PM";
      }
      if (dhr > 12) {

         dhr = dhr - 12;
      }
      if (min < 10) {
         out.println("<option value=\"" +time+ "\">" +dhr+ ":0" +min+ " " +dampm+ "</option>");
      } else {
         out.println("<option value=\"" +time+ "\">" +dhr+ ":" +min+ " " +dampm+ "</option>");
      }

      //
      //  list tee times that follow the one selected, but less than 'last'
      //
      otime = time;           // save original time value
      i = 0;
      hr = start / 100;             // get values for start time (first in select list)
      min = start - (hr * 100);

      loop1:
      while (i < maxtimes) {

         dhr = hr;            // init as same
         dampm = " AM";

         if (hr == 0) {

            dhr = 12;
         }
         if (hr > 12) {

            dampm = " PM";
            dhr = hr - 12;
         }
         if (hr == 12) {

            dampm = " PM";
         }

         time = (hr * 100) + min;      // set time value

         if (time >= last) {           // if we reached the end

            break loop1;              // done
         }

         if (time != otime) {        // if not same as original time
            if (min < 10) {
               out.println("<option value=\"" +time+ "\">" +dhr+ ":0" +min+ " " +dampm+ "</option>");
            } else {
               out.println("<option value=\"" +time+ "\">" +dhr+ ":" +min+ " " +dampm+ "</option>");
            }
         }
           
         min++;               // next minute
           
         if (min > 59) {

            min = 0;          // rotate the hour
            hr++;
         }
         if (hr > 23) {

            break loop1;      // done
         }

         i++;
      }           // end of while

      out.println("</select>");

      out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
      out.println("Front/Back:&nbsp;&nbsp;");
      out.println("<select size=\"1\" name=\"fb\">");
        out.println("<option value=\"00\">Front</option>");
        out.println("<option value=\"01\">Back</option>");
        out.println("<option value=\"09\">Crossover</option>");
      out.println("</select>");
      out.println("<br><br></p>");
      out.println("<p align=\"center\">");
        out.println("<input type=\"submit\" value=\"Insert\" name=\"insertSubmit\"></p>");
      out.println("</font></td></tr></form></table>");
      out.println("<br><br>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
      out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
      out.println("<input type=\"hidden\" name=\"hide\" value=\"" +hide+ "\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" +event_name+ "\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\"></form>");

      //
      //  End of HTML page
      //
      out.println("</td></tr></table>");                           // end of main page
      out.println("</td></tr></table>");                           // end of whole page
      out.println("</center></body></html>");
      out.close();
      
   } else {     // end of Insert Submit processing

      //
      //   Call is from self to process an insert request (submit)
      //
      //   Parms passed:   time = time of the tee time to be inserted
      //                   date = date of the tee sheet
      //                   fb   = the front/back value (see above)
      //                   course = course name
      //                   returnCourse = course name for return

      //
      //  Check to make sure a slot like this doesn't already exist
      //
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "SELECT mm FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setLong(1, date);
         pstmt1.setInt(2, time);
         pstmt1.setInt(3, fb);
         pstmt1.setString(4, course);

         rs = pstmt1.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            out.println(SystemUtils.HeadTitle("DB Error"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
            out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center><BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR>A tee time with these date, time and F/B values already exists.");
            out.println("<BR>One of these values must change so the tee time is unique.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR><BR>");
            out.println("<a href=\"javascript:history.back(1)\">Return</a>");
            out.println("</center></BODY></HTML>");
            return;

         }    // ok if we get here - not matching time slot

         pstmt1.close();   // close the stmt

      }
      catch (Exception ignore) {   // this is good if no match found
      }

      //
      //  This slot is unique - now check for events or restrictions for this date and time
      //

      try {

         SystemUtils.insertTee(date, time, fb, course, day_name, con);     // insert new tee time

      }
      catch (Exception e1) {

         out.println(SystemUtils.HeadTitle("DB Error"));
         out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
         out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center><BR><BR><H3>Database Access Error</H3>");
         out.println("<BR><BR>Unable to access the Database.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact customer support.");
         out.println("<BR><BR>Error in Proshop_devnt: " + e1.getMessage());
         out.println("<BR><BR>");
         out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
         out.println("<input type=\"submit\" value=\"Return to Sheet\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form>");
         out.println("</center></BODY></HTML>");
         out.close();
         return;
      }

      //
      //  Insert complete - inform user
      //
      String sampm = "AM";
      if (hr > 11) {        // if PM

         sampm = "PM";
      }

      out.println("<HTML><HEAD><Title>Proshop Insert Confirmation</Title>");
      out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_devnt?index=" +indexs+ "&course=" +returnCourse+ "&jump=" +jump+ "&email=" +emailOpt+ "&hide=" +hide+ "&name=" +event_name+ "\">");
      out.println("</HEAD>");
      out.println("<BODY bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<center><BR><BR><H3>Insert Tee Time Confirmation</H3>");
      out.println("<BR><BR>Thank you, the following tee time has been added.");
      if (hr > 12) {
         hr = hr - 12;        // convert back to conventional time
      }
      if (min < 10) {
         out.println("<BR><BR>Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":0" + min + " " + sampm + "</b>");
      } else {
         out.println("<BR><BR>Date & Time:  <b>" + day_name + " " + month + "/" + day + "/" + year + " " + hr + ":" + min + " " + sampm + "</b>");
      }
      out.println("<BR><BR>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"index\" value=" + indexs + ">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + returnCourse + "\">");
      out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
      out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + event_name + "\">");
      out.println("<input type=\"hidden\" name=\"email\" value=\"" +emailOpt+ "\">");
      out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\"></form>");
      out.println("</center></BODY></HTML>");
      
      //
      // Refresh the blockers in case the tee time added is covered by a blocker
      //
      SystemUtils.doBlockers(con);
      
      
      out.close();
   }

 }      // end of doInsert

 // *********************************************************
 //  changeCW - change the C/W option for 1 or all players in tee time.  
 //
 //  parms:
 //          jump        = jump index for return
 //          from_player = player position being changed (1-5) 
 //          from_time   = tee time being changed
 //          from_fb     = f/b of tee time
 //          from_course = name of course
 //          to_from     = current C/W option 
 //          to_to       = new C/W option
 //          changeAll   = change all players in slot (true or false)
 //          ninehole    = use 9 Hole options (true or false)
 //
 // *********************************************************

 private void changeCW(parmSlot slotParms, String changeAll, String ninehole, long date, HttpServletRequest req, PrintWriter out, Connection con, HttpServletResponse resp) {


   ResultSet rs = null;

   int in_use = 0;
   int p91 = 0;
   int p92 = 0;
   int p93 = 0;
   int p94 = 0;
   int p95 = 0;

   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String newcw = "";


   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.from_time == 0 || slotParms.from_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.changeCW - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.from_time+ ", course= " +slotParms.from_course+ ", fb= " +slotParms.from_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Check if the requested tee time is currently in use
      //
      try {

         in_use = verifySlot.checkInUse(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms.user, slotParms, con);

      }
      catch (Exception e1) {

         String eMsg = "Error 1 in changeCW. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }

   if (in_use != 0) {              // if time slot already in use

      teeBusy(out, slotParms, req);
      return;
   }

   //
   //  Ok - get current player info from the parm block (set by checkInUse)
   //
   player1 = slotParms.player1;
   player2 = slotParms.player2;
   player3 = slotParms.player3;
   player4 = slotParms.player4;
   player5 = slotParms.player5;
   p1cw = slotParms.p1cw;
   p2cw = slotParms.p2cw;
   p3cw = slotParms.p3cw;
   p4cw = slotParms.p4cw;
   p5cw = slotParms.p5cw;
   p91 = slotParms.p91;
   p92 = slotParms.p92;
   p93 = slotParms.p93;
   p94 = slotParms.p94;
   p95 = slotParms.p95;
     
   //
   //  If '9 Hole' option selected, then change new C/W to 9 hole type
   //
   newcw = slotParms.to_to;            // get selected C/W option
     
   //
   //  Set the new C/W value for each player requested
   //
   if (!player1.equals( "" )) {

      if ((changeAll.equals( "true" )) || (slotParms.from_player == 1)) {   // change this one?

         p1cw = newcw;
         if (ninehole.equals( "true" )) {
            p91 = 1;             // make it a 9 hole type
         } else {
            p91 = 0;             // make it 18 hole 
         }
      }
   }
   if (!player2.equals( "" )) {

      if ((changeAll.equals( "true" )) || (slotParms.from_player == 2)) {   // change this one?

         p2cw = newcw;
         if (ninehole.equals( "true" )) {
            p92 = 1;             // make it a 9 hole type
         } else {
            p92 = 0;             // make it 18 hole
         }
      }
   }
   if (!player3.equals( "" )) {

      if ((changeAll.equals( "true" )) || (slotParms.from_player == 3)) {   // change this one?

         p3cw = newcw;
         if (ninehole.equals( "true" )) {
            p93 = 1;             // make it a 9 hole type
         } else {
            p93 = 0;             // make it 18 hole
         }
      }
   }
   if (!player4.equals( "" )) {

      if ((changeAll.equals( "true" )) || (slotParms.from_player == 4)) {   // change this one?

         p4cw = newcw;
         if (ninehole.equals( "true" )) {
            p94 = 1;             // make it a 9 hole type
         } else {
            p94 = 0;             // make it 18 hole
         }
      }
   }
   if (!player5.equals( "" )) {

      if ((changeAll.equals( "true" )) || (slotParms.from_player == 5)) {   // change this one?

         p5cw = newcw;
         if (ninehole.equals( "true" )) {
            p95 = 1;             // make it a 9 hole type
         } else {
            p95 = 0;             // make it 18 hole
         }
      }
   }
     
   //
   //  Update the tee time and set it no longer in use
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "UPDATE teecurr2 SET " +
         "p1cw=?, p2cw=?, p3cw=?, p4cw=?, in_use=0, p5cw=?, p91=?, p92=?, p93=?, p94=?, p95=? " +
         "WHERE date=? AND time=? AND fb=? AND courseName=?");

      pstmt1.clearParameters();          // clear the parms
      pstmt1.setString(1, p1cw);      
      pstmt1.setString(2, p2cw);
      pstmt1.setString(3, p3cw);
      pstmt1.setString(4, p4cw);
      pstmt1.setString(5, p5cw);
      pstmt1.setInt(6, p91);
      pstmt1.setInt(7, p92);
      pstmt1.setInt(8, p93);
      pstmt1.setInt(9, p94);
      pstmt1.setInt(10, p95);
      pstmt1.setLong(11, date);
      pstmt1.setInt(12, slotParms.from_time);
      pstmt1.setInt(13, slotParms.from_fb);
      pstmt1.setString(14, slotParms.from_course);
      pstmt1.executeUpdate();            // execute the prepared stmt

      pstmt1.close();
   }
   catch (Exception e1) {

      String eMsg = "Error 2 in changeCW. ";
      dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
      return;
   }

   //
   //  Done - return 
   //
   editDone(out, slotParms, resp, req);

 }      // end of changeCW


 // *********************************************************
 //  changeFB - change the F/B option for the tee time specified.
 //
 //  parms: 
 //          jump        = jump index for return
 //          from_time   = tee time being changed
 //          from_fb     = current f/b of tee time
 //          from_course = name of course
 //          to_fb       = new f/b of tee time
 //
 // *********************************************************

 private void changeFB(parmSlot slotParms, long date, HttpServletRequest req, PrintWriter out, Connection con, HttpServletResponse resp) {


   ResultSet rs = null;

   int in_use = 0;


   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.from_time == 0 || slotParms.from_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.changeFB - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.from_time+ ", course= " +slotParms.from_course+ ", fb= " +slotParms.from_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Check if the requested tee time is currently in use
      //
      try {

         in_use = verifySlot.checkInUse(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms.user, slotParms, con);

      }
      catch (Exception e1) {

         String eMsg = "Error 1 in changeFB. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }

   if (in_use != 0) {              // if time slot already in use

      teeBusy(out, slotParms, req);
      return;
   }

   //
   //  Ok, tee time not busy - change the F/B
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "UPDATE teecurr2 SET in_use = 0, fb = ? " +
         "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

      pstmt1.clearParameters();          // clear the parms
      pstmt1.setInt(1, slotParms.to_fb);
      pstmt1.setLong(2, date);
      pstmt1.setInt(3, slotParms.from_time);
      pstmt1.setInt(4, slotParms.from_fb);
      pstmt1.setString(5, slotParms.from_course);
      pstmt1.executeUpdate();            // execute the prepared stmt

      pstmt1.close();
   }
   catch (Exception e1) {

      String eMsg = "Error 2 in changeFB. ";
      dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
      return;
   }

   //
   //  Done - return
   //
   editDone(out, slotParms, resp, req);

 }      // end of changeFB


 // *********************************************************
 //  moveWhole - move an entire tee time
 //
 //  parms:
 //          jump        = jump index for return
 //          from_time   = tee time being moved
 //          from_fb     = f/b of tee time being moved
 //          from_course = name of course of tee time being moved
 //          to_time     = tee time to move to
 //          to_fb       = f/b of tee time to move to
 //          to_course   = name of course of tee time to move to
 //
 //          prompt      = null if first call here
 //                      = 'return' if user wants to return w/o changes
 //                      = 'continue' if user wants to continue with changes
 //          skip        = verification process to skip if 2nd return
 //
 // *********************************************************

 private void moveWhole(parmSlot slotParms, long date, String prompt, int skip, HttpServletRequest req, 
                        PrintWriter out, Connection con, HttpServletResponse resp) {


   ResultSet rs = null;
     
   int in_use = 0;

   String hideUnavail = req.getParameter("hide");
   
   String p1 = "";
   String p2 = "";
   String p3 = "";
   String p4 = "";
   String p5 = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String user1 = "";
   String user2 = "";
   String user3 = "";
   String user4 = "";
   String user5 = "";
   String mNum1 = "";
   String mNum2 = "";
   String mNum3 = "";
   String mNum4 = "";
   String mNum5 = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
   String orig_by = "";
   String conf = "";
   String notes = "";

   short pos1 = 0;
   short pos2 = 0;
   short pos3 = 0;
   short pos4 = 0;
   short pos5 = 0;
   short show1 = 0;
   short show2 = 0;
   short show3 = 0;
   short show4 = 0;
   short show5 = 0;
     
   int hide = 0;
   int p91 = 0;
   int p92 = 0;
   int p93 = 0;
   int p94 = 0;
   int p95 = 0;
   int fives = 0;
   int sendemail = 0;

   float hndcp1 = 0;
   float hndcp2 = 0;
   float hndcp3 = 0;
   float hndcp4 = 0;
   float hndcp5 = 0;

   boolean error = false;
     

   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.from_time == 0 || slotParms.from_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.moveWhole - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.from_time+ ", course= " +slotParms.from_course+ ", fb= " +slotParms.from_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it
      
      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Check if the requested tee time is currently in use (the FROM tee time)
      //
      try {

         //
         //  If we got here by returning from a prompt below, then tee time is already busy
         //
         if (!prompt.equals( "" )) {        // if return, then tee time is already busy

            in_use = 0;
              
            getTeeTimeData(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms, con);

         } else {

            in_use = verifySlot.checkInUse(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms.user, slotParms, con);
            
         }

      }
      catch (Exception e1) {

         String eMsg = "Error 1 in moveWhole. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }

   if (in_use != 0) {                 // if time slot already in use

      teeBusy(out, slotParms, req);       // reject as busy
      return;
   }

   //
   //  Ok - get current 'FROM' player info from the parm block (set by checkInUse) and save it
   //
   player1 = slotParms.player1;
   player2 = slotParms.player2;
   player3 = slotParms.player3;
   player4 = slotParms.player4;
   player5 = slotParms.player5;
   p1cw = slotParms.p1cw;
   p2cw = slotParms.p2cw;
   p3cw = slotParms.p3cw;
   p4cw = slotParms.p4cw;
   p5cw = slotParms.p5cw;
   user1 = slotParms.user1;
   user2 = slotParms.user2;
   user3 = slotParms.user3;
   user4 = slotParms.user4;
   user5 = slotParms.user5;
   hndcp1 = slotParms.hndcp1;
   hndcp2 = slotParms.hndcp2;
   hndcp3 = slotParms.hndcp3;
   hndcp4 = slotParms.hndcp4;
   hndcp5 = slotParms.hndcp5;
   show1 = slotParms.show1;
   show2 = slotParms.show2;
   show3 = slotParms.show3;
   show4 = slotParms.show4;
   show5 = slotParms.show5;
   pos1 = slotParms.pos1;
   pos2 = slotParms.pos2;
   pos3 = slotParms.pos3;
   pos4 = slotParms.pos4;
   pos5 = slotParms.pos5;
   mNum1 = slotParms.mNum1;
   mNum2 = slotParms.mNum2;
   mNum3 = slotParms.mNum3;
   mNum4 = slotParms.mNum4;
   mNum5 = slotParms.mNum5;
   userg1 = slotParms.userg1;
   userg2 = slotParms.userg2;
   userg3 = slotParms.userg3;
   userg4 = slotParms.userg4;
   userg5 = slotParms.userg5;
   notes = slotParms.notes;
   hide = slotParms.hide;
   orig_by = slotParms.orig_by;
   conf = slotParms.conf;
   p91 = slotParms.p91;
   p92 = slotParms.p92;
   p93 = slotParms.p93;
   p94 = slotParms.p94;
   p95 = slotParms.p95;

   slotParms.player1 = "";       // init parmSlot player fields (verifySlot will fill) 
   slotParms.player2 = "";
   slotParms.player3 = "";
   slotParms.player4 = "";
   slotParms.player5 = "";

   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.to_time == 0 || slotParms.to_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.moveWhole2 - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.to_time+ ", course= " +slotParms.to_course+ ", fb= " +slotParms.to_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Now check if the 'TO' tee time is currently in use (this will put its info in slotParms)
      //
      try {

         //
         //  If we got here by returning from a prompt below, then tee time is already busy
         //
         if (!prompt.equals( "" )) {        // if return, tee time already busy

            in_use = 0;

            getTeeTimeData(date, slotParms.to_time, slotParms.to_fb, slotParms.to_course, slotParms, con);

         } else {

            in_use = verifySlot.checkInUse(date, slotParms.to_time, slotParms.to_fb, slotParms.to_course, slotParms.user, slotParms, con);
         }

      }
      catch (Exception e1) {

         String eMsg = "Error 2 in moveWhole. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }


   //
   //  If 'TO' tee time is in use 
   //
   if (in_use != 0) {   

      //
      //  Error - We must free up the 'FROM' tee time
      //
      in_use = 0;

      try {

         PreparedStatement pstmt4 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = ? " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt4.clearParameters();        // clear the parms
         pstmt4.setInt(1, in_use);
         pstmt4.setLong(2, date);
         pstmt4.setInt(3, slotParms.from_time);
         pstmt4.setInt(4, slotParms.from_fb);
         pstmt4.setString(5, slotParms.from_course);
         pstmt4.executeUpdate();      // execute the prepared stmt
         pstmt4.close();

      }
      catch (Exception ignore) {
      }

      teeBusy(out, slotParms, req);
      return;
   }

   //
   //  If user was prompted and opted to return w/o changes, then we must clear the 'in_use' flags
   //  before returning to the tee sheet.
   //
   if (prompt.equals( "return" )) {        // if prompt specified a return

      in_use = 0;

      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = ? " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();
         pstmt1.setInt(1, in_use);
         pstmt1.setLong(2, date);
         pstmt1.setInt(3, slotParms.from_time);
         pstmt1.setInt(4, slotParms.from_fb);
         pstmt1.setString(5, slotParms.from_course);

         pstmt1.executeUpdate();
         pstmt1.close();

         
         pstmt1 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = ? " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setInt(1, in_use);
         pstmt1.setLong(2, date);
         pstmt1.setInt(3, slotParms.to_time);
         pstmt1.setInt(4, slotParms.to_fb);
         pstmt1.setString(5, slotParms.to_course);

         pstmt1.executeUpdate();      // execute the prepared stmt
         pstmt1.close();

      }
      catch (Exception ignore) {
      }

      // return to Proshop_devnt

      out.println("<HTML><HEAD><Title>Proshop Edit Sheet Complete</Title>");
      out.println("<meta http-equiv=\"Refresh\" content=\"0; url=/" +rev+ "/servlet/Proshop_devnt?index=" + slotParms.ind + "&course=" + slotParms.returnCourse + "&email=" + slotParms.sendEmail + "&jump=" + slotParms.jump + "&name=" +slotParms.event+ "&hide=" +hideUnavail+ "\">");
      out.println("</HEAD>");
      out.println("<BODY bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<CENTER><BR>");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<BR><BR><H2>Return Accepted</H2>");
      out.println("<BR><BR>Thank you, click Return' below if this does not automatically return.<BR>");
      out.println("<BR><BR>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"index\" value=" + slotParms.ind + "></input>");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.returnCourse + "\"></input>");
      out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
      out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
      out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\"></form>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;

   } else {    // not a 'return' response from prompt 

      //
      //  This is either the first time here, or a 'Continue' reply to a prompt
      //
      //
      p1 = slotParms.player1;      // get players' names for easier reference
      p2 = slotParms.player2;
      p3 = slotParms.player3;
      p4 = slotParms.player4;
      p5 = slotParms.player5;


      //
      //  If any skips are set, then we've already been through here.
      //
      if (skip == 0) {

         //
         //  Check if 'TO' tee time is empty
         //
         if (!p1.equals( "" ) || !p2.equals( "" ) || !p3.equals( "" ) || !p4.equals( "" ) || !p5.equals( "" )) {

            //
            //  Tee time is occupied - inform user and ask to continue or cancel
            //
            out.println(SystemUtils.HeadTitle("Edit Tee Sheet - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Tee Time is Occupied</H3><BR>");
            out.println("<BR>WARNING: The tee time you are trying to move TO is already occupied.");
            out.println("<BR><BR>If you continue, this tee time will effectively be cancelled.");
            out.println("<BR><BR>Would you like to continue and overwrite this tee time?");
            out.println("<BR><BR>");

            out.println("<BR><BR>Course = " +slotParms.to_course+ ", p1= " +p1+ ", p2= " +p2+ ", p3= " +p3+ ", p4= " +p4+ ", p5= " +p5+ ".");
            out.println("<BR><BR>");

            //
            //  Return to _insert as directed
            //
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"1\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }
        
      //
      //  check if we are to skip this test
      //
      if (skip < 2) {
        
         //
         // *******************************************************************************
         //  Check member restrictions in 'TO' tee time, but 'FROM' players
         //
         //     First, find all restrictions within date & time constraints on this course.
         //     Then, find the ones for this day.
         //     Then, find any for this member type or membership type (all 5 players).
         //
         // *******************************************************************************
         //

         //
         //  allocate and setup new parm block to hold the tee time parms for this process
         //
         parmSlot slotParms2 = new parmSlot();          // allocate a parm block

         slotParms2.date = date;                 // get 'TO' info
         slotParms2.time = slotParms.to_time;
         slotParms2.course = slotParms.to_course;
         slotParms2.fb = slotParms.to_fb;
         slotParms2.day = slotParms.day;
            
         slotParms2.player1 = player1;          // get 'FROM' info      
         slotParms2.player2 = player2;
         slotParms2.player3 = player3;
         slotParms2.player4 = player4;
         slotParms2.player5 = player5;

         try {

            verifySlot.parseGuests(slotParms2, con);     // check for guests and set guest types

            error = verifySlot.parseNames(slotParms2, "pro");   // get the names (lname, fname, mi)

            verifySlot.getUsers(slotParms2, con);        // get the mship and mtype info (needs lname, fname, mi)

            error = false;                               // init error indicator

            error = verifySlot.checkMemRests(slotParms2, con);      // check restrictions  

         }
         catch (Exception ignore) {
         }                           

         if (error == true) {          // if we hit on a restriction
           
            //
            //  Prompt user to see if he wants to override this violation 
            //
            out.println(SystemUtils.HeadTitle("Edit Tee Sheet - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Member Restricted</H3><BR>");
            out.println("<BR>Sorry, <b>" + slotParms2.player + "</b> is restricted from playing during this time.<br><br>");
            out.println("This time slot has the following restriction:  <b>" + slotParms2.rest_name + "</b><br><br>");
            out.println("<BR><BR>Would you like to override the restriction and allow this reservation?");
            out.println("<BR><BR>");

            //
            //  Return to _insert as directed
            //
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"2\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }

      //
      //  check if we are to skip this test
      //
      if (skip < 3) {

         //
         // *******************************************************************************
         //  Check 5-some restrictions - use 'FROM' player5 and 'TO' tee time slot
         //
         //   If 5-somes are restricted during this tee time, warn the proshop user.
         // *******************************************************************************
         //
         if ((!player5.equals( "" )) && (!slotParms.rest5.equals( "" ))) { // if 5-somes restricted prompt user to skip test

            //
            //  Prompt user to see if he wants to override this violation
            //
            out.println(SystemUtils.HeadTitle("Edit Tee Sheet - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Member Restricted</H3><BR>");
            out.println("<BR>Sorry, <b>5-somes</b> are restricted during this time.<br><br>");
            out.println("<BR><BR>Would you like to override the restriction and allow this reservation?");
            out.println("<BR><BR>");

            //
            //  Return to _insert as directed
            //
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"3\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }

      //
      //  check if we are to skip this test
      //
      if (skip < 4) {

         //
         // *******************************************************************************
         //  Check 5-somes allowed on 'to course' and from-player5 specified
         // *******************************************************************************
         //
         if (!player5.equals( "" )) {      // if player5 exists in 'from' slot

            fives = 0;

            try {

               PreparedStatement pstmtc = con.prepareStatement (
                  "SELECT fives " +
                  "FROM clubparm2 WHERE courseName = ?");

               pstmtc.clearParameters();        // clear the parms
               pstmtc.setString(1, slotParms.to_course);
               rs = pstmtc.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  fives = rs.getInt("fives");
               }
               pstmtc.close();
            }
            catch (Exception e) {
            }
           
            if (fives == 0) {      // if 5-somes not allowed on to_course

               //
               //  Prompt user to see if he wants to override this violation
               //
               out.println(SystemUtils.HeadTitle("Edit Tee Sheet - Reject"));
               out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><BR><H3>5-Somes Restricted</H3><BR>");
               out.println("<BR>Sorry, <b>5-somes</b> are not allowed on the course player5 is being moved to.");
               out.println("<BR>Player5 will be lost if you continue.<br><br>");
               out.println("<BR><BR>Would you like to move this tee time without player5?");
               out.println("<BR><BR>");

               //
               //  Return to _insert as directed
               //
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
               out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
               out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
               out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
               out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
               out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
               out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
               out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
               out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
               out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
               out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
               out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
               out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
               out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
               out.println("</form></font>");

               out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
               out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
               out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
               out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
               out.println("<input type=\"hidden\" name=\"day\" value=\"" + slotParms.day + "\">");
               out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
               out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
               out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
               out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
               out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
               out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
               out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hideUnavail + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
               out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
               out.println("<input type=\"hidden\" name=\"skip\" value=\"4\">");
               out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
               out.println("</CENTER></BODY></HTML>");
               out.close();
               return;
            }
         }
      }

   }     // end of IF 'return' reply from prompt

   //
   //  If we get here, then the  move is OK 
   //
   //   - move 'FROM' tee time info into this one (TO)
   //
   if (skip == 4) {      // if player5 being moved to course that does not allow 5-somes
     
      player5 = "";
      user5 = "";
      userg5 = "";
   }        
  
   in_use = 0;
     

   //
   //  Make sure we have the players and other info (this has failed before!!!)
   //
   if (!player1.equals( "" ) || !player2.equals( "" ) || !player3.equals( "" ) || !player4.equals( "" ) || !player5.equals( "" )) {

      try {

         PreparedStatement pstmt6 = con.prepareStatement (
            "UPDATE teecurr2 SET player1 = ?, player2 = ?, player3 = ?, player4 = ?, " +
            "username1 = ?, username2 = ?, username3 = ?, username4 = ?, p1cw = ?, " +
            "p2cw = ?, p3cw = ?, p4cw = ?,  in_use = ?, hndcp1 = ?, hndcp2 = ?, hndcp3 = ?, " +
            "hndcp4 = ?, show1 = ?, show2 = ?, show3 = ?, show4 = ?, player5 = ?, username5 = ?, " +
            "p5cw = ?, hndcp5 = ?, show5 = ?, notes = ?, hideNotes = ?, " +
            "mNum1 = ?, mNum2 = ?, mNum3 = ?, mNum4 = ?, mNum5 = ?, " +
            "userg1 = ?, userg2 = ?, userg3 = ?, userg4 = ?, userg5 = ?, orig_by = ?, conf = ?, " +
            "p91 = ?, p92 = ?, p93 = ?, p94 = ?, p95 = ?, pos1 = ?, pos2 = ?, pos3 = ?, pos4 = ?, pos5 = ?, lottery_email = 2 " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt6.clearParameters();        // clear the parms
         pstmt6.setString(1, player1);
         pstmt6.setString(2, player2);
         pstmt6.setString(3, player3);
         pstmt6.setString(4, player4);
         pstmt6.setString(5, user1);
         pstmt6.setString(6, user2);
         pstmt6.setString(7, user3);
         pstmt6.setString(8, user4);
         pstmt6.setString(9, p1cw);
         pstmt6.setString(10, p2cw);
         pstmt6.setString(11, p3cw);
         pstmt6.setString(12, p4cw);
         pstmt6.setInt(13, in_use);            // set in_use to NOT
         pstmt6.setFloat(14, hndcp1);
         pstmt6.setFloat(15, hndcp2);
         pstmt6.setFloat(16, hndcp3);
         pstmt6.setFloat(17, hndcp4);
         pstmt6.setShort(18, show1);
         pstmt6.setShort(19, show2);
         pstmt6.setShort(20, show3);
         pstmt6.setShort(21, show4);
         pstmt6.setString(22, player5);
         pstmt6.setString(23, user5);
         pstmt6.setString(24, p5cw);
         pstmt6.setFloat(25, hndcp5);
         pstmt6.setShort(26, show5);
         pstmt6.setString(27, notes);
         pstmt6.setInt(28, hide);
         pstmt6.setString(29, mNum1);
         pstmt6.setString(30, mNum2);
         pstmt6.setString(31, mNum3);
         pstmt6.setString(32, mNum4);
         pstmt6.setString(33, mNum5);
         pstmt6.setString(34, userg1);
         pstmt6.setString(35, userg2);
         pstmt6.setString(36, userg3);
         pstmt6.setString(37, userg4);
         pstmt6.setString(38, userg5);
         pstmt6.setString(39, orig_by);
         pstmt6.setString(40, conf);
         pstmt6.setInt(41, p91);
         pstmt6.setInt(42, p92);
         pstmt6.setInt(43, p93);
         pstmt6.setInt(44, p94);
         pstmt6.setInt(45, p95);
         pstmt6.setShort(46, pos1);
         pstmt6.setShort(47, pos2);
         pstmt6.setShort(48, pos3);
         pstmt6.setShort(49, pos4);
         pstmt6.setShort(50, pos5);

         pstmt6.setLong(51, date);
         pstmt6.setInt(52, slotParms.to_time);
         pstmt6.setInt(53, slotParms.to_fb);
         pstmt6.setString(54, slotParms.to_course);

         pstmt6.executeUpdate();      // execute the prepared stmt

         pstmt6.close();

      }
      catch (Exception e1) {

         String eMsg = "Error 3 in moveWhole. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }

      //
      //  Track the history of this tee time - make entry in 'teehist' table (check if new or update)
      //
      String fullName = "Edit Tsheet Moved From " + slotParms.from_time;

      //  new tee time
      SystemUtils.updateHist(date, slotParms.day, slotParms.to_time, slotParms.to_fb, slotParms.to_course, player1, player2, player3,
                             player4, player5, slotParms.user, fullName, 0, con);


      //
      //  Finally, set the 'FROM' tee time to NOT in use and clear out the players
      //
      try {

         PreparedStatement pstmt5 = con.prepareStatement (
            "UPDATE teecurr2 SET player1 = '', player2 = '', player3 = '', player4 = '', " +
            "username1 = '', username2 = '', username3 = '', username4 = '', " +
            "in_use = 0, show1 = 0, show2 = 0, show3 = 0, show4 = 0, " +
            "player5 = '', username5 = '', show5 = 0, " +
            "notes = '', " +
            "mNum1 = '', mNum2 = '', mNum3 = '', mNum4 = '', mNum5 = '', " +
            "userg1 = '', userg2 = '', userg3 = '', userg4 = '', userg5 = '', orig_by = '', conf = '', " +
            "pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0, pos5 = 0, lottery_email = 0 " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt5.clearParameters();        // clear the parms
         pstmt5.setLong(1, date);
         pstmt5.setInt(2, slotParms.from_time);
         pstmt5.setInt(3, slotParms.from_fb);
         pstmt5.setString(4, slotParms.from_course);

         pstmt5.executeUpdate();      // execute the prepared stmt

         pstmt5.close();

         if (slotParms.sendEmail.equalsIgnoreCase( "yes" )) {        // if ok to send emails

            sendemail = 1;          // tee time moved - send email notification
         }

      }
      catch (Exception e1) {

         String eMsg = "Error 4 in moveWhole. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }

      //
      //  Track the history of this tee time - make entry in 'teehist' table (check if new or update)
      //
      String empty = "";
      fullName = "Edit Tsheet Move To " + slotParms.to_time;

      SystemUtils.updateHist(date, slotParms.day, slotParms.from_time, slotParms.from_fb, slotParms.from_course, empty, empty, empty,
                             empty, empty, slotParms.user, fullName, 1, con);

   } else {
     
      //
      //  save message in error log
      //
      String msg = "Error in Proshop_devnt.moveWhole - Player names lost " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.from_time+ ", course= " +slotParms.from_course+ ", fb= " +slotParms.from_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      teeBusy(out, slotParms, req);        // pretend its busy
      return;
   }

   //
   //  Done - return
   //
   editDone(out, slotParms, resp, req);

   try {

      resp.flushBuffer();      // force the repsonse to complete

   }
   catch (Exception ignore) {
   }

   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   if (sendemail != 0) {

      //
      //  allocate a parm block to hold the email parms
      //
      parmEmail parme = new parmEmail();          // allocate an Email parm block

      //
      //  Set the values in the email parm block
      //
      parme.type = "moveWhole";         // type = Move Whole tee time
      parme.date = date;
      parme.time = 0;
      parme.to_time = slotParms.to_time;
      parme.from_time = slotParms.from_time;
      parme.fb = 0;
      parme.to_fb = slotParms.to_fb;
      parme.from_fb = slotParms.from_fb;
      parme.to_course = slotParms.to_course;
      parme.from_course = slotParms.from_course;
      parme.mm = slotParms.mm;
      parme.dd = slotParms.dd;
      parme.yy = slotParms.yy;

      parme.user = slotParms.user;
      parme.emailNew = 0;
      parme.emailMod = 0;
      parme.emailCan = 0;

      parme.p91 = p91;
      parme.p92 = p92;
      parme.p93 = p93;
      parme.p94 = p94;
      parme.p95 = p95;

      parme.day = slotParms.day;

      parme.player1 = player1;
      parme.player2 = player2;
      parme.player3 = player3;
      parme.player4 = player4;
      parme.player5 = player5;

      parme.user1 = user1;
      parme.user2 = user2;
      parme.user3 = user3;
      parme.user4 = user4;
      parme.user5 = user5;

      parme.pcw1 = p1cw;
      parme.pcw2 = p2cw;
      parme.pcw3 = p3cw;
      parme.pcw4 = p4cw;
      parme.pcw5 = p5cw;

      //
      //  Send the email
      //
      sendEmail.sendIt(parme, con);      // in common

   }     // end of IF sendemail
 }      // end of moveWhole


 // *********************************************************
 //  moveSingle - move a single player
 //
 //  parms:
 //          jump        = jump index for return
 //          from_player = player position being moved (1-5)
 //          from_time   = tee time being moved
 //          from_fb     = f/b of tee time being moved
 //          from_course = name of course
 //          to_player   = player position to move to (1-5)
 //          to_time     = tee time to move to
 //          to_fb       = f/b of tee time to move to
 //          to_course   = name of course
 //
 //          prompt      = null if first call here
 //                      = 'return' if user wants to return w/o changes
 //                      = 'continue' if user wants to continue with changes
 //          skip        = verification process to skip if 2nd return
 //
 // *********************************************************

 private void moveSingle(parmSlot slotParms, long date, String prompt, int skip, HttpServletRequest req, 
                         PrintWriter out, Connection con, HttpServletResponse resp) {


   PreparedStatement pstmt6 = null;
   ResultSet rs = null;

   int fives = 0;
   int in_use = 0;
   int from = slotParms.from_player;     // get the player positions (1-5)
   int fr = from;                        // save original value 
   int to = slotParms.to_player;
   int sendemail = 0;

   //
   //  arrays to hold the player info (FROM tee time)
   //
   String [] p = new String [5];
   String [] player = new String [5];
   String [] pcw = new String [5];
   String [] user = new String [5];
   String [] mNum = new String [5];
   String [] userg = new String [5];
   short [] show = new short [5];
   short [] pos = new short [5];
   float [] hndcp = new float [5];
   int [] p9 = new int [5];
     
   boolean error = false;

   String fullName = "Proshop Edit Event";      // for tee time history

   String hide = req.getParameter("hide");

   //
   //  adjust the player positions so they can be used for array indexes
   //
   if (to > 0 && to < 6) {
     
      to--;
        
   } else {
     
      to = 1;    // prevent big problem
   }
   if (from > 0 && from < 6) {

      from--;

   } else {

      from = 1;    // prevent big problem
   }

   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.from_time == 0 || slotParms.from_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.moveSingle - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.from_time+ ", course= " +slotParms.from_course+ ", fb= " +slotParms.from_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Check if the requested tee time is currently in use (the FROM tee time)
      //
      try {

         //
         //  If we got here by returning from a prompt below, then tee time is already busy
         //
         if (!prompt.equals( "" )) {        // if return, tee time already busy

            in_use = 0;

            getTeeTimeData(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms, con);

         } else {

            in_use = verifySlot.checkInUse(date, slotParms.from_time, slotParms.from_fb, slotParms.from_course, slotParms.user, slotParms, con);
         }

      }
      catch (Exception e1) {

         String eMsg = "Error 1 in moveSingle. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }

   if (in_use != 0) {              // if time slot already in use

      teeBusy(out, slotParms, req);       // first call here - reject as busy
      return;
   }

   //
   //  Ok - get current 'FROM' player info from the parm block (set by checkInUse) and save it
   //
   player[0] = slotParms.player1;
   player[1] = slotParms.player2;
   player[2] = slotParms.player3;
   player[3] = slotParms.player4;
   player[4] = slotParms.player5;
   pcw[0] = slotParms.p1cw;
   pcw[1] = slotParms.p2cw;
   pcw[2] = slotParms.p3cw;
   pcw[3] = slotParms.p4cw;
   pcw[4] = slotParms.p5cw;
   user[0] = slotParms.user1;
   user[1] = slotParms.user2;
   user[2] = slotParms.user3;
   user[3] = slotParms.user4;
   user[4] = slotParms.user5;
   hndcp[0] = slotParms.hndcp1;
   hndcp[1] = slotParms.hndcp2;
   hndcp[2] = slotParms.hndcp3;
   hndcp[3] = slotParms.hndcp4;
   hndcp[4] = slotParms.hndcp5;
   show[0] = slotParms.show1;
   show[1] = slotParms.show2;
   show[2] = slotParms.show3;
   show[3] = slotParms.show4;
   show[4] = slotParms.show5;
   mNum[0] = slotParms.mNum1;
   mNum[1] = slotParms.mNum2;
   mNum[2] = slotParms.mNum3;
   mNum[3] = slotParms.mNum4;
   mNum[4] = slotParms.mNum5;
   userg[0] = slotParms.userg1;
   userg[1] = slotParms.userg2;
   userg[2] = slotParms.userg3;
   userg[3] = slotParms.userg4;
   userg[4] = slotParms.userg5;
   p9[0] = slotParms.p91;
   p9[1] = slotParms.p92;
   p9[2] = slotParms.p93;
   p9[3] = slotParms.p94;
   p9[4] = slotParms.p95;
   pos[0] = slotParms.pos1;
   pos[1] = slotParms.pos2;
   pos[2] = slotParms.pos3;
   pos[3] = slotParms.pos4;
   pos[4] = slotParms.pos5;


   slotParms.player1 = "";       // init parmSlot player fields (verifySlot will fill)
   slotParms.player2 = "";
   slotParms.player3 = "";
   slotParms.player4 = "";
   slotParms.player5 = "";

   //
   //  Verify the required parms exist
   //
   if (date == 0 || slotParms.to_time == 0 || slotParms.to_course == null || slotParms.user.equals( "" ) || slotParms.user == null) {

      //
      //  save message in /" +rev+ "/error.txt
      //
      String msg = "Error in Proshop_devnt.moveSingle2 - checkInUse Parms - for user " +slotParms.user+ " at " +slotParms.club+ ".  Date= " +date+ ", time= " +slotParms.to_time+ ", course= " +slotParms.to_course+ ", fb= " +slotParms.to_fb;   // build msg
      SystemUtils.logError(msg);                                   // log it

      in_use = 1;          // make like the time is busy

   } else {               // continue if parms ok

      //
      //  Now check if the 'TO' tee time is currently in use (this will put its info in slotParms)
      //
      try {

         //
         //  If we got here by returning from a prompt below, then tee time is already busy
         //
         if (!prompt.equals( "" )) {        // if return, tee time already busy

            in_use = 0;

            getTeeTimeData(date, slotParms.to_time, slotParms.to_fb, slotParms.to_course, slotParms, con);

         } else {

            in_use = verifySlot.checkInUse(date, slotParms.to_time, slotParms.to_fb, slotParms.to_course, slotParms.user, slotParms, con);
         }

      }
      catch (Exception e1) {

         String eMsg = "Error 2 in moveSingle. ";
         dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
         return;
      }
   }

   //
   //  If 'TO' tee time is in use 
   //
   if (in_use != 0) { 

      //
      //  Error - We must free up the 'FROM' tee time
      //
      try {

         PreparedStatement pstmt4 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = 0 " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt4.clearParameters();        // clear the parms
         pstmt4.setLong(1, date);
         pstmt4.setInt(2, slotParms.from_time);
         pstmt4.setInt(3, slotParms.from_fb);
         pstmt4.setString(4, slotParms.from_course);
         pstmt4.executeUpdate();      // execute the prepared stmt
         pstmt4.close();

      }
      catch (Exception ignore) {
      }

      teeBusy(out, slotParms, req);
      return;
   }

   //
   //  If user was prompted and opted to return w/o changes, then we must clear the 'in_use' flags
   //  before returning to the tee sheet.
   //
   if (prompt.equals( "return" )) {        // if prompt specified a return

      in_use = 0;

      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = ? " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setInt(1, in_use);
         pstmt1.setLong(2, date);
         pstmt1.setInt(3, slotParms.from_time);
         pstmt1.setInt(4, slotParms.from_fb);
         pstmt1.setString(5, slotParms.from_course);

         pstmt1.executeUpdate();      // execute the prepared stmt

         pstmt1.close();

         pstmt1 = con.prepareStatement (
            "UPDATE teecurr2 SET in_use = ? " +
            "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setInt(1, in_use);
         pstmt1.setLong(2, date);
         pstmt1.setInt(3, slotParms.to_time);
         pstmt1.setInt(4, slotParms.to_fb);
         pstmt1.setString(5, slotParms.to_course);

         pstmt1.executeUpdate();      // execute the prepared stmt

         pstmt1.close();

      }
      catch (Exception ignore) {
      }

      // return to Proshop_devnt

      out.println("<HTML><HEAD><Title>Proshop Edit Event Complete</Title>");
      out.println("<meta http-equiv=\"Refresh\" content=\"0; url=/" +rev+ "/servlet/Proshop_devnt?index=" + slotParms.ind + "&course=" + slotParms.returnCourse + "&email=" + slotParms.sendEmail + "&jump=" + slotParms.jump + "&hide=" +hide+ "&name=" +slotParms.event+ "\">");
      out.println("</HEAD>");
      out.println("<BODY bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<CENTER><BR>");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<BR><BR><H2>Return Accepted</H2>");
      out.println("<BR><BR>Thank you, click Return' below if this does not automatically return.<BR>");
      out.println("<BR><BR>");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"index\" value=" + slotParms.ind + "></input>");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.returnCourse + "\"></input>");
      out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
      out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
      out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\"></form>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;

   } else {    // not a 'return' response from prompt

      //
      //  This is either the first time here, or a 'Continue' reply to a prompt
      //
      p[0] = slotParms.player1;    // save 'TO' player names
      p[1] = slotParms.player2;
      p[2] = slotParms.player3;
      p[3] = slotParms.player4;
      p[4] = slotParms.player5;


      //
      //  Make sure there are no duplicate names
      //
      if (!user[from].equals( "" )) {         // if player is a member
        
         if ((player[from].equalsIgnoreCase( p[0] )) || (player[from].equalsIgnoreCase( p[1] )) ||
             (player[from].equalsIgnoreCase( p[2] )) || (player[from].equalsIgnoreCase( p[3] )) ||
             (player[from].equalsIgnoreCase( p[4] ))) {

            //
            //  Error - name already exists
            //
            in_use = 0;

            try {

               PreparedStatement pstmt1 = con.prepareStatement (
                  "UPDATE teecurr2 SET in_use = ? " +
                  "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setInt(1, in_use);
               pstmt1.setLong(2, date);
               pstmt1.setInt(3, slotParms.from_time);
               pstmt1.setInt(4, slotParms.from_fb);
               pstmt1.setString(5, slotParms.from_course);

               pstmt1.executeUpdate();      // execute the prepared stmt

               pstmt1.close();

               pstmt1 = con.prepareStatement (
                  "UPDATE teecurr2 SET in_use = ? " +
                  "WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setInt(1, in_use);
               pstmt1.setLong(2, date);
               pstmt1.setInt(3, slotParms.to_time);
               pstmt1.setInt(4, slotParms.to_fb);
               pstmt1.setString(5, slotParms.to_course);

               pstmt1.executeUpdate();      // execute the prepared stmt

               pstmt1.close();

            }
            catch (Exception ignore) {
            }

            out.println(SystemUtils.HeadTitle("Player Move Error"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Player Move Error</H3>");
            out.println("<BR><BR>Sorry, but the selected player is already scheduled at the time you are moving to.");
            out.println("<BR><BR>");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"index\" value=" + slotParms.ind + "></input>");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.returnCourse + "\"></input>");
               out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
               out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"submit\" value=\"Back to Edit\" style=\"text-decoration:underline; background:#8B8970\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }

      //
      //  If any skips are set, then we've already been through here.
      //
      if (skip == 0) {

         //
         //  Check if 'TO' tee time position is empty
         //
         if (!p[to].equals( "" )) {

            //
            //  Tee time is occupied - inform user and ask to continue or cancel
            //
            out.println(SystemUtils.HeadTitle("Edit Event - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Tee Time Position is Occupied</H3><BR>");
            out.println("<BR>WARNING: The tee time position you are trying to move TO is already occupied.");
            out.println("<BR><BR>If you continue, the current player in this position (" +p[to]+ ") will be replaced.");
            out.println("<BR><BR>Would you like to continue and replace this player?");
            out.println("<BR><BR>");
               
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"1\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
           
         //
         // *******************************************************************************
         //  Check 5-somes allowed on 'to course' if moving to player5 slot
         // *******************************************************************************
         //
         if (to == 4) {      // if player being moved to player5 slot

            fives = 0;

            try {

               PreparedStatement pstmtc = con.prepareStatement (
                  "SELECT fives " +
                  "FROM clubparm2 WHERE courseName = ?");

               pstmtc.clearParameters();        // clear the parms
               pstmtc.setString(1, slotParms.to_course);
               rs = pstmtc.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  fives = rs.getInt("fives");
               }
               pstmtc.close();
            }
            catch (Exception e) {
            }

            if (fives == 0) {      // if 5-somes not allowed on to_course

               out.println(SystemUtils.HeadTitle("Player Move Error"));
               out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><BR><H3>Player Move Error</H3>");
               out.println("<BR><BR>Sorry, but the course you are moving the player to does not support 5-somes.");
               out.println("<BR><BR>");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
               out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
               out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
               out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
               out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
               out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
               out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
               out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
               out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
               out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
               out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
               out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
               out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
               out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
               out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
               out.println("</form></font>");
               out.println("</CENTER></BODY></HTML>");
               out.close();
               return;
            }
         }

      }
        
      //
      //  check if we are to skip this test
      //
      if (skip < 2) {

         //
         // *******************************************************************************
         //  Check member restrictions in 'TO' tee time, but 'FROM' players
         //
         //     First, find all restrictions within date & time constraints on this course.
         //     Then, find the ones for this day.
         //     Then, find any for this member type or membership type (all 5 players).
         //
         // *******************************************************************************
         //

         //
         //  allocate and setup new parm block to hold the tee time parms for this process
         //
         parmSlot slotParms2 = new parmSlot();          // allocate a parm block

         slotParms2.date = date;                 // get 'TO' info
         slotParms2.time = slotParms.to_time;
         slotParms2.course = slotParms.to_course;
         slotParms2.fb = slotParms.to_fb;
         slotParms2.day = slotParms.day;

         slotParms2.player1 = player[from];          // get 'FROM' player (only check this player)

         try {

            verifySlot.parseGuests(slotParms2, con);     // check for guest and set guest type

            error = verifySlot.parseNames(slotParms2, "pro");   // get the name (lname, fname, mi)

            verifySlot.getUsers(slotParms2, con);        // get the mship and mtype info (needs lname, fname, mi)

            error = false;                               // init error indicator

            error = verifySlot.checkMemRests(slotParms2, con);      // check restrictions

         }
         catch (Exception ignore) {
         }

         if (error == true) {          // if we hit on a restriction

            //
            //  Prompt user to see if he wants to override this violation
            //
            out.println(SystemUtils.HeadTitle("Edit Event - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Member Restricted</H3><BR>");
            out.println("<BR>Sorry, <b>" +player[from]+ "</b> is restricted from playing during this time.<br><br>");
            out.println("This time slot has the following restriction:  <b>" + slotParms2.rest_name + "</b><br><br>");
            out.println("<BR><BR>Would you like to override the restriction and allow this reservation?");
            out.println("<BR><BR>");

            //
            //  Return to _insert as directed
            //
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"2\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }

      //
      //  check if we are to skip this test
      //
      if (skip < 3) {

         //
         // *******************************************************************************
         //  Check 5-some restrictions - use 'FROM' player5 and 'TO' tee time slot
         //
         //   If moving to position 5 & 5-somes are restricted during this tee time, warn the proshop user.
         // *******************************************************************************
         //
         if ((to == 4) && (!slotParms.rest5.equals( "" ))) { // if 5-somes restricted prompt user to skip test

            //
            //  Prompt user to see if he wants to override this violation
            //
            out.println(SystemUtils.HeadTitle("Edit Event - Reject"));
            out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><BR><H3>Member Restricted</H3><BR>");
            out.println("<BR>Sorry, <b>5-somes</b> are restricted during this time.<br><br>");
            out.println("<BR><BR>Would you like to override the restriction and allow this reservation?");
            out.println("<BR><BR>");

            //
            //  Return to _insert as directed
            //
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"return\">");
            out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");

            out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
            out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + slotParms.returnCourse + "\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
            out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
            out.println("<input type=\"hidden\" name=\"to_player\" value=\"" + slotParms.to_player + "\">");
            out.println("<input type=\"hidden\" name=\"from_player\" value=\"" + slotParms.from_player + "\">");
            out.println("<input type=\"hidden\" name=\"to_time\" value=\"" + slotParms.to_time + "\">");
            out.println("<input type=\"hidden\" name=\"from_time\" value=\"" + slotParms.from_time + "\">");
            out.println("<input type=\"hidden\" name=\"to_fb\" value=\"" + slotParms.to_fb + "\">");
            out.println("<input type=\"hidden\" name=\"from_fb\" value=\"" + slotParms.from_fb + "\">");
            out.println("<input type=\"hidden\" name=\"to_course\" value=\"" + slotParms.to_course + "\">");
            out.println("<input type=\"hidden\" name=\"from_course\" value=\"" + slotParms.from_course + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
            out.println("<input type=\"hidden\" name=\"prompt\" value=\"continue\">");
            out.println("<input type=\"hidden\" name=\"skip\" value=\"3\">");
            out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submit\"></form>");
            out.println("</CENTER></BODY></HTML>");
            out.close();
            return;
         }
      }

   }     // end of IF 'return' reply from prompt


   //
   //  OK to move player - move 'FROM' player info into this tee time (TO position)
   //
   to++;      // change index back to position value

   String moveP1 = "UPDATE teecurr2 " +
                   "SET player" +to+ " = ?, username" +to+ " = ?, p" +to+ "cw = ?, " +
                        "in_use = 0, hndcp" +to+ " = ?, show" +to+ " = ?, mNum" +to+ " = ?, " +
                        "userg" +to+ " = ?, p9" +to+ " = ?, pos" +to+ " = ?, lottery_email = 2 " +
                   "WHERE date = ? AND time = ? AND fb = ? AND courseName=?";
     
   try {

      pstmt6 = con.prepareStatement (moveP1);

      pstmt6.clearParameters();        // clear the parms
      pstmt6.setString(1, player[from]);
      pstmt6.setString(2, user[from]);
      pstmt6.setString(3, pcw[from]);
      pstmt6.setFloat(4, hndcp[from]);
      pstmt6.setShort(5, show[from]);
      pstmt6.setString(6, mNum[from]);
      pstmt6.setString(7, userg[from]);
      pstmt6.setInt(8, p9[from]);
      pstmt6.setShort(9, pos[from]);

      pstmt6.setLong(10, date);
      pstmt6.setInt(11, slotParms.to_time);
      pstmt6.setInt(12, slotParms.to_fb);
      pstmt6.setString(13, slotParms.to_course);

      pstmt6.executeUpdate();      // execute the prepared stmt

      pstmt6.close();


      if (slotParms.sendEmail.equalsIgnoreCase( "yes" )) {        // if ok to send emails

         sendemail = 1;       // send email notification
      }

      //
      //  Track the history of this tee time - make entry in 'teehist' table (first, get the new players)
      //
      pstmt6 = con.prepareStatement (
      "SELECT player1, player2, player3, player4, player5 " +
      "FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

      pstmt6.clearParameters();        // clear the parms
      pstmt6.setLong(1, date);
      pstmt6.setInt(2, slotParms.to_time);
      pstmt6.setInt(3, slotParms.to_fb);
      pstmt6.setString(4, slotParms.to_course);
      rs = pstmt6.executeQuery();

      if (rs.next()) {

         player[0] = rs.getString(1);
         player[1] = rs.getString(2);
         player[2] = rs.getString(3);
         player[3] = rs.getString(4);
         player[4] = rs.getString(5);
      }
      pstmt6.close();

      fullName = "Edit Tsheet Move Player From " +slotParms.from_time;
      
      SystemUtils.updateHist(date, slotParms.day, slotParms.to_time, slotParms.to_fb, slotParms.to_course, player[0], player[1], player[2],
                             player[3], player[4], slotParms.user, fullName, 1, con);

   }
   catch (Exception e1) {

      String eMsg = "Error 3 in moveSingle. ";
      dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
      return;
   }


   //
   //  Finally, set the 'FROM' tee time to NOT in use and clear out the player info
   //
   String moveP2 = "UPDATE teecurr2 " +
                   "SET player" +fr+ " = '', username" +fr+ " = '', p" +fr+ "cw = '', in_use = 0, " +
                       "show" +fr+ " = 0, mNum" +fr+ " = '', userg" +fr+ " = '', pos" +fr+ " = 0, lottery_email = 0 " +
                   "WHERE date = ? AND time = ? AND fb = ? AND courseName=?";

   try {

      PreparedStatement pstmt5 = con.prepareStatement (moveP2);

      pstmt5.clearParameters();        // clear the parms
      pstmt5.setLong(1, date);
      pstmt5.setInt(2, slotParms.from_time);
      pstmt5.setInt(3, slotParms.from_fb);
      pstmt5.setString(4, slotParms.from_course);

      pstmt5.executeUpdate();      // execute the prepared stmt

      pstmt5.close();


      //
      //  Track the history of this tee time - make entry in 'teehist' table (first get the new player list)
      //
      pstmt6 = con.prepareStatement (
      "SELECT player1, player2, player3, player4, player5 " +
      "FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

      pstmt6.clearParameters();        // clear the parms
      pstmt6.setLong(1, date);
      pstmt6.setInt(2, slotParms.from_time);
      pstmt6.setInt(3, slotParms.from_fb);
      pstmt6.setString(4, slotParms.from_course);
      rs = pstmt6.executeQuery();

      if (rs.next()) {

         player[0] = rs.getString(1);
         player[1] = rs.getString(2);
         player[2] = rs.getString(3);
         player[3] = rs.getString(4);
         player[4] = rs.getString(5);
      }
      pstmt6.close();

      fullName = "Edit Tsheet Move Player To " +slotParms.to_time; 
      
      SystemUtils.updateHist(date, slotParms.day, slotParms.from_time, slotParms.from_fb, slotParms.from_course, player[0], player[1], player[2],
                             player[3], player[4], slotParms.user, fullName, 1, con);


   }
   catch (Exception e1) {

      String eMsg = "Error 4 in moveSingle. ";
      dbError(out, e1, slotParms.ind, slotParms.returnCourse, eMsg);
      return;
   }

   //
   //  Done - return
   //
   editDone(out, slotParms, resp, req);

   try {

      resp.flushBuffer();      // force the repsonse to complete

   }
   catch (Exception ignore) {
   }

   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   if (sendemail != 0) {

      try {                 // get the new 'to' tee time values

         PreparedStatement pstmt5b = con.prepareStatement (
         "SELECT player1, player2, player3, player4, username1, username2, username3, " +
         "username4, p1cw, p2cw, p3cw, p4cw, " +
         "player5, username5, p5cw, p91, p92, p93, p94, p95 " +
         "FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

         pstmt5b.clearParameters();        // clear the parms
         pstmt5b.setLong(1, date);
         pstmt5b.setInt(2, slotParms.to_time);
         pstmt5b.setInt(3, slotParms.to_fb);
         pstmt5b.setString(4, slotParms.to_course);
         rs = pstmt5b.executeQuery();      

         if (rs.next()) {

            player[0] = rs.getString(1);
            player[1] = rs.getString(2);
            player[2] = rs.getString(3);
            player[3] = rs.getString(4);
            user[0] = rs.getString(5);
            user[1] = rs.getString(6);
            user[2] = rs.getString(7);
            user[3] = rs.getString(8);
            pcw[0] = rs.getString(9);
            pcw[1] = rs.getString(10);
            pcw[2] = rs.getString(11);
            pcw[3] = rs.getString(12);
            player[4] = rs.getString(13);
            user[4] = rs.getString(14);
            pcw[4] = rs.getString(15);
            p9[0] = rs.getInt(16);
            p9[1] = rs.getInt(17);
            p9[2] = rs.getInt(18);
            p9[3] = rs.getInt(19);
            p9[4] = rs.getInt(20);
         }
         pstmt5b.close();

      }
      catch (Exception ignoree) {
      }

      //
      //  allocate a parm block to hold the email parms
      //
      parmEmail parme = new parmEmail();          // allocate an Email parm block

      //
      //  Set the values in the email parm block
      //
      parme.type = "tee";         // type = Move Single tee time (use tee and emailMod) 
      parme.date = date;
      parme.time = slotParms.to_time;
      parme.to_time = 0;
      parme.from_time = 0;
      parme.fb = slotParms.to_fb;
      parme.to_fb = 0;
      parme.from_fb = 0;
      parme.to_course = slotParms.to_course;
      parme.from_course = slotParms.from_course;
      parme.mm = slotParms.mm;
      parme.dd = slotParms.dd;
      parme.yy = slotParms.yy;

      parme.user = slotParms.user;
      parme.emailNew = 0;
      parme.emailMod = 1;
      parme.emailCan = 0;

      parme.p91 = p9[0];
      parme.p92 = p9[1];
      parme.p93 = p9[2];
      parme.p94 = p9[3];
      parme.p95 = p9[4];

      parme.day = slotParms.day;

      parme.player1 = player[0];
      parme.player2 = player[1];
      parme.player3 = player[2];
      parme.player4 = player[3];
      parme.player5 = player[4];

      parme.oldplayer1 = slotParms.player1;
      parme.oldplayer2 = slotParms.player2;
      parme.oldplayer3 = slotParms.player3;
      parme.oldplayer4 = slotParms.player4;
      parme.oldplayer5 = slotParms.player5;

      parme.user1 = user[0];
      parme.user2 = user[1];
      parme.user3 = user[2];
      parme.user4 = user[3];
      parme.user5 = user[4];

      parme.olduser1 = slotParms.user1;
      parme.olduser2 = slotParms.user2;
      parme.olduser3 = slotParms.user3;
      parme.olduser4 = slotParms.user4;
      parme.olduser5 = slotParms.user5;

      parme.pcw1 = pcw[0];
      parme.pcw2 = pcw[1];
      parme.pcw3 = pcw[2];
      parme.pcw4 = pcw[3];
      parme.pcw5 = pcw[4];

      parme.oldpcw1 = slotParms.p1cw;
      parme.oldpcw2 = slotParms.p2cw;
      parme.oldpcw3 = slotParms.p3cw;
      parme.oldpcw4 = slotParms.p4cw;
      parme.oldpcw5 = slotParms.p5cw;

      //
      //  Send the email
      //
      sendEmail.sendIt(parme, con);      // in common

   }     // end of IF sendemail
 }      // end of moveSingle


/**
 //************************************************************************
 //
 //   Get tee time data
 //
 //************************************************************************
 **/

 private void getTeeTimeData(long date, int time, int fb, String course, parmSlot slotParms, Connection con)
         throws Exception {


   PreparedStatement pstmt = null;
   Statement stmt = null;
   ResultSet rs = null;


   try {

      pstmt = con.prepareStatement (
         "SELECT * " +
         "FROM teecurr2 WHERE date = ? AND time = ? AND fb = ? AND courseName = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setLong(1, date);         // put the parm in pstmt
      pstmt.setInt(2, time);
      pstmt.setInt(3, fb);
      pstmt.setString(4, course);
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         slotParms.player1 = rs.getString( "player1" );
         slotParms.player2 = rs.getString( "player2" );
         slotParms.player3 = rs.getString( "player3" );
         slotParms.player4 = rs.getString( "player4" );
         slotParms.user1 = rs.getString( "username1" );
         slotParms.user2 = rs.getString( "username2" );
         slotParms.user3 = rs.getString( "username3" );
         slotParms.user4 = rs.getString( "username4" );
         slotParms.p1cw = rs.getString( "p1cw" );
         slotParms.p2cw = rs.getString( "p2cw" );
         slotParms.p3cw = rs.getString( "p3cw" );
         slotParms.p4cw = rs.getString( "p4cw" );
         slotParms.last_user = rs.getString( "in_use_by" );
         slotParms.hndcp1 = rs.getFloat( "hndcp1" );
         slotParms.hndcp2 = rs.getFloat( "hndcp2" );
         slotParms.hndcp3 = rs.getFloat( "hndcp3" );
         slotParms.hndcp4 = rs.getFloat( "hndcp4" );
         slotParms.show1 = rs.getShort( "show1" );
         slotParms.show2 = rs.getShort( "show2" );
         slotParms.show3 = rs.getShort( "show3" );
         slotParms.show4 = rs.getShort( "show4" );
         slotParms.player5 = rs.getString( "player5" );
         slotParms.user5 = rs.getString( "username5" );
         slotParms.p5cw = rs.getString( "p5cw" );
         slotParms.hndcp5 = rs.getFloat( "hndcp5" );
         slotParms.show5 = rs.getShort( "show5" );
         slotParms.notes = rs.getString( "notes" );
         slotParms.hide = rs.getInt( "hideNotes" );
         slotParms.rest5 = rs.getString( "rest5" );
         slotParms.mNum1 = rs.getString( "mNum1" );
         slotParms.mNum2 = rs.getString( "mNum2" );
         slotParms.mNum3 = rs.getString( "mNum3" );
         slotParms.mNum4 = rs.getString( "mNum4" );
         slotParms.mNum5 = rs.getString( "mNum5" );
         slotParms.userg1 = rs.getString( "userg1" );
         slotParms.userg2 = rs.getString( "userg2" );
         slotParms.userg3 = rs.getString( "userg3" );
         slotParms.userg4 = rs.getString( "userg4" );
         slotParms.userg5 = rs.getString( "userg5" );
         slotParms.orig_by = rs.getString( "orig_by" );
         slotParms.conf = rs.getString( "conf" );
         slotParms.p91 = rs.getInt( "p91" );
         slotParms.p92 = rs.getInt( "p92" );
         slotParms.p93 = rs.getInt( "p93" );
         slotParms.p94 = rs.getInt( "p94" );
         slotParms.p95 = rs.getInt( "p95" );
         slotParms.pos1 = rs.getShort( "pos1" );
         slotParms.pos2 = rs.getShort( "pos2" );
         slotParms.pos3 = rs.getShort( "pos3" );
         slotParms.pos4 = rs.getShort( "pos4" );
         slotParms.pos5 = rs.getShort( "pos5" );
      }

      pstmt.close();

   }
   catch (Exception e) {

      throw new Exception("Error getting tee time data - Proshop_devnt.getTeeTimeData - Exception: " + e.getMessage());
   }

 }


 // *********************************************************
 //  Done
 // *********************************************************

 private void editDone(PrintWriter out, parmSlot slotParms, HttpServletResponse resp, HttpServletRequest req) {
   
   String hide = req.getParameter("hide");
   String limit = req.getParameter("limit");
   
   try {

       String url="/" +rev+ "/servlet/Proshop_devnt?index=" +slotParms.ind+ "&course=" + slotParms.returnCourse + "&jump=" + slotParms.jump + "&email=" + slotParms.sendEmail + "&hide=" +hide+ "&name=" + slotParms.event + "&limit=" + limit;
       resp.sendRedirect(url);

   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<CENTER><BR><BR><H3>System Error</H3>");
      out.println("<BR><BR>A system error occurred while trying to return to the edit tee sheet.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, please contact customer support.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_jump?index=" +slotParms.ind+ "&course=" +slotParms.returnCourse+ "\">");
      out.println("Return to Tee Sheet</a></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
   }
 }


 // *********************************************************
 //  Tee Time Busy Error
 // *********************************************************

 private void teeBusy(PrintWriter out, parmSlot slotParms, HttpServletRequest req) {

    String hide = req.getParameter("hide");

    out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
    out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
    out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
    out.println("<CENTER><BR><BR><H2>Tee Time Slot Busy</H2>");
    out.println("<BR><BR>Sorry, but this tee time slot is currently busy.");
    out.println("<BR><BR>If you are attempting to move a player to another position within the same tee time,");
    out.println("<BR>you will have to Return to the Tee Sheet and select that tee time to update it.");
    out.println("<BR><BR>Otherwise, please select another time or try again later.");
    out.println("<BR><BR>");
    out.println("<form action=\"/" +rev+ "/servlet/Proshop_devnt\" method=\"get\" target=\"_top\">");
     out.println("<input type=\"hidden\" name=\"index\" value=" + slotParms.ind + ">");
     out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.returnCourse + "\">");
     out.println("<input type=\"hidden\" name=\"jump\" value=\"" + slotParms.jump + "\">");
     out.println("<input type=\"hidden\" name=\"email\" value=\"" + slotParms.sendEmail + "\">");
     out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
     out.println("<input type=\"hidden\" name=\"name\" value=\"" + slotParms.event + "\">");
    out.println("<input type=\"submit\" value=\"Back to Event Management\" style=\"text-decoration:underline; background:#8B8970\"></form>");

    out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
     out.println("<input type=\"hidden\" name=\"index\" value=\"" + slotParms.ind + "\">");
     out.println("<input type=\"hidden\" name=\"course\" value=\"" + slotParms.returnCourse + "\">");
     out.println("<input type=\"submit\" value=\"Go to Tee Sheet\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
    out.println("</form>");
    out.println("</CENTER></BODY></HTML>");
    out.close();
 }


 // *********************************************************
 //  Database Error
 // *********************************************************

 private void dbError(PrintWriter out, Exception e1, int index, String course, String eMsg) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<CENTER><BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, please contact customer support.");
      out.println("<BR><BR>Error in dbError in Proshop_devnt:");
      out.println("<BR><BR>" + eMsg + " Exc= " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_jump?index=" +index+ "&course=" +course+ "\">");
      out.println("Return to Tee Sheet</a></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
 }

 
 // *********************************************************
 //  Send any unsent emails
 // *********************************************************
 
 private void sendEventEmails(String clubName, String event_name, int event_date, int index, String returnCourse, PrintWriter out, Connection con) {

    out.println("<center>");
    out.println("<h2>Sending Emails...</h2>");
    out.println("<p>THIS MAY TAKE SEVERAL MINUTES TO COMPLETE.<br><br>DO NOT CLICK YOUR BROWSERS BACK BUTTON!</p>");
    out.println("</center>");
     
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    ResultSet rs2 = null;

    String errorMsg = "";
    String course = "";
    String day = "";

    int time = 0;
    int atime1 = 0;
    int dd = 0;
    int mm = 0;
    int yy = 0;
    int afb = 0;
    int count1 = 0; // tee times that we tried to send emails to
    int count2 = 0; // number of members we found email addresses for (recipients)
    int count3 = 0; // number of actual email messages we sent to the email server

    String user1 = "";
    String user2 = "";
    String user3 = "";
    String user4 = "";
    String user5 = "";

    String player1 = "";
    String player2 = "";
    String player3 = "";
    String player4 = "";
    String player5 = "";

    String userg1 = "";
    String userg2 = "";
    String userg3 = "";
    String userg4 = "";
    String userg5 = "";

    String p1cw = "";
    String p2cw = "";
    String p3cw = "";
    String p4cw = "";
    String p5cw = "";
    
    String hole = "";
    
    int teecurr_id = 0;
    int lott_email = 0;
    int event_type = 0;
    int act_hr = 0;
    int act_min = 0;
    
    //
    //  Get today's date and time for email processing
    //
    Calendar ecal = new GregorianCalendar();               // get todays date
    int eyear = ecal.get(Calendar.YEAR);
    int emonth = ecal.get(Calendar.MONTH);
    int eday = ecal.get(Calendar.DAY_OF_MONTH);
    int e_hourDay = ecal.get(Calendar.HOUR_OF_DAY);
    int e_min = ecal.get(Calendar.MINUTE);
    
    int e_time = 0;
    long e_date = 0;
    
    //
    //   Adjust the time based on the club's time zone (we are Central)
    //
    e_time = SystemUtils.adjustTime(con, (e_hourDay * 100) + e_min);
    
    if (e_time < 0) {          // if negative, then we went back or ahead one day
        
        e_time = 0 - e_time;        // convert back to positive value
        
        //
        // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
        //
        ecal.add(Calendar.DATE,( (e_time < 100) ? 1 : -1) );                     // get next day's date

        eyear = ecal.get(Calendar.YEAR);
        emonth = ecal.get(Calendar.MONTH);
        eday = ecal.get(Calendar.DAY_OF_MONTH);
    
    }
    
    emonth++;                            // month starts at zero
    int e_hour = e_time / 100;           // get adjusted hour
    e_min = e_time - (e_hour * 100);     // get minute value
    int e_am_pm = 0;                     // preset to AM
    
    if (e_hour > 11) {
    
        e_am_pm = 1;        // PM
        e_hour -= 12;       // set to 12 hr clock
    }
    
    if (e_hour == 0) e_hour = 12;
    
    //
    //  Build the 'time' string for display
    //
    e_date = (eyear * 10000) + (emonth * 100) + eday;

    //
    //  get date/time string for email message
    //
    String email_time = emonth + "/" + eday + "/" + eyear + " at " + e_hour + ":" + SystemUtils.ensureDoubleDigit(e_min) + ((e_am_pm == 0) ? " AM" : " PM");


            
    //*****************************************************************************
    //  Send an email to all players the are part of this event and have not
    //  yet been sent an email.
    //*****************************************************************************
    //
/*    
    out.println("<br>event_name=" + event_name);
    out.println("<br>event_date=" + event_date);
    out.println("<br>clubName=" + clubName);
    out.println("<br>email_time=" + email_time);
*/    
    try {

        pstmt = con.prepareStatement ("" +
            "SELECT t.*, e.act_hr, e.act_min " +
            "FROM teecurr2 t, events2b e " +
            "WHERE t.date = ? AND t.lottery_email = 2 AND e.name = t.event"); // use the lottery email flag for the events (update, this may not work if they simultaneously work on an event and lottery for the same day at the same time)
            
        pstmt.clearParameters();
        pstmt.setInt(1, event_date);
        //pstmt.setString(2, lott_name);AND lottery = ?


        rs = pstmt.executeQuery();  
      
        while (rs.next()) {
          
            count1++; // inc the tee time count
            
            teecurr_id = rs.getInt("teecurr_id");
            course = rs.getString("courseName");
            day = rs.getString("day");
            dd = rs.getInt("dd");
            mm = rs.getInt("mm");
            yy = rs.getInt("yy");
            afb = rs.getInt("fb");
            atime1 = rs.getInt("time");
            lott_email = rs.getInt("lottery_email");
            event_type = rs.getInt("event_type");
            act_hr = rs.getInt("act_hr");
            act_min = rs.getInt("act_min");

            player1 = rs.getString("player1");
            player2 = rs.getString("player2");
            player3 = rs.getString("player3");
            player4 = rs.getString("player4");
            player5 = rs.getString("player5");
            
            user1 = rs.getString("username1");
            user2 = rs.getString("username2");
            user3 = rs.getString("username3");
            user4 = rs.getString("username4");
            user5 = rs.getString("username5");
            
            p1cw = rs.getString("p1cw");
            p2cw = rs.getString("p2cw");
            p3cw = rs.getString("p3cw");
            p4cw = rs.getString("p4cw");
            p5cw = rs.getString("p5cw");
            
            hole = rs.getString("hole");
               
            //
            //***********************************************
            //  Send email notification if necessary
            //***********************************************
            //
            String to = "";                          // to address
            String f_b = "";
            String eampm = "";
            String etime = "";
            String enewMsg = "";
            int emailOpt = 0;                        // user's email option parm
            int ehr = 0;
            int emin = 0;
            int send = 0;

            PreparedStatement pstmte1 = null;

            //
            //  set the front/back value
            //
            f_b = "Front";

            if (afb == 1) {

            f_b = "Back";
            }

            String enew1 = "";
            //String enew2 = "";
            String subject = "";
            String action = (lott_email == 1) ? "ASSIGNED" : "MODIFIED";

            if (clubName.startsWith( "Old Oaks" )) {

                enew1 = "The following Tee Time has been " + action + ".\n\n";
                //enew2 = "The following Tee Times have been ASSIGNED.\n\n";
                subject = "ForeTees Tee Time Assignment Notification";

            } else if (clubName.startsWith( "Westchester" )) {

                    enew1 = "The following Draw Tee Time has been " + action + ".\n\n";
                    //enew2 = "The following Draw Tee Times have been ASSIGNED.\n\n";
                    subject = "Your Tee Time for Weekend Draw";

            } else {

                enew1 = "The following Event Tee Time has been " + action + ".\n\n";
                //enew2 = "The following Event Tee Times have been ASSIGNED.\n\n";
                subject = "ForeTees Event Assignment Notification";
            }

            if (!clubName.equals( "" )) {

                subject = subject + " - " + clubName;
            }

            Properties properties = new Properties();
            properties.put("mail.smtp.host", SystemUtils.host);                     // set outbound host address
            properties.put("mail.smtp.port", SystemUtils.port);                     // set outbound port
            properties.put("mail.smtp.auth", "true");                               // set 'use authentication'

            Session mailSess = Session.getInstance(properties, SystemUtils.getAuthenticator());   // get session properties

            MimeMessage message = new MimeMessage(mailSess);
            
            try {

                message.setFrom(new InternetAddress(SystemUtils.EFROM));                  // set from addr
                message.setSubject( subject );                                            // set subject line
                message.setSentDate(new java.util.Date());                                // set date/time sent
            }
            catch (Exception exp) { 
                out.println("<p>Can't create message object. " + exp.toString() + "</p>");
            }


            //
            //  Set the recipient addresses
            //
               if (!user1.equals( "" )) {       // if new user exist and not same as old usernames

                  try {
                     pstmte1 = con.prepareStatement (
                              "SELECT email, emailOpt FROM member2b WHERE username = ? AND email_bounced = 0");

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, user1);
                     rs2 = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        to = rs2.getString(1);        // user's email address
                        emailOpt = rs2.getInt(2);        // email option

                        if ((emailOpt != 0) && (!to.equals( "" ))) {    // if user wants email notifications

                           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                           send = 1;
                           count2++;
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  catch (Exception ignore) { }
               }

               if (!user2.equals( "" )) {       // if new user exist and not same as old usernames

                  try {
                     pstmte1 = con.prepareStatement (
                              "SELECT email, emailOpt FROM member2b WHERE username = ? AND email_bounced = 0");

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, user2);
                     rs2 = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        to = rs2.getString(1);        // user's email address
                        emailOpt = rs2.getInt(2);        // email option

                        if ((emailOpt != 0) && (!to.equals( "" ))) {    // if user wants email notifications

                           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                           send = 1;
                           count2++;
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  catch (Exception ignore) {
                  }
               }

               if (!user3.equals( "" )) {       // if new user exist and not same as old usernames

                  try {
                     pstmte1 = con.prepareStatement (
                              "SELECT email, emailOpt FROM member2b WHERE username = ? AND email_bounced = 0");

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, user3);
                     rs2 = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        to = rs2.getString(1);        // user's email address
                        emailOpt = rs2.getInt(2);        // email option

                        if ((emailOpt != 0) && (!to.equals( "" ))) {    // if user wants email notifications

                           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                           send = 1;
                           count2++;
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  catch (Exception ignore) {
                  }
               }

               if (!user4.equals( "" )) {       // if new user exist and not same as old usernames

                  try {
                     pstmte1 = con.prepareStatement (
                              "SELECT email, emailOpt FROM member2b WHERE username = ? AND email_bounced = 0");

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, user4);
                     rs2 = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        to = rs2.getString(1);        // user's email address
                        emailOpt = rs2.getInt(2);        // email option

                        if ((emailOpt != 0) && (!to.equals( "" ))) {    // if user wants email notifications

                           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                           send = 1;
                           count2++;
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  catch (Exception ignore) {
                  }
               }

               if (!user5.equals( "" )) {       // if new user exist and not same as old usernames

                  try {
                     pstmte1 = con.prepareStatement (
                              "SELECT email, emailOpt FROM member2b WHERE username = ? AND email_bounced = 0");

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, user5);
                     rs2 = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        to = rs2.getString(1);        // user's email address
                        emailOpt = rs2.getInt(2);        // email option

                        if ((emailOpt != 0) && (!to.equals( "" ))) {    // if user wants email notifications

                           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                           send = 1;
                           count2++;
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  catch (Exception ignore) {
                  }
               }
               

            //
            //  send email if anyone to send it to
            //
            if (send != 0) {        // if any email addresses specified for members
                
                count3++; // inc the message count
                
                if (event_type == 1) {
                    
                    enewMsg = SystemUtils.header + enew1 + day + " " + mm + "/" + dd + "/" + yy + " ";
                    if (!course.equals( "" )) enewMsg = enewMsg + "\nCourse: " + course;
                    enewMsg = enewMsg + "\nThe start time of the event is " + SystemUtils.getSimpleTime(act_hr, act_min) + ".";
                    if (!hole.equals("")) enewMsg = enewMsg + "\nYour assigned starting hole is " + hole + ".";
                    
                } else {
                    
                    enewMsg = SystemUtils.header + enew1 + day + " " + mm + "/" + dd + "/" + yy + " on the " + f_b + " tee ";
                    if (!course.equals( "" )) enewMsg = enewMsg + "of Course: " + course;
                                
                    //
                    //  convert time to hour and minutes for email msg
                    //
                    time = atime1;              // time for this tee time
                    ehr = time / 100;
                    emin = time - (ehr * 100);
                    eampm = " AM";
                    if (ehr > 12) {

                        eampm = " PM";
                        ehr = ehr - 12;       // convert from military time
                    }
                    if (ehr == 12) eampm = " PM";
                    if (ehr == 0) {

                        ehr = 12;
                        eampm = " AM";
                    }

                    etime = ehr + ":" + SystemUtils.ensureDoubleDigit(emin) + eampm;

                    enewMsg = enewMsg + "\n at " + etime;

                }
                
                enewMsg = enewMsg + "\n";
                
                if (!player1.equals( "" )) {

                    enewMsg = enewMsg + "\nPlayer 1: " + player1 + "  " + p1cw;
                }
                if (!player2.equals( "" )) {

                    enewMsg = enewMsg + "\nPlayer 2: " + player2 + "  " + p2cw;
                }
                if (!player3.equals( "" )) {

                    enewMsg = enewMsg + "\nPlayer 3: " + player3 + "  " + p3cw;
                }
                if (!player4.equals( "" )) {

                    enewMsg = enewMsg + "\nPlayer 4: " + player4 + "  " + p4cw;
                }
                if (!player5.equals( "" )) {

                    enewMsg = enewMsg + "\nPlayer 5: " + player5 + "  " + p5cw;
                }

                enewMsg = enewMsg + SystemUtils.trailer;

                try {

                    message.setText( enewMsg );  // put msg in email text area
                    //out.println("<p>MESSAGE:<br>" + enewMsg + "</p>");
                    Transport.send(message);     // send it!!
                }
                catch (Exception exp) { 
                    teecurr_id = 0; // reset so that we can detect that we didn't send email
                    count3--;
                    SystemUtils.buildDatabaseErrMsg("Can't build message. " + exp.getMessage() + "<br>", exp.toString(), out, false);
                }
                
            }/* else {
             out.println("<p>We did not send emails because no players had email addresses.</p>");   
            }// end of IF send */

            if (teecurr_id > 0) {

                try {

                    PreparedStatement pstmt6 = con.prepareStatement (
                         "UPDATE teecurr2 " +
                         "SET lottery_email = 0 " +
                         "WHERE teecurr_id = ?");

                    pstmt6.clearParameters();
                    pstmt6.setInt(1, teecurr_id);
                    pstmt6.executeUpdate();

                } catch (Exception exp) {
                    SystemUtils.buildDatabaseErrMsg("Error updating tee time entry.", exp.toString(), out, false);
                }

            } // end if
            
        } // end while loop for teecurr2

        pstmt.close();
    }
    catch (Exception exp) {
        SystemUtils.buildDatabaseErrMsg("Fatal error sending emails.", exp.toString(), out, false);
    }

    out.println("<center>");
    
    out.println("<h3>Done!</h3>");
    out.println("<p>We sent " + count3 + " emails to " + count2 + " members for " + count1 + " tee times.</p>");
    //out.println("<a href=\"/" +rev+ "/servlet/Proshop_jump?index=" +index+ "&course=" +returnCourse+ "\" title=\"Return to Tee Sheet\" alt=\"Return\">Back To Tee Sheet</a>");
    
    out.println("<form method=get action=/" + rev + "/servlet/Proshop_jump>");
    out.println("<input type=hidden name=index value=\"" + index + "\">");
    out.println("<input type=hidden name=course value=\"" + course + "\">");
    out.println("<input type=submit value=\"Continue\">");
    out.println("</form>");
    
    out.println("</center>");

 }
 
 
 private static String getMemberNumber(String username, Connection con) {
     
    String memNum = "";
    
    try {
        
        PreparedStatement pstmt = con.prepareStatement (
          "SELECT memNum FROM member2b WHERE username = ?");

        pstmt.clearParameters();
        pstmt.setString(1, username);

        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) memNum = rs.getString(1);

        pstmt.close();
        
    } catch(Exception ignore) { }
    
    return memNum;
    
 } // end getMemberNumber
 
} // end servlet