/***************************************************************************************
 *   Member_waitlist:  This servlet will allow members to submit a wait list request
 *                     as well as process the request.
 *
 *
 *   called by:  Member_sheet (doPost)
 *               
 *
 *
 *   created: 4/19/2008   Paul S
 *
 *   last updated:       ******* keep this accurate ******
 *
 *
 *
 */


import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;


// foretees imports
import com.foretees.common.parmWaitList;
import com.foretees.common.getWaitList;



public class Member_waitlist extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //*****************************************************
 // Process the request from Member_sheet
 //*****************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    PreparedStatement pstmt3 = null;
    Statement stmt = null;
    ResultSet rs = null;

    HttpSession session = SystemUtils.verifyMem(req, out);      // check for intruder

    if (session == null) {

        return;
    }

    Connection con = SystemUtils.getCon(session);               // get DB connection

    if (con == null) {

        out.println(SystemUtils.HeadTitle("DB Connection Error"));
        out.println("<BODY bgcolor=\"#ccccaa\"><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
        out.println("<hr width=\"40%\">");
        out.println("<BR><BR><H3>Database Connection Error</H3>");
        out.println("<BR><BR>Unable to connect to the Database.");
        out.println("<BR>Please try again later.");
        out.println("<BR><BR>If problem persists, please contact customer support.");
        out.println("<BR><BR>");
        out.println("<font size=\"2\">");
        out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
        out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
        out.println("</form></font>");
        out.println("</CENTER></BODY></HTML>");
        return;
    }
    
    String jump = "0";                                          // jump index - default to zero (for _sheet)

    if (req.getParameter("jump") != null) {                     // if jump index provided

        jump = req.getParameter("jump");
    }

    //
    //  Get this session's username
    //
    String club = (String)session.getAttribute("club");
    String user = (String)session.getAttribute("user");
    String name = (String)session.getAttribute("name");         // get users full name

    String sindex = req.getParameter("index");                   //  index value of day (needed by Member_sheet when returning)
    String course = req.getParameter("course");                 //  Name of Course
    String id = req.getParameter("waitListId");               //  uid of the wait list we are working with

    String returnCourse = "";
    
    if (req.getParameter("returnCourse") != null) {             // if returnCourse provided

        returnCourse = req.getParameter("returnCourse");
    }


    String sdate = req.getParameter("date");                    //  date of the request (yyyymmdd)
    String day_name = req.getParameter("day");                  //  name of the day
    String p5 = req.getParameter("p5");                         //  5-somes supported
    String sshr = "";
    String ssmin = "";
    String sampm = "";
    String sehr = "";
    String semin = "";
    String eampm = "";

    int shr = 0;
    int smin = 0;
    int ehr = 0;
    int emin = 0;
    int index = 0;
    int wait_list_id = 0;
    int count = 0;
    
    int mm = 0;
    int dd = 0;
    int yy = 0;
    int date = 0;

    //
    //  Convert the values from string to int
    //
    try {
        
        wait_list_id = Integer.parseInt(id);
        index = Integer.parseInt(sindex);
        date = Integer.parseInt(sdate);
        shr = Integer.parseInt(sshr);
        smin = Integer.parseInt(ssmin);
        ehr = Integer.parseInt(sehr);
        emin = Integer.parseInt(semin);
    }
    catch (NumberFormatException e) { }

    // get our date parts
    yy = date / 10000;
    mm = date - (yy * 10000);
    dd = mm - (mm / 100) * 100;
    mm = mm / 100;
      
    
    //
    //  parm block to hold the wait list parameters
    //
    parmWaitList parmWL = new parmWaitList();                   // allocate a parm block
    
    parmWL.wait_list_id = wait_list_id;
    
    try {
        
        getWaitList.getParms(con, parmWL);                      // get the wait list config
        
        // if members can see the wait list then get the count
        if ( parmWL.member_view == 1 ) 
            count = getWaitList.getListCount(wait_list_id, date, con);
        
    } catch (Exception exp) {
        out.println(exp.getMessage());
    }
    
    out.println("<!-- wait_list_id=" + wait_list_id + ", date=" + date + ", count=" + count + " -->");
    
    //
    //********************************************************************
    //   Build a page to display Wait List details to member
    //********************************************************************
    //
    out.println("<html>");
    out.println("<head>");
    out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
    out.println("<title>Member Wait List Registration Page</title>");
    out.println("</head>");

    out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\" topmargin=\"0\">");
    out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

    out.println("<table border=\"0\" width=\"100%\" align=\"center\" valign=\"top\">");  // large table for whole page
    out.println("<tr><td valign=\"top\" align=\"center\">");

    out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#336633\" align=\"center\" valign=\"top\">");
    out.println("<tr><td align=\"left\" width=\"300\">&nbsp;");
    out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
    out.println("</td>");

    out.println("<td align=\"center\">");
    out.println("<font color=\"ffffff\" size=\"5\">Member Wait List Registration</font>");
    out.println("</font></td>");

    out.println("<td align=\"center\" width=\"300\">");
    out.println("<font size=\"1\" color=\"#ffffff\">Copyright&nbsp;</font>");
    out.println("<font size=\"2\" color=\"#ffffff\">&#169;&nbsp;</font>");
    out.println("<font size=\"1\" color=\"#ffffff\">ForeTees, LLC <br> 2008 All rights reserved.");
    out.println("</font><font size=\"3\">");
    out.println("<br><br><a href=\"/" +rev+ "/member_help.htm\" target=\"_blank\"><b>Help</b></a>");
    out.println("</font></td>");
    out.println("</tr></table>");

    out.println("<br>");

    out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"3\">");
    out.println("<tr>");
    out.println("<td width=\"620\" align=\"center\">");
    out.println("<font size=\"3\">");
    out.println("<b>Wait List Registration</b><br></font>");
    out.println("<font size=\"2\">");
    
    out.println("The golf shop is running a wait list " + ((index == 0) ? "today": "on this day") + ". ");
    out.println("The wait list you've selected is running from " + SystemUtils.getSimpleTime(parmWL.start_time) + " till " + SystemUtils.getSimpleTime(parmWL.end_time) + ". ");
    
    out.println("Review the information below and click on 'Continue With Request' to contnue.");
    out.println("<br>OR click on 'Cancel Request' to delete the request. To return without changes click on 'Go Back'.");

    //out.println("<br><br><b>NOTE:</b> Only the person that originates the request will be allowed to cancel it or change these values.");

    out.println("</font></td></tr>");
    out.println("</table>");
    
    out.println("<br><br>");

    out.println("<table border=0>");
    
    out.println("<tr><td><font size=\"2\">");
    out.println("Date:&nbsp;&nbsp;<b>" + day_name + "&nbsp;&nbsp;" + mm + "/" + dd + "/" + yy + "</b></td>");
    out.println("<td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td><td>");
    if (!course.equals( "" )) {
        out.println("<font size=\"2\">Course:&nbsp;&nbsp;<b>" + course + "</b></font>");
    }
    out.println("</td></tr>");
    
    out.println("<tr><td><font size=\"2\">Wait List:&nbsp;&nbsp;<b>" + SystemUtils.getSimpleTime(parmWL.start_time) + " to " + SystemUtils.getSimpleTime(parmWL.end_time) + "</b></font></td>");
    
    out.println("<td></td>");
    
    out.println("<td><font size=\"2\">Signups:<b>");
    out.print(( (parmWL.member_view == 1) ? count : "N/A") );
    out.println("</b></font></td>");
    
    out.println("</table>");
    
    out.println("<br>");
    
    out.println("<table border=\"0\" align=\"center\">"); // table to contain 2 tables below

    out.println("<tr>");

    
    out.println("<td align=\"center\" valign=\"top\">");

    out.println("<table border=\"1\" bgcolor=\"#f5f5dc\" align=\"center\" width=\"500\" cellpadding=\"5\" cellspacing=\"5\">");  // table for request details
    out.println("<tr bgcolor=\"#336633\"><td align=\"center\">");
    out.println("<font color=\"ffffff\" size=\"3\">");
    out.println("<b>" + ((!parmWL.name.equals("")) ? parmWL.name : "Wait List Information") + "</b>");
    out.println("</font></td></tr>");
    
    out.println("<tr>");
    
    out.println("<form action=\"/" +rev+ "/servlet/Member_waitlist_slot\" method=\"post\">");
    out.println("<input type=\"hidden\" name=\"waitListId\" value=\"" + wait_list_id + "\">");
    out.println("<input type=\"hidden\" name=\"sdate\" value=\"" + date + "\">");
    out.println("<input type=\"hidden\" name=\"day\" value=\"" + day_name + "\">");
    out.println("<input type=\"hidden\" name=\"index\" value=\"" + sindex + "\">");
    out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
    out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + returnCourse + "\">");
    out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
        
    out.println("<td><font size=\"2\"><br>");
    
    // see if they are already on the wait list
    int onlist = 0;
    
    try {

        onlist = getWaitList.onList(user, wait_list_id, date, con);
        
    } catch (Exception exp) {
        
        out.println(exp.toString());
    }
    
    out.println("<input type=\"hidden\" name=\"signupId\" value=\"" + onlist + "\">");
    
    if (onlist == 0) {
        
        // not on the list
        
        //out.println("The golf shop is running a wait list " + ((index == 0) ? "today": "on this day") + ". ");
        //out.println("The wait list you've selected is running from " + SystemUtils.getSimpleTime(parmWL.start_time) + " till " + SystemUtils.getSimpleTime(parmWL.end_time) + ". ");

        try {

            out.println("<pre>");
            out.print(getWaitList.getNotice(wait_list_id, con));
            out.println("</pre>");

        } catch (Exception exp) { }

        if (parmWL.member_access == 1) {
            out.println("<br><p align=center><input type=submit value=\"Continue With Sign-up\" name=\"continue\"></p>");
        } else {
            out.println("<p align=center><b>Contact the golf shop to get on the wait list.</b></p>");
        }
        
    } else {
        
        // already on this list
        
        out.println("<p align=center><b><i>You are already signed up for this wait list.</b></i></p>");
        
        if (parmWL.member_access == 1) {
            out.println("<br><p align=center><input type=submit value=\"Modify Your Sign-up\" name=\"continue\"></p>");
        } else {
            out.println("<p align=center><b>Contact the golf shop to make changes or cancel your entry.</b></p>");
        }
    }
    out.println("<br></font></td>");
    
    out.println("</table>");
    out.println("</form>");
    
    out.println("<br>");    
    
    out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\">");
    out.println("<input type=\"hidden\" name=\"jump\" value=" + jump + ">");
    out.println("<input type=\"hidden\" name=\"index\" value=" + index + ">");
    out.println("<input type=\"hidden\" name=\"course\" value=\"" + ((!returnCourse.equals( "" )) ? returnCourse : course) + "\">");
    out.println("<font size=2>Return w/o Changes:</font><br>");
    out.println("<input type=\"submit\" value=\"Go Back\" name=\"cancel\"></form>");
      
    
 } // end doPost


/*
 public void doPostOld(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    PreparedStatement pstmt3 = null;
    Statement stmt = null;
    ResultSet rs = null;

    HttpSession session = SystemUtils.verifyMem(req, out);      // check for intruder

    if (session == null) {

        return;
    }

    Connection con = SystemUtils.getCon(session);               // get DB connection

    if (con == null) {

        out.println(SystemUtils.HeadTitle("DB Connection Error"));
        out.println("<BODY bgcolor=\"#ccccaa\"><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
        out.println("<hr width=\"40%\">");
        out.println("<BR><BR><H3>Database Connection Error</H3>");
        out.println("<BR><BR>Unable to connect to the Database.");
        out.println("<BR>Please try again later.");
        out.println("<BR><BR>If problem persists, please contact customer support.");
        out.println("<BR><BR>");
        out.println("<font size=\"2\">");
        out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
        out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
        out.println("</form></font>");
        out.println("</CENTER></BODY></HTML>");
        return;
    }

    if (req.getParameter("cancel") != null) {

        //cancel(req, out, con);                                // process cancel request
        return;
    }

    if (req.getParameter("submitForm") != null) {               // if user submitted a lottery request

        verify(req, out, con, session, resp);                   // process reservation requests
        return;
    }

    String jump = "0";                                          // jump index - default to zero (for _sheet)

    if (req.getParameter("jump") != null) {                     // if jump index provided

        jump = req.getParameter("jump");
    }

    

    //
    //  Get this session's username
    //
    String club = (String)session.getAttribute("club");
    String user = (String)session.getAttribute("user");
    String name = (String)session.getAttribute("name");         // get users full name

    String index = req.getParameter("index");                   //  index value of day (needed by Member_sheet when returning)
    String course = req.getParameter("course");                 //  Name of Course
    String id = req.getParameter("wait_list_id");               //  uid of the wait list we are working with

    String returnCourse = "";
    
    if (req.getParameter("returnCourse") != null) {             // if returnCourse provided

        returnCourse = req.getParameter("returnCourse");
    }


    String sdate = req.getParameter("date");                    //  date of the request (yyyymmdd)
    String day_name = req.getParameter("day");                  //  name of the day
    String p5 = req.getParameter("p5");                         //  5-somes supported
    String sshr = "";
    String ssmin = "";
    String sampm = "";
    String sehr = "";
    String semin = "";
    String eampm = "";

    int shr = 0;
    int smin = 0;
    int ehr = 0;
    int emin = 0;
    
    long mm = 0;
    long dd = 0;
    long yy = 0;
    long date = 0;

    //
    //  Convert the values from string to int
    //
    try {
        
        wait_list_id = Integer.parseInt(id);
        date = Long.parseLong(sdate);
        shr = Integer.parseInt(sshr);
        smin = Integer.parseInt(ssmin);
        ehr = Integer.parseInt(sehr);
        emin = Integer.parseInt(semin);
    }
    catch (NumberFormatException e) { }

    // get our date parts
    yy = date / 10000;
    mm = date - (yy * 10000);
    dd = mm - (mm / 100) * 100;
    mm = mm / 100;
      
    
    //
    //  parm block to hold the club parameters
    //
    parmWaitList parmWL = new parmWaitList();                   // allocate a parm block
    
    parmWL.wait_list_id = wait_list_id;
    
    try {
        
        getWaitList.getParms(con, parmWL);                      // get the wait list config
        
    } catch (Exception ignore) { }
    

    //
    //********************************************************************
    //   Build a page to prompt user for lottery request details
    //********************************************************************
    //
    out.println("<html>");
    out.println("<head>");
    out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
    out.println("<title>Member Wait List Registration Page</title>");
    out.println("</head>");

    out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\" topmargin=\"0\">");
    out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

    out.println("<table border=\"0\" width=\"100%\" align=\"center\" valign=\"top\">");  // large table for whole page
    out.println("<tr><td valign=\"top\" align=\"center\">");

    out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#336633\" align=\"center\" valign=\"top\">");
    out.println("<tr><td align=\"left\" width=\"300\">&nbsp;");
    out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
    out.println("</td>");

    out.println("<td align=\"center\">");
    out.println("<font color=\"ffffff\" size=\"5\">Member Wait List Registration</font>");
    out.println("</font></td>");

    out.println("<td align=\"center\" width=\"300\">");
    out.println("<font size=\"1\" color=\"#ffffff\">Copyright&nbsp;</font>");
    out.println("<font size=\"2\" color=\"#ffffff\">&#169;&nbsp;</font>");
    out.println("<font size=\"1\" color=\"#ffffff\">ForeTees, LLC <br> 2008 All rights reserved.");
    out.println("</font><font size=\"3\">");
    out.println("<br><br><a href=\"/" +rev+ "/member_help.htm\" target=\"_blank\"><b>Help</b></a>");
    out.println("</font></td>");
    out.println("</tr></table>");

    out.println("<br>");

    out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"3\">");
    out.println("<tr>");
    out.println("<td width=\"620\" align=\"center\">");
    out.println("<font size=\"3\">");
    out.println("<b>Wait List Registration</b><br></font>");
    out.println("<font size=\"2\">");
    out.println("Provide the requested information below and click on 'Continue With Request' to contnue.");
    out.println("<br>OR click on 'Cancel Request' to delete the request. To return without changes click on 'Go Back'.");

    out.println("<br><br><b>NOTE:</b> Only the person that originates the request will be allowed to cancel it or change these values.");

    out.println("</font></td></tr>");
    out.println("</table>");

    out.println("<font size=\"2\"><br><br>");
    out.println("Date:&nbsp;&nbsp;<b>" + day_name + "&nbsp;&nbsp;" + mm + "/" + dd + "/" + yy + "</b>");
    if (!course.equals( "" )) {
        out.println(" &nbsp;&nbsp;&nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + course + "</b>");
    }
    out.println("</font>");

    out.println("<table border=\"0\" align=\"center\" cellpadding=\"5\" cellspacing=\"5\">"); // table to contain 2 tables below

    out.println("<tr>");

    out.println("<form action=\"/" +rev+ "/servlet/Member_lott\" method=\"post\">");
    out.println("<input type=\"hidden\" name=\"sdate\" value=\"" + sdate + "\">");
    out.println("<input type=\"hidden\" name=\"day\" value=\"" + day_name + "\">");
    out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
    out.println("<input type=\"hidden\" name=\"returnCourse\" value=\"" + returnCourse + "\">");
    out.println("<input type=\"hidden\" name=\"p5\" value=\"" + p5 + "\">");
    out.println("<input type=\"hidden\" name=\"jump\" value=\"" + jump + "\">");
    
    out.println("<td align=\"center\" valign=\"top\">");

    out.println("<table border=\"1\" bgcolor=\"#f5f5dc\" align=\"center\" width=\"500\">");  // table for request details
    out.println("<tr bgcolor=\"#336633\"><td align=\"center\">");
    out.println("<font color=\"ffffff\" size=\"2\">");
    out.println("<b>Wait List Registration Form</b>");
    out.println("</font></td></tr>");
    
    out.println("<tr>");
    out.println("<td><font size=\"2\">");
    
    out.println("");
    
    Common_Config.displayStartTime(shr, smin, sampm, out);
    
    //out.println("<br>");
    
    Common_Config.displayEndTime(ehr, emin, eampm, out);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    out.println("</font></td>");
    out.println("</tr>");
    
    out.println("<tr>");
    out.println("<td align=center><input type=submit value=\"Continue With Request\" name=\"continue\"></td>");
    out.println("</tr>");
    
    out.println("</table>");
    out.println("</form>");
    
    out.println("<br><br>");    
    
    out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\">");
    out.println("<input type=\"hidden\" name=\"jump\" value=" + jump + ">");
    out.println("<input type=\"hidden\" name=\"index\" value=" + index + ">");
    out.println("<input type=\"hidden\" name=\"course\" value=\"" + ((!returnCourse.equals( "" )) ? returnCourse : course) + "\">");
    out.println("<font size=2>Return w/o Changes:</font><br>");
    out.println("<input type=\"submit\" value=\"Go Back\" name=\"cancel\"></form>");
      
    
 } // end doPost
*/
 
 
 private void verify(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session, HttpServletResponse resp) {

    
   //
   //  Get this session's user name
   //
   String user = (String)session.getAttribute("user");
   String club = (String)session.getAttribute("club");
   
   String notes = req.getParameter("notes");                // Member Notes
   String hides = req.getParameter("hide");                 // Hide Notes Indicator
   String jump = req.getParameter("jump");                  // jump index for _sheet
   
   
    
 } // end verify

}
 
 