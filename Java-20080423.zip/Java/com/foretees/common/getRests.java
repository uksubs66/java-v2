/***************************************************************************************
 *   getRests:  This servlet will locate and save all member restrictions for the given
 *              date and user.  This will prevent Member_sheet from having to check for
 *              a restriction at each tee time.
 *
 *   called by:  Member_sheet
 *
 *   created:  8/02/2004   Bob P.
 *
 *
 *   last updated:
 *
 *      1/10/05 RDP  Add checkRests to check if a restriction exists for ALL member types.
 *     11/05/04 RDP  Allow for parm.course to be -ALL-, get all restrictions.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;


public class getRests {


/**
 //************************************************************************
 //
 //  Get the Rests parms
 //
 //************************************************************************
 **/

 public static void getAll(Connection con, parmRest parm)
         throws Exception {


   PreparedStatement pstmt1 = null;
   ResultSet rs = null;

   int i = 0;
   int i2 = 0;
   int i3 = 0;
   int ind = 0;
   int stime = 0;
   int etime = 0;
   int count = 0;

   int memLimit = Labels.MAX_MEMS;
   int mshipLimit = Labels.MAX_MSHIPS;

   String rest_recurr = "";
   String rest_color = "";
   String rest_course = "";
   String rest_fb = "";

   String [] mtypeA = new String [Labels.MAX_MEMS];               // array to hold the member types
   String [] mshipA = new String [Labels.MAX_MSHIPS];             // array to hold the membership types


   //
   //  First, init the parm block
   //
   for (i=0; i<parm.MAX; i++) {
     
      parm.courseName[i] = "";
      parm.color[i] = "";
      parm.fb[i] = "";
      parm.stime[i] = 0;
      parm.etime[i] = 0;
   }
   i = 0;

   //
   //  get the Rests's for this date and user
   //
   try {

      if (parm.course.equals( "-ALL-" )) {

         pstmt1 = con.prepareStatement (
            "SELECT * FROM restriction2 WHERE sdate <= ? AND edate >= ?");

      } else {

         pstmt1 = con.prepareStatement (
            "SELECT * FROM restriction2 WHERE sdate <= ? AND edate >= ? AND " +
            "(courseName = ? OR courseName = '-ALL-')");
      }

      pstmt1.clearParameters();          // clear the parms
      pstmt1.setLong(1, parm.date);
      pstmt1.setLong(2, parm.date);

      if (!parm.course.equals( "-ALL-" )) {
         pstmt1.setString(3, parm.course);
      }

      rs = pstmt1.executeQuery();      // find all matching restrictions, if any

      i = 0;                           // init index for restrictions in parm block

      while (rs.next() && count < parm.MAX) {   // check all matching restrictions for this day, mship, mtype (max of 40)

         stime = rs.getInt("stime");
         etime = rs.getInt("etime");
         rest_recurr = rs.getString("recurr");
         i2 = 1;
         for (i3=0; i3<memLimit; i3++) {
            mtypeA[i3] = rs.getString("mem" +i2);
            i2++;
         }
         i2 = 1;
         for (i3=0; i3<mshipLimit; i3++) {
            mshipA[i3] = rs.getString("mship" +i2);
            i2++;
         }
         rest_color = rs.getString("color");
         rest_course = rs.getString("courseName");
         rest_fb = rs.getString("fb");

         //
         //  We must check the recurrence for this day (Monday, etc.)
         //
         if ((rest_recurr.equalsIgnoreCase( "Every " + parm.day )) ||          // if this day
             (rest_recurr.equalsIgnoreCase( "every day" )) ||        // or everyday
             ((rest_recurr.equalsIgnoreCase( "all weekdays" )) &&    // or all weekdays (and this is one)
               (!parm.day.equalsIgnoreCase( "saturday" )) &&
               (!parm.day.equalsIgnoreCase( "sunday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&    // or all weekends (and this is one)
              (parm.day.equalsIgnoreCase( "saturday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&
              (parm.day.equalsIgnoreCase( "sunday" )))) {

            //
            //  Found a restriction that matches course, date & day - check mtype & mship of this member
            //
            ind = 0;                           // init fields

            loop1:
            while (ind < memLimit) {

               if (parm.mship.equals( mshipA[ind] ) || parm.mtype.equals( mtypeA[ind] )) {

                  //
                  //  restriction found - save it in the rest parm block
                  //
                  parm.courseName[i] = rest_course;
                  parm.fb[i] = rest_fb;
                  parm.color[i] = rest_color;
                  parm.stime[i] = stime;
                  parm.etime[i] = etime;

                  i++;     // next rest
                  count++;
                  break loop1;
               }
               ind++;
            }
         }     // end of 'day' if
      }       // end of while (no more restrictions)

      pstmt1.close();

   }
   catch (Exception e) {

      throw new UnavailableException("Error getting restriction info - getRests.getAll " + e.getMessage());
   }
 }


/**
 //************************************************************************
 //
 //  Check Rests for ALL member types or ALL membership types (called by Member_teelist)
 //
 //************************************************************************
 **/

 public static boolean checkRests(long date, int time, int fb, String course, String day, Connection con)
         throws Exception {


   PreparedStatement pstmt1 = null;
   ResultSet rs = null;

   boolean status = false;
   boolean found = false;

   int i = 0;
   int i2 = 0;
   int ind = 0;
   int count = 0;
   int memLimit = Labels.MAX_MEMS;
   int mshipLimit = Labels.MAX_MSHIPS;

   String rest_recurr = "";
   String rfb = "";
   String bfb = "Both";

   String [] mtypeA = new String [Labels.MAX_MEMS];             //  member types allowed
   String [] mtypeS = new String [Labels.MAX_MEMS];             //  member types specified
   String [] mshipA = new String [Labels.MAX_MSHIPS];           //  membership types allowed
   String [] mshipS = new String [Labels.MAX_MSHIPS];           //  membership types specified

   //
   //   Check for any events during this time
   //
   rfb = "Front";
   if (fb == 1) {       // if back requested

      rfb = "Back";
   }

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   //   Get the guest names specified for this club
   //
   try {

      getClub.getParms(con, parm);        // get the club parms

   }
   catch (Exception e2) {

      throw new UnavailableException("Error getting club parms - getRests.checkRests " + e2.getMessage());
   }

   for (i=0; i<memLimit; i++) {         // get the member types and mship types allowed
      mtypeA[i] = parm.mem[i];
   }
   for (i=0; i<mshipLimit; i++) {
      mshipA[i] = parm.mship[i];
   }

   //
   //  get the Rests's for this date and time
   //
   try {

      pstmt1 = con.prepareStatement (
         "SELECT * FROM restriction2 WHERE sdate <= ? AND edate >= ? AND stime <= ? AND etime >= ? AND " +
         "courseName = ? AND (fb = ? OR fb = ?)");

      pstmt1.clearParameters();          // clear the parms
      pstmt1.setLong(1, date);
      pstmt1.setLong(2, date);
      pstmt1.setInt(3, time);
      pstmt1.setInt(4, time);
      pstmt1.setString(5, course);
      pstmt1.setString(6, rfb);
      pstmt1.setString(7, bfb);

      rs = pstmt1.executeQuery();      // find all matching restrictions, if any

      loop1:
      while (rs.next()) {

         rest_recurr = rs.getString("recurr");
         for (i=0; i<memLimit; i++) {
            mtypeS[i] = rs.getString("mem" +(i+1));
         }
         for (i=0; i<mshipLimit; i++) {
            mshipS[i] = rs.getString("mship" +(i+1));
         }

         //
         //  We must check the recurrence for this day (Monday, etc.)
         //
         if ((rest_recurr.equals( "Every " + day )) ||          // if this day
             (rest_recurr.equalsIgnoreCase( "every day" )) ||        // or everyday
             ((rest_recurr.equalsIgnoreCase( "all weekdays" )) &&    // or all weekdays (and this is one)
               (!day.equalsIgnoreCase( "saturday" )) &&
               (!day.equalsIgnoreCase( "sunday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&    // or all weekends (and this is one)
              (day.equalsIgnoreCase( "saturday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&
              (day.equalsIgnoreCase( "sunday" )))) {

            //
            //  Found a restriction that matches - check mtypes & mships
            //
            status = true;       // default to all specified

            loop2:
            for (i=0; i < memLimit; i++) {    // check each allowed mship type to see if it was specified

               if (!mshipA[i].equals( "" )) {

                  found = false;              // use this indicator for each type
                  loop3:
                  for (i2=0; i2 < memLimit; i2++) {    

                     if (!mshipA[i].equals( mshipS[i2] )) {

                        found = true;
                        break loop3;
                     }
                  }

                  if (found == false) {
                    
                     status = false;      // set as not ALL specified
                     break loop2;
                  }
               }
            }

            if (status == false) {         // if not all matched - check Mem types

               status = true;              // default to all specified

               loop4:
               for (i=0; i < Labels.MAX_MEMS-1; i++) {    // check each allowed mtype type to see if it was specified

                  if (!mtypeA[i].equals( "" )) {

                     found = false;              // use this indicator for each type
                     loop5:
                     for (i2=0; i2 < memLimit; i2++) {

                        if (!mtypeA[i].equals( mtypeS[i2] )) {

                           found = true;
                           break loop5;
                        }
                     }

                     if (found == false) {

                        status = false;      // set as not ALL specified
                        break loop4;
                     }
                  }
               }
            }

            if (status == true) {         // if all match

               break loop1;               // exit and return the status
            }
         }     // end of 'day' if
      }       // end of while (no more restrictions)

      pstmt1.close();

   }
   catch (Exception e) {

      throw new UnavailableException("Error checking restrictions - getRests.checkRests " + e.getMessage());
   }

   return(status);
 }

}  // end of getRests class
