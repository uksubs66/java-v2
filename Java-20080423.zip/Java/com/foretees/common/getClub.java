/***************************************************************************************
 *   getClub:  This servlet will provide some common tee time request processing methods.
 *
 *       called by:  Proshop_slot
 *                   Proshop_insert
 *
 *
 *   created:  1/12/2004   Bob P.
 *
 *
 *   last updated:
 *
 *      3/17/08  Added an additional guest type for Greeley
 *     10/24/07  Added new club option max_originations
 *      5/08/07  getParms - get the 'viewdays' for each mship type.
 *      3/19/07  Added two additional guest types for Greeley
 *      2/15/07  Custom for Greeley/Fort Collins - seperate the guest types for each course/club.
 *      7/21/06  Added new club option no_reservations
 *      6/12/06  Added new club option paceofplay
 *      2/26/05  Ver 5 - added new club option precheckin
 *      1/24/05  RDP  Ver 5 - change club2 to club5.
 *     11/16/04  Ver 5 - add new club options.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;


public class getClub {


/**
 //************************************************************************
 //
 //  Get the club parms
 //
 //************************************************************************
 **/

 public static void getParms(Connection con, parmClub parm)
         throws Exception {


   Statement pstmt1 = null;
   PreparedStatement pstmt2 = null;
   ResultSet rs = null;
   
   int i = 0;
   
   //
   //  get the club's parameters
   //
   try {

      pstmt1 = con.createStatement();        // create a statement
      
      rs = pstmt1.executeQuery("SELECT * FROM club5");
      
      if (rs.next()) {

         parm.clubName = rs.getString("clubName");
         parm.multi = rs.getInt("multi");
         parm.lottery = rs.getInt("lottery");
         parm.contact = rs.getString("contact");
         parm.email = rs.getString("email");
           
         if (parm.club.equals( "fortcollins" )) {     // if Fort Collins or Greeley (shared site)
           
            if (parm.course.equals( "Greeley CC" )) {     // if Greeley

               parm.guest[0] = rs.getString("guest15");      // guest 15 - 24 are for Greeley
               parm.guest[1] = rs.getString("guest16");
               parm.guest[2] = rs.getString("guest17");
               parm.guest[3] = rs.getString("guest18");
               parm.guest[4] = rs.getString("guest19");
               parm.guest[5] = rs.getString("guest20");
               parm.guest[6] = rs.getString("guest21");
               parm.guest[7] = rs.getString("guest22");     // added two new guest types for Greeley (03/19/07)
               parm.guest[8] = rs.getString("guest23");
               parm.guest[9] = rs.getString("guest24");     // added one new guest type for Greeley (04/05/07)
               parm.guest[10] = rs.getString("guest13");    // added new guest type for Geeley (03/17/08)
               parm.guest[11] = "";
               parm.guest[12] = "";
               parm.guest[13] = "";
               parm.guest[14] = "";
               parm.guest[15] = "";
               parm.guest[16] = "";
               parm.guest[17] = "";
               parm.guest[18] = "";
               parm.guest[19] = "";
               parm.guest[20] = "";
               parm.guest[21] = "";
               parm.guest[22] = "";
               parm.guest[23] = "";
               parm.guest[24] = "";
               parm.guest[25] = "";
               parm.guest[26] = "";
               parm.guest[27] = "";
               parm.guest[28] = "";
               parm.guest[29] = "";
               parm.guest[30] = "";
               parm.guest[31] = "";
               parm.guest[32] = "";
               parm.guest[33] = "";
               parm.guest[34] = "";
               parm.guest[35] = "";

            } else {
           
               parm.guest[0] = rs.getString("guest1");       // guest 1 - 14 are for Fort Collins
               parm.guest[1] = rs.getString("guest2");
               parm.guest[2] = rs.getString("guest3");
               parm.guest[3] = rs.getString("guest4");
               parm.guest[4] = rs.getString("guest5");
               parm.guest[5] = rs.getString("guest6");
               parm.guest[6] = rs.getString("guest7");
               parm.guest[7] = rs.getString("guest8");
               parm.guest[8] = rs.getString("guest9");
               parm.guest[9] = rs.getString("guest10");
               parm.guest[10] = rs.getString("guest11");
               parm.guest[11] = rs.getString("guest12");
               parm.guest[12] = rs.getString("guest14");    // was 13 changed to 14 to remove from Fort Collins and added to Greeley?
               parm.guest[13] = ""; //rs.getString("guest14");
               parm.guest[14] = "";
               parm.guest[15] = "";
               parm.guest[16] = "";
               parm.guest[17] = "";
               parm.guest[18] = "";
               parm.guest[19] = "";
               parm.guest[20] = "";
               parm.guest[21] = "";
               parm.guest[22] = "";
               parm.guest[23] = "";
               parm.guest[24] = "";
               parm.guest[25] = "";
               parm.guest[26] = "";
               parm.guest[27] = "";
               parm.guest[28] = "";
               parm.guest[29] = "";
               parm.guest[30] = "";
               parm.guest[31] = "";
               parm.guest[32] = "";
               parm.guest[33] = "";
               parm.guest[34] = "";
               parm.guest[35] = "";
            }

         } else {     // all other clubs

            parm.guest[0] = rs.getString("guest1");
            parm.guest[1] = rs.getString("guest2");
            parm.guest[2] = rs.getString("guest3");
            parm.guest[3] = rs.getString("guest4");
            parm.guest[4] = rs.getString("guest5");
            parm.guest[5] = rs.getString("guest6");
            parm.guest[6] = rs.getString("guest7");
            parm.guest[7] = rs.getString("guest8");
            parm.guest[8] = rs.getString("guest9");
            parm.guest[9] = rs.getString("guest10");
            parm.guest[10] = rs.getString("guest11");
            parm.guest[11] = rs.getString("guest12");
            parm.guest[12] = rs.getString("guest13");
            parm.guest[13] = rs.getString("guest14");
            parm.guest[14] = rs.getString("guest15");
            parm.guest[15] = rs.getString("guest16");
            parm.guest[16] = rs.getString("guest17");
            parm.guest[17] = rs.getString("guest18");
            parm.guest[18] = rs.getString("guest19");
            parm.guest[19] = rs.getString("guest20");
            parm.guest[20] = rs.getString("guest21");
            parm.guest[21] = rs.getString("guest22");
            parm.guest[22] = rs.getString("guest23");
            parm.guest[23] = rs.getString("guest24");
            parm.guest[24] = rs.getString("guest25");
            parm.guest[25] = rs.getString("guest26");
            parm.guest[26] = rs.getString("guest27");
            parm.guest[27] = rs.getString("guest28");
            parm.guest[28] = rs.getString("guest29");
            parm.guest[29] = rs.getString("guest30");
            parm.guest[30] = rs.getString("guest31");
            parm.guest[31] = rs.getString("guest32");
            parm.guest[32] = rs.getString("guest33");
            parm.guest[33] = rs.getString("guest34");
            parm.guest[34] = rs.getString("guest35");
            parm.guest[35] = rs.getString("guest36");
         }
         parm.mem[0] = rs.getString("mem1");
         parm.mem[1] = rs.getString("mem2");
         parm.mem[2] = rs.getString("mem3");
         parm.mem[3] = rs.getString("mem4");
         parm.mem[4] = rs.getString("mem5");
         parm.mem[5] = rs.getString("mem6");
         parm.mem[6] = rs.getString("mem7");
         parm.mem[7] = rs.getString("mem8");
         parm.mem[8] = rs.getString("mem9");
         parm.mem[9] = rs.getString("mem10");
         parm.mem[10] = rs.getString("mem11");
         parm.mem[11] = rs.getString("mem12");
         parm.mem[12] = rs.getString("mem13");
         parm.mem[13] = rs.getString("mem14");
         parm.mem[14] = rs.getString("mem15");
         parm.mem[15] = rs.getString("mem16");
         parm.mem[16] = rs.getString("mem17");
         parm.mem[17] = rs.getString("mem18");
         parm.mem[18] = rs.getString("mem19");
         parm.mem[19] = rs.getString("mem20");
         parm.mem[20] = rs.getString("mem21");
         parm.mem[21] = rs.getString("mem22");
         parm.mem[22] = rs.getString("mem23");
         parm.mem[23] = rs.getString("mem24");
         parm.mship[0] = rs.getString("mship1");
         parm.mship[1] = rs.getString("mship2");
         parm.mship[2] = rs.getString("mship3");
         parm.mship[3] = rs.getString("mship4");
         parm.mship[4] = rs.getString("mship5");
         parm.mship[5] = rs.getString("mship6");
         parm.mship[6] = rs.getString("mship7");
         parm.mship[7] = rs.getString("mship8");
         parm.mship[8] = rs.getString("mship9");
         parm.mship[9] = rs.getString("mship10");
         parm.mship[10] = rs.getString("mship11");
         parm.mship[11] = rs.getString("mship12");
         parm.mship[12] = rs.getString("mship13");
         parm.mship[13] = rs.getString("mship14");
         parm.mship[14] = rs.getString("mship15");
         parm.mship[15] = rs.getString("mship16");
         parm.mship[16] = rs.getString("mship17");
         parm.mship[17] = rs.getString("mship18");
         parm.mship[18] = rs.getString("mship19");
         parm.mship[19] = rs.getString("mship20");
         parm.mship[20] = rs.getString("mship21");
         parm.mship[21] = rs.getString("mship22");
         parm.mship[22] = rs.getString("mship23");
         parm.mship[23] = rs.getString("mship24");
         parm.x = rs.getInt("x");
         parm.xhrs = rs.getInt("xhrs");
         parm.adv_zone = rs.getString("adv_zone");
         parm.emailOpt = rs.getInt("emailOpt");
         parm.lottid = rs.getLong("lottid");
         parm.hotel = rs.getInt("hotel");
         parm.userlock = rs.getInt("userlock");
         parm.unacompGuest = rs.getInt("unacompGuest");
         parm.hndcpProSheet = rs.getInt("hndcpProSheet");
         parm.hndcpProEvent = rs.getInt("hndcpProEvent");
         parm.hndcpMemSheet = rs.getInt("hndcpMemSheet");
         parm.hndcpMemEvent = rs.getInt("hndcpMemEvent");
         parm.posType = rs.getString("posType");
         parm.rnds = rs.getInt("rndsperday");
         parm.hrsbtwn = rs.getInt("hrsbtwn");
         parm.forceg = rs.getInt("forcegnames");
         parm.hiden = rs.getInt("hidenames");
         parm.constimesm = rs.getInt("constimesm");
         parm.constimesp = rs.getInt("constimesp");
         parm.precheckin = rs.getInt("precheckin");
         parm.paceofplay = rs.getInt("paceofplay");
         parm.no_reservations = rs.getInt("no_reservations");
         parm.max_originations = rs.getInt("max_originations");

      }
      pstmt1.close();
      
      //
      // Now get the guest parms for each guest type specified (different table)
      //
      for (i = 0; i < parm.MAX_Guests; i++) {   // init the parms
               parm.gOpt[i] = 0;
      }

      for (i = 0; i < parm.MAX_Guests; i++) {   

         if (!parm.guest[i].equals( "" ) && parm.guest[i] != null) {     // if guest type specified

            pstmt2 = con.prepareStatement (
                    "SELECT gOpt FROM guest5 WHERE guest = ?");

            pstmt2.clearParameters();        // clear the parms
            pstmt2.setString(1, parm.guest[i]);
            rs = pstmt2.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               parm.gOpt[i] = rs.getInt("gOpt");
            }
            pstmt2.close();
         }
      }       // end of FOR loop

      //
      // Now get the mship parms for each mship type specified (different table)
      //
      for (i = 0; i < parm.MAX_Mships; i++) {                       // init the parms
        
         parm.period[i] = "";
         parm.advamd1[i] = "";
         parm.advamd2[i] = "";
         parm.advamd3[i] = "";
         parm.advamd4[i] = "";
         parm.advamd5[i] = "";
         parm.advamd6[i] = "";
         parm.advamd7[i] = "";
      }

      for (i = 0; i < parm.MAX_Mships; i++) {          

         if (!parm.mship[i].equals( "" ) && parm.mship[i] != null) {     // if mship type specified

            pstmt2 = con.prepareStatement (
                    "SELECT * FROM mship5 WHERE mship = ?");

            pstmt2.clearParameters();        // clear the parms
            pstmt2.setString(1, parm.mship[i]);
            rs = pstmt2.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               parm.mtimes[i] = rs.getInt("mtimes");
               parm.period[i] = rs.getString("period");
               parm.days1[i] = rs.getInt("days1");
               parm.days2[i] = rs.getInt("days2");
               parm.days3[i] = rs.getInt("days3");
               parm.days4[i] = rs.getInt("days4");
               parm.days5[i] = rs.getInt("days5");
               parm.days6[i] = rs.getInt("days6");
               parm.days7[i] = rs.getInt("days7");
               parm.advhrd1[i] = rs.getInt("advhrd1");
               parm.advmind1[i] = rs.getInt("advmind1");
               parm.advamd1[i] = rs.getString("advamd1");
               parm.advhrd2[i] = rs.getInt("advhrd2");
               parm.advmind2[i] = rs.getInt("advmind2");
               parm.advamd2[i] = rs.getString("advamd2");
               parm.advhrd3[i] = rs.getInt("advhrd3");
               parm.advmind3[i] = rs.getInt("advmind3");
               parm.advamd3[i] = rs.getString("advamd3");
               parm.advhrd4[i] = rs.getInt("advhrd4");
               parm.advmind4[i] = rs.getInt("advmind4");
               parm.advamd4[i] = rs.getString("advamd4");
               parm.advhrd5[i] = rs.getInt("advhrd5");
               parm.advmind5[i] = rs.getInt("advmind5");
               parm.advamd5[i] = rs.getString("advamd5");
               parm.advhrd6[i] = rs.getInt("advhrd6");
               parm.advmind6[i] = rs.getInt("advmind6");
               parm.advamd6[i] = rs.getString("advamd6");
               parm.advhrd7[i] = rs.getInt("advhrd7");
               parm.advmind7[i] = rs.getInt("advmind7");
               parm.advamd7[i] = rs.getString("advamd7");
               parm.viewdays[i] = rs.getInt("viewdays");
            }
            pstmt2.close();
         }
      }       // end of FOR loop

   }
   catch (Exception e) {

      throw new Exception("Error getting guest info - getClub.getParms, Error=" + e.getMessage());
   }

 }


/**
 //************************************************************************
 //
 //  Get the club and course POS parms
 //
 //************************************************************************
 **/

 public static void getPOS(Connection con, parmPOS parm, String course)
         throws Exception {


   Statement stmt1 = null;
   ResultSet rs = null;
   PreparedStatement pstmt1 = null;

   int i = 0;
     

   //
   //  get the club's parameters
   //
   try {

      stmt1 = con.createStatement();        // create a statement

      rs = stmt1.executeQuery("SELECT * FROM club5");

      if (rs.next()) {

         parm.gtype[0] = rs.getString("guest1");
         parm.gtype[1] = rs.getString("guest2");
         parm.gtype[2] = rs.getString("guest3");
         parm.gtype[3] = rs.getString("guest4");
         parm.gtype[4] = rs.getString("guest5");
         parm.gtype[5] = rs.getString("guest6");
         parm.gtype[6] = rs.getString("guest7");
         parm.gtype[7] = rs.getString("guest8");
         parm.gtype[8] = rs.getString("guest9");
         parm.gtype[9] = rs.getString("guest10");
         parm.gtype[10] = rs.getString("guest11");
         parm.gtype[11] = rs.getString("guest12");
         parm.gtype[12] = rs.getString("guest13");
         parm.gtype[13] = rs.getString("guest14");
         parm.gtype[14] = rs.getString("guest15");
         parm.gtype[15] = rs.getString("guest16");
         parm.gtype[16] = rs.getString("guest17");
         parm.gtype[17] = rs.getString("guest18");
         parm.gtype[18] = rs.getString("guest19");
         parm.gtype[19] = rs.getString("guest20");
         parm.gtype[20] = rs.getString("guest21");
         parm.gtype[21] = rs.getString("guest22");
         parm.gtype[22] = rs.getString("guest23");
         parm.gtype[23] = rs.getString("guest24");
         parm.gtype[24] = rs.getString("guest25");
         parm.gtype[25] = rs.getString("guest26");
         parm.gtype[26] = rs.getString("guest27");
         parm.gtype[27] = rs.getString("guest28");
         parm.gtype[28] = rs.getString("guest29");
         parm.gtype[29] = rs.getString("guest30");
         parm.gtype[30] = rs.getString("guest31");
         parm.gtype[31] = rs.getString("guest32");
         parm.gtype[32] = rs.getString("guest33");
         parm.gtype[33] = rs.getString("guest34");
         parm.gtype[34] = rs.getString("guest35");
         parm.gtype[35] = rs.getString("guest36");
         parm.mship[0] = rs.getString("mship1");
         parm.mship[1] = rs.getString("mship2");
         parm.mship[2] = rs.getString("mship3");
         parm.mship[3] = rs.getString("mship4");
         parm.mship[4] = rs.getString("mship5");
         parm.mship[5] = rs.getString("mship6");
         parm.mship[6] = rs.getString("mship7");
         parm.mship[7] = rs.getString("mship8");
         parm.mship[8] = rs.getString("mship9");
         parm.mship[9] = rs.getString("mship10");
         parm.mship[10] = rs.getString("mship11");
         parm.mship[11] = rs.getString("mship12");
         parm.mship[12] = rs.getString("mship13");
         parm.mship[13] = rs.getString("mship14");
         parm.mship[14] = rs.getString("mship15");
         parm.mship[15] = rs.getString("mship16");
         parm.mship[16] = rs.getString("mship17");
         parm.mship[17] = rs.getString("mship18");
         parm.mship[18] = rs.getString("mship19");
         parm.mship[19] = rs.getString("mship20");
         parm.mship[20] = rs.getString("mship21");
         parm.mship[21] = rs.getString("mship22");
         parm.mship[22] = rs.getString("mship23");
         parm.mship[23] = rs.getString("mship24");
         parm.posType = rs.getString("posType");
      }
      stmt1.close();
           
      //
      // Now get the guest parms for each guest type specified (different table)
      //
      for (i=0; i<parm.MAX_Guests; i++) {

         if (!parm.gtype[i].equals( "" ) && parm.gtype[i] != null) {     // if guest type specified

            pstmt1 = con.prepareStatement (
                    "SELECT * FROM guest5 WHERE guest = ?");

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, parm.gtype[i]);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               parm.gpos[i] = rs.getString("gpos");
               parm.g9pos[i] = rs.getString("g9pos");
               parm.gstI[i] = rs.getString("gstItem");
               parm.gst9I[i] = rs.getString("gst9Item");
            }
            pstmt1.close();
         }
      }       // end of FOR loop
  
      //
      // Now get the mship parms for each mship type specified (different table)
      //
      for (i=0; i<parm.MAX_Mships; i++) {

         if (!parm.mship[i].equals( "" ) && parm.mship[i] != null) {     // if mship type specified

            pstmt1 = con.prepareStatement (
                    "SELECT * FROM mship5 WHERE mship = ?");

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, parm.mship[i]);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               parm.mpos[i] = rs.getString("mpos");
               parm.mposc[i] = rs.getString("mposc");
               parm.m9posc[i] = rs.getString("m9posc");
               parm.mshipI[i] = rs.getString("mshipItem");
               parm.mship9I[i] = rs.getString("mship9Item");
            }
            pstmt1.close();
         }
      }       // end of FOR loop
  
      //
      //  Get the course parms
      //
      PreparedStatement pstmtc = con.prepareStatement (
         "SELECT * " +
         "FROM clubparm2 WHERE courseName = ?");

      pstmtc.clearParameters();        // clear the parms
      pstmtc.setString(1, course);
      rs = pstmtc.executeQuery();      // execute the prepared stmt

      if (rs.next()) {                  

         parm.tmode[0] = rs.getString("tmode1");
         parm.tmodea[0] = rs.getString("tmodea1");
         parm.tmode[1] = rs.getString("tmode2");
         parm.tmodea[1] = rs.getString("tmodea2");
         parm.tmode[2] = rs.getString("tmode3");
         parm.tmodea[2] = rs.getString("tmodea3");
         parm.tmode[3] = rs.getString("tmode4");
         parm.tmodea[3] = rs.getString("tmodea4");
         parm.tmode[4] = rs.getString("tmode5");
         parm.tmodea[4] = rs.getString("tmodea5");
         parm.tmode[5] = rs.getString("tmode6");
         parm.tmodea[5] = rs.getString("tmodea6");
         parm.tmode[6] = rs.getString("tmode7");
         parm.tmodea[6] = rs.getString("tmodea7");
         parm.tmode[7] = rs.getString("tmode8");
         parm.tmodea[7] = rs.getString("tmodea8");
         parm.tmode[8] = rs.getString("tmode9");
         parm.tmodea[8] = rs.getString("tmodea9");
         parm.tmode[9] = rs.getString("tmode10");
         parm.tmodea[9] = rs.getString("tmodea10");
         parm.tmode[10] = rs.getString("tmode11");
         parm.tmodea[10] = rs.getString("tmodea11");
         parm.tmode[11] = rs.getString("tmode12");
         parm.tmodea[11] = rs.getString("tmodea12");
         parm.tmode[12] = rs.getString("tmode13");
         parm.tmodea[12] = rs.getString("tmodea13");
         parm.tmode[13] = rs.getString("tmode14");
         parm.tmodea[13] = rs.getString("tmodea14");
         parm.tmode[14] = rs.getString("tmode15");
         parm.tmodea[14] = rs.getString("tmodea15");
         parm.tmode[15] = rs.getString("tmode16");
         parm.tmodea[15] = rs.getString("tmodea16");
         parm.t9pos[0] = rs.getString("t9pos1");
         parm.tpos[0] = rs.getString("tpos1");
         parm.t9pos[1] = rs.getString("t9pos2");
         parm.tpos[1] = rs.getString("tpos2");
         parm.t9pos[2] = rs.getString("t9pos3");
         parm.tpos[2] = rs.getString("tpos3");
         parm.t9pos[3] = rs.getString("t9pos4");
         parm.tpos[3] = rs.getString("tpos4");
         parm.t9pos[4] = rs.getString("t9pos5");
         parm.tpos[4] = rs.getString("tpos5");
         parm.t9pos[5] = rs.getString("t9pos6");
         parm.tpos[5] = rs.getString("tpos6");
         parm.t9pos[6] = rs.getString("t9pos7");
         parm.tpos[6] = rs.getString("tpos7");
         parm.t9pos[7] = rs.getString("t9pos8");
         parm.tpos[7] = rs.getString("tpos8");
         parm.t9pos[8] = rs.getString("t9pos9");
         parm.tpos[8] = rs.getString("tpos9");
         parm.t9pos[9] = rs.getString("t9pos10");
         parm.tpos[9] = rs.getString("tpos10");
         parm.t9pos[10] = rs.getString("t9pos11");
         parm.tpos[10] = rs.getString("tpos11");
         parm.t9pos[11] = rs.getString("t9pos12");
         parm.tpos[11] = rs.getString("tpos12");
         parm.t9pos[12] = rs.getString("t9pos13");
         parm.tpos[12] = rs.getString("tpos13");
         parm.t9pos[13] = rs.getString("t9pos14");
         parm.tpos[13] = rs.getString("tpos14");
         parm.t9pos[14] = rs.getString("t9pos15");
         parm.tpos[14] = rs.getString("tpos15");
         parm.t9pos[15] = rs.getString("t9pos16");
         parm.tpos[15] = rs.getString("tpos16");
         parm.courseid = rs.getString("courseid");
         parm.t9posc[0] = rs.getString("t9posc1");
         parm.tposc[0] = rs.getString("tposc1");
         parm.t9posc[1] = rs.getString("t9posc2");
         parm.tposc[1] = rs.getString("tposc2");
         parm.t9posc[2] = rs.getString("t9posc3");
         parm.tposc[2] = rs.getString("tposc3");
         parm.t9posc[3] = rs.getString("t9posc4");
         parm.tposc[3] = rs.getString("tposc4");
         parm.t9posc[4] = rs.getString("t9posc5");
         parm.tposc[4] = rs.getString("tposc5");
         parm.t9posc[5] = rs.getString("t9posc6");
         parm.tposc[5] = rs.getString("tposc6");
         parm.t9posc[6] = rs.getString("t9posc7");
         parm.tposc[6] = rs.getString("tposc7");
         parm.t9posc[7] = rs.getString("t9posc8");
         parm.tposc[7] = rs.getString("tposc8");
         parm.t9posc[8] = rs.getString("t9posc9");
         parm.tposc[8] = rs.getString("tposc9");
         parm.t9posc[9] = rs.getString("t9posc10");
         parm.tposc[9] = rs.getString("tposc10");
         parm.t9posc[10] = rs.getString("t9posc11");
         parm.tposc[10] = rs.getString("tposc11");
         parm.t9posc[11] = rs.getString("t9posc12");
         parm.tposc[11] = rs.getString("tposc12");
         parm.t9posc[12] = rs.getString("t9posc13");
         parm.tposc[12] = rs.getString("tposc13");
         parm.t9posc[13] = rs.getString("t9posc14");
         parm.tposc[13] = rs.getString("tposc14");
         parm.t9posc[14] = rs.getString("t9posc15");
         parm.tposc[14] = rs.getString("tposc15");
         parm.t9posc[15] = rs.getString("t9posc16");
         parm.tposc[15] = rs.getString("tposc16");
      }
      pstmtc.close();

   }
   catch (Exception e) {

      throw new Exception("Error getting guest info - getClub.getPOS " + e.getMessage());
   }

 }


/**
 //************************************************************************
 //
 //  Get the Membership and Member Types Only
 // 
 //************************************************************************
 **/

 public static mTypeArrays getMtypes(mTypeArrays mArrays, Connection con)
         throws Exception {


   Statement pstmt1 = null;
   ResultSet rs = null;

   int i = 0;

   //
   //  get the club's parameters
   //
   try {

      pstmt1 = con.createStatement();        // create a statement

      rs = pstmt1.executeQuery("SELECT * FROM club5");

      if (rs.next()) {

         mArrays.mem[0] = rs.getString("mem1");
         mArrays.mem[1] = rs.getString("mem2");
         mArrays.mem[2] = rs.getString("mem3");
         mArrays.mem[3] = rs.getString("mem4");
         mArrays.mem[4] = rs.getString("mem5");
         mArrays.mem[5] = rs.getString("mem6");
         mArrays.mem[6] = rs.getString("mem7");
         mArrays.mem[7] = rs.getString("mem8");
         mArrays.mem[8] = rs.getString("mem9");
         mArrays.mem[9] = rs.getString("mem10");
         mArrays.mem[10] = rs.getString("mem11");
         mArrays.mem[11] = rs.getString("mem12");
         mArrays.mem[12] = rs.getString("mem13");
         mArrays.mem[13] = rs.getString("mem14");
         mArrays.mem[14] = rs.getString("mem15");
         mArrays.mem[15] = rs.getString("mem16");
         mArrays.mem[16] = rs.getString("mem17");
         mArrays.mem[17] = rs.getString("mem18");
         mArrays.mem[18] = rs.getString("mem19");
         mArrays.mem[19] = rs.getString("mem20");
         mArrays.mem[20] = rs.getString("mem21");
         mArrays.mem[21] = rs.getString("mem22");
         mArrays.mem[22] = rs.getString("mem23");
         mArrays.mem[23] = rs.getString("mem24");
         mArrays.mship[0] = rs.getString("mship1");
         mArrays.mship[1] = rs.getString("mship2");
         mArrays.mship[2] = rs.getString("mship3");
         mArrays.mship[3] = rs.getString("mship4");
         mArrays.mship[4] = rs.getString("mship5");
         mArrays.mship[5] = rs.getString("mship6");
         mArrays.mship[6] = rs.getString("mship7");
         mArrays.mship[7] = rs.getString("mship8");
         mArrays.mship[8] = rs.getString("mship9");
         mArrays.mship[9] = rs.getString("mship10");
         mArrays.mship[10] = rs.getString("mship11");
         mArrays.mship[11] = rs.getString("mship12");
         mArrays.mship[12] = rs.getString("mship13");
         mArrays.mship[13] = rs.getString("mship14");
         mArrays.mship[14] = rs.getString("mship15");
         mArrays.mship[15] = rs.getString("mship16");
         mArrays.mship[16] = rs.getString("mship17");
         mArrays.mship[17] = rs.getString("mship18");
         mArrays.mship[18] = rs.getString("mship19");
         mArrays.mship[19] = rs.getString("mship20");
         mArrays.mship[20] = rs.getString("mship21");
         mArrays.mship[21] = rs.getString("mship22");
         mArrays.mship[22] = rs.getString("mship23");
         mArrays.mship[23] = rs.getString("mship24");
      }
      pstmt1.close();

   }
   catch (Exception e) {

      throw new Exception("Error getting guest info - getClub.getMtypes " + e.getMessage());
   }

   return(mArrays);
 }


}  // end of getClub class

