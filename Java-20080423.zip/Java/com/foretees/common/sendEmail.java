/***************************************************************************************
 *   sendEmail:  This servlet will send an email notification based on info provided in the parm table.
 *
 *       called by:  Proshop_slot
 *                   Proshop_lott
 *                   Proshop_evntSignUp
 *                   Proshop_insert
 *                   Member_slot
 *                   Member_lott
 *                   Member_evntSignUp
 *
 *
 *   created:  2/18/2004   Bob P.
 *   
 *   iCal reference: http://tools.ietf.org/html/rfc2445#section-2
 *
 *   last updated:
 *
 *      3/27/08  The CC - Add unhidden notes to tee time emails (Case# 1406)
 *      3/27/08  Tweak date output for season long events
 *      3/10/08  Added support for external mail servers
 *      3/07/08  Piedmont & Gallery - add pro emails to all event signup notifications (cases 1395 & 1398).
 *               This is for these customs, but will be used for all when config added to events.
 *      2/29/08  Add the individual tee times to the groups of multiple tee time requests (case 1231). 
 *     12/31/07  MN Valley CC - send email to pro on mods or cancels of event registrations (Case #1353)
 *     12/14/07  Fixed lesson book emails so they are sent to pro even if member doesn't have email in system
 *      9/24/07  Pinery CC - Hide Front or Back Nine References (Case #1045)
 *      9/24/07  Hallbrook CC - send email to caddie master when a caddie is requested (case #1037) - use Oakmont method.
 *      9/21/07  Mediterra - Added sendMediterraEmail to send email to pro when Sports mship uses up their guest quota
 *      9/21/07  Baltimore CC - send email to pro on all event registration activity (Case #1228)
 *      8/14/07  Changed logic to allow sending to email2 even if email is empty
 *      6/26/07  Blackhawk - blind copy Mark Caufield whenever an email goes to specific members (case #1201).
 *      6/26/07  The CC - do not include the '9' (front/back) in emails - it confuses the members (case #1197).
 *      6/19/07  Winged Foot - copy all emails to pro (case #1146).
 *      6/19/07  TLT - change messages for TLT clubs.
 *      5/07/07  The CC - add a note to all emails for members to contact pro with questions.
 *      5/07/07  Correct special characters in the club name (i.e. & instead of &amp).
 *      4/25/07  Congressional - pass the date for the ourse Name Labeling.
 *      4/10/07  Congressional - abstract the course name depending on the day (Course Name Labeling, case #1046).
 *      3/27/07  Tweaked debug info and changed the word Lottery to Tee Time Request for Pecan Plantation (for spam testing)
 *      3/12/07  Add additional debug information to error log for failed send calls.
 *      2/06/07  Add checks for duplicate email addresses.
 *      1/29/07  Add the time of the event to emails for event signups (for non-shotgun events).
 *     10/07/06  Change queries to only pull back email addresses that don't have the bounced flag on
 *      3/07/06  change logerror to go to verifySlot.
 *     11/02/05  Bellerive - send emails to other clubs from their temp site.
 *     10/14/05  Add spam message for AOL users.
 *      6/16/05  Westchester - custom subject strings.
 *      5/12/05  Send email to lesson pro whenever a lesson is added or cancelled.
 *      3/25/05  Add custom method for Oakmont - send email to caddie master.
 *      1/24/05  RDP Ver 5 - change club2 to club5.
 *      1/05/05  RDP Ver 5 - add emails for frost delay feature in proshop.
 *      8/25/04  RDP Do not send email if today and tee time has past or is within 1 hr of current time.
 *
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.internet.*;
import javax.mail.*;
import javax.activation.*;


public class sendEmail {


   //********************************************************
   // Some constants for emails sent within this class
   //********************************************************
   //
   static String host = ProcessConstants.HOST;

   static String port = ProcessConstants.PORT;

   static String efrom = ProcessConstants.EFROM;

   static String header = ProcessConstants.HEADER;

   static String trailer = ProcessConstants.TRAILER;

   static String trailerAOL = ProcessConstants.TRAILERAOL;

   private static String rev = ProcessConstants.REV;


/**
 //************************************************************************
 //
 //  sendIt - build and send the email notification
 //
 //************************************************************************
 **/

 public static void sendIt(parmEmail parms, Connection con) {

   String debug_addresses = "";
     
   Statement estmt = null;
   Statement stmtN = null;
   ResultSet rs = null;


   //
   //  Get the parms passed in the parm block
   //
   long date = parms.date;
   int time = parms.time;
   int time2 = parms.time2;
   int time3 = parms.time3;
   int time4 = parms.time4;
   int time5 = parms.time5;
   int to_time = parms.to_time;
   int from_time = parms.from_time;
   int fb = parms.fb;
   int to_fb = parms.to_fb;
   int from_fb = parms.from_fb;
   int mm = parms.mm;
   int dd = parms.dd;
   int yy = parms.yy;

   int emailNew = parms.emailNew;
   int emailMod = parms.emailMod;
   int emailCan = parms.emailCan;

   int p91 = parms.p91;
   int p92 = parms.p92;
   int p93 = parms.p93;
   int p94 = parms.p94;
   int p95 = parms.p95;
   int p96 = parms.p96;
   int p97 = parms.p97;
   int p98 = parms.p98;
   int p99 = parms.p99;
   int p910 = parms.p910;
   int p911 = parms.p911;
   int p912 = parms.p912;
   int p913 = parms.p913;
   int p914 = parms.p914;
   int p915 = parms.p915;
   int p916 = parms.p916;
   int p917 = parms.p917;
   int p918 = parms.p918;
   int p919 = parms.p919;
   int p920 = parms.p920;
   int p921 = parms.p921;
   int p922 = parms.p922;
   int p923 = parms.p923;
   int p924 = parms.p924;
   int p925 = parms.p925;
     
   int i = 0;
   int i2 = 0;
   int TLT = 0;

   String type = parms.type;        // tee, event, lottery, moveWhole, or moveSingle
   String day = parms.day;
   String course = parms.course;
   String to_course = parms.to_course;
   String from_course = parms.from_course;

   String [] eaddrA = new String [100];            // arrays to process email addresses (max possible = 100)

   String [] userA = new String [25];              // usernames 
   String [] olduserA = new String [25];           // old usernames

   String player1 = parms.player1;
   String player2 = parms.player2;
   String player3 = parms.player3;
   String player4 = parms.player4;
   String player5 = parms.player5;
   String player6 = parms.player6;
   String player7 = parms.player7;
   String player8 = parms.player8;
   String player9 = parms.player9;
   String player10 = parms.player10;
   String player11 = parms.player11;
   String player12 = parms.player12;
   String player13 = parms.player13;
   String player14 = parms.player14;
   String player15 = parms.player15;
   String player16 = parms.player16;
   String player17 = parms.player17;
   String player18 = parms.player18;
   String player19 = parms.player19;
   String player20 = parms.player20;
   String player21 = parms.player21;
   String player22 = parms.player22;
   String player23 = parms.player23;
   String player24 = parms.player24;
   String player25 = parms.player25;

   String oldplayer1 = parms.oldplayer1;
   String oldplayer2 = parms.oldplayer2;
   String oldplayer3 = parms.oldplayer3;
   String oldplayer4 = parms.oldplayer4;
   String oldplayer5 = parms.oldplayer5;
   String oldplayer6 = parms.oldplayer6;
   String oldplayer7 = parms.oldplayer7;
   String oldplayer8 = parms.oldplayer8;
   String oldplayer9 = parms.oldplayer9;
   String oldplayer10 = parms.oldplayer10;
   String oldplayer11 = parms.oldplayer11;
   String oldplayer12 = parms.oldplayer12;
   String oldplayer13 = parms.oldplayer13;
   String oldplayer14 = parms.oldplayer14;
   String oldplayer15 = parms.oldplayer15;
   String oldplayer16 = parms.oldplayer16;
   String oldplayer17 = parms.oldplayer17;
   String oldplayer18 = parms.oldplayer18;
   String oldplayer19 = parms.oldplayer19;
   String oldplayer20 = parms.oldplayer20;
   String oldplayer21 = parms.oldplayer21;
   String oldplayer22 = parms.oldplayer22;
   String oldplayer23 = parms.oldplayer23;
   String oldplayer24 = parms.oldplayer24;
   String oldplayer25 = parms.oldplayer25;

   String user = parms.user;
   userA[0] = parms.user1;
   userA[1] = parms.user2;
   userA[2] = parms.user3;
   userA[3] = parms.user4;
   userA[4] = parms.user5;
   userA[5] = parms.user6;
   userA[6] = parms.user7;
   userA[7] = parms.user8;
   userA[8] = parms.user9;
   userA[9] = parms.user10;
   userA[10] = parms.user11;
   userA[11] = parms.user12;
   userA[12] = parms.user13;
   userA[13] = parms.user14;
   userA[14] = parms.user15;
   userA[15] = parms.user16;
   userA[16] = parms.user17;
   userA[17] = parms.user18;
   userA[18] = parms.user19;
   userA[19] = parms.user20;
   userA[20] = parms.user21;
   userA[21] = parms.user22;
   userA[22] = parms.user23;
   userA[23] = parms.user24;
   userA[24] = parms.user25;

   olduserA[0] = parms.olduser1;
   olduserA[1] = parms.olduser2;
   olduserA[2] = parms.olduser3;
   olduserA[3] = parms.olduser4;
   olduserA[4] = parms.olduser5;
   olduserA[5] = parms.olduser6;
   olduserA[6] = parms.olduser7;
   olduserA[7] = parms.olduser8;
   olduserA[8] = parms.olduser9;
   olduserA[9] = parms.olduser10;
   olduserA[10] = parms.olduser11;
   olduserA[11] = parms.olduser12;
   olduserA[12] = parms.olduser13;
   olduserA[13] = parms.olduser14;
   olduserA[14] = parms.olduser15;
   olduserA[15] = parms.olduser16;
   olduserA[16] = parms.olduser17;
   olduserA[17] = parms.olduser18;
   olduserA[18] = parms.olduser19;
   olduserA[19] = parms.olduser20;
   olduserA[20] = parms.olduser21;
   olduserA[21] = parms.olduser22;
   olduserA[22] = parms.olduser23;
   olduserA[23] = parms.olduser24;
   olduserA[24] = parms.olduser25;

   String pcw1 = parms.pcw1;
   String pcw2 = parms.pcw2;
   String pcw3 = parms.pcw3;
   String pcw4 = parms.pcw4;
   String pcw5 = parms.pcw5;
   String pcw6 = parms.pcw6;
   String pcw7 = parms.pcw7;
   String pcw8 = parms.pcw8;
   String pcw9 = parms.pcw9;
   String pcw10 = parms.pcw10;
   String pcw11 = parms.pcw11;
   String pcw12 = parms.pcw12;
   String pcw13 = parms.pcw13;
   String pcw14 = parms.pcw14;
   String pcw15 = parms.pcw15;
   String pcw16 = parms.pcw16;
   String pcw17 = parms.pcw17;
   String pcw18 = parms.pcw18;
   String pcw19 = parms.pcw19;
   String pcw20 = parms.pcw20;
   String pcw21 = parms.pcw21;
   String pcw22 = parms.pcw22;
   String pcw23 = parms.pcw23;
   String pcw24 = parms.pcw24;
   String pcw25 = parms.pcw25;

   String oldpcw1 = parms.oldpcw1;
   String oldpcw2 = parms.oldpcw2;
   String oldpcw3 = parms.oldpcw3;
   String oldpcw4 = parms.oldpcw4;
   String oldpcw5 = parms.oldpcw5;
   String oldpcw6 = parms.oldpcw6;
   String oldpcw7 = parms.oldpcw7;
   String oldpcw8 = parms.oldpcw8;
   String oldpcw9 = parms.oldpcw9;
   String oldpcw10 = parms.oldpcw10;
   String oldpcw11 = parms.oldpcw11;
   String oldpcw12 = parms.oldpcw12;
   String oldpcw13 = parms.oldpcw13;
   String oldpcw14 = parms.oldpcw14;
   String oldpcw15 = parms.oldpcw15;
   String oldpcw16 = parms.oldpcw16;
   String oldpcw17 = parms.oldpcw17;
   String oldpcw18 = parms.oldpcw18;
   String oldpcw19 = parms.oldpcw19;
   String oldpcw20 = parms.oldpcw20;
   String oldpcw21 = parms.oldpcw21;
   String oldpcw22 = parms.oldpcw22;
   String oldpcw23 = parms.oldpcw23;
   String oldpcw24 = parms.oldpcw24;
   String oldpcw25 = parms.oldpcw25;

   String name = parms.name;      // Event-only fields
   String wuser1 = parms.wuser1;    
   String wuser2 = parms.wuser2;
   String wuser3 = parms.wuser3;
   String wuser4 = parms.wuser4;
   String wuser5 = parms.wuser5;
   String act_time = parms.act_time;
   
   String tmp_sql = "SELECT (SELECT email FROM member2b WHERE username = ? AND email_bounced = 0) AS email1, (SELECT emailOpt FROM member2b WHERE username = ?) AS emailOpt, (SELECT email2 FROM member2b WHERE username = ? AND email2_bounced = 0) AS email2";
   // old sql was   "SELECT email, emailOpt, email2 FROM member2b WHERE username = ?"
   
   int etype = parms.etype;
   int wait = parms.wait;
   int checkWait = parms.checkWait;

   String recipients = "";
   
   //
   //  Setup for email
   //
   String author = "unknown";
   String userFirst = "";
   String userMi = "";
   String userLast = "";
   String proName = "";
   String proEmail1 = "";
   String proEmail2 = "";
   String clubProName = "";
   String clubProEmail = "";
   String eventPro1 = "";
   String eventPro2 = "";

   boolean aol = false;
   boolean dup = false;
   boolean BHproCCed = false;
     
   
   //
   // Get the SMTP parmaters this club is using
   //
   parmSMTP parm = new parmSMTP();
   
   try {

      getSMTP.getParms(con, parm);       // get the SMTP parms

   } catch (Exception ignore) {}
   
   
   if (type.equals( "event" )) {         // If Event Signup email
      
      eventPro1 = parms.emailpro1;       // get optional pro email addresses 
      eventPro2 = parms.emailpro2;
   }
   
   
   for (i2=0; i2<100; i2++) {            // init the email address array

      eaddrA[i2] = "";
   }


   if (!user.startsWith( "proshop" )) {  // if not proshop

      try {

         //
         //  Get this user's name (for id in email msg)
         //
         PreparedStatement pstmte = con.prepareStatement (
                  "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

         pstmte.clearParameters();        // clear the parms
         pstmte.setString(1, user);
         rs = pstmte.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            userLast = rs.getString(1);        // user's name
            userFirst = rs.getString(2);
            userMi = rs.getString(3);

            if (userMi.equals( "" )) {

               author = userFirst + " " + userLast;

            } else {

               author = userFirst + " " + userMi + " " + userLast;
            }
         }
         pstmte.close();              // close the stmt

      }
      catch (Exception ignore) {
      }
        
   } else {

      author = user;
   }

   //
   //  Get today's date and time for email processing
   //
   Calendar ecal = new GregorianCalendar();               // get todays date
   int eyear = ecal.get(Calendar.YEAR);
   int emonth = ecal.get(Calendar.MONTH);
   int eday = ecal.get(Calendar.DAY_OF_MONTH);
   int e_hourDay = ecal.get(Calendar.HOUR_OF_DAY);
   int e_min = ecal.get(Calendar.MINUTE);
   int e_sec = ecal.get(Calendar.SECOND);

   int emailOk = 1;          // default to 'send it'
   int e_time = 0;
   int e_time2 = 0;
   long e_date = 0;

   String email_time = "";

   //
   //  Build the 'time' string for display
   //
   //    Adjust the time based on the club's time zone (we are Central)
   //
   e_time = (e_hourDay * 100) + e_min;

   e_time = adjustTime(con, e_time);       // adjust for time zone

   if (e_time < 0) {                // if negative, then we went back or ahead one day

      e_time = 0 - e_time;          // convert back to positive value

      if (e_time < 100) {           // if hour is zero, then we rolled ahead 1 day

         //
         // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
         //
         ecal.add(Calendar.DATE,1);                     // get next day's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);

      } else {                        // we rolled back 1 day

         //
         // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
         //
         ecal.add(Calendar.DATE,-1);                     // get yesterday's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);
      }
   }

   int e_hour = e_time / 100;               // get adjusted hour
   e_min = e_time - (e_hour * 100);         // get minute value
   int e_am_pm = 0;                         // preset to AM

   if (e_hour > 11) {

      e_am_pm = 1;                          // PM
      e_hour = e_hour - 12;                 // set to 12 hr clock
   }
   
   if (e_hour == 0) e_hour = 12;

   emonth++;                                // month starts at zero
   e_date = (eyear * 10000) + (emonth * 100) + eday;

   // set the date/time string for email message
   email_time = emonth + "/" + eday + "/" + eyear + " at " + e_hour + ":" + ensureDoubleDigit(e_min) + ((e_am_pm == 0) ? " AM" : " PM");

   String DTSTAMP = e_date + "T" + ensureDoubleDigit(e_hour) + ensureDoubleDigit(e_min) + ensureDoubleDigit(e_sec);
   
   //
   // DONE SETTING UP INITIAL DATE/TIME VARIABLES
   
   
   
   
   if (type.equals( "moveWhole" )) {       // if from edit tee sheet (move whole tee time)
     
      time = to_time;         // set tee time to the time moved to
   }

   //
   //  Determine current time plus one hour - do not send email if within 1 hour of tee time
   //
   e_time2 = e_time + 100;     // current adjusted time plus 1 hr

   if (type.equals( "password" )) {       // if from Login (password request)

      emailOk = 1;                       //  send email
      user = "";                         //  don't need now

   } else {

      if (date == e_date) {          // if tee time is for today

         if (time <= e_time2) {      // if tee time already past or within 1 hr of now

            emailOk = 0;             // do not send email
         }
      }
   }

   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   if (emailOk != 0) {

      String to = "";                           // to address
      String to2 = "";                          // to address
      String f_b = "";
      String eampm = "";
      String etime = "";
      String etime2 = "";
      String etime3 = "";
      String etime4 = "";
      String etime5 = "";
      int emailOpt = 0;                         // user's email option parm
      int ehr = 0;
      int emin = 0;
      int send = 0;
      String clubName = "";
      String errorMsg = "";
        
      PreparedStatement pstmte1 = null;

      //
      //  Get the name of the club
      //
      try {

         stmtN = con.createStatement();

         rs = stmtN.executeQuery("SELECT clubName, contact, email, no_reservations FROM club5 WHERE clubName != ''");

         if (rs.next()) {

            clubName = rs.getString(1);
            clubProName = rs.getString(2);
            clubProEmail = rs.getString(3);
            TLT = rs.getInt(4);                   // TLT Club ?
         }
         stmtN.close();

      }
      catch (Exception ignore) {
      }

      //
      //  Clean up the club name - convert any html special characters to normal
      //
      clubName = unfilter(clubName);
        

      //
      //  convert time to hour and minutes for email msg
      //
      ehr = time / 100;
      emin = time - (ehr * 100);
      eampm = " AM";
      if (ehr > 12) {

         eampm = " PM";
         ehr = ehr - 12;       // convert from military time
      }
      if (ehr == 12) {

         eampm = " PM";
      }
      if (ehr == 0) {

         ehr = 12;
         eampm = " AM";
      }

      etime = ehr + ":" + ensureDoubleDigit(emin) + eampm;
         

      if (time2 > 0) {            // if another time specified (multiple groups)
         
         ehr = time2 / 100;
         emin = time2 - (ehr * 100);
         eampm = " AM";
         if (ehr > 12) {

            eampm = " PM";
            ehr = ehr - 12;       // convert from military time
         }
         if (ehr == 12) {

            eampm = " PM";
         }
         if (ehr == 0) {

            ehr = 12;
            eampm = " AM";
         }

         etime2 = ehr + ":" + ensureDoubleDigit(emin) + eampm;
      }

      if (time3 > 0) {            // if another time specified (multiple groups)
         
         ehr = time3 / 100;
         emin = time3 - (ehr * 100);
         eampm = " AM";
         if (ehr > 12) {

            eampm = " PM";
            ehr = ehr - 12;       // convert from military time
         }
         if (ehr == 12) {

            eampm = " PM";
         }
         if (ehr == 0) {

            ehr = 12;
            eampm = " AM";
         }

         etime3 = ehr + ":" + ensureDoubleDigit(emin) + eampm;
      }

      if (time4 > 0) {            // if another time specified (multiple groups)
         
         ehr = time4 / 100;
         emin = time4 - (ehr * 100);
         eampm = " AM";
         if (ehr > 12) {

            eampm = " PM";
            ehr = ehr - 12;       // convert from military time
         }
         if (ehr == 12) {

            eampm = " PM";
         }
         if (ehr == 0) {

            ehr = 12;
            eampm = " AM";
         }

         etime4 = ehr + ":" + ensureDoubleDigit(emin) + eampm;
      }

      if (time5 > 0) {            // if another time specified (multiple groups)
         
         ehr = time5 / 100;
         emin = time5 - (ehr * 100);
         eampm = " AM";
         if (ehr > 12) {

            eampm = " PM";
            ehr = ehr - 12;       // convert from military time
         }
         if (ehr == 12) {

            eampm = " PM";
         }
         if (ehr == 0) {

            ehr = 12;
            eampm = " AM";
         }

         etime5 = ehr + ":" + ensureDoubleDigit(emin) + eampm;
      }
      
      
   
      //
      // PERFORM PRE-PROCESSING DEPENDING ON "TYPE" OF MESSAGE
      
      if (!type.startsWith( "lesson" )) {       // if not a lesson email (fb = proid for lessons)

         //
         //  set the front/back value
         //
         f_b = "Front";

         if (fb == 1) {

            f_b = "Back";
         }
      }

      if (clubName.startsWith( "The Country Clu" ) || clubName.equalsIgnoreCase("Pinery CC")) {       // if The CC of Brookline or Pinery CC

         f_b = "";              // do not use the f/b indicator in messages
      }


      String ext = "";
      String mod = "";
      String enew = "";
      String can = "";
      String ewait = "";
      String subject = "";
      String dayShort = "";

      //
      //  Get short version of day name
      //
      if (day.equalsIgnoreCase( "Sunday" )) {
        
         dayShort = "Sun ";
           
      } else {
        
         if (day.equalsIgnoreCase( "Monday" )) {

            dayShort = "Mon ";

         } else {

            if (day.equalsIgnoreCase( "Tuesday" )) {

               dayShort = "Tue ";

            } else {

               if (day.equalsIgnoreCase( "Wednesday" )) {

                  dayShort = "Wed ";

               } else {

                  if (day.equalsIgnoreCase( "Thursday" )) {

                     dayShort = "Thu ";

                  } else {

                     if (day.equalsIgnoreCase( "Friday" )) {

                        dayShort = "Fri ";

                     } else {

                        dayShort = "Sat ";
                     }
                  }
               }
            }
         }
      }


      if (clubName.startsWith( "Congressional" )) {

         //
         //  Congressional - change the course names to include Gold or Blue indications so members will know
         //
         if (!course.equals( "" )) {     // if course specified
           
            course = congressionalCustom.getFullCourseName(date, dd, course);
         }  
         
         if (!to_course.equals( "" )) {     // if course specified

            to_course = congressionalCustom.getFullCourseName(date, dd, to_course);
         }

         if (!from_course.equals( "" )) {     // if course specified

            from_course = congressionalCustom.getFullCourseName(date, dd, from_course);
         }
      }


      if (type.equals( "lottery" )) {
        
         ext = "NOTICE:  This is a Request for a Tee Time, NOT an actual Tee Time.\n\n";

         if (clubName.startsWith( "Old Oaks" )) {

            mod = "The following Tee Time Request has been MODIFIED by " + author + ".\n\n";
            enew = "The following Tee Time Request has been ENTERED by " + author + ".\n\n";
            subject = "ForeTees Tee Time Request Notification";

         } else if (clubName.startsWith( "Westchester" )) {

            mod = "The following Draw Request has been MODIFIED by " + author + ".\n\n";
            enew = "The following Draw Request has been ENTERED by " + author + ".\n\n";
            subject = "WCC - Your Lottery Request Has Been Received - This is NOT a Tee Time";

         } else if (clubName.startsWith( "Pecan Plantation" )) {
            
            // TEST to see if using the word Lottery is causing emails to get blocked by Charter.net
            mod = "The following Tee Time Request has been MODIFIED by " + author + ".\n\n";
            enew = "The following Tee Time Request has been ENTERED by " + author + ".\n\n";
            subject = "ForeTees Tee Time Request Notification";
            
         } else {
            
            mod = "The following Lottery Request has been MODIFIED by " + author + ".\n\n" + ext;
            enew = "The following Lottery Request has been ENTERED by " + author + ".\n\n" + ext;
            subject = "ForeTees Lottery Request Notification";
            
         }
      } // end type = lottery

      if (type.equals( "tee" )) {

         if (TLT == 0) {     // if normal tee time system

            can = "The following tee time has been CANCELLED by " + author + ".\n\n";
            mod = "The following tee time has been MODIFIED by " + author + ".\n\n";
            enew = "The following tee time has been RESERVED by " + author + ".\n\n";

         } else {        // TLT system

            can = "The following Notification has been CANCELLED by " + author + ".\n\n";
            mod = "The following Notification has been MODIFIED by " + author + ".\n\n";
            enew = "The following Notification has been SUBMITTED by " + author + ".\n\n";
         }

         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Your Tee Time";

         } else {

            subject = "ForeTees Tee Time Notification (" + dayShort + mm + "/" + dd + "/" + yy + ")";
         }
      } 

      if (type.equals( "frost" )) {      // if Frost Delay

         if (TLT == 0) {     // if normal tee time system

            mod = "The following tee time has been Pushed Back by the Golf Shop Staff (check new time).\n\n";

         } else {        // TLT system

            mod = "There is a frost delay today.  You may want to check for changes.\n\n";
         }

         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Frost Delay Notification";

         } else {

            subject = "ForeTees - Frost Delay Notification";
         }
      }

      if (type.equals( "event" )) {

         can = "The following Event Registration has been CANCELLED by " + author + ".\n\n";
         mod = "The following Event Registration has been MODIFIED by " + author + ".\n\n";
         enew = "The following Event Registration has been RESERVED by " + author + ".\n\n";
         ewait = "You, or your team, have been taken off the WAIT LIST and are now registered for the following event:\n\n";
           
         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Event Registration Notification";

         } else {

            subject = "ForeTees Event Registration Notification";
         }
         
      }

      if (type.equals( "lesson" )) {

         enew = player1 + " has been scheduled for the following Golf Lesson (by " + author + ").\n\n";
         can = player1 + "'s Golf Lesson has been cancelled by " + author + ".\n\n";

         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Golf Lesson Notification";

         } else {

            subject = "ForeTees Golf Lesson Notification";
         }
      }

      if (type.equals( "lessongrp" )) {

         enew = player1 + " has been added to the following Group Lesson (by " + author + ").\n\n";

         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Group Lesson Notification";

         } else {

            subject = "ForeTees Group Lesson Notification";
         }
      }

      if (type.equals( "moveWhole" )) {       // if from edit tee sheet (move whole tee time)

         if (clubName.startsWith( "Westchester" )) {

            subject = "WCC - Tee Time Has Changed";

         } else {

            if (TLT == 0) {     // if normal tee time system

               subject = "ForeTees - Notification Has Changed";

            } else {        // TLT system

               subject = "ForeTees - Tee Time Has Changed";
            }
         }
      }

      if (type.equals( "password" )) {       // if from Login (password request)

         subject = "ForeTees - Credentials";
      }

      if (!clubName.equals( "" )) {

         subject = subject + " - " + clubName;
      }


      if (clubName.equalsIgnoreCase( "The Country Club" )) {     // The Country CLub of Brookline
      
         can = can + "*** NOTE: If you have any questions please email Kim Hall at khall@tcclub.org\n\n";
         mod = mod + "*** NOTE: If you have any questions please email Kim Hall at khall@tcclub.org\n\n";
         enew = enew + "*** NOTE: If you have any questions please email Kim Hall at khall@tcclub.org\n\n";
      }


      Properties properties = new Properties();
      properties.put("mail.smtp.host", parm.SMTP_ADDR);                        // set outbound host address
      properties.put("mail.smtp.port", parm.SMTP_PORT);                        // set port address
      properties.put("mail.smtp.auth", (parm.SMTP_AUTH) ? "true" : "false");   // set 'use authentication'

      Session mailSess;
              
      if (parm.SMTP_AUTH) {
          
          mailSess = Session.getInstance(properties, getAuthenticator(parm.SMTP_USER, parm.SMTP_PASS));
      
      } else {
      
          mailSess = Session.getInstance(properties, null);
      
      }

      MimeMessage message = new MimeMessage(mailSess);
        
      // content-class: urn:content-classes:calendarmessage
      
      try {
        
         message.setFrom(new InternetAddress(parm.EMAIL_FROM));                // set from addr

         message.setSubject( subject );                                        // set subject line
         message.setSentDate(new java.util.Date());                            // set date/time sent
      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         errorMsg = "Error1 in sendEmail (get Properties) for " +clubName+ ": ";
         errorMsg = errorMsg + e1;                                             // build error msg

//         verifySlot.logError(errorMsg);                                      // log it
      }

      //
      //  Set the recipient addresses
      //
      if (type.equals( "password" )) {       // if from Login (password request)

         send = 0;
         to = parms.email; 
         try {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
         }
         catch (Exception ignore) {
         }
      }
      
      //
      //  If event - check for any pro emails to copy
      //
      if (type.equals( "event" )) {
          
          if (!eventPro1.equals( "" )) {      // if pro email address provided

            try {
                message.addRecipient(Message.RecipientType.BCC, new InternetAddress(eventPro1));
                send = 1;
            }
            catch (Exception ignore) {
                send = 0;
            }
          }

          if (!eventPro2.equals( "" )) {      // if pro email address provided

            try {
                message.addRecipient(Message.RecipientType.BCC, new InternetAddress(eventPro2));
                send = 1;
            }
            catch (Exception ignore) {
                send = 0;
            }
          }
      
          //
          // Custom for Baltimore CC - send email to pro on all event registration activity (Case #1228)
          //
          if (clubName.equals( "Baltimore Country Club" )) {

             try {
                 message.addRecipient(Message.RecipientType.BCC, new InternetAddress("jdengler@bcc1898.com"));
                 send = 1;
             }
             catch (Exception ignore) {
                 send = 0;
             }
          }


          //
          // Custom for MN Valley CC - send email to pro on mods or cancels of event registrations (Case #1353)
          //
          if ((emailMod == 1 || emailCan == 1) && clubName.equals( "Minnesota Valley Country Club" )) {

             try {
                 message.addRecipient(Message.RecipientType.BCC, new InternetAddress("rhary@mvccgolf.com"));
                 send = 1;
             }
             catch (Exception ignore) {
                 send = 0;
             }
          }
      } // end if event
      
      if (type.startsWith( "lesson" )) {       // if a lesson type

         //
         //  Get the name of the pro for this lesson
         //
         try {

            pstmte1 = con.prepareStatement (
                    "SELECT lname, fname, mi, suffix, email1, email2 FROM lessonpro5 WHERE id = ?");

            pstmte1.clearParameters();        // clear the parms
            pstmte1.setInt(1, fb);
            rs = pstmte1.executeQuery();      // execute the prepared pstmt

            if (rs.next()) {

               StringBuffer pro_name = new StringBuffer(rs.getString("fname"));  // get first name

               String mi = rs.getString("mi");                   // middle initial
               if (!mi.equals( "" )) {
                  pro_name.append(" ");
                  pro_name.append(mi);
               }
               pro_name.append(" " + rs.getString("lname"));     // last name

               String suffix = rs.getString("suffix");           // suffix
               if (!suffix.equals( "" )) {
                  pro_name.append(" ");
                  pro_name.append(suffix);
               }

               proName = pro_name.toString();                    // convert to one string

               proEmail1 = rs.getString("email1");               // get email addresses                           
               proEmail2 = rs.getString("email2");
               
               if (!proEmail1.equals( "" )) {
                   try {
                       message.addRecipient(Message.RecipientType.BCC, new InternetAddress(proEmail1));   // add pro to BCC
                   }
                   catch (Exception ignore) {}
                   send = 1;
               }
               
               if (!proEmail2.equals( "" )) {

                   try {
                       message.addRecipient(Message.RecipientType.BCC, new InternetAddress(proEmail2));   // add pro to BCC
                   }
                   catch (Exception ignore) {}
                   send = 1;
               }
               
            }
            pstmte1.close();

         }
         catch (Exception exc) {
         }

         if (!userA[0].equals( "" )) {       // if user exists

            try {
               pstmte1 = con.prepareStatement ( tmp_sql );

               pstmte1.clearParameters();        // clear the parms
               pstmte1.setString(1, userA[0]);
               pstmte1.setString(2, userA[0]);
               pstmte1.setString(3, userA[0]);
               rs = pstmte1.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  to = rs.getString(1);         // user's email address
                  emailOpt = rs.getInt(2);      // email option
                  to2 = rs.getString(3);        // user's 2nd email address

                  if (emailOpt != 0) {    // if user wants email notifications
                    
                     if (!to.equals( "" )) {
                         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                         send = 1;
                     }
                     if (!to2.equals( "" )) {     // if 2nd email address

                         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                         send = 1;
                     }

                     if (to.endsWith( "aol.com" ) || to2.endsWith( "aol.com" )) {     // if AOL address

                        aol = true;
                     }

                  }
               }
               pstmte1.close();              // close the stmt
            }
            catch (Exception ignore) {
            }
         }


      } else {                      // NOT a lesson type
        

         //
         //   Check all users from the old request (prior to this change)
         //
         for (i=0; i<25; i++) {           
  
            if (!olduserA[i].equals( "" )) {      // if old user exists

               try {
                  pstmte1 = con.prepareStatement ( tmp_sql );

                  pstmte1.clearParameters();        // clear the parms
                  pstmte1.setString(1, olduserA[i]);
                  pstmte1.setString(2, olduserA[i]);
                  pstmte1.setString(3, olduserA[i]);
                  rs = pstmte1.executeQuery();      // execute the prepared stmt

                  if (rs.next()) {

                     to = rs.getString(1);           // user's email address
                     emailOpt = rs.getInt(2);        // email option
                     to2 = rs.getString(3);          // user's alternate email address

                     if ( emailOpt != 0 ) {    // if user wants email notifications
                        if ( !to.equals( "" ) ) {
                            dup = false;

                            duploop1:
                            for (i2=0; i2<100; i2++) {          // check for duplicate address (can't have dups)

                               if (eaddrA[i2].equals( "" )) {    // if we've reached an empty slot

                                  eaddrA[i2] = to;               // place this addr in the array
                                  break duploop1;                // exit loop

                               } else {

                                  if (to.equals( eaddrA[i2] )) {    // if dup found

                                     dup = true;
                                     break duploop1;
                                  }
                               }
                            }          // end of duploop1

                            if (dup == false) {         // if ok

                               message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               debug_addresses += to + ", ";
                               send = 1;

                               if (to.endsWith( "aol.com" )) {     // if AOL address

                                  aol = true;
                               }
                            }
                        } // end if to not empty
                        
                        if (!to2.equals( "" )) {     // if 2nd email address

                           dup = false;

                           duploop2:
                           for (i2=0; i2<100; i2++) {          // check for duplicate address (can't have dups)

                              if (eaddrA[i2].equals( "" )) {    // if we've reached the end

                                 eaddrA[i2] = to2;              // place this addr in the array
                                 break duploop2;                // exit loop

                              } else {

                                 if (to2.equals( eaddrA[i2] )) {    // if dup found

                                    dup = true;
                                    break duploop2;
                                 }
                              }
                           }          // end of duploop2
                           
                           if (dup == false) {         // if ok

                              message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                              debug_addresses += to2 + ", ";
                              send = 1;
                              
                              if (to2.endsWith( "aol.com" )) {     // if AOL address

                                 aol = true;
                              }
                           }
                        } // end if 2nd email address
                     } // if emailOpt != 0
                  }
                  pstmte1.close();              // close the stmt
                    
                  //
                  //  Custom for Blackhawk CC - BCC the pro
                  //
                  if (clubName.startsWith( "Blackhawk" ) && clubProName.equals( "Mark Caufield" )) {   // if Blackhawk CC (Mark Caufield)

                     if (olduserA[i].equals( "3503" ) || olduserA[i].equals( "2853" ) || olduserA[i].equals( "1539" )) {   // if one of specified members 

                        if (send == 1 && BHproCCed == false) {         // if members to send to

                           message.addRecipient(Message.RecipientType.BCC, new InternetAddress(clubProEmail));   // add pro to BCC

                           BHproCCed = true;           // indicate pro CC'ed already
                        }
                     }
                  }

               }
               catch (Exception ignore) {
               }
            }
         } // end i for next loop 
         

         //
         //  check new players
         //
         for (i=0; i<25; i++) {

            if (!userA[i].equals( "" )) {      // if old user exists

               try {
                  pstmte1 = con.prepareStatement ( tmp_sql );

                  pstmte1.clearParameters();        // clear the parms
                  pstmte1.setString(1, userA[i]);
                  pstmte1.setString(2, userA[i]);
                  pstmte1.setString(3, userA[i]);
                  rs = pstmte1.executeQuery();      // execute the prepared stmt

                  if (rs.next()) {

                     to = rs.getString(1);           // user's email address
                     emailOpt = rs.getInt(2);        // email option
                     to2 = rs.getString(3);          // user's alternate email address

                     if (emailOpt != 0) {    // if user wants email notifications
                        if (!to.equals( "" )) {
                            dup = false;

                            duploop3:
                            for (i2=0; i2<100; i2++) {          // check for duplicate address (can't have dups)

                               if (eaddrA[i2].equals( "" )) {    // if we've reached an empty slot

                                  eaddrA[i2] = to;               // place this addr in the array
                                  break duploop3;                // exit loop

                               } else {

                                  if (to.equals( eaddrA[i2] )) {    // if dup found

                                     dup = true;
                                     break duploop3;
                                  }
                               }
                            }          // end of duploop3

                            if (dup == false) {         // if ok

                               message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               debug_addresses += to + ", ";
                               send = 1;

                               if (to.endsWith( "aol.com" )) {     // if AOL address

                                  aol = true;
                               }
                            }
                        }
                        
                        if (!to2.equals( "" )) {     // if 2nd email address

                           dup = false;

                           duploop4:
                           for (i2=0; i2<100; i2++) {          // check for duplicate address (can't have dups)

                              if (eaddrA[i2].equals( "" )) {    // if we've reached the end

                                 eaddrA[i2] = to2;              // place this addr in the array
                                 break duploop4;                // exit loop

                              } else {

                                 if (to2.equals( eaddrA[i2] )) {    // if dup found

                                    dup = true;
                                    break duploop4;
                                 }
                              }
                           }          // end of duploop4

                           if (dup == false) {         // if ok

                              message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                              debug_addresses += to2 + ", ";
                              send = 1;
                              if (to2.endsWith( "aol.com" )) {     // if AOL address

                                 aol = true;
                              }
                           }
                        } // end if to2 empty
                     } // end if emailOpt != 0
                  }
                  pstmte1.close();              // close the stmt
                    
                  //
                  //  Custom for Blackhawk CC - BCC the pro
                  //
                  if (clubName.startsWith( "Blackhawk" ) && clubProName.equals( "Mark Caufield" )) {   // if Blackhawk CC (Mark Caufield)

                     if (userA[i].equals( "3503" ) || userA[i].equals( "2853" ) || userA[i].equals( "1539" )) {   // if one of specified members

                        if (send == 1 && BHproCCed == false) {         // if members to send to

                           message.addRecipient(Message.RecipientType.BCC, new InternetAddress(clubProEmail));   // add pro to BCC

                           BHproCCed = true;           // indicate pro CC'ed already
                        }
                     }
                  }

               }
               catch (Exception ignore) {
               }
            }
         }

      } // end if type = lesson


      if (clubName.startsWith( "Winged Fo" )) {        // if Winged Foot

         //
         //  Send a copy of notification emails to pro
         //
         to = "dzona@wfgc.org";   // pro's email address
           
         try {
           
            if (send == 0) {         // if no members to send to
           
               message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                 
               send = 1;            // make sure it gets sent
  
            } else {

               message.addRecipient(Message.RecipientType.BCC, new InternetAddress(to));   // add pro to BCC

            }
         }
            catch (Exception ignore) {
         }
      }

      
      //
      //  send email if anyone to send it to
      //
      if (send != 0) {        // if any email addresses specified for members

         //
         //  set trans mode based on 9-hole options
         //
         if (p91 == 1) {

            pcw1 = pcw1 + "9";
         }
         if (p92 == 1) {

            pcw2 = pcw2 + "9";
         }
         if (p93 == 1) {

            pcw3 = pcw3 + "9";
         }
         if (p94 == 1) {

            pcw4 = pcw4 + "9";
         }
         if (p95 == 1) {

            pcw5 = pcw5 + "9";
         }
         if (p96 == 1) {

            pcw6 = pcw6 + "9";
         }
         if (p97 == 1) {

            pcw7 = pcw7 + "9";
         }
         if (p98 == 1) {

            pcw8 = pcw8 + "9";
         }
         if (p99 == 1) {

            pcw9 = pcw9 + "9";
         }
         if (p910 == 1) {

            pcw10 = pcw10 + "9";
         }
         if (p911 == 1) {

            pcw11 = pcw11 + "9";
         }
         if (p912 == 1) {

            pcw12 = pcw12 + "9";
         }
         if (p913 == 1) {

            pcw13 = pcw13 + "9";
         }
         if (p914 == 1) {

            pcw14 = pcw14 + "9";
         }
         if (p915 == 1) {

            pcw15 = pcw15 + "9";
         }
         if (p916 == 1) {

            pcw16 = pcw16 + "9";
         }
         if (p917 == 1) {

            pcw17 = pcw17 + "9";
         }
         if (p918 == 1) {

            pcw18 = pcw18 + "9";
         }
         if (p919 == 1) {

            pcw19 = pcw19 + "9";
         }
         if (p920 == 1) {

            pcw20 = pcw20 + "9";
         }
         if (p921 == 1) {

            pcw21 = pcw21 + "9";
         }
         if (p922 == 1) {

            pcw22 = pcw22 + "9";
         }
         if (p923 == 1) {

            pcw23 = pcw23 + "9";
         }
         if (p924 == 1) {

            pcw24 = pcw24 + "9";
         }
         if (p925 == 1) {

            pcw25 = pcw25 + "9";
         }
           
         //
         //  if player is 'x' then change c/w option to space
         //
         if (player1.equalsIgnoreCase( "x" )) {

            pcw1 = " ";
         }
         if (player2.equalsIgnoreCase( "x" )) {

            pcw2 = " ";
         }
         if (player3.equalsIgnoreCase( "x" )) {

            pcw3 = " ";
         }
         if (player4.equalsIgnoreCase( "x" )) {

            pcw4 = " ";
         }
         if (player5.equalsIgnoreCase( "x" )) {

            pcw5 = " ";
         }
         if (player6.equalsIgnoreCase( "x" )) {

            pcw6 = " ";
         }
         if (player7.equalsIgnoreCase( "x" )) {

            pcw7 = " ";
         }
         if (player8.equalsIgnoreCase( "x" )) {

            pcw8 = " ";
         }
         if (player9.equalsIgnoreCase( "x" )) {

            pcw9 = " ";
         }
         if (player10.equalsIgnoreCase( "x" )) {

            pcw10 = " ";
         }
         if (player11.equalsIgnoreCase( "x" )) {

            pcw11 = " ";
         }
         if (player12.equalsIgnoreCase( "x" )) {

            pcw12 = " ";
         }
         if (player13.equalsIgnoreCase( "x" )) {

            pcw13 = " ";
         }
         if (player14.equalsIgnoreCase( "x" )) {

            pcw14 = " ";
         }
         if (player15.equalsIgnoreCase( "x" )) {

            pcw15 = " ";
         }
         if (player16.equalsIgnoreCase( "x" )) {

            pcw16 = " ";
         }
         if (player17.equalsIgnoreCase( "x" )) {

            pcw17 = " ";
         }
         if (player18.equalsIgnoreCase( "x" )) {

            pcw18 = " ";
         }
         if (player19.equalsIgnoreCase( "x" )) {

            pcw19 = " ";
         }
         if (player20.equalsIgnoreCase( "x" )) {

            pcw20 = " ";
         }
         if (player21.equalsIgnoreCase( "x" )) {

            pcw21 = " ";
         }
         if (player22.equalsIgnoreCase( "x" )) {

            pcw22 = " ";
         }
         if (player23.equalsIgnoreCase( "x" )) {

            pcw23 = " ";
         }
         if (player24.equalsIgnoreCase( "x" )) {

            pcw24 = " ";
         }
         if (player25.equalsIgnoreCase( "x" )) {

            pcw25 = " ";
         }
           
         String players = "";
               
         //
         //  Process according to the request type
         //
         if (emailNew != 0) {        // if new tee time
            //
            //  Create the message content
            //
            String enewMsg = "";

            if (type.startsWith( "lesson" )) {         // if lesson type

               if (type.equals( "lessongrp" )) {         // if group lesson 

                 enewMsg = header + enew + " Group Lesson: " + course + "    Date: " +day+ ", " +mm+ "/" +dd+ "/" +yy+ 
                           " at " + etime + " With " +proName+ ".";

               } else {              // normal lesson

                 enewMsg = header + enew + " Lesson Type: " + course + "    Date: " +day+ ", " +mm+ "/" +dd+ "/" +yy+
                           " at " + etime + " With " +proName+ ".";
               }
                 
            } else {              // tee time or event

               if (type.equals( "event" )) {
                  
                  if (parms.season == 0) {
                      
                      // NOT a season long event
                      enewMsg = header + enew + " Event: " + name + "    Date: " + mm + "/" + dd + "/" + yy + " ";

                      if (!course.equals( "" )) {

                         enewMsg = enewMsg + "on Course: " + course + " ";
                      }

                      enewMsg = enewMsg + "at " + act_time + ".";        // add the event time

                      if (etype == 0) {                                  // if NOT shotgun event

                         enewMsg = enewMsg + "\n\nTime indicates when event starts.  Your actual time may vary.";
                      }
                  } else {
                      
                      // season long event
                      enewMsg = header + enew + " Event: " + name + "    Date: Season Long ";

                      if (!course.equals( "" )) {

                         enewMsg = enewMsg + "\nCourse: " + course + " ";
                      }
                  }
                  if (wait > 0) {            // if on wait list

                     enewMsg = enewMsg + "\n\nNote:  This team is currently on the WAIT LIST.";
                  }

               } else {         // tee time

                  enewMsg = header + enew + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " ";

                  if (!f_b.equals ( "" )) {
                    
                     enewMsg = enewMsg + "on the " + f_b + " 9 of ";
                       
                  } else {

                     enewMsg = enewMsg + "on ";
                  }

                  if (!course.equals( "" )) {

                     enewMsg = enewMsg + "Course: " + course;
                  }
               }

               enewMsg = enewMsg + "\n";
               

               //
               //  build message text
               //
               if (!player1.equals( "" )) {

                  players = players + "\nPlayer 1: " + player1 + "  " + pcw1;
               }
               if (!player2.equals( "" )) {

                  players = players + "\nPlayer 2: " + player2 + "  " + pcw2;
               }
               if (!player3.equals( "" )) {

                  players = players + "\nPlayer 3: " + player3 + "  " + pcw3;
               }
               if (!player4.equals( "" )) {

                  players = players + "\nPlayer 4: " + player4 + "  " + pcw4;
               }
               if (!player5.equals( "" )) {

                  players = players + "\nPlayer 5: " + player5 + "  " + pcw5;
               }
               
               if (!etime2.equals("")) {
                  
                  players = players + "\n\n" + etime2;
               }
               
               if (!player6.equals( "" )) {

                  players = players + "\nPlayer 6: " + player6 + "  " + pcw6;
               }
               if (!player7.equals( "" )) {

                  players = players + "\nPlayer 7: " + player7 + "  " + pcw7;
               }
               if (!player8.equals( "" )) {

                  players = players + "\nPlayer 8: " + player8 + "  " + pcw8;
               }
               if (!player9.equals( "" )) {

                  players = players + "\nPlayer 9: " + player9 + "  " + pcw9;
               }
               if (!player10.equals( "" )) {

                  players = players + "\nPlayer 10: " + player10 + "  " + pcw10;
               }
               
               if (!etime3.equals("")) {
                  
                  players = players + "\n\n" + etime3;
               }
               
               if (!player11.equals( "" )) {

                  players = players + "\nPlayer 11: " + player11 + "  " + pcw11;
               }
               if (!player12.equals( "" )) {

                  players = players + "\nPlayer 12: " + player12 + "  " + pcw12;
               }
               if (!player13.equals( "" )) {

                  players = players + "\nPlayer 13: " + player13 + "  " + pcw13;
               }
               if (!player14.equals( "" )) {

                  players = players + "\nPlayer 14: " + player14 + "  " + pcw14;
               }
               if (!player15.equals( "" )) {

                  players = players + "\nPlayer 15: " + player15 + "  " + pcw15;
               }
               
               if (!etime4.equals("")) {
                  
                  players = players + "\n\n" + etime4;
               }
               
               if (!player16.equals( "" )) {

                  players = players + "\nPlayer 16: " + player16 + "  " + pcw16;
               }
               if (!player17.equals( "" )) {

                  players = players + "\nPlayer 17: " + player17 + "  " + pcw17;
               }
               if (!player18.equals( "" )) {

                  players = players + "\nPlayer 18: " + player18 + "  " + pcw18;
               }
               if (!player19.equals( "" )) {

                  players = players + "\nPlayer 19: " + player19 + "  " + pcw19;
               }
               if (!player20.equals( "" )) {

                  players = players + "\nPlayer 20: " + player20 + "  " + pcw20;
               }
               
               if (!etime5.equals("")) {
                  
                  players = players + "\n\n" + etime5;
               }
               
               if (!player21.equals( "" )) {

                  players = players + "\nPlayer 21: " + player21 + "  " + pcw21;
               }
               if (!player22.equals( "" )) {

                  players = players + "\nPlayer 22: " + player22 + "  " + pcw22;
               }
               if (!player23.equals( "" )) {

                  players = players + "\nPlayer 23: " + player23 + "  " + pcw23;
               }
               if (!player24.equals( "" )) {

                  players = players + "\nPlayer 24: " + player24 + "  " + pcw24;
               }
               if (!player25.equals( "" )) {

                  players = players + "\nPlayer 25: " + player25 + "  " + pcw25;
               }
            }

            enewMsg = enewMsg + players;
            
            if (type.equals("tee") && (clubName.equals("The Country Club") || clubName.startsWith("ForeTees"))) {
                
              if (!parms.notes.equals( "" ) && parms.hideNotes == 0) {

                 enewMsg = enewMsg + "\n\nNotes: " + parms.notes;        // add notes (case# 1406)
              }
            }
            
            String tmp_course = "";
            String tmp_time = date + "T" + ((time < 1000) ? "0" + time : time) + "00";
            
            if (!course.equals("")) tmp_course = "Course: " + course + "\\n";
            
            StringBuffer vCalMsg = new StringBuffer();       // use string buffer to build file

            // TODO: wrap descriptions at 75 bytes
            vCalMsg.append("" +
                "BEGIN:VCALENDAR\n" +
                "PRODID:-//ForeTees//NONSGML v1.0//EN\n" +
                "METHOD:PUBLISH\n" +
                "BEGIN:VEVENT\n" +
                "DTSTAMP:" + DTSTAMP + "\n" +
                "DTSTART:" + tmp_time + "\n" +
                "SUMMARY:" + etime + " Tee Time\n" +
                "LOCATION:" + clubName + "\n" + 
                "DESCRIPTION:" + tmp_course + players.replace("\n", "\\n") + "\n" +
                "URL:http://www1.foretees.com/demov4\n" +
                "END:VEVENT\n" +
                "END:VCALENDAR");
            
/*

"VERSION:2.0\n" +

*/
            
            if (aol == true) {                     // if AOL user in the group
              
               enewMsg = enewMsg + trailerAOL;     // add special AOL message
            }

            enewMsg = enewMsg + trailer + "\n\n";

            
            //
            // MESSAGE BODY BUILT AND RECIPIENTS SET 
            //
            
            try {
                
                BodyPart msgBodyPart = new MimeBodyPart();

                msgBodyPart.setText( enewMsg );
            
                Multipart multipart = new MimeMultipart();

                multipart.addBodyPart(msgBodyPart);

                // do not send iCal attachments for season long events
                if (clubName.startsWith("ForeTees") && parms.season == 0) {
                    msgBodyPart = new MimeBodyPart();
                    msgBodyPart.setFileName("teetime.ics");
                    msgBodyPart.setContent(vCalMsg.toString(), "text/plain");

                    multipart.addBodyPart(msgBodyPart);
                }
                
                message.setContent(multipart);
      
                Transport.send(message);
      
            } catch (Exception e1) {
                
                errorMsg = "Error2 (NEW) in sendEmail (Transport.send) for " +clubName+ ": ";
                errorMsg = errorMsg + e1;

                verifySlot.logError(errorMsg); 
            }
            
/*      
            try {
               message.setText( enewMsg );  // put msg in email text area

               Transport.send(message);     // send it!!
            }
            catch (Exception e1) {
               //
               //  save error message in /" +rev+ "/error.txt
               //
               errorMsg = "Error2 (NEW) in sendEmail (Transport.send) for " +clubName+ ": ";
               errorMsg = errorMsg + e1;                              // build error msg
               
               try {
                   errorMsg = errorMsg + "  Recipients: " + debug_addresses; //message.getAllRecipients().toString();
               } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }

               verifySlot.logError(errorMsg);                                       // log it
            }
*/
         }  // end if new tee time

         if (emailCan != 0) {        // if Cancelled tee time
            //
            //  Create the message content
            //
            String ecanMsg = "";
  
            if (type.startsWith( "lesson" )) {         // if lesson type

               ecanMsg = header + can + " Lesson Type: " + course + "    Date: " +day+ ", " +mm+ "/" +dd+ "/" +yy+
                           " at " + etime + " With " +proName+ ".";

            } else {              // tee time or event

               if (type.equals( "event" )) {

                  if (etype == 1) {             // if shotgun event, show time of event

                      ecanMsg = header + can + " Event: " + name + "    Date: " + mm + "/" + dd + "/" + yy +
                                    " at " + act_time + " ";

                  } else {

                     ecanMsg = header + can + " Event: " + name + "    Date: " + mm + "/" + dd + "/" + yy + " ";
                  }

                  if (!course.equals( "" )) {

                     ecanMsg = ecanMsg + "on Course: " + course;
                  }

               } else {

                  ecanMsg = header + can + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " ";

                  if (!f_b.equals ( "" )) {

                     ecanMsg = ecanMsg + "on the " + f_b + " 9 of ";

                  } else {

                     ecanMsg = ecanMsg + "on ";
                  }

                  if (!course.equals( "" )) {

                     ecanMsg = ecanMsg + "Course: " + course;
                  }
               }

               ecanMsg = ecanMsg + "\n";

               //
               //  build message text
               //
               if (!oldplayer1.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 1: " + oldplayer1 + "  " + oldpcw1;
               }
               if (!oldplayer2.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 2: " + oldplayer2 + "  " + oldpcw2;
               }
               if (!oldplayer3.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 3: " + oldplayer3 + "  " + oldpcw3;
               }
               if (!oldplayer4.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 4: " + oldplayer4 + "  " + oldpcw4;
               }
               if (!oldplayer5.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 5: " + oldplayer5 + "  " + oldpcw5;
               }
               if (!oldplayer6.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 6: " + oldplayer6 + "  " + oldpcw6;
               }
               if (!oldplayer7.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 7: " + oldplayer7 + "  " + oldpcw7;
               }
               if (!oldplayer8.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 8: " + oldplayer8 + "  " + oldpcw8;
               }
               if (!oldplayer9.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 9: " + oldplayer9 + "  " + oldpcw9;
               }
               if (!oldplayer10.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 10: " + oldplayer10 + "  " + oldpcw10;
               }
               if (!oldplayer11.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 11: " + oldplayer11 + "  " + oldpcw11;
               }
               if (!oldplayer12.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 12: " + oldplayer12 + "  " + oldpcw12;
               }
               if (!oldplayer13.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 13: " + oldplayer13 + "  " + oldpcw13;
               }
               if (!oldplayer14.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 14: " + oldplayer14 + "  " + oldpcw14;
               }
               if (!oldplayer15.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 15: " + oldplayer15 + "  " + oldpcw15;
               }
               if (!oldplayer16.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 16: " + oldplayer16 + "  " + oldpcw16;
               }
               if (!oldplayer17.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 17: " + oldplayer17 + "  " + oldpcw17;
               }
               if (!oldplayer18.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 18: " + oldplayer18 + "  " + oldpcw18;
               }
               if (!oldplayer19.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 19: " + oldplayer19 + "  " + oldpcw19;
               }
               if (!oldplayer20.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 20: " + oldplayer20 + "  " + oldpcw20;
               }
               if (!oldplayer21.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 21: " + oldplayer21 + "  " + oldpcw21;
               }
               if (!oldplayer22.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 22: " + oldplayer22 + "  " + oldpcw22;
               }
               if (!oldplayer23.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 23: " + oldplayer23 + "  " + oldpcw23;
               }
               if (!oldplayer24.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 24: " + oldplayer24 + "  " + oldpcw24;
               }
               if (!oldplayer25.equals( "" )) {

                  ecanMsg = ecanMsg + "\nPlayer 25: " + oldplayer25 + "  " + oldpcw25;
               }
            }

            if (aol == true) {                     // if AOL user in the group

               ecanMsg = ecanMsg + trailerAOL;     // add special AOL message
            }

            ecanMsg = ecanMsg + trailer;

            try {
               message.setText( ecanMsg );  // put msg in email text area

               Transport.send(message);     // send it!!
            }
            catch (Exception e1) {
               //
               //  save error message in /" +rev+ "/error.txt
               //
               errorMsg = "Error3 (CANCEL) in sendEmail (Transport.send) for " +clubName+ ": ";
               errorMsg = errorMsg + e1;                              // build error msg
               
               try {
                   errorMsg = errorMsg + "  Recipients: " + message.getAllRecipients().toString();
               } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }

               verifySlot.logError(errorMsg);                                       // log it
            }
         } // end if Cancelled tee time

         if (emailMod != 0) {        // /if tee time modified
            //
            //  Create the message content
            //
            String emodMsg = "";

            if (type.equals( "event" )) {      

               emodMsg = header + mod + " Event: " + name + "    Date: " + mm + "/" + dd + "/" + yy + " ";

               if (!course.equals( "" )) {

                  emodMsg = emodMsg + "on Course: " + course + " ";
               }

               emodMsg = emodMsg + "at " + act_time + ".";        // add the event time

               if (etype == 0) {                                  // if NOT shotgun event

                  emodMsg = emodMsg + "\n\nTime indicates when event starts.  Your actual time may vary.";
               }

               if (wait > 0) {            // if on wait list

                  emodMsg = emodMsg + "\n\nNote:  This team is currently on the WAIT LIST.";
               }

            } else {  
  
               emodMsg = header + mod + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " ";

               if (!f_b.equals ( "" )) {

                  emodMsg = emodMsg + "on the " + f_b + " 9 of ";

               } else {

                  emodMsg = emodMsg + "on ";
               }

               if (!from_course.equals( "" )) {

                  course = to_course;
               }

               if (!course.equals( "" )) {

                  emodMsg = emodMsg + "Course: " + course;
               }
            }

            if (type.equals( "frost" )) {
               emodMsg = emodMsg + "\n\nGroup:\n";
            } else {
               emodMsg = emodMsg + "\n\nNew Group:\n";
            }

            if (!player1.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 1: " + player1 + "  " + pcw1;
            }
            if (!player2.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 2: " + player2 + "  " + pcw2;
            }
            if (!player3.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 3: " + player3 + "  " + pcw3;
            }
            if (!player4.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 4: " + player4 + "  " + pcw4;
            }
            if (!player5.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 5: " + player5 + "  " + pcw5;
            }
            if (!player6.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 6: " + player6 + "  " + pcw6;
            }
            if (!player7.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 7: " + player7 + "  " + pcw7;
            }
            if (!player8.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 8: " + player8 + "  " + pcw8;
            }
            if (!player9.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 9: " + player9 + "  " + pcw9;
            }
            if (!player10.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 10: " + player10 + "  " + pcw10;
            }
            if (!player11.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 11: " + player11 + "  " + pcw11;
            }
            if (!player12.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 12: " + player12 + "  " + pcw12;
            }
            if (!player13.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 13: " + player13 + "  " + pcw13;
            }
            if (!player14.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 14: " + player14 + "  " + pcw14;
            }
            if (!player15.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 15: " + player15 + "  " + pcw15;
            }
            if (!player16.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 16: " + player16 + "  " + pcw16;
            }
            if (!player17.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 17: " + player17 + "  " + pcw17;
            }
            if (!player18.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 18: " + player18 + "  " + pcw18;
            }
            if (!player19.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 19: " + player19 + "  " + pcw19;
            }
            if (!player20.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 20: " + player20 + "  " + pcw20;
            }
            if (!player21.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 21: " + player21 + "  " + pcw21;
            }
            if (!player22.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 22: " + player22 + "  " + pcw22;
            }
            if (!player23.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 23: " + player23 + "  " + pcw23;
            }
            if (!player24.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 24: " + player24 + "  " + pcw24;
            }
            if (!player25.equals( "" )) {

               emodMsg = emodMsg + "\nPlayer 25: " + player25 + "  " + pcw25;
            }

            if (!type.equals( "frost" )) {

               emodMsg = emodMsg + "\n\nPrevious Group (before change):\n";

               if (!oldplayer1.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 1: " + oldplayer1 + "  " + oldpcw1;
               }
               if (!oldplayer2.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 2: " + oldplayer2 + "  " + oldpcw2;
               }
               if (!oldplayer3.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 3: " + oldplayer3 + "  " + oldpcw3;
               }
               if (!oldplayer4.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 4: " + oldplayer4 + "  " + oldpcw4;
               }
               if (!oldplayer5.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 5: " + oldplayer5 + "  " + oldpcw5;
               }
               if (!oldplayer6.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 6: " + oldplayer6 + "  " + oldpcw6;
               }
               if (!oldplayer7.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 7: " + oldplayer7 + "  " + oldpcw7;
               }
               if (!oldplayer8.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 8: " + oldplayer8 + "  " + oldpcw8;
               }
               if (!oldplayer9.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 9: " + oldplayer9 + "  " + oldpcw9;
               }
               if (!oldplayer10.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 10: " + oldplayer10 + "  " + oldpcw10;
               }
               if (!oldplayer11.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 11: " + oldplayer11 + "  " + oldpcw11;
               }
               if (!oldplayer12.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 12: " + oldplayer12 + "  " + oldpcw12;
               }
               if (!oldplayer13.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 13: " + oldplayer13 + "  " + oldpcw13;
               }
               if (!oldplayer14.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 14: " + oldplayer14 + "  " + oldpcw14;
               }
               if (!oldplayer15.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 15: " + oldplayer15 + "  " + oldpcw15;
               }
               if (!oldplayer16.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 16: " + oldplayer16 + "  " + oldpcw16;
               }
               if (!oldplayer17.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 17: " + oldplayer17 + "  " + oldpcw17;
               }
               if (!oldplayer18.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 18: " + oldplayer18 + "  " + oldpcw18;
               }
               if (!oldplayer19.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 19: " + oldplayer19 + "  " + oldpcw19;
               }
               if (!oldplayer20.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 20: " + oldplayer20 + "  " + oldpcw20;
               }
               if (!oldplayer21.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 21: " + oldplayer21 + "  " + oldpcw21;
               }
               if (!oldplayer22.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 22: " + oldplayer22 + "  " + oldpcw22;
               }
               if (!oldplayer23.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 23: " + oldplayer23 + "  " + oldpcw23;
               }
               if (!oldplayer24.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 24: " + oldplayer24 + "  " + oldpcw24;
               }
               if (!oldplayer25.equals( "" )) {

                  emodMsg = emodMsg + "\nPlayer 25: " + oldplayer25 + "  " + oldpcw25;
               }
            }

            if (type.equals("tee") && (clubName.equals("The Country Club") || clubName.startsWith("ForeTees"))) {
                
              if (!parms.notes.equals( "" ) && parms.hideNotes == 0) {

                 emodMsg = emodMsg + "\n\nNotes: " + parms.notes;        // add notes (case# 1406)
              }
            }
            
            if (aol == true) {                     // if AOL user in the group

               emodMsg = emodMsg + trailerAOL;     // add special AOL message
            }

            emodMsg = emodMsg + trailer;

            try {
                
               message.setText( emodMsg );  // put msg in email text area

               Transport.send(message);     // send it!!

            }
            catch (Exception e1) {
               //
               //  save error message in /" +rev+ "/error.txt
               //
               errorMsg = "Error4 (MODIFIED) in sendEmail (Transport.send) for " +clubName+ ": ";
               errorMsg = errorMsg + e1;                              // build error msg
               
               try {
                   errorMsg = errorMsg + "  Recipients: " + debug_addresses; //message.getAllRecipients().toString();
               } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }

               verifySlot.logError(errorMsg);                                       // log it
            }
         }  // end if tee time modified

         //
         //  Check for Tee Time moved (from edit tee sheet - Proshop_insert)
         //
         if (type.equals( "moveWhole" )) {        // if whole tee time moved
            //
            //  Create the message content
            //
            String moveMsg = "";

            if (TLT == 0) {          // if Tee Time system
              
               moveMsg = header+ "The following tee time has been MOVED by the Golf Shop (" + author + ").\n\n";

            } else {                 // TLT System

               moveMsg = header+ "The following Notification has been MOVED by the Golf Shop (" + author + ").\n\n";
            }

            moveMsg = moveMsg + day + " " + mm + "/" + dd + "/" + yy;

            //
            //  convert from_time to hour and minutes for email msg
            //
            ehr = from_time / 100;
            emin = from_time - (ehr * 100);
            eampm = " AM";
            if (ehr > 12) {

               eampm = " PM";
               ehr = ehr - 12;       // convert from military time
            }
            if (ehr == 12) {

               eampm = " PM";
            }
            if (ehr == 0) {

               ehr = 12;
               eampm = " AM";
            }

            etime = ehr + ":" + ensureDoubleDigit(emin) + eampm;
               

            f_b = "Front";
            if (from_fb == 1) {
              
               f_b = "Back";
            }

            if (clubName.startsWith( "The Country Clu" )) {       // if The CC of Brookline

               moveMsg = moveMsg + "\n\nOriginal time: " + etime + " ";

               if (!from_course.equals( "" )) {

                  moveMsg = moveMsg + "on Course: " + from_course;
               }

            } else {
              
               moveMsg = moveMsg + "\n\nOriginal time: " + etime + " " +
                                "on the " + f_b + " 9 ";

               if (!from_course.equals( "" )) {

                  moveMsg = moveMsg + " of Course: " + from_course;
               }
            }

            //
            //  convert to_time to hour and minutes for email msg
            //
            ehr = to_time / 100;
            emin = to_time - (ehr * 100);
            eampm = " AM";
            if (ehr > 12) {

               eampm = " PM";
               ehr = ehr - 12;       // convert from military time
            }
            if (ehr == 12) {

               eampm = " PM";
            }
            if (ehr == 0) {

               ehr = 12;
               eampm = " AM";
            }

            etime = ehr + ":" + ensureDoubleDigit(emin) + eampm;
               

            f_b = "Front";
            if (to_fb == 1) {

               f_b = "Back";
            }

            if (clubName.startsWith( "The Country Clu" )) {       // if The CC of Brookline

               moveMsg = moveMsg + "\n\nNew time: " + etime + " ";

               if (!to_course.equals( "" )) {

                  moveMsg = moveMsg + "on Course: " + to_course;
               }

            } else {

               moveMsg = moveMsg + "\n\nNew time: " + etime + " " +
                                "on the " + f_b + " 9 ";

               if (!to_course.equals( "" )) {

                  moveMsg = moveMsg + " of Course: " + to_course;
               }
            }

            moveMsg = moveMsg + "\n\n";

            //
            //  build message text
            //
            if (!player1.equals( "" )) {

               moveMsg = moveMsg + "\nPlayer 1: " + player1 + "  " + pcw1;
            }
            if (!player2.equals( "" )) {

               moveMsg = moveMsg + "\nPlayer 2: " + player2 + "  " + pcw2;
            }
            if (!player3.equals( "" )) {

               moveMsg = moveMsg + "\nPlayer 3: " + player3 + "  " + pcw3;
            }
            if (!player4.equals( "" )) {

               moveMsg = moveMsg + "\nPlayer 4: " + player4 + "  " + pcw4;
            }
            if (!player5.equals( "" )) {

               moveMsg = moveMsg + "\nPlayer 5: " + player5 + "  " + pcw5;
            }

            if (aol == true) {                     // if AOL user in the group

               moveMsg = moveMsg + trailerAOL;     // add special AOL message
            }

            moveMsg = moveMsg + trailer;

            try {
                
               message.setText( moveMsg );  // put msg in email text area
               Transport.send(message);     // send it!!
            }
            catch (Exception e1) {
               //
               //  save error message in /" +rev+ "/error.txt
               //
               errorMsg = "Error5 in sendEmail (Transport.send) for " +clubName+ ": ";
               errorMsg = errorMsg + e1;                              // build error msg
               
               try {
                   errorMsg = errorMsg + "  Recipients: " + message.getAllRecipients().toString();
               } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }

               verifySlot.logError(errorMsg);                                       // log it
            }
         }

         send = 0;   // init send flag

         //
         //  Now check if any team from the wait list was bumped up to the normal event sign-up list
         //
         if (type.equals( "event" ) && checkWait != 0) {

            try {
              
               if (!wuser1.equals( "" ) || !wuser2.equals( "" ) || !wuser3.equals( "" ) || !wuser4.equals( "" ) || !wuser5.equals( "" )) {

                  Properties properties2 = new Properties();
                  properties.put("mail.smtp.host", parm.SMTP_ADDR);                        // set outbound host address
                  properties.put("mail.smtp.port", parm.SMTP_PORT);                        // set port address
                  properties.put("mail.smtp.auth", (parm.SMTP_AUTH) ? "true" : "false");   // set 'use authentication'

                  subject = "ForeTees Event Registration Notification";

                  if (!clubName.equals( "" )) {

                     subject = subject + " - " + clubName;
                  }

                  //Session mailSess2 = Session.getDefaultInstance(properties2, getAuthenticator());    // get session properties
                  //Session mailSess2 = Session.getInstance(properties2, getAuthenticator());           // get session properties

                  Session mailSess2;
      
                  if (parm.SMTP_AUTH) {

                      mailSess2 = Session.getInstance(properties2, getAuthenticator(parm.SMTP_USER, parm.SMTP_PASS));

                  } else {

                      mailSess2 = Session.getInstance(properties2, null);

                  }
                  
                  MimeMessage message2 = new MimeMessage(mailSess2);
                  message2.setFrom(new InternetAddress(parm.EMAIL_FROM));        // set from addr

                  message2.setSubject( subject );                                // set subject line
                  message2.setSentDate(new java.util.Date());                    // set date/time sent

                  //
                  //  Set the recipient addresses
                  //
                  if (!wuser1.equals( "" )) {       // if user exist

                     pstmte1 = con.prepareStatement ( tmp_sql );

                     pstmte1.clearParameters();        // clear the parms
                     pstmte1.setString(1, wuser1);
                     pstmte1.setString(2, wuser1);
                     pstmte1.setString(3, wuser1);
                     rs = pstmte1.executeQuery();      // execute the prepared stmt

                     if (rs.next()) {

                        to = rs.getString(1);        // user's email address
                        emailOpt = rs.getInt(2);        // email option
                        to2 = rs.getString(3);        // user's 2nd email address

                        if (emailOpt != 0) {    // if user wants email notifications

                           if (!to.equals( "" )) { 
                               
                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               send = 1;    // ok to send
                           }
                           if (!to2.equals( "" )) {     // if 2nd email address

                              message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                              send = 1;    // ok to send
                           }
                        }
                     }
                     pstmte1.close();              // close the stmt
                  }
                  if (!wuser2.equals( "" )) {       // if user exist

                     PreparedStatement pstmte2 = con.prepareStatement ( tmp_sql );

                     pstmte2.clearParameters();        // clear the parms
                     pstmte2.setString(1, wuser2);
                     pstmte2.setString(2, wuser2);
                     pstmte2.setString(3, wuser2);
                     rs = pstmte2.executeQuery();      // execute the prepared stmt

                     if (rs.next()) {

                        to = rs.getString(1);        // user's email address
                        emailOpt = rs.getInt(2);        // email option
                        to2 = rs.getString(3);        // user's 2nd email address

                        if (emailOpt != 0) {    // if user wants email notifications

                           if (!to.equals( "" )) {
                               
                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               send = 1;    // ok to send
                           }
                           
                           if (!to2.equals( "" )) {     // if 2nd email address

                              message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                              send = 1;    // ok to send
                           }
                        }
                     }
                     pstmte2.close();              // close the stmt
                  }
                  if (!wuser3.equals( "" )) {       // if user exist

                     PreparedStatement pstmte3 = con.prepareStatement ( tmp_sql );

                     pstmte3.clearParameters();        // clear the parms
                     pstmte3.setString(1, wuser3);
                     pstmte3.setString(2, wuser3);
                     pstmte3.setString(3, wuser3);
                     rs = pstmte3.executeQuery();      // execute the prepared stmt

                     if (rs.next()) {

                        to = rs.getString(1);        // user's email address
                        emailOpt = rs.getInt(2);        // email option
                        to2 = rs.getString(3);        // user's 2nd email address

                        if (emailOpt != 0) {    // if user wants email notifications

                           if (!to.equals( "" )) {
                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               send = 1;    // ok to send
                           }
                           if (!to2.equals( "" )) {     // if 2nd email address

                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                               send = 1;    // ok to send
                           }
                        }
                     }
                     pstmte3.close();              // close the stmt
                  }
                  if (!wuser4.equals( "" )) {       // if user exist

                     PreparedStatement pstmte4 = con.prepareStatement ( tmp_sql );

                     pstmte4.clearParameters();        // clear the parms
                     pstmte4.setString(1, wuser4);
                     pstmte4.setString(2, wuser4);
                     pstmte4.setString(3, wuser4);
                     rs = pstmte4.executeQuery();      // execute the prepared stmt

                     if (rs.next()) {

                        to = rs.getString(1);        // user's email address
                        emailOpt = rs.getInt(2);        // email option
                        to2 = rs.getString(3);        // user's 2nd email address

                        if (emailOpt != 0) {    // if user wants email notifications

                           if (!to.equals( "" )) {
                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               send = 1;    // ok to send
                           }
                           if (!to2.equals( "" )) {     // if 2nd email address

                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                               send = 1;    // ok to send
                           }
                        }
                     }
                     pstmte4.close();              // close the stmt
                  }
                  if (!wuser5.equals( "" )) {       // if user exist

                     PreparedStatement pstmte5 = con.prepareStatement ( tmp_sql );

                     pstmte5.clearParameters();        // clear the parms
                     pstmte5.setString(1, wuser5);
                     pstmte5.setString(2, wuser5);
                     pstmte5.setString(3, wuser5);
                     rs = pstmte5.executeQuery();      // execute the prepared stmt

                     if (rs.next()) {

                        to = rs.getString(1);        // user's email address
                        emailOpt = rs.getInt(2);        // email option
                        to2 = rs.getString(3);        // user's 2nd email address

                        if (emailOpt != 0) {    // if user wants email notifications

                           if (!to.equals( "" )) {
                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                               send = 1;    // ok to send
                           }
                           if (!to2.equals( "" )) {     // if 2nd email address

                               message2.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
                               send = 1;    // ok to send
                           }
                        }
                     }
                     pstmte5.close();              // close the stmt
                  }

                  if (send != 0) {      // if recipient found

                     //
                     //  Create the message content
                     //
                     String ewaitMsg = header + ewait + " Event: " + name + "    Date: " + mm + "/" + dd + "/" + yy +
                                      " at " + act_time + " ";

                     if (!course.equals( "" )) {

                        ewaitMsg = ewaitMsg + "on Course: " + course;
                     }

                     ewaitMsg = ewaitMsg + "\n";

                     if (aol == true) {                       // if AOL user in the group

                        ewaitMsg = ewaitMsg + trailerAOL;     // add special AOL message
                     }

                     ewaitMsg = ewaitMsg + trailer;

                     message2.setText( ewaitMsg );  // put msg in email text area

                     Transport.send(message2);     // send it!!
                  }
                    
               }      // end of IF user
            }
            catch (Exception e1) {
               //
               //  save error message in /" +rev+ "/error.txt
               //
               errorMsg = "Error6 in sendEmail (Event CheckWait) for " +clubName+ ": ";
               errorMsg = errorMsg + e1;                              // build error msg
               
               try {
                   errorMsg = errorMsg + "  Recipients: " + message.getAllRecipients().toString();
               } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }

               verifySlot.logError(errorMsg);                                       // log it
            }
         }         // end of IF checkwait

      }     // end of IF send
        
      if (type.equals( "password" )) {       // if from Login (password request)

         //
         //  Create the message content
         //
         String pwMsg = header+ "The following password is for " + author + ".\n\n";

         pwMsg = pwMsg + "Password = " +parms.password+ "\n\n";
         pwMsg = pwMsg + "Thank you for using ForeTees!\n\n";

         try {
            message.setText( pwMsg );  // put msg in email text area

            Transport.send(message);     // send it!!
         }
         catch (Exception e1) {
            //
            //  save error message in /" +rev+ "/error.txt
            //
            errorMsg = "Error7 in sendEmail (Transport.send) for " +clubName+ ": ";
            errorMsg = errorMsg + e1;                              // build error msg
            
            try {
                errorMsg = errorMsg + "  Recipients: " + message.getAllRecipients().toString();
            } catch (Exception err1) { errorMsg = " RecipientsErr: " + err1.toString(); }
            
            verifySlot.logError(errorMsg);                                       // log it
         }
           
      }     // end of IF password request from Login

   }        // end of IF ok

 }  // end of sendIt method


 // ************************************************************************
 //  Process 'send email to Caddie Master' request for Oalmont CC and Hallbrook CC
 // ************************************************************************

 public static void sendOakmontEmail(parmEmail parms, Connection con, String club) {


   Statement estmt = null;
   Statement stmtN = null;
   ResultSet rs = null;

   //
   //  Get the parms passed in the parm block
   //
   long date = parms.date;
   int time = parms.time;
   int to_time = parms.to_time;
   int from_time = parms.from_time;
   int fb = parms.fb;
   int to_fb = parms.to_fb;
   int from_fb = parms.from_fb;
   int mm = parms.mm;
   int dd = parms.dd;
   int yy = parms.yy;

   int emailNew = parms.emailNew;
   int emailMod = parms.emailMod;
   int emailCan = parms.emailCan;

   int p91 = parms.p91;
   int p92 = parms.p92;
   int p93 = parms.p93;
   int p94 = parms.p94;
   int p95 = parms.p95;

   String day = parms.day;
   String course = parms.course;
   String to_course = parms.to_course;
   String from_course = parms.from_course;
   String notes = parms.notes;

   String player1 = parms.player1;
   String player2 = parms.player2;
   String player3 = parms.player3;
   String player4 = parms.player4;
   String player5 = parms.player5;

   String oldplayer1 = parms.oldplayer1;
   String oldplayer2 = parms.oldplayer2;
   String oldplayer3 = parms.oldplayer3;
   String oldplayer4 = parms.oldplayer4;
   String oldplayer5 = parms.oldplayer5;

   String user = parms.user;

   String pcw1 = parms.pcw1;
   String pcw2 = parms.pcw2;
   String pcw3 = parms.pcw3;
   String pcw4 = parms.pcw4;
   String pcw5 = parms.pcw5;

   String oldpcw1 = parms.oldpcw1;
   String oldpcw2 = parms.oldpcw2;
   String oldpcw3 = parms.oldpcw3;
   String oldpcw4 = parms.oldpcw4;
   String oldpcw5 = parms.oldpcw5;

   //
   //  Setup for email
   //
   String author = "unknown";
   String userFirst = "";
   String userMi = "";
   String userLast = "";
   String proName = "";

   //
   // Get the SMTP parmaters this club is using
   //
   parmSMTP parm = new parmSMTP();
   
   try {

      getSMTP.getParms(con, parm);        // get the SMTP parms

   } catch (Exception ignore) {}
   
   
   if (!user.startsWith( "proshop" )) {        // if not proshop

      try {

         //
         //  Get this user's name (for id in email msg)
         //
         PreparedStatement pstmte = con.prepareStatement (
                  "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

         pstmte.clearParameters();        // clear the parms
         pstmte.setString(1, user);
         rs = pstmte.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            userLast = rs.getString(1);        // user's name
            userFirst = rs.getString(2);
            userMi = rs.getString(3);

            if (userMi.equals( "" )) {

               author = userFirst + " " + userLast;

            } else {

               author = userFirst + " " + userMi + " " + userLast;
            }
         }
         pstmte.close();              // close the stmt

      }
      catch (Exception ignore) {
      }

   } else {

      author = user;
   }

   //
   //  Get today's date and time for email processing
   //
   Calendar ecal = new GregorianCalendar();               // get todays date
   int eyear = ecal.get(Calendar.YEAR);
   int emonth = ecal.get(Calendar.MONTH);
   int eday = ecal.get(Calendar.DAY_OF_MONTH);
   int e_hourDay = ecal.get(Calendar.HOUR_OF_DAY);
   int e_min = ecal.get(Calendar.MINUTE);

   int e_time = 0;
   int e_time2 = 0;
   long e_date = 0;

   String email_time = "";

   //
   //  Build the 'time' string for display
   //
   //    Adjust the time based on the club's time zone (we are Central)
   //
   e_time = (e_hourDay * 100) + e_min;

   e_time = adjustTime(con, e_time);       // adjust for time zone

   if (e_time < 0) {                // if negative, then we went back or ahead one day

      e_time = 0 - e_time;          // convert back to positive value

      if (e_time < 100) {           // if hour is zero, then we rolled ahead 1 day

         //
         // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
         //
         ecal.add(Calendar.DATE,1);                     // get next day's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);

      } else {                        // we rolled back 1 day

         //
         // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
         //
         ecal.add(Calendar.DATE,-1);                     // get yesterday's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);
      }
   }

   int e_hour = e_time / 100;           // get adjusted hour
   e_min = e_time - (e_hour * 100);     // get minute value
   int e_am_pm = 0;                     // preset to AM

   if (e_hour > 11) {

      e_am_pm = 1;                      // PM
      e_hour = e_hour - 12;             // set to 12 hr clock
   }
   
   if (e_hour == 0) e_hour = 12;

   emonth++;                            // month starts at zero
   e_date = (eyear * 10000) + (emonth * 100) + eday;

   
   // set the date/time string for email message
   email_time = emonth + "/" + eday + "/" + eyear + " at " + e_hour + ":" + ensureDoubleDigit(e_min) + ((e_am_pm == 0) ? " AM" : " PM");


   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   String to = "caddiemaster@oakmont-countryclub.org";            // to address
   if (club.equals( "hallbrookcc" )) {
      to = "golf@hallbrookcc.org";                                // to address for Hallbrook CC
   }
   String f_b = "";
   String eampm = "";
   String etime = "";
   int ehr = 0;
   int emin = 0;
   int send = 0;
   String clubName = "";
   String errorMsg = "";

   PreparedStatement pstmte1 = null;

   //
   //  Get the name of the club
   //
   try {

      stmtN = con.createStatement();

      rs = stmtN.executeQuery("SELECT clubName FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         clubName = rs.getString(1);
      }
      stmtN.close();

   }
   catch (Exception ignore) {
   }

   //
   //  convert time to hour and minutes for email msg
   //
   ehr = time / 100;
   emin = time - (ehr * 100);
   eampm = " AM";
   if (ehr > 12) {

      eampm = " PM";
      ehr = ehr - 12;       // convert from military time
   }
   if (ehr == 12) {

      eampm = " PM";
   }
   if (ehr == 0) {

      ehr = 12;
      eampm = " AM";
   }

   etime = ehr + ":" + ensureDoubleDigit(emin) + eampm;
   

   //
   //  set the front/back value
   //
   f_b = "Front";

   if (fb == 1) {

      f_b = "Back";
   }

   String mod = "";
   String enew = "";
   String can = "";
   String enewMsg = "";
   String emodMsg = "";
   String ecanMsg = "";

   mod = "The following Tee Time Request has been MODIFIED by " + author + ".\n\n";
   enew = "The following Tee Time Request has been ENTERED by " + author + ".\n\n";
   can = "The following tee time has been CANCELLED by " + author + ".\n\n";
   String subjectNew = "ADD from ForeTees - A Guest Tee Time has been added.";
   String subjectMod = "CHANGE from ForeTees - A Guest Tee Time has been changed.";
   String subjectCan = "DELETED from ForeTees - A Guest Tee Time has been cancelled.";

   if (club.equals( "hallbrookcc" )) {

      subjectNew = "ADD from ForeTees - A Caddie Request has been added.";
      subjectMod = "CHANGE from ForeTees - A Caddie Request has been changed.";
      subjectCan = "DELETED from ForeTees - A Caddie has been cancelled.";
   }
        
      
   Properties properties = new Properties();
   properties.put("mail.smtp.host", parm.SMTP_ADDR);                        // set outbound host address
   properties.put("mail.smtp.port", parm.SMTP_PORT);                        // set port address
   properties.put("mail.smtp.auth", (parm.SMTP_AUTH) ? "true" : "false");   // set 'use authentication'

   //Session mailSess = Session.getInstance(properties, getAuthenticator()); // get session properties
   
   Session mailSess;
      
   if (parm.SMTP_AUTH) {

       mailSess = Session.getInstance(properties, getAuthenticator(parm.SMTP_USER, parm.SMTP_PASS));

   } else {

       mailSess = Session.getInstance(properties, null);

   } 
   
   MimeMessage message = new MimeMessage(mailSess);

   try {

      message.setFrom(new InternetAddress(parm.EMAIL_FROM));                              // set from addr
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
      message.setSentDate(new java.util.Date());                                // set date/time sent

      if (emailNew != 0) {        // if new tee time

         message.setSubject( subjectNew );                                            // set subject line
      }

      if (emailMod != 0) {        // if modified tee time

         message.setSubject( subjectMod );                                            // set subject line
      }

      if (emailCan != 0) {        // if Cancel tee time

         message.setSubject( subjectCan );                                            // set subject line
      }

   }
   catch (Exception e1) {
      //
      //  save error message in /" +rev+ "/error.txt
      //
      errorMsg = "Error1 in Oakmont sendEmail (get Properties) from Member_slot: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

   //
   //  set trans mode based on 9-hole options
   //
   if (p91 == 1) {

      pcw1 = pcw1 + "9";
   }
   if (p92 == 1) {

      pcw2 = pcw2 + "9";
   }
   if (p93 == 1) {

      pcw3 = pcw3 + "9";
   }
   if (p94 == 1) {

      pcw4 = pcw4 + "9";
   }
   if (p95 == 1) {

      pcw5 = pcw5 + "9";
   }

   //
   //  if player is 'x' then change c/w option to space
   //
   if (player1.equalsIgnoreCase( "x" )) {

      pcw1 = " ";
   }
   if (player2.equalsIgnoreCase( "x" )) {

      pcw2 = " ";
   }
   if (player3.equalsIgnoreCase( "x" )) {

      pcw3 = " ";
   }
   if (player4.equalsIgnoreCase( "x" )) {

      pcw4 = " ";
   }
   if (player5.equalsIgnoreCase( "x" )) {

      pcw5 = " ";
   }

   //
   //  Process according to the request type
   //
   if (emailNew != 0) {        // if new tee time

      enewMsg = header + enew + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " " +
                       "on the " + f_b + " 9 ";

      if (!course.equals( "" )) {

         enewMsg = enewMsg + "of Course: " + course;
      }

      enewMsg = enewMsg + "\n";

      //
      //  build message text
      //
      if (!player1.equals( "" )) {

         enewMsg = enewMsg + "\nPlayer 1: " + player1 + "  " + pcw1;
      }
      if (!player2.equals( "" )) {

         enewMsg = enewMsg + "\nPlayer 2: " + player2 + "  " + pcw2;
      }
      if (!player3.equals( "" )) {

         enewMsg = enewMsg + "\nPlayer 3: " + player3 + "  " + pcw3;
      }
      if (!player4.equals( "" )) {

         enewMsg = enewMsg + "\nPlayer 4: " + player4 + "  " + pcw4;
      }
      if (!player5.equals( "" )) {

         enewMsg = enewMsg + "\nPlayer 5: " + player5 + "  " + pcw5;
      }

      if (!notes.equals( "" )) {
      
         enewMsg = enewMsg + "\nNotes: " + notes;        // add notes
      }

      enewMsg = enewMsg + trailer;

      try {
         message.setText( enewMsg );  // put msg in email text area

         Transport.send(message);     // send it!!
      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         errorMsg = "Error2 in sendOakmontEmail (Transport.send) from Member_slot: ";
         errorMsg = errorMsg + e1;                              // build error msg

         verifySlot.logError(errorMsg);                                       // log it
      }
   }

   if (emailCan != 0) {        // if Cancelled tee time

      //
      //  Create the message content
      //
      ecanMsg = header + can + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " " +
                             "on the " + f_b + " 9 ";

      if (!course.equals( "" )) {

          ecanMsg = ecanMsg + "of Course: " + course;
      }

      ecanMsg = ecanMsg + "\n";

      //
      //  build message text
      //
      if (!oldplayer1.equals( "" )) {

         ecanMsg = ecanMsg + "\nPlayer 1: " + oldplayer1 + "  " + oldpcw1;
      }
      if (!oldplayer2.equals( "" )) {

         ecanMsg = ecanMsg + "\nPlayer 2: " + oldplayer2 + "  " + oldpcw2;
      }
      if (!oldplayer3.equals( "" )) {

         ecanMsg = ecanMsg + "\nPlayer 3: " + oldplayer3 + "  " + oldpcw3;
      }
      if (!oldplayer4.equals( "" )) {

         ecanMsg = ecanMsg + "\nPlayer 4: " + oldplayer4 + "  " + oldpcw4;
      }
      if (!oldplayer5.equals( "" )) {

         ecanMsg = ecanMsg + "\nPlayer 5: " + oldplayer5 + "  " + oldpcw5;
      }

      ecanMsg = ecanMsg + trailer;

      try {
         message.setText( ecanMsg );  // put msg in email text area

         Transport.send(message);     // send it!!
      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         errorMsg = "Error3 in sendOakmontEmail (Transport.send) from Member_slot: ";
         errorMsg = errorMsg + e1;                              // build error msg

         verifySlot.logError(errorMsg);                                       // log it
      }
   }

   if (emailMod != 0) {        // if tee time modified

      //
      //  Create the message content
      //
      emodMsg = header + mod + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " " +
                  "on the " + f_b + " 9 ";

      if (!from_course.equals( "" )) {

         course = to_course;
      }

      if (!course.equals( "" )) {

         emodMsg = emodMsg + "of Course: " + course;
      }

      emodMsg = emodMsg + "\n\nNew Group:\n";

      if (!player1.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 1: " + player1 + "  " + pcw1;
      }
      if (!player2.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 2: " + player2 + "  " + pcw2;
      }
      if (!player3.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 3: " + player3 + "  " + pcw3;
      }
      if (!player4.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 4: " + player4 + "  " + pcw4;
      }
      if (!player5.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 5: " + player5 + "  " + pcw5;
      }

      if (!notes.equals( "" )) {

         emodMsg = emodMsg + "\nNotes: " + notes;        // add notes
      }

      emodMsg = emodMsg + "\n\nPrevious Group (before change):\n";

      if (!oldplayer1.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 1: " + oldplayer1 + "  " + oldpcw1;
      }
      if (!oldplayer2.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 2: " + oldplayer2 + "  " + oldpcw2;
      }
      if (!oldplayer3.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 3: " + oldplayer3 + "  " + oldpcw3;
      }
      if (!oldplayer4.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 4: " + oldplayer4 + "  " + oldpcw4;
      }
      if (!oldplayer5.equals( "" )) {

         emodMsg = emodMsg + "\nPlayer 5: " + oldplayer5 + "  " + oldpcw5;
      }

      emodMsg = emodMsg + trailer;

      try {
         message.setText( emodMsg );  // put msg in email text area

         Transport.send(message);     // send it!!

      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         errorMsg = "Error4 in sendOakmontEmail (Transport.send) from Member_slot: ";
         errorMsg = errorMsg + e1;                              // build error msg

         verifySlot.logError(errorMsg);                                       // log it
      }
   }

 }  // end of sendOakmontEmail


 // ************************************************************************
 //  Process 'send email to Head Pro' request for Congressional CC
 // ************************************************************************

 public static void sendCongressEmail(parmEmail parms, Connection con) {


   Statement estmt = null;
   Statement stmtN = null;
   ResultSet rs = null;

   //
   //  Get the parms passed in the parm block
   //
   long date = parms.date;
   int time = parms.time;
   int to_time = parms.to_time;
   int from_time = parms.from_time;
   int fb = parms.fb;
   int to_fb = parms.to_fb;
   int from_fb = parms.from_fb;
   int mm = parms.mm;
   int dd = parms.dd;
   int yy = parms.yy;

   int emailNew = parms.emailNew;
   int emailMod = parms.emailMod;
   int emailCan = parms.emailCan;

   int p91 = parms.p91;
   int p92 = parms.p92;
   int p93 = parms.p93;
   int p94 = parms.p94;
   int p95 = parms.p95;

   String day = parms.day;
   String course = parms.course;
   String to_course = parms.to_course;
   String from_course = parms.from_course;
   String notes = parms.notes;

   String player1 = parms.player1;
   String player2 = parms.player2;
   String player3 = parms.player3;
   String player4 = parms.player4;
   String player5 = parms.player5;

   String oldplayer1 = parms.oldplayer1;
   String oldplayer2 = parms.oldplayer2;
   String oldplayer3 = parms.oldplayer3;
   String oldplayer4 = parms.oldplayer4;
   String oldplayer5 = parms.oldplayer5;

   String user = parms.user;

   String pcw1 = parms.pcw1;
   String pcw2 = parms.pcw2;
   String pcw3 = parms.pcw3;
   String pcw4 = parms.pcw4;
   String pcw5 = parms.pcw5;

   String oldpcw1 = parms.oldpcw1;
   String oldpcw2 = parms.oldpcw2;
   String oldpcw3 = parms.oldpcw3;
   String oldpcw4 = parms.oldpcw4;
   String oldpcw5 = parms.oldpcw5;

   //
   //  Setup for email
   //
   String author = "unknown";
   String userFirst = "";
   String userMi = "";
   String userLast = "";
   String proName = "";

   //
   // Get the SMTP parmaters this club is using
   //
   parmSMTP parm = new parmSMTP();
   
   try {

      getSMTP.getParms(con, parm);        // get the SMTP parms

   } catch (Exception ignore) {}
   
   
   if (!user.startsWith( "proshop" )) {        // if not proshop

      try {

         //
         //  Get this user's name (for id in email msg)
         //
         PreparedStatement pstmte = con.prepareStatement (
                  "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

         pstmte.clearParameters();        // clear the parms
         pstmte.setString(1, user);
         rs = pstmte.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            userLast = rs.getString(1);        // user's name
            userFirst = rs.getString(2);
            userMi = rs.getString(3);

            if (userMi.equals( "" )) {

               author = userFirst + " " + userLast;

            } else {

               author = userFirst + " " + userMi + " " + userLast;
            }
         }
         pstmte.close();              // close the stmt

      }
      catch (Exception ignore) {
      }

   } else {

      author = user;
   }

   //
   //  Get today's date and time for email processing
   //
   Calendar ecal = new GregorianCalendar();               // get todays date
   int eyear = ecal.get(Calendar.YEAR);
   int emonth = ecal.get(Calendar.MONTH);
   int eday = ecal.get(Calendar.DAY_OF_MONTH);
   int e_hourDay = ecal.get(Calendar.HOUR_OF_DAY);
   int e_min = ecal.get(Calendar.MINUTE);

   int e_time = 0;
   int e_time2 = 0;
   long e_date = 0;

   String email_time = "";

   //
   //  Build the 'time' string for display
   //
   //    Adjust the time based on the club's time zone (we are Central)
   //
   e_time = (e_hourDay * 100) + e_min;

   e_time = adjustTime(con, e_time);       // adjust for time zone

   if (e_time < 0) {                // if negative, then we went back or ahead one day

      e_time = 0 - e_time;          // convert back to positive value

      if (e_time < 100) {           // if hour is zero, then we rolled ahead 1 day

         //
         // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
         //
         ecal.add(Calendar.DATE,1);                     // get next day's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);

      } else {                        // we rolled back 1 day

         //
         // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
         //
         ecal.add(Calendar.DATE,-1);                     // get yesterday's date

         eyear = ecal.get(Calendar.YEAR);
         emonth = ecal.get(Calendar.MONTH);
         eday = ecal.get(Calendar.DAY_OF_MONTH);
      }
   }

   int e_hour = e_time / 100;                // get adjusted hour
   e_min = e_time - (e_hour * 100);          // get minute value
   int e_am_pm = 0;                         // preset to AM

   if (e_hour > 11) {

      e_am_pm = 1;                // PM
      e_hour = e_hour - 12;       // set to 12 hr clock
   }
   if (e_hour == 0) {

      e_hour = 12;
   }

   emonth = emonth + 1;                            // month starts at zero
   e_date = (eyear * 10000) + (emonth * 100) + eday;

   
   // set the date/time string for email message
   email_time = emonth + "/" + eday + "/" + eyear + " at " + e_hour + ":" + ensureDoubleDigit(e_min) + ((e_am_pm == 0) ? " AM" : " PM");


   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   String to = "golfpro@ccclub.org";                   // to address
   String f_b = "";
   String eampm = "";
   String etime = "";
   int ehr = 0;
   int emin = 0;
   int send = 0;
   String clubName = "Congressional CC";
   String errorMsg = "";

   PreparedStatement pstmte1 = null;

   //
   //  convert time to hour and minutes for email msg
   //
   ehr = time / 100;
   emin = time - (ehr * 100);
   eampm = " AM";
   if (ehr > 12) {

      eampm = " PM";
      ehr = ehr - 12;       // convert from military time
   }
   if (ehr == 12) {

      eampm = " PM";
   }
   if (ehr == 0) {

      ehr = 12;
      eampm = " AM";
   }

   etime = ehr + ":" + ensureDoubleDigit(emin) + eampm;

   //
   //  set the front/back value
   //
   f_b = "Front";

   if (fb == 1) {

      f_b = "Back";
   }

   String can = "";
   String ecanMsg = "";

   can = "The following 'Non Local Guest' tee time has been CANCELLED by " + author + ".\n\n";
   String subjectCan = "ForeTees - Non Local Guest Tee Time has been cancelled.";


   Properties properties = new Properties();
   properties.put("mail.smtp.host", parm.SMTP_ADDR);                        // set outbound host address
   properties.put("mail.smtp.port", parm.SMTP_PORT);                        // set port address
   properties.put("mail.smtp.auth", (parm.SMTP_AUTH) ? "true" : "false");   // set 'use authentication'

   //Session mailSess = Session.getInstance(properties, getAuthenticator());  // get session properties

   Session mailSess;
      
   if (parm.SMTP_AUTH) {

       mailSess = Session.getInstance(properties, getAuthenticator(parm.SMTP_USER, parm.SMTP_PASS));

   } else {

       mailSess = Session.getInstance(properties, null);

   }
   
   MimeMessage message = new MimeMessage(mailSess);

   try {

      message.setFrom(new InternetAddress(parm.EMAIL_FROM));                          // set from addr
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
      message.setSentDate(new java.util.Date());                            // set date/time sent

      message.setSubject( subjectCan );                                     // set subject line

   }
   catch (Exception e1) {
      //
      //  save error message in /" +rev+ "/error.txt
      //
      errorMsg = "Error1 in Congressional sendEmail (get Properties) from Member_slot: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

   //
   //  set trans mode based on 9-hole options
   //
   if (p91 == 1) {

      pcw1 = pcw1 + "9";
   }
   if (p92 == 1) {

      pcw2 = pcw2 + "9";
   }
   if (p93 == 1) {

      pcw3 = pcw3 + "9";
   }
   if (p94 == 1) {

      pcw4 = pcw4 + "9";
   }
   if (p95 == 1) {

      pcw5 = pcw5 + "9";
   }

   //
   //  if player is 'x' then change c/w option to space
   //
   if (player1.equalsIgnoreCase( "x" )) {

      pcw1 = " ";
   }
   if (player2.equalsIgnoreCase( "x" )) {

      pcw2 = " ";
   }
   if (player3.equalsIgnoreCase( "x" )) {

      pcw3 = " ";
   }
   if (player4.equalsIgnoreCase( "x" )) {

      pcw4 = " ";
   }
   if (player5.equalsIgnoreCase( "x" )) {

      pcw5 = " ";
   }

   //
   //  Process Cancel email
   //
   ecanMsg = header + can + day + " " + mm + "/" + dd + "/" + yy + " at " + etime + " " +
                          "on the " + f_b + " 9 ";

   if (!course.equals( "" )) {

       ecanMsg = ecanMsg + "of Course: " + course;
   }

   ecanMsg = ecanMsg + "\n";

   //
   //  build message text
   //
   if (!oldplayer1.equals( "" )) {

      ecanMsg = ecanMsg + "\nPlayer 1: " + oldplayer1 + "  " + oldpcw1;
   }
   if (!oldplayer2.equals( "" )) {

      ecanMsg = ecanMsg + "\nPlayer 2: " + oldplayer2 + "  " + oldpcw2;
   }
   if (!oldplayer3.equals( "" )) {

      ecanMsg = ecanMsg + "\nPlayer 3: " + oldplayer3 + "  " + oldpcw3;
   }
   if (!oldplayer4.equals( "" )) {

      ecanMsg = ecanMsg + "\nPlayer 4: " + oldplayer4 + "  " + oldpcw4;
   }
   if (!oldplayer5.equals( "" )) {

      ecanMsg = ecanMsg + "\nPlayer 5: " + oldplayer5 + "  " + oldpcw5;
   }

   ecanMsg = ecanMsg + trailer;

   try {
      message.setText( ecanMsg );  // put msg in email text area

      Transport.send(message);     // send it!!
   }
   catch (Exception e1) {
      //
      //  save error message in /" +rev+ "/error.txt
      //
      errorMsg = "Error3 in sendCongressEmail (Transport.send) from Member_slot: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

 }  // end of sendCongressEmail


 // **************************************************************************************************************
 //  Process send email to Westchester CC or Pelicans Nest GC - 
 //       - a member has changed his/her email address (from Member_services)
 // **************************************************************************************************************

 public static void sendWestEmail(parmEmail parms, Connection con) {


   Statement estmt = null;
   Statement stmtN = null;
   ResultSet rs = null;

   //
   //  Get the parms passed in the parm block
   //
   String player1 = parms.player1;              // get email address
   String player2 = parms.player2;              // 2nd email address
   String user = parms.user;                    // member
   String errorMsg = "";


   //
   //  Setup for email
   //
   String author = "unknown";
   String userFirst = "";
   String userMi = "";
   String userLast = "";


   //
   // Get the SMTP parmaters this club is using
   //
   parmSMTP parm = new parmSMTP();
   
   try {

      getSMTP.getParms(con, parm);        // get the SMTP parms

   } catch (Exception ignore) {}
   
   
   try {

      //
      //  Get this user's name (for id in email msg)
      //
      PreparedStatement pstmte = con.prepareStatement (
               "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

      pstmte.clearParameters();        // clear the parms
      pstmte.setString(1, user);
      rs = pstmte.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         userLast = rs.getString(1);        // user's name
         userFirst = rs.getString(2);
         userMi = rs.getString(3);

         if (userMi.equals( "" )) {

            author = userFirst + " " + userLast;

         } else {

            author = userFirst + " " + userMi + " " + userLast;
         }
      }
      pstmte.close();              // close the stmt

   }
   catch (Exception ignore) {
   }


   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   String to = "";                   // to addresses
   String to2 = "";    

   if (parms.type.equals( "Westchester" )) {

      to = "cisolini@wccclub.org";            // to address
      to2 = "aspiconardi@wccclub.org";        // to address

   } else {       // else Pelicans Nest
    
      to = "cpera@pelicansnest.org";            // to address
   }

   String msg = "\nMember " + author + " has added or changed an email address on the ForeTees system.\n\n";
   String subject = "Member Email Address Change Notification from ForeTees";

   String trailerWest = "\n\n\n*****************************************************************************************" +
                    "\nThis message is sent by the ForeTees system whenever a member of your club changes one or both " +
                    "of his/her email addresses.  This allows you the opportunity to make the same change in any of " +
                    "your other member databases.  Please contact ForeTees at support@foretees.com to request any " +
                    "changes. " +
                    "Thank you for using the ForeTees Reservation System." +
                    "\n********************************************************************************************";


   Properties properties = new Properties();
   properties.put("mail.smtp.host", parm.SMTP_ADDR);                        // set outbound host address
   properties.put("mail.smtp.port", parm.SMTP_PORT);                        // set port address
   properties.put("mail.smtp.auth", (parm.SMTP_AUTH) ? "true" : "false");   // set 'use authentication'

   //Session mailSess = Session.getInstance(properties, getAuthenticator());  // get session properties

   Session mailSess;
      
   if (parm.SMTP_AUTH) {

       mailSess = Session.getInstance(properties, getAuthenticator(parm.SMTP_USER, parm.SMTP_PASS));

   } else {

       mailSess = Session.getInstance(properties, null);

   }
   
   MimeMessage message = new MimeMessage(mailSess);

   try {

      message.setFrom(new InternetAddress(parm.SMTP_ADDR));                 // set from addr
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
      if (!to2.equals( "" )) {
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
      }
      message.setSentDate(new java.util.Date());                            // set date/time sent
      message.setSubject( subject );                                        // set subject line

   }
   catch (Exception e1) {
      //
      //  save error message in /" +rev+ "/error.txt
      //
      errorMsg = "Error1 in sendEmail.sendWestEmail (get Properties) from Member_services: ";
      errorMsg = errorMsg + e1;                                             // build error msg

      verifySlot.logError(errorMsg);                                        // log it
   }

   if (player1 == null) {       // make sure email #1 is not null

      player1 = " ";
   }
   if (player2 == null) {

      player2 = " ";
   }
     
   msg = msg + "New primary email address: " + player1;

   msg = msg + "\n\nNew alternate email address: " + player2;

   msg = msg + trailerWest;            // add trailer

   try {
      message.setText( msg );      // put msg in email text area

      Transport.send(message);     // send it!!
        
   }
   catch (Exception e1) {
      //
      //  save error message in /" +rev+ "/error.txt
      //
      errorMsg = "Error2 in sendEmail.sendWestEmail (Transport.send) from Member_services: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

 }  // end of sendWestEmail


 // **************************************************************************************************************
 //  Process send email to Winged Foot Pro -
 //       - a member has gotten close to his/her guest quota (within 3)
 // **************************************************************************************************************

 public static void sendWFemail(int remaining, int quota, String player, String msgType) {


   //
   //  Send email notification if necessary
   //
   String errorMsg = "";      
   String to = "dzona@wfgc.org";              // to address


   String msg = "\nMember " +player+ " has " +remaining+ " guest(s) remaing in his/her guest quota of " +quota+ " for the " +msgType+ ".\n\n";
   String subject = "Member Guest Quota Notification from ForeTees";

   String trailerWF = "\n\n\n*****************************************************************************************" +
                    "\nThis message is sent by the ForeTees system whenever a member of your club comes " +
                    "within 4 guests of their family quota for the season or the year. " +
                    "Please contact ForeTees at support@foretees.com to request any changes. " +
                    "Thank you for using the ForeTees Reservation System." +
                    "\n********************************************************************************************";


   Properties properties = new Properties();
   properties.put("mail.smtp.host", host);                      // set outbound host address
   properties.put("mail.smtp.port", port);                      // set port address
   properties.put("mail.smtp.auth", "true");                    // set 'use authentication'

   Session mailSess = Session.getInstance(properties, getAuthenticator("support@foretees.com", "fikd18")); // get session properties
   
   MimeMessage message = new MimeMessage(mailSess);

   try {

      message.setFrom(new InternetAddress(efrom));                               // set from addr
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
      message.setSentDate(new java.util.Date());                                // set date/time sent
      message.setSubject( subject );                                            // set subject line

   }
   catch (Exception e1) {
      errorMsg = "Error1 in sendEmail.sendWFemail (get Properties) from Member_services: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }


   msg = msg + trailerWF;            // add trailer

   try {
      message.setText( msg );      // put msg in email text area

      Transport.send(message);     // send it!!

   }
   catch (Exception e1) {
      errorMsg = "Error2 in sendEmail.sendWFemail (Transport.send) from Member_services: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

 }  // end of sendWFemail

 
 
 // **************************************************************************************************************
 //  Process send email to Mediterra Pro -  (Case 1262)
 //       - a sports member has booked their final tee time allowed in time period
 // **************************************************************************************************************

 public static void sendMediterraEmail(String player, String mnum) {


   //
   //  Send email notification if necessary
   //
   String errorMsg = "";      
   String to = "KrisinC@bonitabaygroup.com";              // to address


   String msg = "\nMember " +player+ " (member number " + mnum + ") has used their 4 allowed rounds.\n\n";
   String subject = "Sports member has reached their quota.";

   String trailerWF = "\n\n\n*****************************************************************************************" +
                    "\nThis message is sent by the ForeTees system whenever a Sports member of your club " +
                    "uses all their allowed rounds of golf for the season. " +
                    "Please contact ForeTees at support@foretees.com to request any changes. " +
                    "Thank you for using the ForeTees Reservation System." +
                    "\n********************************************************************************************";


   Properties properties = new Properties();
   properties.put("mail.smtp.host", host);                      // set outbound host address
   properties.put("mail.smtp.port", port);                      // set port address
   properties.put("mail.smtp.auth", "true");                    // set 'use authentication'

   Session mailSess = Session.getInstance(properties, getAuthenticator("support@foretees.com", "fikd18")); // get session properties

   MimeMessage message = new MimeMessage(mailSess);

   try {

      message.setFrom(new InternetAddress(efrom));                               // set from addr
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
      message.setSentDate(new java.util.Date());                                // set date/time sent
      message.setSubject( subject );                                            // set subject line

   }
   catch (Exception e1) {
      errorMsg = "Error1 in sendEmail.sendMediterraEmail (get Properties) from Member_services: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }


   msg = msg + trailerWF;            // add trailer

   try {
      message.setText( msg );      // put msg in email text area

      Transport.send(message);     // send it!!

   }
   catch (Exception e1) {
      errorMsg = "Error2 in sendEmail.sendMediterraEmail (Transport.send) from Member_services: ";
      errorMsg = errorMsg + e1;                              // build error msg

      verifySlot.logError(errorMsg);                                       // log it
   }

 }  // end of sendMediterraEmail

 
 //************************************************************************
 //  adjustTime - receives a time value (hhmm) and adjusts it for the club's
 //               specified time zone.
 //
 //  Called by:  Proshop_lott
 //              Member_lott
 //              Proshop_select
 //              Member_select
 //              moveReqs (and others above)
 //
 //
 //   returns: time (hhmm) - negative value if it rolled back or ahead a day
 //
 //************************************************************************

 public static int adjustTime(Connection con, int time) {


   Statement stmt = null;
   ResultSet rs = null;

   int hour = 0;
   int min = 0;
   boolean roll = false;

   String adv_zone = "";

   //
   //  separate hour and min from time
   //
   hour = time / 100;                    // 00 - 23
   min = time - (hour * 100);            // 00 - 59

   //
   //  get the club's time zone
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT adv_zone " +
                              "FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         adv_zone = rs.getString(1);
      }
      stmt.close();

   }
   catch (Exception ignore) {
   }

   if (adv_zone.equals( "Eastern" )) {      // Eastern Time = +1 hr

      hour++;                // adjust the hour value

      if (hour == 24) {

         hour = 0;           // keep from 0 to 23
         roll = true;        // rolled ahead a day
      }
   }

   if (adv_zone.equals( "Mountain" )) {      // Mountain Time = -1 hr

      if (hour == 0) {

         hour = 24;          // change so it can be adjusted below
         roll = true;        // rolled back a day
      }

      hour--;                // adjust the hour value
   }

   if (adv_zone.equals( "Pacific" )) {      // Pacific Time = -2 hrs

      if (hour == 0) {

         hour = 22;          // adjust it
         roll = true;        // rolled back a day

      } else {

         if (hour == 1) {

            hour = 23;          // adjust it
            roll = true;        // rolled back a day

         } else {

            hour = hour - 2;             // adjust the hour value
         }
      }
   }
   time = (hour * 100) + min;

   if (roll == true) {

      time = (0 - time);        // create negative value to indicate we rolled back one day
   }

   return( time );

 }  // end of adjustTime


 //************************************************************************
 //  unfilter - Searches the string provided for special HTML characters and
 //             replaces them with normal special characters.
 //
 //           &lt becomes <
 //           &gt becomes >
 //           &quot becomes "
 //           &amp becomes &
 //
 //
 //    called by:  Send_email
 //
 //************************************************************************

 public static String unfilter(String input) {


    StringBuffer unfiltered = new StringBuffer(input.length());
    StringBuffer spec = new StringBuffer(5);

    int length = input.length();
    char c;
    String specs = "";

    for(int i=0; i<length; i++) {

       c = input.charAt(i);
       if (c == '&') {                  // if special html char

          spec = new StringBuffer(5);   // init string

          while (c != ';' && i<length) {   // go till end of spec char - semi-colon

             spec.append(c);            // put in buffer
             i++;
             c = input.charAt(i);       // get next
          }                             // end of WHILE

          specs = spec.toString();      // put in string form

          if (specs.equals("&lt")) {                  // if special char
             unfiltered.append('<');                 // change back to normal spec char
          } else if (specs.equals("&gt")) {
             unfiltered.append('>');
          } else if (specs.equals("&quot")) {
             unfiltered.append('"');
          } else if (specs.equals("&amp")) {
             unfiltered.append('&');
          } else if (specs.equals("&#35")) {
             unfiltered.append('#');
          } else if (specs.equals("&#33")) {
             unfiltered.append('!');
          } else if (specs.equals("&#36")) {
             unfiltered.append("$");
          } else if (specs.equals("&#37")) {
             unfiltered.append('%');
          } else if (specs.equals("&#40")) {
             unfiltered.append('(');
          } else if (specs.equals("&#41")) {
             unfiltered.append(')');
          } else if (specs.equals("&#42")) {
             unfiltered.append('*');
          } else if (specs.equals("&#43")) {
             unfiltered.append('+');
          } else if (specs.equals("&#44")) {
             unfiltered.append(',');
          } else if (specs.equals("&#45")) {
             unfiltered.append('-');
          } else if (specs.equals("&#46")) {
             unfiltered.append('.');
          } else if (specs.equals("&#47")) {
             unfiltered.append('/');
          } else if (specs.equals("&#61")) {
             unfiltered.append('=');
          } else if (specs.equals("&#63")) {
             unfiltered.append('?');
          } else if (specs.equals("&#64")) {
             unfiltered.append('@');
          } else if (specs.equals("&#91")) {
             unfiltered.append('[');
          } else if (specs.equals("&#93")) {
             unfiltered.append(']');
          } else if (specs.equals("&#94")) {
             unfiltered.append('^');
          } else if (specs.equals("&#95")) {
             unfiltered.append('_');
          } else if (specs.equals("&#123")) {
             unfiltered.append('{');
          } else if (specs.equals("&#124")) {
             unfiltered.append('|');
          } else if (specs.equals("&#125")) {
             unfiltered.append('}');
          } else if (specs.equals("&#126")) {
             unfiltered.append('~');
          }
       } else {
          unfiltered.append(c);

       }          // end of IF spec char
    }             // end of DO loop

    return(unfiltered.toString());

 }  // end of unfilter


 // ************************************************************************
 //  Process getAuthenticator for email authentication
 // ************************************************************************

 private static Authenticator getAuthenticator(final String user, final String pass) {

    Authenticator auth = new Authenticator() {

       public PasswordAuthentication getPasswordAuthentication() {

         return new PasswordAuthentication(user, pass); // credentials
         //return new PasswordAuthentication("support@foretees.com", "fikd18"); // credentials
       }
    };

    return auth;
 }
 
 
 //************************************************************************
 //
 // Return a string with a leading zero is nessesary
 //
 //************************************************************************
 private static String ensureDoubleDigit(int value) {

    return ((value < 10) ? "0" + value : "" + value);
     
 }
 
}  // end of sendEmail class
