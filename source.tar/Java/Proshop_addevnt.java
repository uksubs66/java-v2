/***************************************************************************************     
 *   Proshop_addevnt:  This servlet will process the 'add event' request from Proshop's
 *                     addevnt page.
 *
 *
 *   called by:  Proshop_events
 *
 *   created: 12/19/2001   Bob P.
 *
 *   last updated:
 *
 *        4/07/08   Fixes for season long events
 *        3/24/08   Add gender field to event config
 *        2/27/08   Removed message of 254 char restriction on Itinerary - removed actual limitation last year
 *       10/14/07   Do not update 'holes' on 2nd page - it was getting overwritten.
 *        9/25/07   Add minimum sign-up size to configurable options
 *       10/11/06   Call Common_Config to output the colors.
 *        6/22/06   Remove POS charge codes until the POS interfaces are added for events.
 *        5/10/05   Add mtype and mship restrictions to the events.
 *        2/16/05   Ver 5 - start with today's date and use common function to set it.
 *        1/24/05   Ver 5 - change club2 to club5.
 *        1/07/05   If copying an event, copy the 2nd page also - get name from Proshop_events.
 *        7/08/04   Add 'Make Copy' option to allow pro to copy an existing event.
 *        5/05/04   Add 2nd set of block times for events.
 *        5/05/04   Move Itinery from 2nd page to first page so it is always included.
 *                  Add 2nd set of blocker times so pro can block off another group of
 *                  times for cross-overs during event.
 *        2/16/04   Enhancements for Version 4.  Add dynamic Modes of Trans options.
 *                  Add POS Charge fields for cost of event.
 *        7/18/03   Enhancements for Version 3 of the software.
 *        2/10/03   Enhancement for V2 - add event sign-up.
 *        1/14/03   Add SignUp option for members to sign up online.
 *        1/06/03   Enhancements for Version 2 of the software.
 *                  Add support for multiple courses.
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
  
// foretees imports
import com.foretees.common.parmClub;
import com.foretees.common.getClub;
import com.foretees.common.dateOpts;
import com.foretees.common.Labels;


public class Proshop_addevnt extends HttpServlet {
 

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 //****************************************************
 // Process the request from Proshop_events
 //****************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Statement stmt = null;
   ResultSet rs = null;
   String omit = "";

   HttpSession session = SystemUtils.verifyPro(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H1>Database Connection Error</H1>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   //
   //  Array to hold the course names
   //
   String [] course = new String [20];                     // max of 20 courses per club

   String courseName = "";        // course names
   int multi = 0;               // multiple course support
   int index = 0;
   int tmp = 0;

   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   //
   //  Get today's date
   //
   Calendar cal = new GregorianCalendar();       // get todays date
   int thisYear = cal.get(Calendar.YEAR);        // get the year
   int thisMonth = cal.get(Calendar.MONTH) +1;
   int thisDay = cal.get(Calendar.DAY_OF_MONTH);

   //
   // Get the 'Multiple Course' option from the club db
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT multi " +
                             "FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         multi = rs.getInt(1);
      }
      stmt.close();

      if (multi != 0) {           // if multiple courses supported for this club

         while (index< 20) {

            course[index] = "";       // init the course array
            index++;
         }

         index = 0;

         //
         //  Get the names of all courses for this club
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT courseName " +
                                "FROM clubparm2 WHERE first_hr != 0");

         while (rs.next() && index < 20) {

            courseName = rs.getString(1);

            course[index] = courseName;      // add course name to array
            index++;
         }
         stmt.close();
      }

   }
   catch (Exception exc) {

      out.println(SystemUtils.HeadTitle("Database Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR><br>Exception: " + exc.getMessage());
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   //
   //  Build the HTML page to prompt user for the info
   //
   out.println(SystemUtils.HeadTitle2("Proshop - Add Event Main"));
      out.println("<script>");
      out.println("<!--");
      out.println("function cursor(){document.f.event_name.focus();}");
      out.println("// -->");
      out.println("</script>");
   out.println("</head>");

   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" onLoad=cursor()>");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, sans-serif\">");
   out.println("<center>");
   out.println("<table border=\"1\" bgcolor=\"#336633\" cellpadding=\"5\" align=\"center\">");
   out.println("<tr><td align=\"center\">");
   out.println("<font color=\"#FFFFFF\" size=\"3\">");
      out.println("<b>Special Events</b><br>");
   out.println("</font><font color=\"#FFFFFF\" size=\"2\">");
      out.println("Complete the following information for each event to be added.<br>");
      out.println("Click on <b>Continue</b> to add the event.");
   out.println("</font></td></tr></table><br>");
   out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"8\" align=\"center\">");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_addevnt\" method=\"post\" target=\"bot\" name=\"f\" id=\"f\">");
      out.println("<tr>");
      out.println("<td width=\"530\">");
         out.println("<font size=\"2\">");
         out.println("<p align=\"left\"><nobr>Event Name (Use A-Z, a-z, 0-9 and spaces <b>only</b>):&nbsp;&nbsp;");
            out.println("<input type=\"text\" name=\"event_name\" size=\"30\" maxlength=\"30\"></nobr>");
            out.println("<br>&nbsp;&nbsp;&nbsp;* Must be unique");
         out.println("<br><br>");
         
           out.println("Season Long Event?&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"season\" onchange=\"toggleSeason(this.selectedIndex)\">");
             out.println("<option value=\"0\">No</option>");
             out.println("<option value=\"1\">Yes</option>");
           out.println("</select>");
           
         out.println("<br><br>");
         
         //
         //  If multiple courses, then add a drop-down box for course names
         //
         if (multi != 0) {           // if multiple courses supported for this club

            out.println("&nbsp;&nbsp;Course:&nbsp;&nbsp;");
            out.println("<select size=\"1\" name=\"course\">");
            out.println("<option selected value=\"-ALL-\">ALL</option>");

            index = 0;
            courseName = course[index];      // get first course name from array

            while ((!courseName.equals( "" )) && (index < 20)) {

               out.println("<option value=\"" + courseName + "\">" + courseName + "</option>");
               index++;
               courseName = course[index];      // get course name from array
            }
            out.println("</select>");
            out.println("<br><br>");

         } else {
            out.println("<input type=\"hidden\" name=\"course\" value=\"\">");
         }
         
        out.println("<div id=\"season_data\" style=\"height: auto; width: auto\">");

         out.println("&nbsp;&nbsp;Tees:&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"fb\">");
             out.println("<option value=\"Both\">Both</option>");
             out.println("<option value=\"Front\">Front</option>");
             out.println("<option value=\"Back\">Back</option>");
           out.println("</select>");
         out.println("<br><br>"); 
         
         out.println("Date of Event:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
           out.println("Month:&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"month\">");
              dateOpts.opMonth(out, thisMonth);         // output the month options
           out.println("</select>");
             
           out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"day\">");
              dateOpts.opDay(out, thisDay);         // output the day options
           out.println("</select>");
             
           out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"year\">");
              dateOpts.opYear(out, thisYear);         // output the year options
           out.println("</select>");
             
         out.println("<br><br>");
         
         out.println("Time to Start Blocking Tees:&nbsp;&nbsp;&nbsp; hr &nbsp;");
           out.println("<select size=\"1\" name=\"start_hr\">");
           for (tmp=1; tmp <= 12; tmp++) {
               Common_Config.buildOption(tmp, SystemUtils.ensureDoubleDigit(tmp), 0, out);
           }
           out.println("</select>");
           out.println("&nbsp; min &nbsp;");
           out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"start_min\">");
           out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"start_ampm\">");
             out.println("<option value=\"00\">AM</option>");
             out.println("<option value=\"12\">PM</option>");
           out.println("</select>");
         out.println("<br><br>");
         
         out.println("Time to Stop Blocking Tees:&nbsp;&nbsp;&nbsp; hr &nbsp;");
           out.println("<select size=\"1\" name=\"end_hr\">");
           for (tmp=1; tmp <= 12; tmp++) {
               Common_Config.buildOption(tmp, SystemUtils.ensureDoubleDigit(tmp), 0, out);
           }
           out.println("</select>");                         
           out.println("&nbsp; min &nbsp;");
           out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"end_min\">");
           out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"end_ampm\">");
             out.println("<option value=\"00\">AM</option>");
             out.println("<option value=\"12\">PM</option>");
           out.println("</select>");
         out.println("<br><br>");
         
         out.println("Actual Start Time of Event:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;");
           out.println("<select size=\"1\" name=\"act_hr\">");
           for (tmp=1; tmp <= 12; tmp++) {
               Common_Config.buildOption(tmp, SystemUtils.ensureDoubleDigit(tmp), 0, out);
           }
           out.println("</select>");
           out.println("&nbsp; min &nbsp;");
           out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"act_min\">");
           out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"act_ampm\">");
             out.println("<option value=\"00\">AM</option>");
             out.println("<option value=\"12\">PM</option>");
           out.println("</select>");
         out.println("<br><br>");
         out.println("<hr width=\"400\"><br>");             // separate with bar
         
           out.println("Optional 2nd Set of Tee Times to Block (e.g. for cross-overs)<br><br>");
         out.println("&nbsp;&nbsp;Tees:&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"fb2\">");
             out.println("<option value=\"Both\">Both</option>");
             out.println("<option value=\"Front\">Front</option>");
             out.println("<option value=\"Back\">Back</option>");
           out.println("</select>");
         out.println("<br><br>");
         out.println("Time to Start Blocking Tees:&nbsp;&nbsp;&nbsp; hr &nbsp;");
           out.println("<select size=\"1\" name=\"start_hr2\">");
           for (tmp=1; tmp <= 12; tmp++) {
               Common_Config.buildOption(tmp, SystemUtils.ensureDoubleDigit(tmp), 0, out);
           }
           out.println("</select>");
           out.println("&nbsp; min &nbsp;");
           out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"start_min2\">");
           out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"start_ampm2\">");
             out.println("<option value=\"00\">AM</option>");
             out.println("<option value=\"12\">PM</option>");
           out.println("</select>");
         out.println("<br><br>");
         out.println("Time to Stop Blocking Tees:&nbsp;&nbsp;&nbsp; hr &nbsp;");
           out.println("<select size=\"1\" name=\"end_hr2\">");
           for (tmp=1; tmp <= 12; tmp++) {
               Common_Config.buildOption(tmp, SystemUtils.ensureDoubleDigit(tmp), 0, out);
           }
           out.println("</select>");
           out.println("&nbsp; min &nbsp;");
           out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"end_min2\">");
           out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"end_ampm2\">");
             out.println("<option value=\"00\">AM</option>");
             out.println("<option value=\"12\">PM</option>");
           out.println("</select>");
            
         out.println("<br><br><hr width=\"400\"><br>");

           out.println("Shotgun Event?&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"type\">");
             out.println("<option value=\"00\">No</option>");
             out.println("<option value=\"01\">Yes</option>");
           out.println("</select>");
         out.println("<br><br>");
         
         out.println("</div>");
         
           out.println("Number of holes to be played:&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"holes\">");
             out.println("<option value=\"18\">18</option>");
             out.println("<option value=\"09\">9</option>");
             out.println("<option value=\"27\">27</option>");
             out.println("<option value=\"36\">36</option>");
             out.println("<option value=\"45\">45</option>");
             out.println("<option value=\"54\">54</option>");
           out.println("</select>");
         out.println("<br><br>");
           out.println("Guest Only Event (Outside Event)?&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"gstOnly\">");
             out.println("<option value=\"No\">No</option>");
             out.println("<option value=\"Yes\">Yes</option>");
           out.println("</select>");
           out.println("<br><br>");
           out.println("Gender Based Event?&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"gender\">");
             //out.println("<option value=-1>Choose...</option>");
             out.println("<option value=\"1\">" + Labels.gender_opts[1] + "</option>");
             out.println("<option value=\"2\">" + Labels.gender_opts[2] + "</option>");
             out.println("<option value=\"3\">" + Labels.gender_opts[3] + "</option>");
           out.println("</select>");
           out.println("<br><br>");
         out.println("Color to make this event on the tee sheet:&nbsp;&nbsp;");
           
         Common_Config.displayColors(out);       // output the color options
           
           out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
           out.println("<a href=\"/" +rev+ "/proshop_color.htm\" target=\"_blank\">View Colors</a>");
           out.println("<br><br>");
           out.println("Itinerary: (Optional explaination of event - double quotes not allowed)<br>");
           out.println("<textarea name=\"itin\" value=\"\" id=\"itin\" cols=\"55\" rows=\"5\"></textarea>");
           //out.println("<br>Optional. Double quotes not allowed.");
           out.println("<br><br>");
           out.println("Allow Members to Sign Up Online?&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"signUp\">");
             out.println("<option value=\"No\">No</option>");
             out.println("<option value=\"Yes\">Yes</option>");
           out.println("</select>");
           out.println("<br>(Multiple day events - select 'No' if not 1st day. Guest only event - select 'No'.)");
           out.println("<br><br>");
           
           out.println("If you wish to receive an email notification of all signups/modifications/cancelations<br>");
           out.println("provide up to two email address in the boxes below.<br><br>");
            out.println("&nbsp;&nbsp;Email #1: <input type=text name=email1 size=40 maxlength=50><br><br>");
            out.println("&nbsp;&nbsp;Email #2: <input type=text name=email2 size=40 maxlength=50>");
           
           out.println("<br><br>");
           
           //out.println("If you wish to export this event to an external program, select it from the list below:");
           out.println("Export Type:&nbsp;&nbsp;&nbsp;");
           out.println("<select size=\"1\" name=\"export_type\">");
             out.println("<option value=\"0\">None</option>");
             out.println("<option value=\"1\">TPP</option>");
             out.println("<option value=\"2\">EventMan</option>");
           out.println("</select>");
           
         out.println("<p align=\"center\">");
           out.println("<input type=\"submit\" value=\"Continue\">");
           out.println("</p>");
         out.println("</font>");
      out.println("</td>");
   out.println("</tr>");
   out.println("</form>");
   out.println("</table>");
   out.println("<font size=\"2\"><br>");
   out.println("<table border=\"1\" cellpadding=\"5\" bgcolor=\"#F5F5DC\">");
   out.println("<tr><td align=\"center\">");
      out.println("<font size=\"2\"><b>Note:</b>&nbsp;&nbsp;Adding an event will block all members from the tee times within the timeframe specified here.<br>");
       out.println("Only proshop personnel will be allowed to update these tee times.<br>");
       out.println("If the event spans more than 1 day, add 1 event per day and use unique names <br>");
       out.println("(i.e. 'Couples Best Ball Day 1' and 'Couples Best Ball Day 2').");
   out.println("</font></td></tr></table><br>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_events\">");
   out.println("<input type=\"submit\" value=\"Done\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</form></font>");
   out.println("</center>");
   out.println("</font>");
   
    out.println("<script type=\"text/javascript\">");
    out.println("function toggleSeason(id) {");
    //out.println(" alert('id='+id);");
    out.println(" var b = (id == 0);");
    out.println(" document.getElementById('season_data').style.display = ((b) ? 'block' : 'none');");
    out.println(" document.getElementById('season_data').style.visibility = ((b) ? 'visible' : 'hidden');");
    out.println(" document.getElementById('season_data').style.height = ((b) ? 'auto' : '0px');");
/*    out.println(" var f = document.forms['f'];");
    out.println(" f.month.disabled = b;");
    out.println(" f.day.disabled = b;");
    out.println(" f.year.disabled = b;");
    out.println(" f.start_hr.disabled = b;");
    out.println(" f.start_min.disabled = b;");
    out.println(" f.start_ampm.disabled = b;");
    out.println(" f.end_hr.disabled = b;");
    out.println(" f.end_min.disabled = b;");
    out.println(" f.end_ampm.disabled = b;");
    out.println(" f.act_hr.disabled = b;");
    out.println(" f.act_min.disabled = b;");
    out.println(" f.act_ampm.disabled = b;");
    out.println(" f.fb2.disabled = b;");
    out.println(" f.start_hr2.disabled = b;");
    out.println(" f.start_min2.disabled = b;");
    out.println(" f.start_ampm2.disabled = b;");
    out.println(" f.end_hr2.disabled = b;");
    out.println(" f.end_min2.disabled = b;");
    out.println(" f.end_ampm2.disabled = b;"); */
    out.println("}");
    
    out.println("toggleSeason(document.forms['f'].season.selectedIndex)");
    
    out.println("</script>");

   out.println("</body>");
   out.println("</html>");
   out.close();

 }     // end of doGet processing


 //****************************************************
 // Process the form request from doGet above
 //****************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   PreparedStatement pstmt = null; 
   Statement stmtc = null;
   ResultSet rs = null;
   String omit = "";

   HttpSession session = SystemUtils.verifyPro(req, out);   // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_announce\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   String format = "";
   String pairings = "";
   String ssize = "";
   String sminsize = "";
   String smax = "";
   String sguests = "";
   String memcost = "";
   String gstcost = "";
   String ssu_month = "";
   String ssu_day = "";
   String ssu_year = "";
   String ssu_hr = "";
   String ssu_min = "";
   String su_ampm = "";
   String sc_month = "";
   String sc_day = "";
   String sc_year = "";
   String sc_hr = "";
   String sc_min = "";
   String c_ampm = "";
   String posType = "";
   String sx = "";
   String sxhrs = "";
   String mempos = "";
   String gstpos = "";
   String copyname = "";

   String [] tmode = new String [16];                       // Modes of trans 

   int [] tmodei = new int [16];                            // Modes of trans indicators

   int i = 0;
   int i2 = 0;
   int month = 0;
   int day = 0;
   int s_hr = 0;
   int s_min = 0;
   int s_ampm = 0;
   int e_hr = 0;
   int e_min = 0;
   int e_ampm = 0;
   int s_hr2 = 0;
   int s_min2 = 0;
   int s_ampm2 = 0;
   int e_hr2 = 0;
   int e_min2 = 0;
   int e_ampm2 = 0;
   int a_hr = 0;
   int a_min = 0;
   int a_ampm = 0;
   int year = 0;
   int type = 0;
   int signUp = 0;
   int size = 0;
   int minsize = 0;
   int max = 0;
   int guests = 0;
   int holes = 0;
   int x = 0;
   int xhrs = 0;
   int gstOnly = 0;
   int gender = 0;
   int c_month = 0;
   int c_day = 0;
   int c_year = 0;
   int c_hr = 0;
   int c_min = 0;
   int c_time = 0;
   int su_month = 0;
   int su_day = 0;
   int su_year = 0;
   int su_hr = 0;
   int su_min = 0;
   int su_time = 0;
   int itinL = 0;
   int export_type = 0;
   int season = 0;
   long c_date = 0;
   long su_date = 0;

   boolean copy = false;

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();                          // allocate a parm block

   String [] mship = new String [parm.MAX_Mems+1];            // Mem Types
   String [] mtype = new String [parm.MAX_Mships+1];          // Mship Types

   if (req.getParameter("copy") != null) {

      copy = true;            // this is a copy request (from doCopy in _events)
   }
   if (req.getParameter("copyname") != null) {

      copyname = req.getParameter("copyname");           //  name of event being copied
   }

   //
   // Get all the parameters entered
   //
   String name = req.getParameter("event_name");           //  new event name  
   String course = req.getParameter("course");             //  course name
   String fb = req.getParameter("fb");                     //  Front/Back/Both tees
   String s_month = req.getParameter("month");             //  month (00 - 12)
   String s_day = req.getParameter("day");                 //  day (01 - 31)
   String s_year = req.getParameter("year");               //  year (2004 - 20xx)
   String start_hr = req.getParameter("start_hr");         //  start hour (01 - 12)
   String start_min = req.getParameter("start_min");       //  start min (00 - 59)
   String start_ampm = req.getParameter("start_ampm");     //  AM/PM (00 or 12)
   String end_hr = req.getParameter("end_hr");             //   .
   String end_min = req.getParameter("end_min");           //   .
   String end_ampm = req.getParameter("end_ampm");         //   .
   String act_hr = req.getParameter("act_hr");             //   .
   String act_min = req.getParameter("act_min");           //   .
   String act_ampm = req.getParameter("act_ampm");         //   .
   String fb2 = req.getParameter("fb2");                   //  Front/Back/Both tees #2
   String start_hr2 = req.getParameter("start_hr2");       //  start hour (01 - 12)
   String start_min2 = req.getParameter("start_min2");     //  start min (00 - 59)
   String start_ampm2 = req.getParameter("start_ampm2");   //  AM/PM (00 or 12)
   String end_hr2 = req.getParameter("end_hr2");           //   .
   String end_min2 = req.getParameter("end_min2");         //   .
   String end_ampm2 = req.getParameter("end_ampm2");       //   .
   String stype = req.getParameter("type");                //  type of event (shotgun?)
   String sholes = req.getParameter("holes");              //  number of holes to play
   String color = req.getParameter("color");               //  color for the event display
   String ssignUp = req.getParameter("signUp");            //  allow members to sign up online
   String guestOnly = req.getParameter("gstOnly");
   String sgender = req.getParameter("gender");
   String itin = req.getParameter("itin");
   String sseason = req.getParameter("season");
   String email1 = req.getParameter("email1");
   String email2 = req.getParameter("email2");
   String sexport_type = req.getParameter("export_type");

   //
   //  Get today's date
   //
   Calendar cal = new GregorianCalendar();       // get todays date
   int thisYear = cal.get(Calendar.YEAR);        // get the year
   int thisMonth = cal.get(Calendar.MONTH) +1;
   int thisDay = cal.get(Calendar.DAY_OF_MONTH);


   if (req.getParameter("page2") != null) {                // if member signup selected and 2nd page of options

      format = req.getParameter("format");
      pairings = req.getParameter("pairings");
      ssize = req.getParameter("size");
      sminsize = req.getParameter("minsize");
      smax = req.getParameter("max");
      sguests = req.getParameter("guests");
      sx = req.getParameter("x");
      sxhrs = req.getParameter("xhrs");
      memcost = req.getParameter("memcost");
      gstcost = req.getParameter("gstcost");
      ssu_month = req.getParameter("su_month");
      ssu_day = req.getParameter("su_day");
      ssu_year = req.getParameter("su_year");
      ssu_hr = req.getParameter("su_hr");
      ssu_min = req.getParameter("su_min");
      su_ampm = req.getParameter("su_ampm");
      sc_month = req.getParameter("c_month");
      sc_day = req.getParameter("c_day");
      sc_year = req.getParameter("c_year");
      sc_hr = req.getParameter("c_hr");
      sc_min = req.getParameter("c_min");
      c_ampm = req.getParameter("c_ampm");

      if (req.getParameter("mempos") != null) {   // if member POS charge code specified

         mempos = req.getParameter("mempos");
      }
      if (req.getParameter("gstpos") != null) {   // if guest POS charge code specified

         gstpos = req.getParameter("gstpos");
      }
      if (req.getParameter("tmode1") != null) {   

         tmodei[0] = 1;
      } else {
         tmodei[0] = 0;
      }
      if (req.getParameter("tmode2") != null) {

         tmodei[1] = 1;
      } else {
         tmodei[1] = 0;
      }
      if (req.getParameter("tmode3") != null) {

         tmodei[2] = 1;
      } else {
         tmodei[2] = 0;
      }
      if (req.getParameter("tmode4") != null) {

         tmodei[3] = 1;
      } else {
         tmodei[3] = 0;
      }
      if (req.getParameter("tmode5") != null) {

         tmodei[4] = 1;
      } else {
         tmodei[4] = 0;
      }
      if (req.getParameter("tmode6") != null) {

         tmodei[5] = 1;
      } else {
         tmodei[5] = 0;
      }
      if (req.getParameter("tmode7") != null) {

         tmodei[6] = 1;
      } else {
         tmodei[6] = 0;
      }
      if (req.getParameter("tmode8") != null) {

         tmodei[7] = 1;
      } else {
         tmodei[7] = 0;
      }
      if (req.getParameter("tmode9") != null) {

         tmodei[8] = 1;
      } else {
         tmodei[8] = 0;
      }
      if (req.getParameter("tmode10") != null) {

         tmodei[9] = 1;
      } else {
         tmodei[9] = 0;
      }
      if (req.getParameter("tmode11") != null) {

         tmodei[10] = 1;
      } else {
         tmodei[10] = 0;
      }
      if (req.getParameter("tmode12") != null) {

         tmodei[11] = 1;
      } else {
         tmodei[11] = 0;
      }
      if (req.getParameter("tmode13") != null) {

         tmodei[12] = 1;
      } else {
         tmodei[12] = 0;
      }
      if (req.getParameter("tmode14") != null) {

         tmodei[13] = 1;
      } else {
         tmodei[13] = 0;
      }
      if (req.getParameter("tmode15") != null) {

         tmodei[14] = 1;
      } else {
         tmodei[14] = 0;
      }
      if (req.getParameter("tmode16") != null) {

         tmodei[15] = 1;
      } else {
         tmodei[15] = 0;
      }
        
      for (i=1; i<parm.MAX_Mems+1; i++) {
         mtype[i] = "";
         if (req.getParameter("mem" +i) != null) {

            mtype[i] = req.getParameter("mem" +i);
         }
      }

      for (i=1; i<parm.MAX_Mships+1; i++) {
         mship[i] = "";
         if (req.getParameter("mship" +i) != null) {

            mship[i] = req.getParameter("mship" +i);
         }
      }

      i = 0;
   }

   //
   // Convert the numeric string parameters to Int's
   //
   try {
      month = Integer.parseInt(s_month);
      day = Integer.parseInt(s_day);
      year = Integer.parseInt(s_year);
      s_hr = Integer.parseInt(start_hr);
      s_min = Integer.parseInt(start_min);
      s_ampm = Integer.parseInt(start_ampm);
      e_hr = Integer.parseInt(end_hr);
      e_min = Integer.parseInt(end_min);
      e_ampm = Integer.parseInt(end_ampm);
      s_hr2 = Integer.parseInt(start_hr2);
      s_min2 = Integer.parseInt(start_min2);
      s_ampm2 = Integer.parseInt(start_ampm2);
      e_hr2 = Integer.parseInt(end_hr2);
      e_min2 = Integer.parseInt(end_min2);
      e_ampm2 = Integer.parseInt(end_ampm2);
      a_hr = Integer.parseInt(act_hr);
      a_min = Integer.parseInt(act_min);
      a_ampm = Integer.parseInt(act_ampm);
      type = Integer.parseInt(stype);
      holes = Integer.parseInt(sholes);
      export_type = Integer.parseInt(sexport_type);

      if (ssignUp.equals( "Yes" )) {

         signUp = 1;
      }
      if (!ssize.equals( "" )) {

         size = Integer.parseInt(ssize);
      }
      if (!sminsize.equals( "" )) {

         minsize = Integer.parseInt(sminsize);
      }
      if (!smax.equals( "" )) {

         max = Integer.parseInt(smax);
      }
      if (!sguests.equals( "" )) {

         guests = Integer.parseInt(sguests);
      }
      if (!sx.equals( "" )) {

         x = Integer.parseInt(sx);
      }
      if (!sxhrs.equals( "" )) {

         xhrs = Integer.parseInt(sxhrs);
      }
      if (!ssu_month.equals( "" )) {

         su_month = Integer.parseInt(ssu_month);
      }
      if (!ssu_day.equals( "" )) {

         su_day = Integer.parseInt(ssu_day);
      }
      if (!ssu_year.equals( "" )) {

         su_year = Integer.parseInt(ssu_year);
      }
      if (!ssu_hr.equals( "" )) {

         su_hr = Integer.parseInt(ssu_hr);
      }
      if (!ssu_min.equals( "" )) {

         su_min = Integer.parseInt(ssu_min);
      }
      if (!sc_month.equals( "" )) {

         c_month = Integer.parseInt(sc_month);
      }
      if (!sc_day.equals( "" )) {

         c_day = Integer.parseInt(sc_day);
      }
      if (!sc_year.equals( "" )) {

         c_year = Integer.parseInt(sc_year);
      }
      if (!sc_hr.equals( "" )) {

         c_hr = Integer.parseInt(sc_hr);
      }
      if (!sc_min.equals( "" )) {

         c_min = Integer.parseInt(sc_min);
      }
      if (!sgender.equals( "" )) {

         gender = Integer.parseInt(sgender);
      }
      
      if (sseason.equals( "1" )) { season = 1; } 
      
   }
   catch (NumberFormatException e) {

      out.println(SystemUtils.HeadTitle("Database Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Data Input Error</H3>");
      out.println("<BR><BR>Sorry, we are unable to process one or more of the parameters entered.");
      out.println("<BR>Please go back and make sure all values are correct.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR>Exception:   " + e.getMessage());
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }
     
   if (guestOnly.equals( "Yes" )) {

      gstOnly = 1;
   }
/*     
   //
   //  Get the length of Itin (max length of 255 chars)
   //
   if (!itin.equals( "" )) {

      itinL = itin.length();       // get length of itin
   }
*/
   //
   //  verify the required fields (name reqr'ed)
   //
   if (name.equals( omit )) {

      invData(out);    // inform the user and return
      return;
   }

   //
   //  Event names cannot include special chars 
   //
   boolean error = SystemUtils.scanName(name);           // check for special characters

   if (error == true) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>Special characters cannot be part of the Event Name.");
      out.println("<BR>You can only use the characters A-Z, a-z, 0-9 and space.");
      out.println("<BR>You entered:" + name);
      out.println("<BR>Please try again.");
      out.println("<br><br><font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }
   
   //
   //  Validate minute values
   //
   if ((s_min < 0) || (s_min > 59)) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>Start Minute parameter must be in the range of 00 - 59.");
      out.println("<BR>You entered:" + s_min);
      out.println("<BR>Please try again.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   if ((e_min < 0) || (e_min > 59)) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>End Minute parameter must be in the range of 00 - 59.");
      out.println("<BR>You entered:" + e_min);
      out.println("<BR>Please try again.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   if ((a_min < 0) || (a_min > 59)) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>Actual Minute parameter must be in the range of 00 - 59.");
      out.println("<BR>You entered:" + e_min);
      out.println("<BR>Please try again.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   if (holes < 9) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>The Number of Holes for the event must be at least 9.");
      out.println("<BR>You entered:" + holes);
      out.println("<BR>Please try again.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   //
   //  adjust some values for the table
   //
   long date = year * 10000;      // create event date
   date = date + (month * 100);
   date = date + day;             // date = yyyymmdd (for comparisons)

   if (s_hr != 12) {              // _hr specified as 01 - 12 (_ampm = 00 or 12)
      s_hr = s_hr + s_ampm;       // convert to military time (12 is always Noon or PM)
   }
   if (e_hr != 12) {              // ditto
      e_hr = e_hr + e_ampm;
   }
   if (a_hr != 12) {              // ditto
      a_hr = a_hr + a_ampm;
   }

   int stime = s_hr * 100;
   stime = stime + s_min;
   int etime = e_hr * 100;
   etime = etime + e_min;
   int atime = a_hr * 100;
   atime = atime + a_min;

   if (s_hr2 != 12) {              // _hr specified as 01 - 12 (_ampm = 00 or 12)
      s_hr2 = s_hr2 + s_ampm2;       // convert to military time (12 is always Noon or PM)
   }
   if (e_hr2 != 12) {              // ditto
      e_hr2 = e_hr2 + e_ampm2;
   }

   int stime2 = s_hr2 * 100;
   stime2 = stime2 + s_min2;
   int etime2 = e_hr2 * 100;
   etime2 = etime2 + e_min2;

   // if not a season long event, then verify the dates & times passed
   if (season == 0) {

       //
       //  verify that the start time is less than the end time
       //
       if (stime >= etime) {

          invData(out);    // inform the user and return
          return;
       }

       //
       //  verify that the actual start time is greater than start time and  less than the end time
       //
       if ((atime < stime) || (atime >= etime)) {

          invData(out);    // inform the user and return
          return;
       }

       //
       //  verify that the 2nd start time is less than the 2nd end time (if specified - this is optional)
       //
       if (stime2 != etime2) {

          if (stime2 > etime2) {

             out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
             out.println("<BODY><CENTER><BR>");
             out.println("<p>&nbsp;</p>");
             out.println("<BR><H3>Input Error</H3><BR>");
             out.println("<BR><BR>Sorry, the times specified for the 2nd Set of Blockers are invalid.<BR>");
             out.println("The start time cannot be greater than the end time.<BR>");
             out.println("<BR>Please try again.<BR>");
             out.println("<BR><BR>");
             out.println("<font size=\"2\">");
             out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
             out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
             out.println("</form></font>");
             out.println("</CENTER></BODY></HTML>");
             out.close();
             return;
          }
       }
       
   } // end if not season long event
   
   //
   //  If Members can sign up, then check if guest-only was specified
   //
   if (signUp != 0) {

      if (gstOnly != 0) {
        
         out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
         out.println("<BODY><CENTER><BR>");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H3>Input Error</H3><BR>");
         out.println("<BR><BR>You have specified 'Guest Only' and 'Allow Members to Sign Up'.<BR>");
         out.println("You cannot specify both of these options for the same event.<BR>");
         out.println("<BR>Please try again.<BR>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }
   }

   //
   //  If Members can sign up and this is page2 being submitted, then check some fields
   //
   if (signUp != 0 && req.getParameter("page2") != null) {

      //
      // check for at least one mode of trans
      //
      boolean some = false;
         
      for (i=0; i<16; i++) {
        
         if (tmodei[i] == 1) {
            
            some = true;
         }
      }
        
      if (some == false) {    // if no modes specified

         out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
         out.println("<BODY><CENTER><BR>");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H3>Input Error</H3><BR>");
         out.println("<BR><BR>You have specified 'Allow Members to Sign Up' but did not specify<BR>");
         out.println("any transportation modes.  You must specify at least one transportation mode.<BR>");
         out.println("<BR>Please try again.<BR>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }

      if (max == 0 || max > 999) {

         out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
         out.println("<BODY><CENTER><BR>");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H3>Input Error</H3><BR>");
         out.println("<BR><BR>Sorry, the Max Number of Teams value is invalid.<BR>");
         out.println("It must be in the range of 1 - 999.<BR>");
         out.println("<BR>Please try again.<BR>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }
        
      if (su_min > 59) {

         out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
         out.println("<BODY><CENTER><BR>");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H3>Input Error</H3><BR>");
         out.println("<BR><BR>Sorry, the Minute value for the Sign-up Time is invalid.<BR>");
         out.println("It cannot be greater than 59.<BR>");
         out.println("<BR>Please try again.<BR>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }
        
      if (c_min > 59) {

         out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
         out.println("<BODY><CENTER><BR>");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H3>Input Error</H3><BR>");
         out.println("<BR><BR>Sorry, the Minute value for the cut-off Time is invalid.<BR>");
         out.println("It cannot be greater than 59.<BR>");
         out.println("<BR>Please try again.<BR>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }

      //
      //  adjust some values for the table
      //
      su_date = su_year * 10000;             // create a date field from input values
      su_date = su_date + (su_month * 100);
      su_date = su_date + su_day;             // date = yyyymmdd (for comparisons)

      if ((su_hr != 12) && (su_ampm.equals( "PM" ))) {   // _hr specified as 01 - 12

         su_hr = su_hr + 12;                             // convert to military time (12 is always Noon or PM)
      }

      if ((su_hr == 12) && (su_ampm.equals( "AM" ))) {   // _hr specified as 01 - 12

         su_hr = 0;                                     // midnight is 00:00
      }

      su_time = su_hr * 100;
      su_time = su_time + su_min;

      c_date = c_year * 10000;             // create a date field from input values
      c_date = c_date + (c_month * 100);
      c_date = c_date + c_day;             // date = yyyymmdd (for comparisons)

      if ((c_hr != 12) && (c_ampm.equals( "PM" ))) {   // _hr specified as 01 - 12

         c_hr = c_hr + 12;                             // convert to military time (12 is always Noon or PM)
      }

      if ((c_hr == 12) && (c_ampm.equals( "AM" ))) {   // _hr specified as 01 - 12

         c_hr = 0;                                     // midnight is 00:00
      }

      c_time = c_hr * 100;
      c_time = c_time + c_min;

      //
      //  verify that the signup cut-off date is earlier than the events date (skip for season long events)
      //
      if (c_date > date && season == 0) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<BODY><CENTER>");
         out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
         out.println("<BR><BR>The Sign Up Cut-off date cannot be later than the Event date.");
         out.println("<BR>Please try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }

      //
      //  verify that the signup cut-off date is later than the start sign-up date
      //
      if (c_date < su_date) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<BODY><CENTER>");
         out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
         out.println("<BR><BR>The Cut-Off date cannot be earlier than the Sign-Up date.");
         out.println("<BR>Please try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }
      
      //
      //  Validate minimum team size
      //
      if (minsize > size) {

          out.println(SystemUtils.HeadTitle("Data Entry Error"));
          out.println("<BODY><CENTER>");
          out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
          out.println("<BR><BR>The minimum team size is larger then the team size.");
          out.println("<BR>You entered a team size of " + size + " and a minimum sign-up size of " + minsize + ".");
          out.println("<BR>Please try again.");
          out.println("<br><br><font size=\"2\">");
          out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
          out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
          out.println("</form></font>");
          out.println("</CENTER></BODY></HTML>");
          return;
      }
   }
        
   try {

      if (req.getParameter("page2") == null) {   // if first time here (page 1)

         //
         //  Check if event already exists in database
         //
         PreparedStatement stmt = con.prepareStatement (
                 "SELECT date FROM events2b WHERE name = ?");

         stmt.clearParameters();        // clear the parms
         stmt.setString(1, name);       // put the parm in stmt
         rs = stmt.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            dupMem(out);    // member exists - inform the user and return
            stmt.close();
            return;
         }
         stmt.close();

         //
         //  add event data to the database
         //
         pstmt = con.prepareStatement (
           "INSERT INTO events2b (name, date, year, month, day, start_hr, start_min, " +
           "stime, end_hr, end_min, etime, color, type, act_hr, act_min, courseName, signUp, " +
           "format, pairings, size, max, guests, memcost, gstcost, c_month, c_day, c_year, c_hr, c_min, " +
           "c_date, c_time, itin, mc, pc, wa, ca, gstOnly, x, xhrs, holes, su_month, su_day, su_year, " +
           "su_hr, su_min, su_date, su_time, fb, mempos, gstpos, tmode1, tmode2, tmode3, tmode4, tmode5, tmode6, " +
           "tmode7, tmode8, tmode9, tmode10, tmode11, tmode12, tmode13, tmode14, tmode15, tmode16, " +
           "stime2, etime2, fb2, gender, season, export_type, email1, email2, " +
           "mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
           "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
           "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24, " +
           "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
           "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
           "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24) " +
           "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'','',0,0,0,'','',0,0,0,0,0,0,0,?,0,0,0,0,?,0,0,?,0,0,0,0,0,0,0,?, " +
           "'','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,?,?,?,?,?,?,?,?, " +
           "'','','','','','','','','','','','','','','','','','','','','','','',''," +
           "'','','','','','','','','','','','','','','','','','','','','','','','')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, name);       // put the parm in pstmt
         pstmt.setLong(2, date);
         pstmt.setInt(3, year);
         pstmt.setInt(4, month);
         pstmt.setInt(5, day);
         pstmt.setInt(6, s_hr);
         pstmt.setInt(7, s_min);
         pstmt.setInt(8, stime);
         pstmt.setInt(9, e_hr);
         pstmt.setInt(10, e_min);
         pstmt.setInt(11, etime);
         pstmt.setString(12, color);
         pstmt.setInt(13, type);
         pstmt.setInt(14, a_hr);
         pstmt.setInt(15, a_min);
         pstmt.setString(16, course);
         pstmt.setInt(17, signUp);
         pstmt.setString(18, itin);
         pstmt.setInt(19, gstOnly);
         pstmt.setInt(20, holes);
         pstmt.setString(21, fb);
         pstmt.setInt(22, stime2);
         pstmt.setInt(23, etime2);
         pstmt.setString(24, fb2);
         pstmt.setInt(25, gender);
         pstmt.setInt(26, season);
         pstmt.setInt(27, export_type);
         pstmt.setString(28, email1);
         pstmt.setString(29, email2);
         pstmt.executeUpdate();          // execute the prepared stmt

         pstmt.close();   // close the stmt
      
         //
         //  If member signup was specified, then prompt for page2 of options
         //
         if (signUp != 0) {  

            //
            //  If we got here from a Copy request, go to Proshop_editevnt to do the 2nd page
            //
            if (!copyname.equals( "" )) {

               out.println("<script type=\"text/javascript\">");
               out.println("document.location.href='/" +rev+ "/servlet/Proshop_editevnt?signUp=yes&Continue=yes&name=" +name+ "&course=" +course+ "&copyname=" +copyname+ "'");
               out.println("</script>");
               return;
            }

            //
            // Get the 'POS Type' option from the club db, if specified
            //
            try {

               stmtc = con.createStatement();        // create a statement

               rs = stmtc.executeQuery("SELECT posType " +
                                      "FROM club5 WHERE clubName != ''");

               if (rs.next()) {

                  posType = rs.getString(1);

               }
               stmtc.close();

               //
               //  Get the Modes of Trans for the course specified
               //
               PreparedStatement pstmtc = null;

               if (course.equals( "-ALL-" )) {

                  pstmtc = con.prepareStatement (
                     "SELECT * FROM clubparm2");        // get the first course's parms

                  pstmtc.clearParameters();

               } else {

                  pstmtc = con.prepareStatement (
                     "SELECT * " +
                     "FROM clubparm2 WHERE courseName = ?");

                  pstmtc.clearParameters();        // clear the parms
                  pstmtc.setString(1, course);
               }

               rs = pstmtc.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  tmode[0] = rs.getString("tmode1");
                  tmode[1] = rs.getString("tmode2");
                  tmode[2] = rs.getString("tmode3");
                  tmode[3] = rs.getString("tmode4");
                  tmode[4] = rs.getString("tmode5");
                  tmode[5] = rs.getString("tmode6");
                  tmode[6] = rs.getString("tmode7");
                  tmode[7] = rs.getString("tmode8");
                  tmode[8] = rs.getString("tmode9");
                  tmode[9] = rs.getString("tmode10");
                  tmode[10] = rs.getString("tmode11");
                  tmode[11] = rs.getString("tmode12");
                  tmode[12] = rs.getString("tmode13");
                  tmode[13] = rs.getString("tmode14");
                  tmode[14] = rs.getString("tmode15");
                  tmode[15] = rs.getString("tmode16");
               }
               pstmtc.close();

               //
               // Get the Mem and Mship Types from the club db
               //
               getClub.getParms(con, parm);        // get the club parms

            }
            catch (Exception ignore) {
            }

            //
            //  Build the HTML page to prompt user for the info
            //
            out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">");
            out.println("<html>");
            out.println("<HEAD><link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
               out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
               out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
               out.println("<title> \"ForeTees Proshop Add Special Event Main\"</title>");
               out.println("<script>");
               out.println("<!--");
               out.println("function cursor(){document.f.format.focus();}");
               out.println("// -->");
               out.println("</script>");
            out.println("</head>");

            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" onLoad=cursor()>");
            SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
            out.println("<font face=\"Arial, Helvetica, sans-serif\">");
            out.println("<center>");
            out.println("<table border=\"1\" bgcolor=\"#336633\" cellpadding=\"5\" align=\"center\">");
            out.println("<tr><td align=\"center\">");
            out.println("<font color=\"#FFFFFF\" size=\"3\">");
               out.println("<b>Special Events</b><br>");
            out.println("</font><font color=\"#FFFFFF\" size=\"2\">");
               out.println("Complete the following information for the Member Signup.<br>");
               out.println("Click on <b>Continue</b> to add this information to the event.");
            out.println("</font></td></tr></table><br>");
            out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"8\" align=\"center\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_addevnt\" method=\"post\" target=\"bot\" name=\"f\">");
               out.println("<tr>");
               out.println("<td width=\"530\">");
                  out.println("<font size=\"2\">");
                    out.println("<b>Complete the following ONLY if you selected Yes for members to sign up online:</b>");
                    out.println("<br> (This information will be used to define the event for member sign up.)");
                    out.println("<br><br>");
                  out.println("Event Format:&nbsp;&nbsp;");
                     out.println("<input type=\"text\" name=\"format\" size=\"40\" maxlength=\"60\">");
                     out.println("");
                  out.println("<br><br>");
                    out.println("Who Makes the Teams:&nbsp;&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"pairings\">");
                      out.println("<option value=\"ProShop\">Golf Shop</option>");
                      out.println("<option value=\"Member\">Member</option>");
                    out.println("</select>");
                    out.println("<br><br>");
                    out.println("Team Size (if Members Make Their Own Teams):&nbsp;&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"size\">");
                      out.println("<option value=\"1\">1</option>");
                      out.println("<option value=\"2\">2</option>");
                      out.println("<option value=\"3\">3</option>");
                      out.println("<option value=\"4\">4</option>");
                      out.println("<option value=\"5\">5</option>");
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;(1 if Golf Shop Makes Teams)");
                    out.println("<br><br>");
                    out.println("Min. Sign-up Size (if Members Make Their Own Teams):&nbsp;&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"minsize\">");
                      out.println("<option value=\"1\">1</option>");
                      out.println("<option value=\"2\">2</option>");
                      out.println("<option value=\"3\">3</option>");
                      out.println("<option value=\"4\">4</option>");
                      out.println("<option value=\"5\">5</option>");
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;(must not be greater than team size)");
                    out.println("<br><br>");
                  out.println("Max # of Teams:&nbsp;&nbsp;&nbsp;");
                     out.println("<input type=\"text\" name=\"max\" size=\"3\" maxlength=\"3\">");
                     out.println("<br> (If Golf Shop Makes Teams, this will be # of members allowed to sign up.)");
                     out.println("");
                    out.println("<br><br>");
                    out.println("Guests Allowed per Member (if Member Makes Teams):&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"guests\">");
                      out.println("<option value=\"0\">0</option>");
                      out.println("<option value=\"1\">1</option>");
                      out.println("<option value=\"2\">2</option>");
                      out.println("<option value=\"3\">3</option>");
                      out.println("<option value=\"4\">4</option>");
                    out.println("</select>");
                    out.println("<br><br>");
                      out.println("Allow members to reserve player positions using an <b>'X'</b>?<br>");
                        out.println("If yes, how many X's can members specify per team? (0 [zero] = NO): &nbsp;&nbsp;");
                        out.println("<select size=\"1\" name=\"x\">");
                          out.println("<option value=\"0\">0</option>");
                          out.println("<option value=\"1\">1</option>");
                          out.println("<option value=\"2\">2</option>");
                          out.println("<option value=\"3\">3</option>");
                          out.println("<option value=\"4\">4</option>");
                        out.println("</select>");
                    out.println("<br>");
                      out.println("How many hours in advance of cut-off date/time should we remove X's?: &nbsp;&nbsp;");
                        out.println("<input type=\"text\" name=\"xhrs\" size=\"2\" maxlength=\"2\">&nbsp;&nbsp;(0 - 48)");
                    out.println("<br><br>");
                      out.println("Player Transportation Options allowed (select all that apply):");
                      i2 = 1;
                      for (i=0; i<16; i++) {
                         if (!tmode[i].equals( "" ) && !tmode[i].equals( null )) {
                            out.println("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                            out.println("<input type=\"checkbox\" name=\"tmode" +i2+ "\" value=\"yes\">&nbsp;&nbsp;" +tmode[i]+ "");
                         }
                         i2++;
                      }
                    out.println("<br><br>");
                  out.println("Cost:&nbsp;&nbsp;per Member&nbsp;");
                     out.println("<input type=\"text\" name=\"memcost\" size=\"10\" maxlength=\"10\">");
/*
                     if (!posType.equals( "" )) {   // if POS charges needed
                        out.println("&nbsp;&nbsp;&nbsp;&nbsp;POS Charge Code&nbsp;");
                        out.println("<input type=\"text\" name=\"mempos\" size=\"15\" maxlength=\"30\">");
                     }
*/
                  out.println("<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                  out.println("&nbsp;&nbsp;per Guest&nbsp;");
                     out.println("<input type=\"text\" name=\"gstcost\" size=\"10\" maxlength=\"10\">");
/*
                     if (!posType.equals( "" )) {   // if POS charges needed
                        out.println("&nbsp;&nbsp;&nbsp;&nbsp;POS Charge Code&nbsp;");
                        out.println("<input type=\"text\" name=\"gstpos\" size=\"15\" maxlength=\"30\">");
                     }
*/
                    out.println("<br><br>");
                  out.println("Sign-up Date and Time (when members can begin to sign up):<br><br>");
                    out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Month:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"su_month\">");
                       dateOpts.opMonth(out, thisMonth);         // output the month options
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"su_day\">");
                       dateOpts.opDay(out, thisDay);         // output the day options
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"su_year\">");
                       dateOpts.opYear(out, thisYear);         // output the year options
                    out.println("</select>");
                  out.println("<br><br>");
                  out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hour &nbsp;");
                    out.println("<select size=\"1\" name=\"su_hr\">");
                      out.println("<option value=\"01\">01</option>");
                      out.println("<option value=\"02\">02</option>");
                      out.println("<option value=\"03\">03</option>");
                      out.println("<option value=\"04\">04</option>");
                      out.println("<option value=\"05\">05</option>");
                      out.println("<option value=\"06\">06</option>");
                      out.println("<option value=\"07\">07</option>");
                      out.println("<option value=\"08\">08</option>");
                      out.println("<option value=\"09\">09</option>");
                      out.println("<option value=\"10\">10</option>");
                      out.println("<option value=\"11\">11</option>");
                      out.println("<option value=\"12\">12</option>");
                    out.println("</select>");
                    out.println("&nbsp; Min &nbsp;");
                    out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"su_min\">");
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"su_ampm\">");
                      out.println("<option value=\"AM\">AM</option>");
                      out.println("<option value=\"PM\">PM</option>");
                    out.println("</select>");
                    out.println("<br><br>");
                  out.println("Cut-off Date and Time (when members can no longer sign up):<br><br>");
                    out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Month:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"c_month\">");
                       dateOpts.opMonth(out, thisMonth);         // output the month options
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"c_day\">");
                       dateOpts.opDay(out, thisDay);         // output the day options
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"c_year\">");
                       dateOpts.opYear(out, thisYear);         // output the year options
                    out.println("</select>");
                  out.println("<br><br>");
                  out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hour &nbsp;");
                    out.println("<select size=\"1\" name=\"c_hr\">");
                      out.println("<option value=\"01\">01</option>");
                      out.println("<option value=\"02\">02</option>");
                      out.println("<option value=\"03\">03</option>");
                      out.println("<option value=\"04\">04</option>");
                      out.println("<option value=\"05\">05</option>");
                      out.println("<option value=\"06\">06</option>");
                      out.println("<option value=\"07\">07</option>");
                      out.println("<option value=\"08\">08</option>");
                      out.println("<option value=\"09\">09</option>");
                      out.println("<option value=\"10\">10</option>");
                      out.println("<option value=\"11\">11</option>");
                      out.println("<option value=\"12\">12</option>");
                    out.println("</select>");
                    out.println("&nbsp; Min &nbsp;");
                    out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=\"00\" name=\"c_min\">");
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"c_ampm\">");
                      out.println("<option value=\"AM\">AM</option>");
                      out.println("<option value=\"PM\">PM</option>");
                    out.println("</select>");
                  out.println("</p>");
                      
                  out.println("<p align=\"left\">&nbsp;&nbsp;<b>Groups to be Restricted</b><br>");
                  out.println("&nbsp;&nbsp;Specify Members to restrict and/or Membership Types to restrict.<br>");
                  out.println("&nbsp;&nbsp;(Any members with the selected Member Type or Membership Type will NOT be allowed.)</p>");

                  out.println("<p align=\"left\">&nbsp;&nbsp;Members to be Restricted (select all that apply, or none):");
                  for (i = 0; i < parm.MAX_Mems; i++) {
                     if (!parm.mem[i].equals( "" )) {
                        i2 = i + 1;
                        out.println("<br>");
                        out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                        out.println("<input type=\"checkbox\" name=\"mem" +i2+ "\" value=\"" + parm.mem[i] + "\">&nbsp;&nbsp;" + parm.mem[i]);
                     }
                  }
                  out.println("<br><br>&nbsp;&nbsp;Membership Types to be Restricted (select all that apply, or none):");
                  for (i = 0; i < parm.MAX_Mships; i++) {
                     if (!parm.mship[i].equals( "" )) {
                        i2 = i + 1;
                        out.println("<br>");
                        out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                        out.println("<input type=\"checkbox\" name=\"mship" +i2+ "\" value=\"" + parm.mship[i] + "\">&nbsp;&nbsp;" + parm.mship[i]);
                     }
                  }
                  out.println("</p>");
  
                  out.println("<input type=\"hidden\" name=\"page2\" value=\"yes\">");
                  out.println("<input type=\"hidden\" name=\"event_name\" value=\"" +name+ "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" +course+ "\">");
                  out.println("<input type=\"hidden\" name=\"fb\" value=\"" +fb+ "\">");
                  out.println("<input type=\"hidden\" name=\"month\" value=\"" +s_month+ "\">");
                  out.println("<input type=\"hidden\" name=\"day\" value=\"" +s_day+ "\">");
                  out.println("<input type=\"hidden\" name=\"year\" value=\"" +s_year+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_hr\" value=\"" +start_hr+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_min\" value=\"" +start_min+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_ampm\" value=\"" +start_ampm+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_hr\" value=\"" +end_hr+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_min\" value=\"" +end_min+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_ampm\" value=\"" +end_ampm+ "\">");
                  out.println("<input type=\"hidden\" name=\"act_hr\" value=\"" +act_hr+ "\">");
                  out.println("<input type=\"hidden\" name=\"act_min\" value=\"" +act_min+ "\">");
                  out.println("<input type=\"hidden\" name=\"act_ampm\" value=\"" +act_ampm+ "\">");
                  out.println("<input type=\"hidden\" name=\"fb2\" value=\"" +fb2+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_hr2\" value=\"" +start_hr2+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_min2\" value=\"" +start_min2+ "\">");
                  out.println("<input type=\"hidden\" name=\"start_ampm2\" value=\"" +start_ampm2+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_hr2\" value=\"" +end_hr2+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_min2\" value=\"" +end_min2+ "\">");
                  out.println("<input type=\"hidden\" name=\"end_ampm2\" value=\"" +end_ampm2+ "\">");
                  out.println("<input type=\"hidden\" name=\"type\" value=\"" +stype+ "\">");
                  out.println("<input type=\"hidden\" name=\"holes\" value=\"" +holes+ "\">");
                  out.println("<input type=\"hidden\" name=\"color\" value=\"" +color+ "\">");
                  out.println("<input type=\"hidden\" name=\"signUp\" value=\"" +ssignUp+ "\">");
                  out.println("<input type=\"hidden\" name=\"gstOnly\" value=\"" +guestOnly+ "\">");
                  out.println("<input type=\"hidden\" name=\"gender\" value=\"" +gender+ "\">");
                  out.println("<input type=\"hidden\" name=\"season\" value=\"" +season+ "\">");
                  out.println("<input type=\"hidden\" name=\"export_type\" value=\"" +export_type+ "\">");
                  out.println("<input type=\"hidden\" name=\"email1\" value=\"" +email1+ "\">");
                  out.println("<input type=\"hidden\" name=\"email2\" value=\"" +email2+ "\">");
                  out.println("<input type=\"hidden\" name=\"itin\" value=\"" +itin+ "\">");
                  if (copy == true) {
                     out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");
                  }
                  out.println("<p align=\"center\">");
                    out.println("<input type=\"submit\" value=\"Continue\">");
                    out.println("</p>");
                  out.println("</font>");
               out.println("</td>");
            out.println("</tr>");
            out.println("</form>");
            out.println("</table>");
            out.println("<font size=\"2\"><br>");
            out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_events\">");
            out.println("<input type=\"submit\" value=\"Done\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
            out.println("</center>");
            out.println("</font>");
            out.println("</body>");
            out.println("</html>");
            out.close();
            return;               // exit and wiat for reply
         }

      } else {   // this is page2 - update the event
        
         pstmt = con.prepareStatement (
           "UPDATE events2b SET " +
           "format = ?, pairings = ?, size = ?, max = ?, guests = ?, memcost = ?, " +
           "gstcost = ?, c_month = ?, c_day = ?, c_year = ?, c_hr = ?, c_min = ?, c_date = ?, " +
           "c_time = ?, gstOnly = ?, x = ?, xhrs = ?, " +
           "su_month = ?, su_day = ?, su_year = ?, su_hr = ?, su_min = ?, su_date = ?, su_time = ?, " +
           "mempos = ?, gstpos = ?, tmode1 = ?, tmode2 = ?, tmode3 = ?, tmode4 = ?, tmode5 = ?, tmode6 = ?, " + 
           "tmode7 = ?, tmode8 = ?, tmode9 = ?, tmode10 = ?, tmode11 = ?, tmode12 = ?, tmode13 = ?, " +
           "tmode14 = ?, tmode15 = ?, tmode16 = ?, " +
           "mem1 = ?, mem2 = ?, mem3 = ?, mem4 = ?, mem5 = ?, mem6 = ?, mem7 = ?, mem8 = ?, " +
           "mem9 = ?, mem10 = ?, mem11 = ?, mem12 = ?, mem13 = ?, mem14 = ?, mem15 = ?, mem16 = ?, " +
           "mem17 = ?, mem18 = ?, mem19 = ?, mem20 = ?, mem21 = ?, mem22 = ?, mem23 = ?, mem24 = ?, " +
           "mship1 = ?, mship2 = ?, mship3 = ?, mship4 = ?, mship5 = ?, mship6 = ?, mship7 = ?, mship8 = ?, " +
           "mship9 = ?, mship10 = ?, mship11 = ?, mship12 = ?, mship13 = ?, mship14 = ?, mship15 = ?, mship16 = ?, " +
           "mship17 = ?, mship18 = ?, mship19 = ?, mship20 = ?, mship21 = ?, mship22 = ?, mship23 = ?, mship24 = ?, " +
           "minsize = ? " +
           "WHERE name = ? AND courseName = ?");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, format);
         pstmt.setString(2, pairings);
         pstmt.setInt(3, size);
         pstmt.setInt(4, max);
         pstmt.setInt(5, guests);
         pstmt.setString(6, memcost);
         pstmt.setString(7, gstcost);
         pstmt.setInt(8, c_month);
         pstmt.setInt(9, c_day);
         pstmt.setInt(10, c_year);
         pstmt.setInt(11, c_hr);
         pstmt.setInt(12, c_min);
         pstmt.setLong(13, c_date);
         pstmt.setInt(14, c_time);
         pstmt.setInt(15, gstOnly);
         pstmt.setInt(16, x);
         pstmt.setInt(17, xhrs);
         pstmt.setInt(18, su_month);
         pstmt.setInt(19, su_day);
         pstmt.setInt(20, su_year);
         pstmt.setInt(21, su_hr);
         pstmt.setInt(22, su_min);
         pstmt.setLong(23, su_date);
         pstmt.setInt(24, su_time);
         pstmt.setString(25, mempos);
         pstmt.setString(26, gstpos);
         pstmt.setInt(27, tmodei[0]);
         pstmt.setInt(28, tmodei[1]);
         pstmt.setInt(29, tmodei[2]);
         pstmt.setInt(30, tmodei[3]);
         pstmt.setInt(31, tmodei[4]);
         pstmt.setInt(32, tmodei[5]);
         pstmt.setInt(33, tmodei[6]);
         pstmt.setInt(34, tmodei[7]);
         pstmt.setInt(35, tmodei[8]);
         pstmt.setInt(36, tmodei[9]);
         pstmt.setInt(37, tmodei[10]);
         pstmt.setInt(38, tmodei[11]);
         pstmt.setInt(39, tmodei[12]);
         pstmt.setInt(40, tmodei[13]);
         pstmt.setInt(41, tmodei[14]);
         pstmt.setInt(42, tmodei[15]);
         for (i=1; i<parm.MAX_Mems+1; i++) {
            pstmt.setString(42+i, mtype[i]);
         }
         for (i=1; i<parm.MAX_Mships+1; i++) {
            pstmt.setString(66+i, mship[i]);
         }
        
         pstmt.setInt(91, minsize);
         pstmt.setString(92, name);
         pstmt.setString(93, course);

         pstmt.executeUpdate();     // execute the prepared stmt

         pstmt.close();
      }
   }
   catch (Exception exc) {

      out.println(SystemUtils.HeadTitle("Database Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR>Exception:   " + exc.getMessage());
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_announce\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   //
   // Database updated - inform user
   //
   out.println(SystemUtils.HeadTitle("Proshop Add Event"));
   out.println("<BODY>");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<CENTER><BR>");
   out.println("<BR><BR><H3>The Event Has Been Added</H3>");
   out.println("<BR><BR>Thank you, the event has been added to the system database.");
/*   
   if (itinL > 255) {

      out.println("<br><br><b>Notice:</b>&nbsp;&nbsp;The Itinerary you entered exceeded 254 characters in length.  All characters beyond 254 will be truncated.</p>");
   }
*/
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   if (copy == false) {
      out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_addevnt\">");
   } else {
      out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_events\">");
      out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");
   }
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</form></font>");
   out.println("</CENTER></BODY></HTML>");
   out.close();

   try {
      resp.flushBuffer();      // force the repsonse to complete
   }
   catch (Exception ignore) {
   }

   //
   //  Now, call utility to scan the event table and update tee slots in teecurr accordingly
   //
   SystemUtils.do1Event(con, name);

 }   // end of doPost   


 // *********************************************************
 // Missing or invalid data entered...
 // *********************************************************

 private void invData(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
   out.println("<BODY><CENTER><BR>");
   out.println("<p>&nbsp;</p>");
   out.println("<BR><H3>Input Error</H3><BR>");
   out.println("<BR><BR>Sorry, some data you entered is missing or invalid.<BR>");
   out.println("Check the Name, Start Time and End Time fields.<BR>");
   out.println("<BR>Please try again.<BR>");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</form></font>");
   out.println("</CENTER></BODY></HTML>");
   out.close();
 }

 // *********************************************************
 // Member already exists
 // *********************************************************

 private void dupMem(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
   out.println("<BODY><CENTER><BR>");
   out.println("<p>&nbsp;</p>");
   out.println("<BR><H3>Input Error</H3><BR>");
   out.println("<BR><BR>Sorry, the <b>event name</b> you specified already exists in the database.<BR>");
   out.println("<BR>Please use the edit feature to change an existing event record.<BR>");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</form></font>");
   out.println("</CENTER></BODY></HTML>");
   out.close();
 }

}
