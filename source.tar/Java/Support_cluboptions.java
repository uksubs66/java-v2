/***************************************************************************************     
 *   Support_cluboptions:  This servlet will process the add or init club options request from Support's Init page.
 *
 *                   This is used to set some club options we need before the pro configures the site.
 *
 *
 *   called by:  support_main.htm
 *
 *   created: 6/04/2007   Bob P.
 *
 *   last updated:
 *
 *
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;


public class Support_cluboptions extends HttpServlet {
 
       
 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //*********************************************************************************
 // Process the request from support_main.htm
 //*********************************************************************************

 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           
   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();
        
   Connection con = null;                  // init DB objects
   Statement stmt = null;
   ResultSet rs = null;
     
   String support = "support";             // valid username
   String clubname = "";

   HttpSession session = null; 


   // Make sure user didn't enter illegally.........

   session = req.getSession(false);  // Get user's session object (no new one)

   if (session == null) {

      invalidUser(out);            // Intruder - reject
      return;
   }

   String user = (String)session.getAttribute("user");   // get username

   if (!user.equals( support )) {

      invalidUser(out);            // Intruder - reject
      return;
   }


   // Load the JDBC Driver and connect to DB.........

   String club = (String)session.getAttribute("club");   // get club name

   try {
      con = dbConn.Connect(club);

   }
   catch (Exception exc) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB.");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }


   boolean exists = false;
     
   String zipcode = "";

   int notification = 0;
   int seamless = 0;
   int rsync = 0;
   int primaryif = 0;
   int mnum = 0;
   int mapping = 0;
   int stripzero = 0;

   //
   //  See if the club5 table exists yet
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT clubName FROM club5");   // check for club5 table entry

      if (rs.next()) {

         // club5 DB Table already exists

         exists = true;

      } else {
        
         exists = false;
      }

      stmt.close();

   }
   catch (Exception exc) {

      exists = false;
   }


   if (exists == false ) {             // create entry if club5 does not exist yet
     
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "INSERT INTO club5 (clubName, multi, lottery, contact, email, " +
            "guest1, guest2, guest3, guest4, guest5, guest6, guest7, guest8, " +
            "guest9, guest10, guest11, guest12, guest13, guest14, guest15, " +
            "guest16, guest17, guest18, guest19, guest20, guest21, guest22, " +
            "guest23, guest24, guest25, guest26, guest27, guest28, guest29, " +
            "guest30, guest31, guest32, guest33, guest34, guest35, guest36, " +
            "mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
            "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
            "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24, " +
            "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
            "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
            "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24, " +
            "x, xhrs, adv_zone, emailOpt, lottid, hotel, userlock, " +
            "unacompGuest, hndcpProSheet, hndcpProEvent, hndcpMemSheet, hndcpMemEvent, " +
            "posType, logins, rndsperday, hrsbtwn, forcegnames, hidenames, " +
            "constimesm, constimesp, precheckin, paceofplay, no_reservations, " +
            "salestax, nwindow_starttime, nwindow_endtime, notify_interval, " +
            "hdcpSystem, allowMemPost, lastHdcpSync, hdcpStartDate, hdcpEndDate, " +
            "rsync, seamless, zipcode, primaryif, mnum, mapping, stripzero) " +
            "VALUES ('',0,0,'','', " +
            "'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','', " +
            "'','','','','','','','','','','','','','','','','','','','','','','','', " +
            "'','','','','','','','','','','','','','','','','','','','','','','','', " +
            "0,0,'',0,0,0,0, " +
            "0,0,0,0,0, " +
            "'',0,0,0,0,0, " +
            "0,0,0,0,0, " +
            "0,'00:00:00','00:00:00',0," +
            "'',0,'0000-00-00','0000-00-00 00:00:00','0000-00-00 00:00:00', " +
            "0,0,'',0,0,0,0)");

         pstmt1.executeUpdate();          // execute the prepared stmt

         pstmt1.close();

      }
      catch (Exception exc) {

         out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
         out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
         out.println("<BR><BR>Error inserting row in club5 for new club.");
         out.println("<BR>Exception: "+ exc.getMessage());
         out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
  
   } else {
   
      //
      //  club5 exists - get current values
      //
      try {

         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT no_reservations, rsync, seamless, zipcode, primaryif, mnum, mapping, stripzero " +
                                "FROM club5");

         if (rs.next()) {

            notification = rs.getInt(1);
            rsync = rs.getInt(2);
            seamless = rs.getInt(3);
            zipcode = rs.getString(4);
            primaryif = rs.getInt(5);
            mnum = rs.getInt(6);
            mapping = rs.getInt(7);
            stripzero = rs.getInt(8);
         }
         stmt.close();
        
      }
      catch (Exception exc) {

         out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
         out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
         out.println("<BR><BR>Error getting club5 data.");
         out.println("<BR>Exception: "+ exc.getMessage());
         out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

   }  // end of IF exists

   //
   //  Now present a form to display and gather the options
   //
   out.println("<HTML><HEAD><TITLE>Support Init DB</TITLE></HEAD>");
   out.println("<BODY><CENTER><BR><H3>Set Club Options</H3>");
   out.println("<BR><b>NOTE:</b> We must set the following options for all new clubs.");
   out.println("<BR><BR>");

   out.println("<table border=\"1\" bgcolor=\"#F5F5DC\" width=\"300\">");
      out.println("<tr bgcolor=\"#336633\"><td align=\"center\" colspan=\"2\">");
      out.println("<font color=\"#FFFFFF\" size=\"2\">");
      out.println("<b>Club Options</b><br>");
      out.println("<br>Change the desired information below.<br>");
      out.println("Click on <b>Submit</b> to submit the record.");
      out.println("</font></td></tr>");
        
      out.println("<form action=\"/" +rev+ "/servlet/Support_cluboptions\" method=\"post\">");
        
      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Notification System?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"notification\">");
      if (notification == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Roster Sync?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"rsync\">");
      if (rsync == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Seamless Interface?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"seamless\">");
      if (seamless == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Primary-Only Interface?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"primaryif\">");
      if (primaryif == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Username = Member Number (mNum)?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"mnum\">");
      if (mnum == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Use Mapping (to webid)?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"mapping\">");
      if (mapping == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Strip Leading Zero?:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<select size=\"1\" name=\"stripzero\">");
      if (stripzero == 0) {
         out.println("<option selected value=\"No\">No</option>");
         out.println("<option value=\"Yes\">Yes</option>");
      } else {
         out.println("<option value=\"No\">No</option>");
         out.println("<option selected value=\"Yes\">Yes</option>");
      }
      out.println("</select>");
      out.println("</td></tr>");

      out.println("<tr><td align=\"left\" width=\"200\">");
      out.println("<font size=\"2\"><br>");
      out.println("&nbsp;&nbsp;Zip Code:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\" width=\"100\">");
      out.println("<input type=\"text\" id=\"zipcode\" name=\"zipcode\" value=\"" +zipcode+ "\" size=\"5\" maxlength=\"5\">");
      out.println("<br><br>");

      out.println("<p align=\"center\">");
      out.println("<input type=\"submit\" name=\"Submit\" value=\"Submit\">");
   out.println("</font></td></tr></form></table>");

   out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return - Cancel</A>.");
   out.println("</CENTER></BODY></HTML>");
   out.close();

 }        // end of doGet
 

 //*********************************************************************************
 // Process the form request from above
 //*********************************************************************************

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Connection con = null;                  // init DB objects
   Statement stmt = null;
   ResultSet rs = null;

   String support = "support";             // valid username
   String clubname = "";

   HttpSession session = null;


   // Make sure user didn't enter illegally.........

   session = req.getSession(false);  // Get user's session object (no new one)

   if (session == null) {

      invalidUser(out);            // Intruder - reject
      return;
   }

   String user = (String)session.getAttribute("user");   // get username

   if (!user.equals( support )) {

      invalidUser(out);            // Intruder - reject
      return;
   }


   // Load the JDBC Driver and connect to DB.........

   String club = (String)session.getAttribute("club");   // get club name

   try {
      con = dbConn.Connect(club);

   }
   catch (Exception exc) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB.");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }


   //
   //  Get the parms passed
   //
   boolean exist = false;

   String notifications = req.getParameter("notification");           //  get club options
   String seamlesss = req.getParameter("seamless");
   String rsyncs = req.getParameter("rsync");
   String primaryifs = req.getParameter("primaryif");
   String mnums = req.getParameter("mnum");
   String mappings = req.getParameter("mapping");
   String stripzeros = req.getParameter("stripzero");
   String zipcode = req.getParameter("zipcode");

   int notification = 0;
   int seamless = 0;
   int rsync = 0;
   int primaryif = 0;
   int mnum = 0;
   int mapping = 0;
   int stripzero = 0;

   // Convert to ints

   if (notifications.equals( "Yes" )) {
      notification = 1;
   }
   if (seamlesss.equals( "Yes" )) {
      seamless = 1;
   }
   if (rsyncs.equals( "Yes" )) {
      rsync = 1;
   }
   if (primaryifs.equals( "Yes" )) {
      primaryif = 1;
   }
   if (mnums.equals( "Yes" )) {
      mnum = 1;
   }
   if (mappings.equals( "Yes" )) {
      mapping = 1;
   }
   if (stripzeros.equals( "Yes" )) {
      stripzero = 1;
   }


   //
   //  Update the club5 table
   //
   try {

      PreparedStatement pstmt = con.prepareStatement (
         "UPDATE club5 SET no_reservations = ?, rsync = ?, seamless = ?, zipcode = ?, primaryif = ?, " +
         "mnum = ?, mapping = ?, stripzero = ?");

      pstmt.clearParameters();            // clear the parms
      pstmt.setInt(1, notification);
      pstmt.setInt(2, rsync);
      pstmt.setInt(3, seamless);
      pstmt.setString(4, zipcode);
      pstmt.setInt(5, primaryif);
      pstmt.setInt(6, mnum);
      pstmt.setInt(7, mapping);
      pstmt.setInt(8, stripzero);
        
      pstmt.executeUpdate();  // execute the prepared stmt

      pstmt.close();

   }
   catch (Exception exc) {

      // SQL Error ....

      out.println("<HTML><HEAD><TITLE>SQL Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>SQL Type Error</H3>");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   // DB Table setup complete - inform support....

   out.println("<HTML><HEAD><TITLE>Club5 Table Update Complete</TITLE></HEAD>");
   out.println("<BODY><CENTER><H3>Club5 Table Successfully Updated</H3>");
   out.println("<BR><BR>Please continue.");
   out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main.htm\">Return</A>.");
   out.println("</CENTER></BODY></HTML>");
   out.close();

   if (con != null) {
      try {
         con.close();       // Close the db connection........
      }
      catch (SQLException ignored) {
      }
   }
 }   
    
 // *********************************************************
 // Illegal access by user - force user to login....
 // *********************************************************

 private void invalidUser(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Access Error - Redirect"));
   out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H2>Access Error</H2><BR>");
   out.println("<BR><BR>Sorry, you must login before attempting to access these features.<BR>");
   out.println("<BR><BR>Please <A HREF=\"/" +rev+ "/servlet/Logout\">login</A>");
   out.println("</CENTER></BODY></HTML>");

 }

}
