/***************************************************************************************     
 *   Support_sync:  This servlet will look in the v_/roster folder for a text file
 *                 that contains member records for the club being processed.  The
 *                 member records will be compared against those already in the system.
 *
 *
 *   called by: support_main2.htm (for single club)
 *
 *
 *   created:   4/07/06 Bob P.
 *
 *   updated:
 *              7/24/07 Added call to Common_ghin.updateMemberHdcps after getPostedScoresForClub call
 *              3/20/07 Added new call to Common_ghin.getPostedScoresForClub if posted_scores is present.
 *                      Invoked by new menu item on Menu #2 'Download Posted Scores For This Club'
 *              8/28/06 Added refreshMemberHdcps method for updating hdcps stored
 *                      in teecurr2 and evntsup2.  Invoked by new menu item on Menu #2
 *                      'Refresh All Saved Handicaps For This Club'
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;


public class Support_sync extends HttpServlet {
                           

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 
 //*****************************************************************
 // Process the request from support_main2.htm for a single club
 //*****************************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Connection con = null;                  // init DB objects

   HttpSession session = null;

   String support = "support";             // valid username


   // Make sure user didn't enter illegally.........

   session = req.getSession(false);  // Get user's session object (no new one)

   if (session == null) {

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>Session Error</H3>");
      out.println("<BR><BR>Invalid Session.");
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   String user = (String)session.getAttribute("user");   // get username
   String club = (String)session.getAttribute("club");   // get club


   if (!user.equals( support )) {

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>Session Error</H3>");
      out.println("<BR><BR>Invalid Session.");
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }


   // Load the JDBC Driver and connect to DB.........
   try {
      con = dbConn.Connect(club);

   }
   catch (Exception exc) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB.");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   if (req.getParameter("posted_scores") != null && req.getParameter("posted_scores").equals("yes")) {

      String startDate = "";  // 30 days ago
      String endDate = "";    // today


      out.println("<HTML><HEAD><TITLE>Download Posted Scores</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>Downloading Posted Scores</H3>");
      out.println("<BR><BR>Club: " + club);

      if (req.getParameter("todo") == null) {

          try {

              Statement stmt = con.createStatement();
              ResultSet rs = stmt.executeQuery("" +
                  "SELECT " +
                  "DATE_FORMAT(now(), '%Y%m%d') AS endDate, " +
                  "DATE_FORMAT(DATE_ADD(now(), INTERVAL - 28 DAY), '%Y%m%d') AS startDate;");

              if (rs.next()) {
                  startDate = rs.getString("startDate");
                  endDate = rs.getString("endDate");
              }

          } catch (Exception exc) {

              SystemUtils.logError("Support_sync: Error getting dates.  Exception was " + exc.getMessage());
          }

          out.println("<BR><BR>");
          out.println("<form>");
          out.println("<input type=hidden value=yes name=posted_scores>");
          out.println("<input type=text name=startDate value=\"" + startDate + "\">");
          out.println("<input type=text name=endDate value=\"" + endDate + "\">");
          out.println("<BR><BR>");
          out.println("<input type=submit value=\"Get Scores\" name=todo>");
          out.println("</form>");
          return;

      }

      startDate = req.getParameter("startDate");
      endDate = req.getParameter("endDate");

      out.println("<BR><BR>Dates Requested: " + startDate + " thru " + endDate + "<BR><BR>");

      Common_ghin.getPostedScoresForClub(club, startDate, endDate, con, out);
      Common_ghin.updateMemberHdcps(club, con);

      out.println("<BR><BR>DONE!");
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
    
   } // end if posted_scores request
   
   
   if (req.getParameter("upd_hdcp") != null && req.getParameter("upd_hdcp").equals("yes")) {
    
       refreshMemberHdcps(club, con, out);
       
       // Member Handicaps Refreshed - inform support....
       //
       out.println("<HTML><HEAD><TITLE>Member Handicaps Refreshed</TITLE></HEAD>");
       out.println("<BODY><CENTER><H3>Member Handicaps Refreshed OK</H3>");
       out.println("<BR><BR>Member handicaps refreshed for: " +club);
       out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
       out.println("</CENTER></BODY></HTML>");
   }
   
   
   if (req.getParameter("support") != null && req.getParameter("support").equals("yes")) {
       
       //
       //  Go process this club (in Common_sync)
       //
       int result = Common_sync.clubSync(club, con);              // go process this club!!!!!
       
       // Roster Sync complete - inform support....
       //
       out.println("<HTML><HEAD><TITLE>Roster Sync Results</TITLE></HEAD><BODY><CENTER>");
       
       if (result == 0) {
           out.println("<H3>Club Not Using Roster Sync</H3>");
           out.println("<BR><BR>Roster Not Updated for: " +club);
       } else if (result == 1) {
           out.println("<H3>Roster Successfully Updated</H3>");
           out.println("<BR><BR>Roster Updated for: " +club);
       } else if (result == -1) {
           out.println("<H3>Roster Not Updated</H3>");
           out.println("<BR><BR>Roster Sync Failed for: " +club);
       }
       
       out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
       out.println("</CENTER></BODY></HTML>");
   }

   return;

 }    // end of doGet from Support

 
 //
 //  Loop thru and update all instances of a members hndcp in the system
 //  updates tables teecurr2, evntsup2b with hdcp data from member2b
 //
 private void refreshMemberHdcps(String club, Connection con, PrintWriter out) {

    Statement stmt = null;
    String teecurr_sql = "";
    String evntsup_sql = "";

    try {
        
        stmt = con.createStatement();
        
        for (int x=1;x<5;x++) {
            
            teecurr_sql = "" + 
                    "UPDATE teecurr2 t, member2b m " +
                    "SET " +
                        "t.hndcp" + x + " = (IF(t.username" + x + " = m.username,m.c_hancap,t.hndcp" + x + ")) " + 
                    "WHERE " +
                        "t.username" + x + " = m.username AND " +
                        "m.c_hancap <> -99 AND m.c_hancap <> 99";

            stmt.executeUpdate(teecurr_sql);
        }
        
        for (int x=1;x<10;x++) {
            evntsup_sql = "" + 
                    "UPDATE evntsup2b e, member2b m " +
                    "SET " +
                        "e.hndcp" + x + " = (IF(e.username" + x + " = m.username,m.c_hancap,e.hndcp" + x + ")) " + 
                    "WHERE " +
                        "e.username" + x + " = m.username AND " +
                        "m.c_hancap <> -99 AND m.c_hancap <> 99";

            stmt.executeUpdate(evntsup_sql);
            
        } // end loop each player position
        
        stmt.close();
        
    } catch (Exception exc) {
      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB.");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/" +rev+ "/support_main2.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
    }
 }
 
}
