/***************************************************************************************
 *   Support_upgrade:  This servlet will process the upgrade request from Support's Upgrade page.
 *
 *
 *   UPGRADE FROM V4 to V5 !!!!!!!!!!!!!!!
 *
 *
 *     ******** modified version - fix the clubs db tables  ************
 *
 *
 *   called by:  support_upgrade.htm
 *
 *   created:  1/24/2005   Bob P. 
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;


public class Support_upgrade extends HttpServlet {


 // Process the form request from support_upgrade.htm.....

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Connection con = null;                  // init DB objects
   Connection con2 = null;                 // init DB objects
   Statement stmt = null;
   PreparedStatement pstmt = null;
   ResultSet rs = null;

   String support = "support";             // valid username

   HttpSession session = null;


   // Make sure user didn't enter illegally.........

   session = req.getSession(false);  // Get user's session object (no new one)

   if (session == null) {

      invalidUser(out);            // Intruder - reject
      return;
   }

   String userName = (String)session.getAttribute("user");   // get username

   if (!userName.equals( support )) {

      invalidUser(out);            // Intruder - reject
      return;
   }

   //
   // Load the JDBC Driver and connect to DB
   //
   String club = (String)session.getAttribute("club");   // get club name

   try {
      con = SystemUtils.Connect(club);

   }
   catch (Exception exc) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB.");
      out.println("<BR>Exception: "+ exc.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   String clubname = "";
   int multi = 0;               // multiple course support = no
   int lottery = 0;             // lottery support = no
   String contact = "";         // club contact
   String email = "";           // contact's email
   String mem1 = "";   
   String mem2 = "";
   String mem3 = "";
   String mem4 = "";
   String mem5 = "";
   String mem6 = "";
   String mem7 = "";
   String mem8 = "";
   int x = 0;                   // use 'x' (0 - 4)
   int xhrs = 0;                // # of hrs in advance to remove x's
   int days1 = 0;
   int days2 = 0;
   int days3 = 0;
   int days4 = 0;
   int days5 = 0;
   int days6 = 0;
   int days7 = 0;
   int adv_hr = 0;
   int adv_min = 0;
   String adv_ampm = "";
   String adv_zone = "";
   int emailOpt = 0;
   long lottid = 0;
   int hotel = 0;
   int userlock = 0;
   int m2days1 = 0;
   int m2days2 = 0;
   int m2days3 = 0;
   int m2days4 = 0;
   int m2days5 = 0;
   int m2days6 = 0;
   int m2days7 = 0;
   int m3days1 = 0;
   int m3days2 = 0;
   int m3days3 = 0;
   int m3days4 = 0;
   int m3days5 = 0;
   int m3days6 = 0;
   int m3days7 = 0;
   int m4days1 = 0;
   int m4days2 = 0;
   int m4days3 = 0;
   int m4days4 = 0;
   int m4days5 = 0;
   int m4days6 = 0;
   int m4days7 = 0;
   int m5days1 = 0;
   int m5days2 = 0;
   int m5days3 = 0;
   int m5days4 = 0;
   int m5days5 = 0;
   int m5days6 = 0;
   int m5days7 = 0;
   int m6days1 = 0;
   int m6days2 = 0;
   int m6days3 = 0;
   int m6days4 = 0;
   int m6days5 = 0;
   int m6days6 = 0;
   int m6days7 = 0;
   int m7days1 = 0;
   int m7days2 = 0;
   int m7days3 = 0;
   int m7days4 = 0;
   int m7days5 = 0;
   int m7days6 = 0;
   int m7days7 = 0;
   int m8days1 = 0;
   int m8days2 = 0;
   int m8days3 = 0;
   int m8days4 = 0;
   int m8days5 = 0;
   int m8days6 = 0;
   int m8days7 = 0;
   int advhr1d1 = 0;
   int advhr1d2 = 0;
   int advhr1d3 = 0;
   int advhr1d4 = 0;
   int advhr1d5 = 0;
   int advhr1d6 = 0;
   int advhr1d7 = 0;
   int advhr2d1 = 0;
   int advhr2d2 = 0;
   int advhr2d3 = 0;
   int advhr2d4 = 0;
   int advhr2d5 = 0;
   int advhr2d6 = 0;
   int advhr2d7 = 0;
   int advhr3d1 = 0;
   int advhr3d2 = 0;
   int advhr3d3 = 0;
   int advhr3d4 = 0;
   int advhr3d5 = 0;
   int advhr3d6 = 0;
   int advhr3d7 = 0;
   int advhr4d1 = 0;
   int advhr4d2 = 0;
   int advhr4d3 = 0;
   int advhr4d4 = 0;
   int advhr4d5 = 0;
   int advhr4d6 = 0;
   int advhr4d7 = 0;
   int advhr5d1 = 0;
   int advhr5d2 = 0;
   int advhr5d3 = 0;
   int advhr5d4 = 0;
   int advhr5d5 = 0;
   int advhr5d6 = 0;
   int advhr5d7 = 0;
   int advhr6d1 = 0;
   int advhr6d2 = 0;
   int advhr6d3 = 0;
   int advhr6d4 = 0;
   int advhr6d5 = 0;
   int advhr6d6 = 0;
   int advhr6d7 = 0;
   int advhr7d1 = 0;
   int advhr7d2 = 0;
   int advhr7d3 = 0;
   int advhr7d4 = 0;
   int advhr7d5 = 0;
   int advhr7d6 = 0;
   int advhr7d7 = 0;
   int advhr8d1 = 0;
   int advhr8d2 = 0;
   int advhr8d3 = 0;
   int advhr8d4 = 0;
   int advhr8d5 = 0;
   int advhr8d6 = 0;
   int advhr8d7 = 0;
   int advmin1d1 = 0;
   int advmin1d2 = 0;
   int advmin1d3 = 0;
   int advmin1d4 = 0;
   int advmin1d5 = 0;
   int advmin1d6 = 0;
   int advmin1d7 = 0;
   int advmin2d1 = 0;
   int advmin2d2 = 0;
   int advmin2d3 = 0;
   int advmin2d4 = 0;
   int advmin2d5 = 0;
   int advmin2d6 = 0;
   int advmin2d7 = 0;
   int advmin3d1 = 0;
   int advmin3d2 = 0;
   int advmin3d3 = 0;
   int advmin3d4 = 0;
   int advmin3d5 = 0;
   int advmin3d6 = 0;
   int advmin3d7 = 0;
   int advmin4d1 = 0;
   int advmin4d2 = 0;
   int advmin4d3 = 0;
   int advmin4d4 = 0;
   int advmin4d5 = 0;
   int advmin4d6 = 0;
   int advmin4d7 = 0;
   int advmin5d1 = 0;
   int advmin5d2 = 0;
   int advmin5d3 = 0;
   int advmin5d4 = 0;
   int advmin5d5 = 0;
   int advmin5d6 = 0;
   int advmin5d7 = 0;
   int advmin6d1 = 0;
   int advmin6d2 = 0;
   int advmin6d3 = 0;
   int advmin6d4 = 0;
   int advmin6d5 = 0;
   int advmin6d6 = 0;
   int advmin6d7 = 0;
   int advmin7d1 = 0;
   int advmin7d2 = 0;
   int advmin7d3 = 0;
   int advmin7d4 = 0;
   int advmin7d5 = 0;
   int advmin7d6 = 0;
   int advmin7d7 = 0;
   int advmin8d1 = 0;
   int advmin8d2 = 0;
   int advmin8d3 = 0;
   int advmin8d4 = 0;
   int advmin8d5 = 0;
   int advmin8d6 = 0;
   int advmin8d7 = 0;
   String advam1d1 = "";
   String advam1d2 = "";
   String advam1d3 = "";
   String advam1d4 = "";
   String advam1d5 = "";
   String advam1d6 = "";
   String advam1d7 = "";
   String advam2d1 = "";
   String advam2d2 = "";
   String advam2d3 = "";
   String advam2d4 = "";
   String advam2d5 = "";
   String advam2d6 = "";
   String advam2d7 = "";
   String advam3d1 = "";
   String advam3d2 = "";
   String advam3d3 = "";
   String advam3d4 = "";
   String advam3d5 = "";
   String advam3d6 = "";
   String advam3d7 = "";
   String advam4d1 = "";
   String advam4d2 = "";
   String advam4d3 = "";
   String advam4d4 = "";
   String advam4d5 = "";
   String advam4d6 = "";
   String advam4d7 = "";
   String advam5d1 = "";
   String advam5d2 = "";
   String advam5d3 = "";
   String advam5d4 = "";
   String advam5d5 = "";
   String advam5d6 = "";
   String advam5d7 = "";
   String advam6d1 = "";
   String advam6d2 = "";
   String advam6d3 = "";
   String advam6d4 = "";
   String advam6d5 = "";
   String advam6d6 = "";
   String advam6d7 = "";
   String advam7d1 = "";
   String advam7d2 = "";
   String advam7d3 = "";
   String advam7d4 = "";
   String advam7d5 = "";
   String advam7d6 = "";
   String advam7d7 = "";
   String advam8d1 = "";
   String advam8d2 = "";
   String advam8d3 = "";
   String advam8d4 = "";
   String advam8d5 = "";
   String advam8d6 = "";
   String advam8d7 = "";
   int unacompGuest = 0;
   int hndcpProSheet = 0;
   int hndcpProEvent = 0;
   int hndcpMemSheet = 0;
   int hndcpMemEvent = 0;
   int logins = 0;
   String posType = "";             // POS Type - None, Jonas, or Pro-ShopKeeper

   String [] guest = new String [37];
   String [] gstItem = new String [37];
   String [] gpos = new String [37];
   String [] g9pos = new String [37];
   String [] mship = new String [9];
   String [] mshipItem = new String [9];
   String [] mpos = new String [9];
   String [] mposc = new String [9];
   String [] m9posc = new String [9];
   String [] period = new String [9];

   int [] mtimes = new int [9];
   int [] gOpt = new int [37];

   String omit = "";
   String index = "";
   String clubName = "";
   String fullname = "";
   String phone = "";
   String fax = "";
   String gmname = "";
   String gmemail = "";
   String gmphone = "";
   String proname = "";
   String proemail = "";
   String prophone = "";
   int i = 0;
   long date = 0;
   long posChit = 0;


   try {
      stmt = con.createStatement();           // create a statement

      stmt.executeUpdate("DROP TABLE club5");

      stmt.executeUpdate("DROP TABLE mship5");

      stmt.executeUpdate("DROP TABLE guest5");

      stmt.executeUpdate("DROP TABLE stats5");

   }
   catch (Exception e1) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB - error1.");
      out.println("<BR>Exception: "+ e1.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   try {

      //
      //**********************************************************************************************
      //
      //  ADD New Tables
      //
      //**********************************************************************************************
      //
      //
      //  Club Parameters Table
      //
      stmt.executeUpdate("CREATE TABLE club5 (clubName varchar(30), multi smallint, " +
                         "lottery smallint, contact varchar(40), email varchar(40), " +
                         "guest1 varchar(20), guest2 varchar(20), guest3 varchar(20), guest4 varchar(20), " +
                         "guest5 varchar(20), guest6 varchar(20), guest7 varchar(20), guest8 varchar(20), " +
                         "guest9 varchar(20), guest10 varchar(20), guest11 varchar(20), guest12 varchar(20), " +
                         "guest13 varchar(20), guest14 varchar(20), guest15 varchar(20), guest16 varchar(20), " +
                         "guest17 varchar(20), guest18 varchar(20), guest19 varchar(20), guest20 varchar(20), " +
                         "guest21 varchar(20), guest22 varchar(20), guest23 varchar(20), guest24 varchar(20), " +
                         "guest25 varchar(20), guest26 varchar(20), guest27 varchar(20), guest28 varchar(20), " +
                         "guest29 varchar(20), guest30 varchar(20), guest31 varchar(20), guest32 varchar(20), " +
                         "guest33 varchar(20), guest34 varchar(20), guest35 varchar(20), guest36 varchar(20), " +
                         "mem1 varchar(30), mem2 varchar(30), mem3 varchar(30), mem4 varchar(30), " +
                         "mem5 varchar(30), mem6 varchar(30), mem7 varchar(30), mem8 varchar(30), " +
                         "mem9 varchar(30), mem10 varchar(30), mem11 varchar(30), mem12 varchar(30), " +
                         "mem13 varchar(30), mem14 varchar(30), mem15 varchar(30), mem16 varchar(30), " +
                         "mem17 varchar(30), mem18 varchar(30), mem19 varchar(30), mem20 varchar(30), " +
                         "mem21 varchar(30), mem22 varchar(30), mem23 varchar(30), mem24 varchar(30), " +
                         "mship1 varchar(30), mship2 varchar(30), mship3 varchar(30), mship4 varchar(30), " +
                         "mship5 varchar(30), mship6 varchar(30), mship7 varchar(30), mship8 varchar(30), " +
                         "mship9 varchar(30), mship10 varchar(30), mship11 varchar(30), mship12 varchar(30), " +
                         "mship13 varchar(30), mship14 varchar(30), mship15 varchar(30), mship16 varchar(30), " +
                         "mship17 varchar(30), mship18 varchar(30), mship19 varchar(30), mship20 varchar(30), " +
                         "mship21 varchar(30), mship22 varchar(30), mship23 varchar(30), mship24 varchar(30), " +
                         "x smallint, xhrs smallint, adv_zone varchar(8), emailOpt smallint, " +
                         "lottid bigint, hotel smallint, userlock smallint, " +
                         "unacompGuest smallint, hndcpProSheet smallint, hndcpProEvent smallint, " +
                         "hndcpMemSheet smallint, hndcpMemEvent smallint, posType varchar(20), " +
                         "logins integer, rndsperday smallint, hrsbtwn smallint, forcegnames smallint, " +
                         "hidenames smallint, constimesm smallint, constimesp smallint)");


      //
      //  Membership Type Table (one entry per mship type)
      //
      stmt.executeUpdate("CREATE TABLE mship5 (mship varchar(30), " +
                         "mtimes integer, period varchar(5), days1 smallint, " +
                         "days2 smallint, days3 smallint, days4 smallint, " +
                         "days5 smallint, days6 smallint, days7 smallint, " +
                         "advhrd1 smallint, advmind1 smallint, advamd1 varchar(2), " +
                         "advhrd2 smallint, advmind2 smallint, advamd2 varchar(2), " +
                         "advhrd3 smallint, advmind3 smallint, advamd3 varchar(2), " +
                         "advhrd4 smallint, advmind4 smallint, advamd4 varchar(2), " +
                         "advhrd5 smallint, advmind5 smallint, advamd5 varchar(2), " +
                         "advhrd6 smallint, advmind6 smallint, advamd6 varchar(2), " +
                         "advhrd7 smallint, advmind7 smallint, advamd7 varchar(2), " +
                         "mpos varchar(10), mposc varchar(10), m9posc varchar(10), " +
                         "mshipItem varchar(7), mship9Item varchar(7))");


      //
      //  Guest Type Table (one entry per guest type)
      //
      stmt.executeUpdate("CREATE TABLE guest5 (guest varchar(20), " +
                         "gOpt smallint, gpos varchar(30), g9pos varchar(30), " +
                         "gstItem varchar(7), gst9Item varchar(7))");



      //
      //  Table for maintaining report statistics
      //
      stmt.executeUpdate("CREATE TABLE stats5 (date bigint, year integer, month smallint, day smallint, course varchar(30), " +
                         "mem1Rounds9 integer, mem1Rounds18 integer, mem2Rounds9 integer, mem2Rounds18 integer, " +
                         "mem3Rounds9 integer, mem3Rounds18 integer, mem4Rounds9 integer, mem4Rounds18 integer, " +
                         "mem5Rounds9 integer, mem5Rounds18 integer, mem6Rounds9 integer, mem6Rounds18 integer, " +
                         "mem7Rounds9 integer, mem7Rounds18 integer, mem8Rounds9 integer, mem8Rounds18 integer, " +
                         "mem9Rounds9 integer, mem9Rounds18 integer, mem10Rounds9 integer, mem10Rounds18 integer, " +
                         "mem11Rounds9 integer, mem11Rounds18 integer, mem12Rounds9 integer, mem12Rounds18 integer, " +
                         "mem13Rounds9 integer, mem13Rounds18 integer, mem14Rounds9 integer, mem14Rounds18 integer, " +
                         "mem15Rounds9 integer, mem15Rounds18 integer, mem16Rounds9 integer, mem16Rounds18 integer, " +
                         "mem17Rounds9 integer, mem17Rounds18 integer, mem18Rounds9 integer, mem18Rounds18 integer, " +
                         "mem19Rounds9 integer, mem19Rounds18 integer, mem20Rounds9 integer, mem20Rounds18 integer, " +
                         "mem21Rounds9 integer, mem21Rounds18 integer, mem22Rounds9 integer, mem22Rounds18 integer, " +
                         "mem23Rounds9 integer, mem23Rounds18 integer, mem24Rounds9 integer, mem24Rounds18 integer, " +
                         "mship1Rounds9 integer, mship1Rounds18 integer, mship2Rounds9 integer, mship2Rounds18 integer, " +
                         "mship3Rounds9 integer, mship3Rounds18 integer, mship4Rounds9 integer, mship4Rounds18 integer, " +
                         "mship5Rounds9 integer, mship5Rounds18 integer, mship6Rounds9 integer, mship6Rounds18 integer, " +
                         "mship7Rounds9 integer, mship7Rounds18 integer, mship8Rounds9 integer, mship8Rounds18 integer, " +
                         "mship9Rounds9 integer, mship9Rounds18 integer, mship10Rounds9 integer, mship10Rounds18 integer, " +
                         "mship11Rounds9 integer, mship11Rounds18 integer, mship12Rounds9 integer, mship12Rounds18 integer, " +
                         "mship13Rounds9 integer, mship13Rounds18 integer, mship14Rounds9 integer, mship14Rounds18 integer, " +
                         "mship15Rounds9 integer, mship15Rounds18 integer, mship16Rounds9 integer, mship16Rounds18 integer, " +
                         "mship17Rounds9 integer, mship17Rounds18 integer, mship18Rounds9 integer, mship18Rounds18 integer, " +
                         "mship19Rounds9 integer, mship19Rounds18 integer, mship20Rounds9 integer, mship20Rounds18 integer, " +
                         "mship21Rounds9 integer, mship21Rounds18 integer, mship22Rounds9 integer, mship22Rounds18 integer, " +
                         "mship23Rounds9 integer, mship23Rounds18 integer, mship24Rounds9 integer, mship24Rounds18 integer, " +
                         "gst1Rounds9 integer, gst1Rounds18 integer, gst2Rounds9 integer, gst2Rounds18 integer, " +
                         "gst3Rounds9 integer, gst3Rounds18 integer, gst4Rounds9 integer, gst4Rounds18 integer, " +
                         "gst5Rounds9 integer, gst5Rounds18 integer, gst6Rounds9 integer, gst6Rounds18 integer, " +
                         "gst7Rounds9 integer, gst7Rounds18 integer, gst8Rounds9 integer, gst8Rounds18 integer, " +
                         "gst9Rounds9 integer, gst9Rounds18 integer, gst10Rounds9 integer, gst10Rounds18 integer, " +
                         "gst11Rounds9 integer, gst11Rounds18 integer, gst12Rounds9 integer, gst12Rounds18 integer, " +
                         "gst13Rounds9 integer, gst13Rounds18 integer, gst14Rounds9 integer, gst14Rounds18 integer, " +
                         "gst15Rounds9 integer, gst15Rounds18 integer, gst16Rounds9 integer, gst16Rounds18 integer, " +
                         "gst17Rounds9 integer, gst17Rounds18 integer, gst18Rounds9 integer, gst18Rounds18 integer, " +
                         "gst19Rounds9 integer, gst19Rounds18 integer, gst20Rounds9 integer, gst20Rounds18 integer, " +
                         "gst21Rounds9 integer, gst21Rounds18 integer, gst22Rounds9 integer, gst22Rounds18 integer, " +
                         "gst23Rounds9 integer, gst23Rounds18 integer, gst24Rounds9 integer, gst24Rounds18 integer, " +
                         "gst25Rounds9 integer, gst25Rounds18 integer, gst26Rounds9 integer, gst26Rounds18 integer, " +
                         "gst27Rounds9 integer, gst27Rounds18 integer, gst28Rounds9 integer, gst28Rounds18 integer, " +
                         "gst29Rounds9 integer, gst29Rounds18 integer, gst30Rounds9 integer, gst30Rounds18 integer, " +
                         "gst31Rounds9 integer, gst31Rounds18 integer, gst32Rounds9 integer, gst32Rounds18 integer, " +
                         "gst33Rounds9 integer, gst33Rounds18 integer, gst34Rounds9 integer, gst34Rounds18 integer, " +
                         "gst35Rounds9 integer, gst35Rounds18 integer, gst36Rounds9 integer, gst36Rounds18 integer, " +
                         "tmode1R9 integer, tmode1R18 integer, tmode2R9 integer, tmode2R18 integer, " +
                         "tmode3R9 integer, tmode3R18 integer, tmode4R9 integer, tmode4R18 integer, " +
                         "tmode5R9 integer, tmode5R18 integer, tmode6R9 integer, tmode6R18 integer, " +
                         "tmode7R9 integer, tmode7R18 integer, tmode8R9 integer, tmode8R18 integer, " +
                         "tmode9R9 integer, tmode9R18 integer, tmode10R9 integer, tmode10R18 integer, " +
                         "tmode11R9 integer, tmode11R18 integer, tmode12R9 integer, tmode12R18 integer, " +
                         "tmode13R9 integer, tmode13R18 integer, tmode14R9 integer, tmode14R18 integer, " +
                         "tmode15R9 integer, tmode15R18 integer, tmode16R9 integer, tmode16R18 integer, " +
                         "tmodeOldR9 integer, tmodeOldR18 integer, " +
                         "otherRounds9 integer, otherRounds18 integer, cartsRounds9 integer, cartsRounds18 integer, " +
                         "caddyRounds9 integer, caddyRounds18 integer, pullcartRounds9 integer, pullcartRounds18 integer, " +
                         "walkRounds9 integer, walkRounds18 integer, memnoshow9 integer, memnoshow18 integer, " +
                         "gstnoshow9 integer, gstnoshow18 integer, mem9unknown integer, mem18unknown integer, " +
                         "mship9unknown integer, mship18unknown integer, " +
                         "index ind1 (date, course))");
                     // leave index at end (for searches)

   }
   catch (Exception e2) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB - error2.");
      out.println("<BR>Exception: "+ e2.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }


   try {

      //
      //*******************************************************
      //  recreate club2 - move to club5, mship5 & guest5
      //*******************************************************
      //
      rs = stmt.executeQuery("SELECT * FROM club2");

      if (rs.next()) {

         clubName = rs.getString(1);
         multi = rs.getInt(2);
         lottery = rs.getInt(3);
         contact = rs.getString(4);
         email = rs.getString(5);
         guest[1] = rs.getString(6);
         guest[2] = rs.getString(7);
         guest[3] = rs.getString(8);
         guest[4] = rs.getString(9);
         guest[5] = rs.getString(10);
         guest[6] = rs.getString(11);
         guest[7] = rs.getString(12);
         guest[8] = rs.getString(13);
         mem1 = rs.getString(14);
         mem2 = rs.getString(15);
         mem3 = rs.getString(16);
         mem4 = rs.getString(17);
         mem5 = rs.getString(18);
         mem6 = rs.getString(19);
         mem7 = rs.getString(20);
         mem8 = rs.getString(21);
         mship[1] = rs.getString(22);
         mship[2] = rs.getString(23);
         mship[3] = rs.getString(24);
         mship[4] = rs.getString(25);
         mship[5] = rs.getString(26);
         mship[6] = rs.getString(27);
         mship[7] = rs.getString(28);
         mship[8] = rs.getString(29);
         mtimes[1] = rs.getInt(30);
         mtimes[2] = rs.getInt(31);
         mtimes[3] = rs.getInt(32);
         mtimes[4] = rs.getInt(33);
         mtimes[5] = rs.getInt(34);
         mtimes[6] = rs.getInt(35);
         mtimes[7] = rs.getInt(36);
         mtimes[8] = rs.getInt(37);
         period[1] = rs.getString(38);
         period[2] = rs.getString(39);
         period[3] = rs.getString(40);
         period[4] = rs.getString(41);
         period[5] = rs.getString(42);
         period[6] = rs.getString(43);
         period[7] = rs.getString(44);
         period[8] = rs.getString(45);
         x = rs.getInt(46);
         xhrs = rs.getInt(47);
         days1 = rs.getInt(48);
         days2 = rs.getInt(49);
         days3 = rs.getInt(50);
         days4 = rs.getInt(51);
         days5 = rs.getInt(52);
         days6 = rs.getInt(53);
         days7 = rs.getInt(54);
         adv_hr = rs.getInt(55);
         adv_min = rs.getInt(56);
         adv_ampm = rs.getString(57);
         adv_zone = rs.getString(58);
         gOpt[1] = rs.getInt(59);
         gOpt[2] = rs.getInt(60);
         gOpt[3] = rs.getInt(61);
         gOpt[4] = rs.getInt(62);
         gOpt[5] = rs.getInt(63);
         gOpt[6] = rs.getInt(64);
         gOpt[7] = rs.getInt(65);
         gOpt[8] = rs.getInt(66);
         emailOpt = rs.getInt(67);
         lottid = rs.getLong(68);
         hotel = rs.getInt(69);
         userlock = rs.getInt(70);
         guest[9] = rs.getString(71);
         guest[10] = rs.getString(72);
         guest[11] = rs.getString(73);
         guest[12] = rs.getString(74);
         guest[13] = rs.getString(75);
         guest[14] = rs.getString(76);
         guest[15] = rs.getString(77);
         guest[16] = rs.getString(78);
         guest[17] = rs.getString(79);
         guest[18] = rs.getString(80);
         guest[19] = rs.getString(81);
         guest[20] = rs.getString(82);
         guest[21] = rs.getString(83);
         guest[22] = rs.getString(84);
         guest[23] = rs.getString(85);
         guest[24] = rs.getString(86);
         guest[25] = rs.getString(87);
         guest[26] = rs.getString(88);
         guest[27] = rs.getString(89);
         guest[28] = rs.getString(90);
         guest[29] = rs.getString(91);
         guest[30] = rs.getString(92);
         guest[31] = rs.getString(93);
         guest[32] = rs.getString(94);
         guest[33] = rs.getString(95);
         guest[34] = rs.getString(96);
         guest[35] = rs.getString(97);
         guest[36] = rs.getString(98);
         gOpt[9] = rs.getInt(99);
         gOpt[10] = rs.getInt(100);
         gOpt[11] = rs.getInt(101);
         gOpt[12] = rs.getInt(102);
         gOpt[13] = rs.getInt(103);
         gOpt[14] = rs.getInt(104);
         gOpt[15] = rs.getInt(105);
         gOpt[16] = rs.getInt(106);
         gOpt[17] = rs.getInt(107);
         gOpt[18] = rs.getInt(108);
         gOpt[19] = rs.getInt(109);
         gOpt[20] = rs.getInt(110);
         gOpt[21] = rs.getInt(111);
         gOpt[22] = rs.getInt(112);
         gOpt[23] = rs.getInt(113);
         gOpt[24] = rs.getInt(114);
         gOpt[25] = rs.getInt(115);
         gOpt[26] = rs.getInt(116);
         gOpt[27] = rs.getInt(117);
         gOpt[28] = rs.getInt(118);
         gOpt[29] = rs.getInt(119);
         gOpt[30] = rs.getInt(120);
         gOpt[31] = rs.getInt(121);
         gOpt[32] = rs.getInt(122);
         gOpt[33] = rs.getInt(123);
         gOpt[34] = rs.getInt(124);
         gOpt[35] = rs.getInt(125);
         gOpt[36] = rs.getInt(126);
         m2days1 = rs.getInt(127);
         m2days2 = rs.getInt(128);
         m2days3 = rs.getInt(129);
         m2days4 = rs.getInt(130);
         m2days5 = rs.getInt(131);
         m2days6 = rs.getInt(132);
         m2days7 = rs.getInt(133);
         m3days1 = rs.getInt(134);
         m3days2 = rs.getInt(135);
         m3days3 = rs.getInt(136);
         m3days4 = rs.getInt(137);
         m3days5 = rs.getInt(138);
         m3days6 = rs.getInt(139);
         m3days7 = rs.getInt(140);
         m4days1 = rs.getInt(141);
         m4days2 = rs.getInt(142);
         m4days3 = rs.getInt(143);
         m4days4 = rs.getInt(144);
         m4days5 = rs.getInt(145);
         m4days6 = rs.getInt(146);
         m4days7 = rs.getInt(147);
         m5days1 = rs.getInt(148);
         m5days2 = rs.getInt(149);
         m5days3 = rs.getInt(150);
         m5days4 = rs.getInt(151);
         m5days5 = rs.getInt(152);
         m5days6 = rs.getInt(153);
         m5days7 = rs.getInt(154);
         m6days1 = rs.getInt(155);
         m6days2 = rs.getInt(156);
         m6days3 = rs.getInt(157);
         m6days4 = rs.getInt(158);
         m6days5 = rs.getInt(159);
         m6days6 = rs.getInt(160);
         m6days7 = rs.getInt(161);
         m7days1 = rs.getInt(162);
         m7days2 = rs.getInt(163);
         m7days3 = rs.getInt(164);
         m7days4 = rs.getInt(165);
         m7days5 = rs.getInt(166);
         m7days6 = rs.getInt(167);
         m7days7 = rs.getInt(168);
         m8days1 = rs.getInt(169);
         m8days2 = rs.getInt(170);
         m8days3 = rs.getInt(171);
         m8days4 = rs.getInt(172);
         m8days5 = rs.getInt(173);
         m8days6 = rs.getInt(174);
         m8days7 = rs.getInt(175);
         advhr1d1 = rs.getInt("advhr1d1");
         advmin1d1 = rs.getInt("advmin1d1");
         advam1d1 = rs.getString("advam1d1");
         advhr1d2 = rs.getInt("advhr1d2");
         advmin1d2 = rs.getInt("advmin1d2");
         advam1d2 = rs.getString("advam1d2");
         advhr1d3 = rs.getInt("advhr1d3");
         advmin1d3 = rs.getInt("advmin1d3");
         advam1d3 = rs.getString("advam1d3");
         advhr1d4 = rs.getInt("advhr1d4");
         advmin1d4 = rs.getInt("advmin1d4");
         advam1d4 = rs.getString("advam1d4");
         advhr1d5 = rs.getInt("advhr1d5");
         advmin1d5 = rs.getInt("advmin1d5");
         advam1d5 = rs.getString("advam1d5");
         advhr1d6 = rs.getInt("advhr1d6");
         advmin1d6 = rs.getInt("advmin1d6");
         advam1d6 = rs.getString("advam1d6");
         advhr1d7 = rs.getInt("advhr1d7");
         advmin1d7 = rs.getInt("advmin1d7");
         advam1d7 = rs.getString("advam1d7");
         advhr2d1 = rs.getInt("advhr2d1");
         advmin2d1 = rs.getInt("advmin2d1");
         advam2d1 = rs.getString("advam2d1");
         advhr2d2 = rs.getInt("advhr2d2");
         advmin2d2 = rs.getInt("advmin2d2");
         advam2d2 = rs.getString("advam2d2");
         advhr2d3 = rs.getInt("advhr2d3");
         advmin2d3 = rs.getInt("advmin2d3");
         advam2d3 = rs.getString("advam2d3");
         advhr2d4 = rs.getInt("advhr2d4");
         advmin2d4 = rs.getInt("advmin2d4");
         advam2d4 = rs.getString("advam2d4");
         advhr2d5 = rs.getInt("advhr2d5");
         advmin2d5 = rs.getInt("advmin2d5");
         advam2d5 = rs.getString("advam2d5");
         advhr2d6 = rs.getInt("advhr2d6");
         advmin2d6 = rs.getInt("advmin2d6");
         advam2d6 = rs.getString("advam2d6");
         advhr2d7 = rs.getInt("advhr2d7");
         advmin2d7 = rs.getInt("advmin2d7");
         advam2d7 = rs.getString("advam2d7");
         advhr3d1 = rs.getInt("advhr3d1");
         advmin3d1 = rs.getInt("advmin3d1");
         advam3d1 = rs.getString("advam3d1");
         advhr3d2 = rs.getInt("advhr3d2");
         advmin3d2 = rs.getInt("advmin3d2");
         advam3d2 = rs.getString("advam3d2");
         advhr3d3 = rs.getInt("advhr3d3");
         advmin3d3 = rs.getInt("advmin3d3");
         advam3d3 = rs.getString("advam3d3");
         advhr3d4 = rs.getInt("advhr3d4");
         advmin3d4 = rs.getInt("advmin3d4");
         advam3d4 = rs.getString("advam3d4");
         advhr3d5 = rs.getInt("advhr3d5");
         advmin3d5 = rs.getInt("advmin3d5");
         advam3d5 = rs.getString("advam3d5");
         advhr3d6 = rs.getInt("advhr3d6");
         advmin3d6 = rs.getInt("advmin3d6");
         advam3d6 = rs.getString("advam3d6");
         advhr3d7 = rs.getInt("advhr3d7");
         advmin3d7 = rs.getInt("advmin3d7");
         advam3d7 = rs.getString("advam3d7");
         advhr4d1 = rs.getInt("advhr4d1");
         advmin4d1 = rs.getInt("advmin4d1");
         advam4d1 = rs.getString("advam4d1");
         advhr4d2 = rs.getInt("advhr4d2");
         advmin4d2 = rs.getInt("advmin4d2");
         advam4d2 = rs.getString("advam4d2");
         advhr4d3 = rs.getInt("advhr4d3");
         advmin4d3 = rs.getInt("advmin4d3");
         advam4d3 = rs.getString("advam4d3");
         advhr4d4 = rs.getInt("advhr4d4");
         advmin4d4 = rs.getInt("advmin4d4");
         advam4d4 = rs.getString("advam4d4");
         advhr4d5 = rs.getInt("advhr4d5");
         advmin4d5 = rs.getInt("advmin4d5");
         advam4d5 = rs.getString("advam4d5");
         advhr4d6 = rs.getInt("advhr4d6");
         advmin4d6 = rs.getInt("advmin4d6");
         advam4d6 = rs.getString("advam4d6");
         advhr4d7 = rs.getInt("advhr4d7");
         advmin4d7 = rs.getInt("advmin4d7");
         advam4d7 = rs.getString("advam4d7");
         advhr5d1 = rs.getInt("advhr5d1");
         advmin5d1 = rs.getInt("advmin5d1");
         advam5d1 = rs.getString("advam5d1");
         advhr5d2 = rs.getInt("advhr5d2");
         advmin5d2 = rs.getInt("advmin5d2");
         advam5d2 = rs.getString("advam5d2");
         advhr5d3 = rs.getInt("advhr5d3");
         advmin5d3 = rs.getInt("advmin5d3");
         advam5d3 = rs.getString("advam5d3");
         advhr5d4 = rs.getInt("advhr5d4");
         advmin5d4 = rs.getInt("advmin5d4");
         advam5d4 = rs.getString("advam5d4");
         advhr5d5 = rs.getInt("advhr5d5");
         advmin5d5 = rs.getInt("advmin5d5");
         advam5d5 = rs.getString("advam5d5");
         advhr5d6 = rs.getInt("advhr5d6");
         advmin5d6 = rs.getInt("advmin5d6");
         advam5d6 = rs.getString("advam5d6");
         advhr5d7 = rs.getInt("advhr5d7");
         advmin5d7 = rs.getInt("advmin5d7");
         advam5d7 = rs.getString("advam5d7");
         advhr6d1 = rs.getInt("advhr6d1");
         advmin6d1 = rs.getInt("advmin6d1");
         advam6d1 = rs.getString("advam6d1");
         advhr6d2 = rs.getInt("advhr6d2");
         advmin6d2 = rs.getInt("advmin6d2");
         advam6d2 = rs.getString("advam6d2");
         advhr6d3 = rs.getInt("advhr6d3");
         advmin6d3 = rs.getInt("advmin6d3");
         advam6d3 = rs.getString("advam6d3");
         advhr6d4 = rs.getInt("advhr6d4");
         advmin6d4 = rs.getInt("advmin6d4");
         advam6d4 = rs.getString("advam6d4");
         advhr6d5 = rs.getInt("advhr6d5");
         advmin6d5 = rs.getInt("advmin6d5");
         advam6d5 = rs.getString("advam6d5");
         advhr6d6 = rs.getInt("advhr6d6");
         advmin6d6 = rs.getInt("advmin6d6");
         advam6d6 = rs.getString("advam6d6");
         advhr6d7 = rs.getInt("advhr6d7");
         advmin6d7 = rs.getInt("advmin6d7");
         advam6d7 = rs.getString("advam6d7");
         advhr7d1 = rs.getInt("advhr7d1");
         advmin7d1 = rs.getInt("advmin7d1");
         advam7d1 = rs.getString("advam7d1");
         advhr7d2 = rs.getInt("advhr7d2");
         advmin7d2 = rs.getInt("advmin7d2");
         advam7d2 = rs.getString("advam7d2");
         advhr7d3 = rs.getInt("advhr7d3");
         advmin7d3 = rs.getInt("advmin7d3");
         advam7d3 = rs.getString("advam7d3");
         advhr7d4 = rs.getInt("advhr7d4");
         advmin7d4 = rs.getInt("advmin7d4");
         advam7d4 = rs.getString("advam7d4");
         advhr7d5 = rs.getInt("advhr7d5");
         advmin7d5 = rs.getInt("advmin7d5");
         advam7d5 = rs.getString("advam7d5");
         advhr7d6 = rs.getInt("advhr7d6");
         advmin7d6 = rs.getInt("advmin7d6");
         advam7d6 = rs.getString("advam7d6");
         advhr7d7 = rs.getInt("advhr7d7");
         advmin7d7 = rs.getInt("advmin7d7");
         advam7d7 = rs.getString("advam7d7");
         advhr8d1 = rs.getInt("advhr8d1");
         advmin8d1 = rs.getInt("advmin8d1");
         advam8d1 = rs.getString("advam8d1");
         advhr8d2 = rs.getInt("advhr8d2");
         advmin8d2 = rs.getInt("advmin8d2");
         advam8d2 = rs.getString("advam8d2");
         advhr8d3 = rs.getInt("advhr8d3");
         advmin8d3 = rs.getInt("advmin8d3");
         advam8d3 = rs.getString("advam8d3");
         advhr8d4 = rs.getInt("advhr8d4");
         advmin8d4 = rs.getInt("advmin8d4");
         advam8d4 = rs.getString("advam8d4");
         advhr8d5 = rs.getInt("advhr8d5");
         advmin8d5 = rs.getInt("advmin8d5");
         advam8d5 = rs.getString("advam8d5");
         advhr8d6 = rs.getInt("advhr8d6");
         advmin8d6 = rs.getInt("advmin8d6");
         advam8d6 = rs.getString("advam8d6");
         advhr8d7 = rs.getInt("advhr8d7");
         advmin8d7 = rs.getInt("advmin8d7");
         advam8d7 = rs.getString("advam8d7");
         unacompGuest = rs.getInt("unacompGuest");
         hndcpProSheet = rs.getInt("hndcpProSheet");
         hndcpProEvent = rs.getInt("hndcpProEvent");
         hndcpMemSheet = rs.getInt("hndcpMemSheet");
         hndcpMemEvent = rs.getInt("hndcpMemEvent");
         posType = rs.getString("posType");
         gpos[1] = rs.getString("gpos1");
         gpos[2] = rs.getString("gpos2");
         gpos[3] = rs.getString("gpos3");
         gpos[4] = rs.getString("gpos4");
         gpos[5] = rs.getString("gpos5");
         gpos[6] = rs.getString("gpos6");
         gpos[7] = rs.getString("gpos7");
         gpos[8] = rs.getString("gpos8");
         gpos[9] = rs.getString("gpos9");
         gpos[10] = rs.getString("gpos10");
         gpos[11] = rs.getString("gpos11");
         gpos[12] = rs.getString("gpos12");
         gpos[13] = rs.getString("gpos13");
         gpos[14] = rs.getString("gpos14");
         gpos[15] = rs.getString("gpos15");
         gpos[16] = rs.getString("gpos16");
         gpos[17] = rs.getString("gpos17");
         gpos[18] = rs.getString("gpos18");
         gpos[19] = rs.getString("gpos19");
         gpos[20] = rs.getString("gpos20");
         gpos[21] = rs.getString("gpos21");
         gpos[22] = rs.getString("gpos22");
         gpos[23] = rs.getString("gpos23");
         gpos[24] = rs.getString("gpos24");
         gpos[25] = rs.getString("gpos25");
         gpos[26] = rs.getString("gpos26");
         gpos[27] = rs.getString("gpos27");
         gpos[28] = rs.getString("gpos28");
         gpos[29] = rs.getString("gpos29");
         gpos[30] = rs.getString("gpos30");
         gpos[31] = rs.getString("gpos31");
         gpos[32] = rs.getString("gpos32");
         gpos[33] = rs.getString("gpos33");
         gpos[34] = rs.getString("gpos34");
         gpos[35] = rs.getString("gpos35");
         gpos[36] = rs.getString("gpos36");
         g9pos[1] = rs.getString("g9pos1");
         g9pos[2] = rs.getString("g9pos2");
         g9pos[3] = rs.getString("g9pos3");
         g9pos[4] = rs.getString("g9pos4");
         g9pos[5] = rs.getString("g9pos5");
         g9pos[6] = rs.getString("g9pos6");
         g9pos[7] = rs.getString("g9pos7");
         g9pos[8] = rs.getString("g9pos8");
         g9pos[9] = rs.getString("g9pos9");
         g9pos[10] = rs.getString("g9pos10");
         g9pos[11] = rs.getString("g9pos11");
         g9pos[12] = rs.getString("g9pos12");
         g9pos[13] = rs.getString("g9pos13");
         g9pos[14] = rs.getString("g9pos14");
         g9pos[15] = rs.getString("g9pos15");
         g9pos[16] = rs.getString("g9pos16");
         g9pos[17] = rs.getString("g9pos17");
         g9pos[18] = rs.getString("g9pos18");
         g9pos[19] = rs.getString("g9pos19");
         g9pos[20] = rs.getString("g9pos20");
         g9pos[21] = rs.getString("g9pos21");
         g9pos[22] = rs.getString("g9pos22");
         g9pos[23] = rs.getString("g9pos23");
         g9pos[24] = rs.getString("g9pos24");
         g9pos[25] = rs.getString("g9pos25");
         g9pos[26] = rs.getString("g9pos26");
         g9pos[27] = rs.getString("g9pos27");
         g9pos[28] = rs.getString("g9pos28");
         g9pos[29] = rs.getString("g9pos29");
         g9pos[30] = rs.getString("g9pos30");
         g9pos[31] = rs.getString("g9pos31");
         g9pos[32] = rs.getString("g9pos32");
         g9pos[33] = rs.getString("g9pos33");
         g9pos[34] = rs.getString("g9pos34");
         g9pos[35] = rs.getString("g9pos35");
         g9pos[36] = rs.getString("g9pos36");
         mpos[1] = rs.getString("mpos1");
         mpos[2] = rs.getString("mpos2");
         mpos[3] = rs.getString("mpos3");
         mpos[4] = rs.getString("mpos4");
         mpos[5] = rs.getString("mpos5");
         mpos[6] = rs.getString("mpos6");
         mpos[7] = rs.getString("mpos7");
         mpos[8] = rs.getString("mpos8");
         mposc[1] = rs.getString("mposc1");
         mposc[2] = rs.getString("mposc2");
         mposc[3] = rs.getString("mposc3");
         mposc[4] = rs.getString("mposc4");
         mposc[5] = rs.getString("mposc5");
         mposc[6] = rs.getString("mposc6");
         mposc[7] = rs.getString("mposc7");
         mposc[8] = rs.getString("mposc8");
         posChit = rs.getLong("posChit");
         m9posc[1] = rs.getString("m9posc1");
         m9posc[2] = rs.getString("m9posc2");
         m9posc[3] = rs.getString("m9posc3");
         m9posc[4] = rs.getString("m9posc4");
         m9posc[5] = rs.getString("m9posc5");
         m9posc[6] = rs.getString("m9posc6");
         m9posc[7] = rs.getString("m9posc7");
         m9posc[8] = rs.getString("m9posc8");
         gstItem[1] = rs.getString("gstItem1");
         gstItem[2] = rs.getString("gstItem2");
         gstItem[3] = rs.getString("gstItem3");
         gstItem[4] = rs.getString("gstItem4");
         gstItem[5] = rs.getString("gstItem5");
         gstItem[6] = rs.getString("gstItem6");
         gstItem[7] = rs.getString("gstItem7");
         gstItem[8] = rs.getString("gstItem8");
         gstItem[9] = rs.getString("gstItem9");
         gstItem[10] = rs.getString("gstItem10");
         gstItem[11] = rs.getString("gstItem11");
         gstItem[12] = rs.getString("gstItem12");
         gstItem[13] = rs.getString("gstItem13");
         gstItem[14] = rs.getString("gstItem14");
         gstItem[15] = rs.getString("gstItem15");
         gstItem[16] = rs.getString("gstItem16");
         gstItem[17] = rs.getString("gstItem17");
         gstItem[18] = rs.getString("gstItem18");
         gstItem[19] = rs.getString("gstItem19");
         gstItem[20] = rs.getString("gstItem20");
         gstItem[21] = rs.getString("gstItem21");
         gstItem[22] = rs.getString("gstItem22");
         gstItem[23] = rs.getString("gstItem23");
         gstItem[24] = rs.getString("gstItem24");
         gstItem[25] = rs.getString("gstItem25");
         gstItem[26] = rs.getString("gstItem26");
         gstItem[27] = rs.getString("gstItem27");
         gstItem[28] = rs.getString("gstItem28");
         gstItem[29] = rs.getString("gstItem29");
         gstItem[30] = rs.getString("gstItem30");
         gstItem[31] = rs.getString("gstItem31");
         gstItem[32] = rs.getString("gstItem32");
         gstItem[33] = rs.getString("gstItem33");
         gstItem[34] = rs.getString("gstItem34");
         gstItem[35] = rs.getString("gstItem35");
         gstItem[36] = rs.getString("gstItem36");
         mshipItem[1] = rs.getString("mshipItem1");
         mshipItem[2] = rs.getString("mshipItem2");
         mshipItem[3] = rs.getString("mshipItem3");
         mshipItem[4] = rs.getString("mshipItem4");
         mshipItem[5] = rs.getString("mshipItem5");
         mshipItem[6] = rs.getString("mshipItem6");
         mshipItem[7] = rs.getString("mshipItem7");
         mshipItem[8] = rs.getString("mshipItem8");
//         logins = rs.getInt("logins");
         logins = 0;

      }
      stmt.close();

      for (i=1; i<9; i++) {
        
         if (mpos[i] == null) {
            mpos[i] = "";
         }
         if (m9posc[i] == null) {
            m9posc[i] = "";
         }
         if (mposc[i] == null) {
            mposc[i] = "";
         }
         if (mshipItem[i] == null) {
            mshipItem[i] = "";
         }
      }

      pstmt = con.prepareStatement (
         "INSERT INTO club5 (clubName, multi, lottery, contact, email, " +
         "guest1, guest2, guest3, guest4, guest5, guest6, guest7, guest8, " +
         "guest9, guest10, guest11, guest12, guest13, guest14, guest15, " +
         "guest16, guest17, guest18, guest19, guest20, guest21, guest22, " +
         "guest23, guest24, guest25, guest26, guest27, guest28, guest29, " +
         "guest30, guest31, guest32, guest33, guest34, guest35, guest36, " +
         "mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
         "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
         "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24, " +
         "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
         "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
         "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24, " +
         "x, xhrs, adv_zone, emailOpt, lottid, hotel, userlock, " +
         "unacompGuest, hndcpProSheet, hndcpProEvent, hndcpMemSheet, hndcpMemEvent, " +
         "posType, logins, rndsperday, hrsbtwn, forcegnames, hidenames, " +
         "constimesm, constimesp) " +
         "VALUES (?,?,?,?,?, " +
         "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, " +
         "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, " +
         "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, " +
         "?,?,?,?,?,?,?, " +
         "?,?,?,?,?, " +
         "?,?,1,0,0,0, " +
         "1,1)");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, clubName);
      pstmt.setInt(2, multi);
      pstmt.setInt(3, lottery);
      pstmt.setString(4, contact);
      pstmt.setString(5, email);
      pstmt.setString(6, guest[1]);
      pstmt.setString(7, guest[2]);
      pstmt.setString(8, guest[3]);
      pstmt.setString(9, guest[4]);
      pstmt.setString(10, guest[5]);
      pstmt.setString(11, guest[6]);
      pstmt.setString(12, guest[7]);
      pstmt.setString(13, guest[8]);
      pstmt.setString(14, guest[9]);
      pstmt.setString(15, guest[10]);
      pstmt.setString(16, guest[11]);
      pstmt.setString(17, guest[12]);
      pstmt.setString(18, guest[13]);
      pstmt.setString(19, guest[14]);
      pstmt.setString(20, guest[15]);
      pstmt.setString(21, guest[16]);
      pstmt.setString(22, guest[17]);
      pstmt.setString(23, guest[18]);
      pstmt.setString(24, guest[19]);
      pstmt.setString(25, guest[20]);
      pstmt.setString(26, guest[21]);
      pstmt.setString(27, guest[22]);
      pstmt.setString(28, guest[23]);
      pstmt.setString(29, guest[24]);
      pstmt.setString(30, guest[25]);
      pstmt.setString(31, guest[26]);
      pstmt.setString(32, guest[27]);
      pstmt.setString(33, guest[28]);
      pstmt.setString(34, guest[29]);
      pstmt.setString(35, guest[30]);
      pstmt.setString(36, guest[31]);
      pstmt.setString(37, guest[32]);
      pstmt.setString(38, guest[33]);
      pstmt.setString(39, guest[34]);
      pstmt.setString(40, guest[35]);
      pstmt.setString(41, guest[36]);
      pstmt.setString(42, mem1);
      pstmt.setString(43, mem2);
      pstmt.setString(44, mem3);
      pstmt.setString(45, mem4);
      pstmt.setString(46, mem5);
      pstmt.setString(47, mem6);
      pstmt.setString(48, mem7);
      pstmt.setString(49, mem8);
      pstmt.setString(50, omit);
      pstmt.setString(51, omit);
      pstmt.setString(52, omit);
      pstmt.setString(53, omit);
      pstmt.setString(54, omit);
      pstmt.setString(55, omit);
      pstmt.setString(56, omit);
      pstmt.setString(57, omit);
      pstmt.setString(58, omit);
      pstmt.setString(59, omit);
      pstmt.setString(60, omit);
      pstmt.setString(61, omit);
      pstmt.setString(62, omit);
      pstmt.setString(63, omit);
      pstmt.setString(64, omit);
      pstmt.setString(65, omit);
      pstmt.setString(66, mship[1]);
      pstmt.setString(67, mship[2]);
      pstmt.setString(68, mship[3]);
      pstmt.setString(69, mship[4]);
      pstmt.setString(70, mship[5]);
      pstmt.setString(71, mship[6]);
      pstmt.setString(72, mship[7]);
      pstmt.setString(73, mship[8]);
      pstmt.setString(74, omit);
      pstmt.setString(75, omit);
      pstmt.setString(76, omit);
      pstmt.setString(77, omit);
      pstmt.setString(78, omit);
      pstmt.setString(79, omit);
      pstmt.setString(80, omit);
      pstmt.setString(81, omit);
      pstmt.setString(82, omit);
      pstmt.setString(83, omit);
      pstmt.setString(84, omit);
      pstmt.setString(85, omit);
      pstmt.setString(86, omit);
      pstmt.setString(87, omit);
      pstmt.setString(88, omit);
      pstmt.setString(89, omit);
      pstmt.setInt(90, x);
      pstmt.setInt(91, xhrs);
      pstmt.setString(92, adv_zone);
      pstmt.setInt(93, emailOpt);
      pstmt.setLong(94, lottid);
      pstmt.setInt(95, hotel);
      pstmt.setInt(96, userlock);
      pstmt.setInt(97, unacompGuest);
      pstmt.setInt(98, hndcpProSheet);
      pstmt.setInt(99, hndcpProEvent);
      pstmt.setInt(100, hndcpMemSheet);
      pstmt.setInt(101, hndcpMemEvent);
      pstmt.setString(102, posType);
      pstmt.setInt(103, logins);

      pstmt.executeUpdate();          // execute the prepared stmt

      pstmt.close();

      //
      // Now set the mship parms for each mship type specified (different table)
      //
      i = 1;
        
      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, days1);
         pstmt.setInt(5, days2);
         pstmt.setInt(6, days3);
         pstmt.setInt(7, days4);
         pstmt.setInt(8, days5);
         pstmt.setInt(9, days6);
         pstmt.setInt(10, days7);
         pstmt.setInt(11, advhr1d1);
         pstmt.setInt(12, advmin1d1);
         pstmt.setString(13, advam1d1);
         pstmt.setInt(14, advhr1d2);
         pstmt.setInt(15, advmin1d2);
         pstmt.setString(16, advam1d2);
         pstmt.setInt(17, advhr1d3);
         pstmt.setInt(18, advmin1d3);
         pstmt.setString(19, advam1d3);
         pstmt.setInt(20, advhr1d4);
         pstmt.setInt(21, advmin1d4);
         pstmt.setString(22, advam1d4);
         pstmt.setInt(23, advhr1d5);
         pstmt.setInt(24, advmin1d5);
         pstmt.setString(25, advam1d5);
         pstmt.setInt(26, advhr1d6);
         pstmt.setInt(27, advmin1d6);
         pstmt.setString(28, advam1d6);
         pstmt.setInt(29, advhr1d7);
         pstmt.setInt(30, advmin1d7);
         pstmt.setString(31, advam1d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 2;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m2days1);
         pstmt.setInt(5, m2days2);
         pstmt.setInt(6, m2days3);
         pstmt.setInt(7, m2days4);
         pstmt.setInt(8, m2days5);
         pstmt.setInt(9, m2days6);
         pstmt.setInt(10, m2days7);
         pstmt.setInt(11, advhr2d1);
         pstmt.setInt(12, advmin2d1);
         pstmt.setString(13, advam2d1);
         pstmt.setInt(14, advhr2d2);
         pstmt.setInt(15, advmin2d2);
         pstmt.setString(16, advam2d2);
         pstmt.setInt(17, advhr2d3);
         pstmt.setInt(18, advmin2d3);
         pstmt.setString(19, advam2d3);
         pstmt.setInt(20, advhr2d4);
         pstmt.setInt(21, advmin2d4);
         pstmt.setString(22, advam2d4);
         pstmt.setInt(23, advhr2d5);
         pstmt.setInt(24, advmin2d5);
         pstmt.setString(25, advam2d5);
         pstmt.setInt(26, advhr2d6);
         pstmt.setInt(27, advmin2d6);
         pstmt.setString(28, advam2d6);
         pstmt.setInt(29, advhr2d7);
         pstmt.setInt(30, advmin2d7);
         pstmt.setString(31, advam2d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 3;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m3days1);
         pstmt.setInt(5, m3days2);
         pstmt.setInt(6, m3days3);
         pstmt.setInt(7, m3days4);
         pstmt.setInt(8, m3days5);
         pstmt.setInt(9, m3days6);
         pstmt.setInt(10, m3days7);
         pstmt.setInt(11, advhr3d1);
         pstmt.setInt(12, advmin3d1);
         pstmt.setString(13, advam3d1);
         pstmt.setInt(14, advhr3d2);
         pstmt.setInt(15, advmin3d2);
         pstmt.setString(16, advam3d2);
         pstmt.setInt(17, advhr3d3);
         pstmt.setInt(18, advmin3d3);
         pstmt.setString(19, advam3d3);
         pstmt.setInt(20, advhr3d4);
         pstmt.setInt(21, advmin3d4);
         pstmt.setString(22, advam3d4);
         pstmt.setInt(23, advhr3d5);
         pstmt.setInt(24, advmin3d5);
         pstmt.setString(25, advam3d5);
         pstmt.setInt(26, advhr3d6);
         pstmt.setInt(27, advmin3d6);
         pstmt.setString(28, advam3d6);
         pstmt.setInt(29, advhr3d7);
         pstmt.setInt(30, advmin3d7);
         pstmt.setString(31, advam3d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 4;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m4days1);
         pstmt.setInt(5, m4days2);
         pstmt.setInt(6, m4days3);
         pstmt.setInt(7, m4days4);
         pstmt.setInt(8, m4days5);
         pstmt.setInt(9, m4days6);
         pstmt.setInt(10, m4days7);
         pstmt.setInt(11, advhr4d1);
         pstmt.setInt(12, advmin4d1);
         pstmt.setString(13, advam4d1);
         pstmt.setInt(14, advhr4d2);
         pstmt.setInt(15, advmin4d2);
         pstmt.setString(16, advam4d2);
         pstmt.setInt(17, advhr4d3);
         pstmt.setInt(18, advmin4d3);
         pstmt.setString(19, advam4d3);
         pstmt.setInt(20, advhr4d4);
         pstmt.setInt(21, advmin4d4);
         pstmt.setString(22, advam4d4);
         pstmt.setInt(23, advhr4d5);
         pstmt.setInt(24, advmin4d5);
         pstmt.setString(25, advam4d5);
         pstmt.setInt(26, advhr4d6);
         pstmt.setInt(27, advmin4d6);
         pstmt.setString(28, advam4d6);
         pstmt.setInt(29, advhr4d7);
         pstmt.setInt(30, advmin4d7);
         pstmt.setString(31, advam4d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 5;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m5days1);
         pstmt.setInt(5, m5days2);
         pstmt.setInt(6, m5days3);
         pstmt.setInt(7, m5days4);
         pstmt.setInt(8, m5days5);
         pstmt.setInt(9, m5days6);
         pstmt.setInt(10, m5days7);
         pstmt.setInt(11, advhr5d1);
         pstmt.setInt(12, advmin5d1);
         pstmt.setString(13, advam5d1);
         pstmt.setInt(14, advhr5d2);
         pstmt.setInt(15, advmin5d2);
         pstmt.setString(16, advam5d2);
         pstmt.setInt(17, advhr5d3);
         pstmt.setInt(18, advmin5d3);
         pstmt.setString(19, advam5d3);
         pstmt.setInt(20, advhr5d4);
         pstmt.setInt(21, advmin5d4);
         pstmt.setString(22, advam5d4);
         pstmt.setInt(23, advhr5d5);
         pstmt.setInt(24, advmin5d5);
         pstmt.setString(25, advam5d5);
         pstmt.setInt(26, advhr5d6);
         pstmt.setInt(27, advmin5d6);
         pstmt.setString(28, advam5d6);
         pstmt.setInt(29, advhr5d7);
         pstmt.setInt(30, advmin5d7);
         pstmt.setString(31, advam5d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 6;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m6days1);
         pstmt.setInt(5, m6days2);
         pstmt.setInt(6, m6days3);
         pstmt.setInt(7, m6days4);
         pstmt.setInt(8, m6days5);
         pstmt.setInt(9, m6days6);
         pstmt.setInt(10, m6days7);
         pstmt.setInt(11, advhr6d1);
         pstmt.setInt(12, advmin6d1);
         pstmt.setString(13, advam6d1);
         pstmt.setInt(14, advhr6d2);
         pstmt.setInt(15, advmin6d2);
         pstmt.setString(16, advam6d2);
         pstmt.setInt(17, advhr6d3);
         pstmt.setInt(18, advmin6d3);
         pstmt.setString(19, advam6d3);
         pstmt.setInt(20, advhr6d4);
         pstmt.setInt(21, advmin6d4);
         pstmt.setString(22, advam6d4);
         pstmt.setInt(23, advhr6d5);
         pstmt.setInt(24, advmin6d5);
         pstmt.setString(25, advam6d5);
         pstmt.setInt(26, advhr6d6);
         pstmt.setInt(27, advmin6d6);
         pstmt.setString(28, advam6d6);
         pstmt.setInt(29, advhr6d7);
         pstmt.setInt(30, advmin6d7);
         pstmt.setString(31, advam6d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 7;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m7days1);
         pstmt.setInt(5, m7days2);
         pstmt.setInt(6, m7days3);
         pstmt.setInt(7, m7days4);
         pstmt.setInt(8, m7days5);
         pstmt.setInt(9, m7days6);
         pstmt.setInt(10, m7days7);
         pstmt.setInt(11, advhr7d1);
         pstmt.setInt(12, advmin7d1);
         pstmt.setString(13, advam7d1);
         pstmt.setInt(14, advhr7d2);
         pstmt.setInt(15, advmin7d2);
         pstmt.setString(16, advam7d2);
         pstmt.setInt(17, advhr7d3);
         pstmt.setInt(18, advmin7d3);
         pstmt.setString(19, advam7d3);
         pstmt.setInt(20, advhr7d4);
         pstmt.setInt(21, advmin7d4);
         pstmt.setString(22, advam7d4);
         pstmt.setInt(23, advhr7d5);
         pstmt.setInt(24, advmin7d5);
         pstmt.setString(25, advam7d5);
         pstmt.setInt(26, advhr7d6);
         pstmt.setInt(27, advmin7d6);
         pstmt.setString(28, advam7d6);
         pstmt.setInt(29, advhr7d7);
         pstmt.setInt(30, advmin7d7);
         pstmt.setString(31, advam7d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      i = 8;

      if (!mship[i].equals( "" )) {     // if mship type specified

         pstmt = con.prepareStatement (
            "INSERT INTO mship5 (mship, mtimes, period, " +
            "days1, days2, days3, days4, days5, days6, days7, " +
            "advhrd1, advmind1, advamd1, advhrd2, advmind2, advamd2, advhrd3, advmind3, advamd3, " +
            "advhrd4, advmind4, advamd4, advhrd5, advmind5, advamd5, " +
            "advhrd6, advmind6, advamd6, advhrd7, advmind7, advamd7, " +
            "mpos, mposc, m9posc, mshipItem, mship9Item) " +
            "VALUES (?,?,?, " +
            "?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,?,?, " +
            "?,?,?,?,'')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, mship[i]);
         pstmt.setInt(2, mtimes[i]);
         pstmt.setString(3, period[i]);
         pstmt.setInt(4, m8days1);
         pstmt.setInt(5, m8days2);
         pstmt.setInt(6, m8days3);
         pstmt.setInt(7, m8days4);
         pstmt.setInt(8, m8days5);
         pstmt.setInt(9, m8days6);
         pstmt.setInt(10, m8days7);
         pstmt.setInt(11, advhr8d1);
         pstmt.setInt(12, advmin8d1);
         pstmt.setString(13, advam8d1);
         pstmt.setInt(14, advhr8d2);
         pstmt.setInt(15, advmin8d2);
         pstmt.setString(16, advam8d2);
         pstmt.setInt(17, advhr8d3);
         pstmt.setInt(18, advmin8d3);
         pstmt.setString(19, advam8d3);
         pstmt.setInt(20, advhr8d4);
         pstmt.setInt(21, advmin8d4);
         pstmt.setString(22, advam8d4);
         pstmt.setInt(23, advhr8d5);
         pstmt.setInt(24, advmin8d5);
         pstmt.setString(25, advam8d5);
         pstmt.setInt(26, advhr8d6);
         pstmt.setInt(27, advmin8d6);
         pstmt.setString(28, advam8d6);
         pstmt.setInt(29, advhr8d7);
         pstmt.setInt(30, advmin8d7);
         pstmt.setString(31, advam8d7);
         pstmt.setString(32, mpos[i]);
         pstmt.setString(33, mposc[i]);
         pstmt.setString(34, m9posc[i]);
         pstmt.setString(35, mshipItem[i]);

         pstmt.executeUpdate();          // execute the prepared stmt
         pstmt.close();
      }

      //
      // Now set the guest parms for each guest type specified (different table)
      //
      for (i=1; i<37; i++) {

         if (!guest[i].equals( "" )) {     // if guest type specified

            pstmt = con.prepareStatement (
               "INSERT INTO guest5 (guest, gOpt, " +
               "gpos, g9pos, gstItem, gst9Item) " +
               "VALUES (?,?,?,?,?,'')");

            pstmt.clearParameters();        // clear the parms
            pstmt.setString(1, guest[i]);
            pstmt.setInt(2, gOpt[i]);
            pstmt.setString(3, gpos[i]);
            pstmt.setString(4, g9pos[i]);
            pstmt.setString(5, gstItem[i]);

            pstmt.executeUpdate();          // execute the prepared stmt
            pstmt.close();
         }
      }


   }
   catch (Exception e4) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB - error4.");
      out.println("<BR>Exception: "+ e4.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   try {

      int [] counts = new int [156];
      long sdate = 0;
      int syear = 0;
      int smonth = 0;
      int sday = 0;
      int i2 = 0;
      String scourse= "";

      stmt = con.createStatement();           // create a statement

      //
      //  recreate stats2 -> stats5
      //
      stmt.executeUpdate("UPDATE stats2 SET " +
            "tmodeOldR9 = 0, tmodeOldR18 = 0");

      rs = stmt.executeQuery("SELECT * FROM stats2 WHERE date > 0");

      while (rs.next()) {

         sdate = rs.getLong(1);
         syear = rs.getInt(2);
         smonth = rs.getInt(3);
         sday = rs.getInt(4);
         scourse = rs.getString(5);

         i2 = 6;
         for (i=0; i<156; i++) {       // get all the counts (all integers)
           
            counts[i] = rs.getInt(i2);
            i2++;
         }
  
         pstmt = con.prepareStatement (
            "INSERT INTO stats5 (date, year, month, day, course, " +
             "mem1Rounds9, mem1Rounds18, mem2Rounds9, mem2Rounds18, " +
             "mem3Rounds9, mem3Rounds18, mem4Rounds9, mem4Rounds18, " +
             "mem5Rounds9, mem5Rounds18, mem6Rounds9, mem6Rounds18, " +
             "mem7Rounds9, mem7Rounds18, mem8Rounds9, mem8Rounds18, " +
             "mem9Rounds9, mem9Rounds18, mem10Rounds9, mem10Rounds18, " +
             "mem11Rounds9, mem11Rounds18, mem12Rounds9, mem12Rounds18, " +
             "mem13Rounds9, mem13Rounds18, mem14Rounds9, mem14Rounds18, " +
             "mem15Rounds9, mem15Rounds18, mem16Rounds9, mem16Rounds18, " +
             "mem17Rounds9, mem17Rounds18, mem18Rounds9, mem18Rounds18, " +
             "mem19Rounds9, mem19Rounds18, mem20Rounds9, mem20Rounds18, " +
             "mem21Rounds9, mem21Rounds18, mem22Rounds9, mem22Rounds18, " +
             "mem23Rounds9, mem23Rounds18, mem24Rounds9, mem24Rounds18, " +
             "mship1Rounds9, mship1Rounds18, mship2Rounds9, mship2Rounds18, " +
             "mship3Rounds9, mship3Rounds18, mship4Rounds9, mship4Rounds18, " +
             "mship5Rounds9, mship5Rounds18, mship6Rounds9, mship6Rounds18, " +
             "mship7Rounds9, mship7Rounds18, mship8Rounds9, mship8Rounds18, " +
             "mship9Rounds9, mship9Rounds18, mship10Rounds9, mship10Rounds18, " +
             "mship11Rounds9, mship11Rounds18, mship12Rounds9, mship12Rounds18, " +
             "mship13Rounds9, mship13Rounds18, mship14Rounds9, mship14Rounds18, " +
             "mship15Rounds9, mship15Rounds18, mship16Rounds9, mship16Rounds18, " +
             "mship17Rounds9, mship17Rounds18, mship18Rounds9, mship18Rounds18, " +
             "mship19Rounds9, mship19Rounds18, mship20Rounds9, mship20Rounds18, " +
             "mship21Rounds9, mship21Rounds18, mship22Rounds9, mship22Rounds18, " +
             "mship23Rounds9, mship23Rounds18, mship24Rounds9, mship24Rounds18, " +
             "gst1Rounds9, gst1Rounds18, gst2Rounds9, gst2Rounds18, " +
             "gst3Rounds9, gst3Rounds18, gst4Rounds9, gst4Rounds18, " +
             "gst5Rounds9, gst5Rounds18, gst6Rounds9, gst6Rounds18, " +
             "gst7Rounds9, gst7Rounds18, gst8Rounds9, gst8Rounds18, " +
             "gst9Rounds9, gst9Rounds18, gst10Rounds9, gst10Rounds18, " +
             "gst11Rounds9, gst11Rounds18, gst12Rounds9, gst12Rounds18, " +
             "gst13Rounds9, gst13Rounds18, gst14Rounds9, gst14Rounds18, " +
             "gst15Rounds9, gst15Rounds18, gst16Rounds9, gst16Rounds18, " +
             "gst17Rounds9, gst17Rounds18, gst18Rounds9, gst18Rounds18, " +
             "gst19Rounds9, gst19Rounds18, gst20Rounds9, gst20Rounds18, " +
             "gst21Rounds9, gst21Rounds18, gst22Rounds9, gst22Rounds18, " +
             "gst23Rounds9, gst23Rounds18, gst24Rounds9, gst24Rounds18, " +
             "gst25Rounds9, gst25Rounds18, gst26Rounds9, gst26Rounds18, " +
             "gst27Rounds9, gst27Rounds18, gst28Rounds9, gst28Rounds18, " +
             "gst29Rounds9, gst29Rounds18, gst30Rounds9, gst30Rounds18, " +
             "gst31Rounds9, gst31Rounds18, gst32Rounds9, gst32Rounds18, " +
             "gst33Rounds9, gst33Rounds18, gst34Rounds9, gst34Rounds18, " +
             "gst35Rounds9, gst35Rounds18, gst36Rounds9, gst36Rounds18, " +
             "tmode1R9, tmode1R18, tmode2R9, tmode2R18, tmode3R9, tmode3R18, tmode4R9, tmode4R18, " +
             "tmode5R9, tmode5R18, tmode6R9, tmode6R18, tmode7R9, tmode7R18, tmode8R9, tmode8R18, " +
             "tmode9R9, tmode9R18, tmode10R9, tmode10R18, tmode11R9, tmode11R18, tmode12R9, tmode12R18, " +
             "tmode13R9, tmode13R18, tmode14R9, tmode14R18, tmode15R9, tmode15R18, tmode16R9, tmode16R18, " +
             "tmodeOldR9, tmodeOldR18, " +
             "otherRounds9, otherRounds18, cartsRounds9, cartsRounds18, " +
             "caddyRounds9, caddyRounds18, pullcartRounds9, pullcartRounds18, " +
             "walkRounds9, walkRounds18, memnoshow9, memnoshow18, " +
             "gstnoshow9, gstnoshow18, mem9unknown, mem18unknown, mship9unknown, mship18unknown) " +
             "VALUES (?,?,?,?,?," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,0,0,0,0,0," +
             "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,0,0,0,0,0," +
             "0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
             "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
             "?,?,?,?,0,0,0,0,0,0,0,0,?,?,?,?,?,?,?,?)");

         pstmt.clearParameters();        // clear the parms
         pstmt.setLong(1, sdate);
         pstmt.setInt(2, syear);
         pstmt.setInt(3, smonth);
         pstmt.setInt(4, sday);
         pstmt.setString(5, scourse);
           
         i2 = 6;
         for (i=0; i<16; i++) {       // get the mem counts (mem1 - mem8)

            pstmt.setInt(i2, counts[i]);
            i2++;
         }

         for (i=32; i<48; i++) {       // get the mship counts (mship1 - mship8)

            pstmt.setInt(i2, counts[i]);
            i2++;
         }

         for (i=16; i<32; i++) {       // get the guest counts 

            pstmt.setInt(i2, counts[i]);
            i2++;
         }

         for (i=66; i<122; i++) {       // get the guest counts

            pstmt.setInt(i2, counts[i]);
            i2++;
         }

         for (i=122; i<156; i++) {       // get the tmode counts

            pstmt.setInt(i2, counts[i]);
            i2++;
         }

         pstmt.setInt(i2, counts[48]);   // Other Rounds
         i2++;
         pstmt.setInt(i2, counts[49]);
         i2++;

         for (i=58; i<66; i++) {       // get the No Show counts

            pstmt.setInt(i2, counts[i]);
            i2++;
         }
           
         pstmt.executeUpdate();          // execute the prepared stmt

         pstmt.close();

      }
      stmt.close();

   }
   catch (Exception e5) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB - error5.");
      out.println("<BR>Exception: "+ e5.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   try {


      //
      //   Add logins for ForeTees Support
      //
      pstmt = con.prepareStatement (
         "INSERT INTO login2 (username, password, message) VALUES ('admin4tea', 'fore0909', '')");   // admin user

      pstmt.clearParameters();        // clear the parms
      pstmt.executeUpdate();     // execute the prepared stmt

      pstmt.close();

      pstmt = con.prepareStatement (
         "INSERT INTO login2 (username, password, message) VALUES ('proshop4tea', 'fore0909', '')");   // proshop4tea user

      pstmt.clearParameters();        // clear the parms
      pstmt.executeUpdate();     // execute the prepared stmt

      pstmt.close();

      con.close();                           // close the connection to the club db

   }
   catch (Exception e6) {

      // Error connecting to db....

      out.println("<HTML><HEAD><TITLE>DB Connection Error Received</TITLE></HEAD>");
      out.println("<BODY><CENTER><H3>DB Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the DB - error6.");
      out.println("<BR>Exception: "+ e6.getMessage());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   out.println("<HTML><HEAD><TITLE>Upgrade Complete</TITLE></HEAD>");
   out.println("<BODY><CENTER><H3>Upgrade Complete</H3>");
   out.println("<BR><BR>Club " + club + " has been upgraded to V5.");
   out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>");
   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Illegal access by user - force user to login....
 // *********************************************************

 private void invalidUser(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Access Error - Redirect"));
   out.println("<BODY><CENTER><img src=\"/v5/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H2>Access Error</H2><BR>");
   out.println("<BR><BR>Sorry, you must login before attempting to access these features.<BR>");
   out.println("<BR><BR>Please <A HREF=\"/v5/servlet/Logout\">login</A>");
   out.println("</CENTER></BODY></HTML>");

 }

}
