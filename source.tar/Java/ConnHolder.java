/***************************************************************************************
 *   ConnHolder:  This class will provide a holder mechanism for the DB connection
 *                so that it may be saved in the session block.
 *
 *   Implements:  HttpSessionBindingListener (manages the session's lifecycle)
 *
 *   created: 12/05/2001   Bob P.
 *
 *   last updated:
 *
 *        1/24/05   Ver 5 - change club2 to club5.
 *        7/18/03   Enhancements (none) for Version 3 of the software.
 *        9/18/02   Enhancements for Version 2 of the software.
 *
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

class ConnHolder implements HttpSessionBindingListener, Serializable {
    
  private Connection con = null;
      
  public ConnHolder(Connection con) {

     this.con = con;                 // save the connection
     try {
        con.setAutoCommit(false);    // xactions can extend between pages
     }
     catch(SQLException e) {
     }
  }
    

  // This method will be called by others to get the saved connection

  public Connection getConn() {
      
     return con;    // return the connection
  }
       

  // This method will be called by the listener when the session is bound

  public void valueBound(HttpSessionBindingEvent event) {
     // ignore this Bind Event..
  }
       

  // This method will be called by the listener when the session is unbound

  public void valueUnbound(HttpSessionBindingEvent event) {

    SystemUtils.logError("Session Timed Out");
            
    Statement stmt = null;
    ResultSet rs = null;

    int count = 0;
   
     //
     //  Trace all logouts/timeouts (this always goes to v5 folder instead of the club folder - skip this)
     //
//     SystemUtils.sessionLog("Session Timed Out", "", "", "", "");                   // log it

     if (con != null) {
          
        try {

           //
           //  Adjust the number of users logged in
           //
           stmt = con.createStatement();        // create a statement

           rs = stmt.executeQuery("SELECT logins FROM club5");          // get # of users logged in

           if (rs.next()) {

              count = rs.getInt("logins");
           }
           stmt.close();

           //
           //  adjust the count if not already zero
           //
           if (count > 0) {

              count--;
           }

           PreparedStatement pstmt = con.prepareStatement (
                    "UPDATE club5 SET logins = ?");                  // set new count

           pstmt.clearParameters();
           pstmt.setInt(1, count);
           pstmt.executeUpdate();

           pstmt.close();

        }
        catch (SQLException e) {
            SystemUtils.logError("valueUnbound: read/update club5 error: " + e.toString());
        }

        try {

           con.rollback();    // abandon any unfinished transactions

           //con.close();       // return/close the connection (already closed - rollback closes??)

        }
        catch (Exception e) {
            SystemUtils.logError("valueUnbound: rollback error: " + e.toString());
        }
        
        try {

           //con.rollback();    // abandon any unfinished transactions

           con.close();       // return/close the connection (already closed - rollback closes??)

        }
        catch (Exception e) {
            SystemUtils.logError("valueUnbound: close error: " + e.toString());
        }
     } else {
          
        SystemUtils.logError("valueUnbound: con == null");
     }
    con = null;
  }
}
