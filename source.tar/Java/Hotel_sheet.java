/***************************************************************************************
 *   Hotel_sheet:  This servlet will process the 'View Tee Sheet' request from
 *                    the Hotel's Select page.
 *
 *
 *   called by:  Hotel_select (doPost)
 *               Hotel_slot (via Hotel_jump on a cancel)
 *
 *
 *   created: 11/18/2003   Bob P.
 *
 *   last updated:        ******* keep this accurate *******
 *
 *        3/06/08   Cordillera - change custom lodge time check to change bgcolor even when allow=false already set.
 *       11/16/07   Add -ALL- option for course selection  (Case #1111)
 *        1/18/07   Cordillera - change the date checks for custom rest's.
 *        4/20/06   Cordillera - do not allow members to access tee times on the day of (today).
 *        3/08/05   Updated calendars to use new calv30 version - the dynamic calendar is now sticky
 *        4/03/05   Cordillera - add some custom hotel restrictions.
 *       12/20/04   Sawgrass - do not allow more than 16 tee times per day for hotel.
 *                             Also, do not allow hotel to change a tee time within 24 hrs of time.
 *        9/20/04   Ver 5 - change getClub from SystemUtils to common.
 *                     - remove adv_hr and adv_min as not needed for hotel user.
 *        3/10/04   RDP Change calendars to js cals for 365 day support.
 *        2/06/04   Add support for configurable transportation modes.
 *       12/15/02   Bob P.   Do not show member restriction in legend if showit=no.
 *       01/07/04   JAG  Modified to match new color scheme
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.util.zip.*;
import java.sql.*;
import java.lang.Math;

// foretees imports
import com.foretees.common.DaysAdv;
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.BigDate;
import com.foretees.common.parmClub;
import com.foretees.common.getClub;
import com.foretees.common.cordilleraCustom;


public class Hotel_sheet extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //*****************************************************
 // Process the return from Hotel_jump
 //*****************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   doPost(req, resp);      // call doPost processing

 }


 //*****************************************************
 // Process the request from Hotel_select
 //*****************************************************
 //

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


   resp.setContentType("text/html");
   PrintWriter out;


   PreparedStatement pstmt = null;
   PreparedStatement pstmt5 = null;
   Statement stmt = null;
   Statement stmtc = null;
   ResultSet rs = null;
   ResultSet rs2 = null;
   ResultSet rs3 = null;
   ResultSet rs4 = null;

   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

   String [] mm_table = { "inv", "January", "February", "March", "April", "May", "June", "July", "August",
                          "September", "October", "November", "December" };

   //
   //  Num of days in each month
   //
   int [] numDays_table = { 0, 31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   //
   //  Num of days in Feb indexed by year starting with 2000 - 2040
   //
   int [] feb_table = { 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29,  +
                            28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29 };


   //
   //  use GZip (compression) if supported by browser
   //
   String encodings = req.getHeader("Accept-Encoding");               // browser encodings

   if ((encodings != null) && (encodings.indexOf("gzip") != -1)) {    // if browser supports gzip

      OutputStream out1 = resp.getOutputStream();
      out = new PrintWriter(new GZIPOutputStream(out1), false);       // use compressed output stream
      resp.setHeader("Content-Encoding", "gzip");                     // indicate gzip

   } else {

      out = resp.getWriter();                                         // normal output stream
   }

   HttpSession session = SystemUtils.verifyHotel(req, out);             // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/motel_mainleft.htm\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

   int hr = 0;
   int min = 0;
   int tee_time = 0;
   int year = 0;
   int month = 0;
   int day = 0;
   int day_num = 0;
   int type = 0;                       // event type
   int shotgun = 1;                    // event type = shotgun
   int in_use = 0;
   int sawgrassCount = 0;
     
   short fb = 0;

   String name = "";
   String num = "";
   String submit = "";
   String event = "";
   String ecolor = "";
   String rest = "";
   String rcolor = "";
   String rest5 = "";
   String bgcolor5 = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String ampm = "";
   String event_rest = "";
   String bgcolor = "";
   String sfb = "";

   String event1 = "";       // for legend - max 2 events, 4 rest's, 4 guest rest's
   String ecolor1 = "";
   String event2 = "";
   String ecolor2 = "";
   String rest1 = "";
   String rcolor1 = "";
   String rest2 = "";
   String rcolor2 = "";
   String rest3 = "";
   String rcolor3 = "";
   String rest4 = "";
   String rcolor4 = "";
   String grest1 = "";
   String grest2 = "";
   String grest3 = "";
   String grest4 = "";
   String gcolor = "";
   String gcolor2 = "";

   String blocker = "";
   String adv_ampm = "";

   String mem1 = "";
   String mem2 = "";
   String mem3 = "";
   String mem4 = "";
   String mem5 = "";
   String mem6 = "";
   String mem7 = "";
   String mem8 = "";

   String rcourse = "";
   String grest_recurr = "";
   String grest_color = "";

   String rest_recurr = "";
   String rest_name = "";
   String sfb2 = "";
   String rest_color = "";
   String rest_fb = "";
   String jumps = "";
   String lottery = "";

   String calDate = "";

   float hndcp1 = 0;
   float hndcp2 = 0;
   float hndcp3 = 0;
   float hndcp4 = 0;
   float hndcp5 = 0;

   int days1 = 0;               // days in advance that Hotels can make tee times
   int days2 = 0;               //         one per day of week (Sun - Sat)
   int days3 = 0;
   int days4 = 0;
   int days5 = 0;
   int days6 = 0;
   int days7 = 0;
   int hndcp = 0;
   int index = 0;
   int index2 = 0;
   int days = 0;
   int multi = 0;               // multiple course support
   int i = 0;
   int i2 = 0;
   int fives = 0;               // support 5-somes
   int g1 = 0;                  // guest indicators
   int g2 = 0;
   int g3 = 0;
   int g4 = 0;
   int g5 = 0;
   int p91;
   int p92;
   int p93;
   int p94;
   int p95;
   int ind = 0;
   int j = 0;
   int jump = 0;
   int lott = 0;
   int courseCount = 0;

   int cal_time = 0;            // calendar time for compares

   boolean allow = true;
   boolean block = false;
   boolean restrictAll = false;

   //
   //  Array to hold the course names
   //
   int cMax = 21;                                       // max of 20 courses + -ALL-
   String courseName = "";
   String [] course = new String [cMax];            // max of 20 courses per club
   int [] fivesA = new int [cMax];                  // array to hold 5-some option for each course
   int fivesALL = 0;
   String [] course_color = new String [cMax];

   int tmp_i = 0; // counter for course[], shading of course field

   // set default course colors
   course_color[0] = "#F5F5DC"; // beige (4 shades)
   course_color[1] = "#DDDDBE";
   course_color[2] = "#B3B392";
   course_color[3] = "#8B8970";
   course_color[4] = "#E7F0E7"; // greens (5 shades)
   course_color[5] = "#C6D3C6";
   course_color[6] = "#95B795";
   course_color[7] = "#648A64";
   course_color[8] = "#407340";
   course_color[9] = "#FFFFFF"; // new colors needed
   course_color[10] = "#FFFFFF";
   course_color[11] = "#FFFFFF";
   course_color[12] = "#FFFFFF";
   course_color[13] = "#FFFFFF";
   course_color[14] = "#FFFFFF";
   course_color[15] = "#FFFFFF";
   course_color[16] = "#FFFFFF";
   course_color[17] = "#FFFFFF";
   course_color[18] = "#FFFFFF";
   course_color[19] = "#FFFFFF";
   
   //
   //  Array to hold the Guest Restriction's guest types
   //
   String [] rguest = new String [36];            // max of 36 guest types
   String [] xguest = new String [36];            // max of 36 guest types per hotel user

   //
   //  Array to hold the 'Days in Advance' value for each day of the week
   //
   int [] advdays = new int [7];                        // 0=Sun, 6=Sat

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   //  parm block to hold the course parameters
   //
   parmCourse parmc = new parmCourse();          // allocate a parm block

   //
   //  Get this user's username and club name
   //
   String user = (String)session.getAttribute("user");
   String club = (String)session.getAttribute("club");      // get club name

   //
   //  Check if we came from Hotel_select - If so, calculate the index value passed
   //
   if (req.getParameter("calDate") != null) {

      //
      //************************************************************
      //  From Hotel_select
      //
      //   Convert the date received from mm/dd/yyyy to 'index' value
      //
      //   (index no longer passed from Hotel_select as of V4)
      //
      //************************************************************
      //
      //
      //  make sure we have the date value
      //
      calDate = req.getParameter("calDate");       //  get the date requested (mm/dd/yyyy)

      //
      //  Convert the index value from string to int
      //
      StringTokenizer tok = new StringTokenizer( calDate, "/" );     // space is the default token - use '/'

      num = tok.nextToken();                    // get the mm value

      month = Integer.parseInt(num);

      num = tok.nextToken();                    // get the dd value

      day = Integer.parseInt(num);

      num = tok.nextToken();                    // get the yyyy value

      year = Integer.parseInt(num);

      //
      //  Get today's date and then set the requested date to get the day name, etc.
      //
      Calendar cal = new GregorianCalendar();       // get todays date

      cal.set(Calendar.YEAR, year);                 // change to requested date
      cal.set(Calendar.MONTH, month-1);
      cal.set(Calendar.DAY_OF_MONTH, day);

      day_num = cal.get(Calendar.DAY_OF_WEEK);          // day of week (01 - 07)

      //
      // Calculate the number of days between today and the date requested (=> ind)
      //
      BigDate today = BigDate.localToday();                 // get today's date
      BigDate thisdate = new BigDate(year, month, day);     // get requested date

      index = (thisdate.getOrdinal() - today.getOrdinal());   // number of days between
        
      name = "i" + index;               // create index parm to pass to _slot 

   } else {

      //
      //    The name of the submit button is an index value preceeded by the letter 'i' (must start with alpha)
      //    (0 = today, 1 = tomorrow, etc.)
      //
      //    Other parms passed:  course - name of course
      //
      name = "";                                      // init

      Enumeration enum1 = req.getParameterNames();     // get the parm names passed

      loop1:
      while (enum1.hasMoreElements()) {

         name = (String) enum1.nextElement();          // get name of parm

         if (name.startsWith( "i" )) {

            break loop1;                              // done - exit while loop
         }
      }

      //
      //  make sure we have the index value
      //
      if (!name.startsWith( "i" )) {

         out.println(SystemUtils.HeadTitle("Procedure Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H3>Access Procdure Error</H3>");
         out.println("<BR><BR>Required Parameter is Missing - Hotel_sheet.");
         out.println("<BR>Please exit and try again.");
         out.println("<BR><BR>If problem persists, report this error to your golf shop staff.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/hotel_mainleft.htm\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
         return;
      }

      //
      //  Convert the index value from string to int
      //
      StringTokenizer tok = new StringTokenizer( name, "i" );     // space is the default token - use 'i'

      num = tok.nextToken();                // get just the index number (name= parm must start with alpha)

      try {
         index = Integer.parseInt(num);
      }
      catch (NumberFormatException e) {
         // ignore error
      }
   }

   index2 = index;     // save for later (number of days from today)

   //
   //  Get the golf course name requested
   //
   String courseName1 = req.getParameter("course");

   if (courseName1 == null || courseName1.equals( "null" )) {

      courseName1 = "";     // change to other null
   }

   //
   //  get the jump parm if provided (location on page to jump to)
   //
   if (req.getParameter("jump") != null) {

      jumps = req.getParameter("jump");         //  jump index value for where to jump to on the page

      try {
         jump = Integer.parseInt(jumps);
      }
      catch (NumberFormatException e) {
         // ignore error
         jump = 0;
      }
   }

   //
   //   Adjust jump so we jump to the selected line minus 3 so its not on top of page
   //
   if (jump > 3) {

      jump = jump - 3;

   } else {

      jump = 0;         // jump to top of page
   }

   //
   //  Get today's date and then use the value passed to locate the requested date
   //
   Calendar cal = new GregorianCalendar();       // get todays date

   cal.add(Calendar.DATE,index);                  // roll ahead 'index' days

   year = cal.get(Calendar.YEAR);
   month = cal.get(Calendar.MONTH);
   day = cal.get(Calendar.DAY_OF_MONTH);
   day_num = cal.get(Calendar.DAY_OF_WEEK);             // day of week (01 - 07)

   month = month + 1;                            // month starts at zero

   String day_name = day_table[day_num];         // get name for day

   long date = year * 10000;                     // create a date field of yyyymmdd
   date = date + (month * 100);
   date = date + day;                            // date = yyyymmdd (for comparisons)

   long dateShort = (month * 100) + day;         // create date of mmdd for customs
  
   i = 0;
   while (i < cMax) {

      course[i] = "";       // init the course array
      i++;
   }
   
   try {

      //
      // Get the Multiple Course Option, guest types and time for advance from the club db
      //
      getClub.getParms(con, parm);        // get the club parms

      multi = parm.multi;
      
      if (multi != 0) {           // if multiple courses supported for this club

         i = 0;

         //
         //  Get the names of all courses for this club
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT courseName " +
                                 "FROM clubparm2 WHERE first_hr != 0");

         while (rs.next() && i < cMax) {

            courseName = rs.getString(1);

            course[i] = courseName;      // add course name to array
            i++;
         }
         stmt.close();  
         
         if (i > 1 && i < cMax) {                // if more than 1 course, add -ALL- option

            course[i] = "-ALL-";
            i++;
         }
         
         if (i > cMax) {               // make sure we didn't go past max

            courseCount = cMax;

         } else {

            courseCount = i;              // save number of courses
         }
         
      } else {
          
            courseCount = 1;
      }
  
   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<BR><BR><H2>Database Access Error</H2>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>Error loading course array: " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/hotel_mainleft.htm\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }
   
   out.println("<!-- courseCount="+courseCount+" -->");
   
   try {
          
      //
      //  Get the System Parameters for this Course
      //
      if (courseName1.equals( "-ALL-" )) {

         //
         //  Check all courses for 5-some support
         //
         i = 0;
         loopc:
         while (i < cMax) {

            courseName = course[i];       // get a course name

            if (!courseName.equals( "-ALL-" )) {   // skip if -ALL-

               if (courseName.equals( "" )) {      // done if null
                  break loopc;
               }
               getParms.getCourse(con, parmc, courseName);
               fivesA[i] = parmc.fives;      // get fivesome option
               if (fivesA[i] == 1) {
                  fives = 1;
               }
            }
            i++;
         }

      } else {       // single course requested

         getParms.getCourse(con, parmc, courseName1);

         fives = parmc.fives;      // get fivesome option
      }

      fivesALL = fives;            // save 5-somes option for table display below
      
   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<BR><BR><H2>Database Access Error</H2>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>Error determining five-some support for course " + courseName + ": " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/hotel_mainleft.htm\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }
   
   // main try catch for this page
   try {
/*
      //
      //  Get the walk/cart options available, and the 5-some option
      //
      getParms.getCourse(con, parmc, courseName1);

      fives = parmc.fives;      // get fivesome option
*/

      PreparedStatement pstmt2 = con.prepareStatement (
         "SELECT * " +
         "FROM hotel3 WHERE username = ?");

      pstmt2.clearParameters();         // clear the parms
      pstmt2.setString(1, user);        // put the username field in statement
      rs = pstmt2.executeQuery();       // execute the prepared stmt

      if (rs.next()) {

         days1 = rs.getInt("days1");
         days2 = rs.getInt("days2");
         days3 = rs.getInt("days3");
         days4 = rs.getInt("days4");
         days5 = rs.getInt("days5");
         days6 = rs.getInt("days6");
         days7 = rs.getInt("days7");
         parm.guest[0] = rs.getString("guest1");       // save in club parms
         parm.guest[1] = rs.getString("guest2");
         parm.guest[2] = rs.getString("guest3");
         parm.guest[3] = rs.getString("guest4");
         parm.guest[4] = rs.getString("guest5");
         parm.guest[5] = rs.getString("guest6");
         parm.guest[6] = rs.getString("guest7");
         parm.guest[7] = rs.getString("guest8");
         parm.guest[8] = rs.getString("guest9");
         parm.guest[9] = rs.getString("guest10");
         parm.guest[10] = rs.getString("guest11");
         parm.guest[11] = rs.getString("guest12");
         parm.guest[12] = rs.getString("guest13");
         parm.guest[13] = rs.getString("guest14");
         parm.guest[14] = rs.getString("guest15");
         parm.guest[15] = rs.getString("guest16");
         parm.guest[16] = rs.getString("guest17");
         parm.guest[17] = rs.getString("guest18");
         parm.guest[18] = rs.getString("guest19");
         parm.guest[19] = rs.getString("guest20");
         parm.guest[20] = rs.getString("guest21");
         parm.guest[21] = rs.getString("guest22");
         parm.guest[22] = rs.getString("guest23");
         parm.guest[23] = rs.getString("guest24");
         parm.guest[24] = rs.getString("guest25");
         parm.guest[25] = rs.getString("guest26");
         parm.guest[26] = rs.getString("guest27");
         parm.guest[27] = rs.getString("guest28");
         parm.guest[28] = rs.getString("guest29");
         parm.guest[29] = rs.getString("guest30");
         parm.guest[30] = rs.getString("guest31");
         parm.guest[31] = rs.getString("guest32");
         parm.guest[32] = rs.getString("guest33");
         parm.guest[33] = rs.getString("guest34");
         parm.guest[34] = rs.getString("guest35");
         parm.guest[35] = rs.getString("guest36");
      }
      pstmt2.close();


      //
      //  init the guest types, and save them for tests below
      //
      for (i = 0; i < parm.MAX_Guests; i++) {

         xguest[i] = "";

         if (!parm.guest[i].equals( "" )) {

            xguest[i] = parm.guest[i];
         }
      }

      //
      //  Check for any guest restrictions for this hotel's guests
      //
      pstmt5 = con.prepareStatement (
         "SELECT * " +
         "FROM guestres2 WHERE sdate <= ? AND edate >= ?");

      pstmt5.clearParameters();        // clear the parms
      pstmt5.setLong(1, date);
      pstmt5.setLong(2, date);
      rs2 = pstmt5.executeQuery();      // execute the prepared stmt

      while (rs2.next()) {

         grest_recurr = rs2.getString("recurr");
         rguest[0] = rs2.getString("guest1");
         rguest[1] = rs2.getString("guest2");
         rguest[2] = rs2.getString("guest3");
         rguest[3] = rs2.getString("guest4");
         rguest[4] = rs2.getString("guest5");
         rguest[5] = rs2.getString("guest6");
         rguest[6] = rs2.getString("guest7");
         rguest[7] = rs2.getString("guest8");
         rcourse = rs2.getString("courseName");
         rest_fb = rs2.getString("fb");
         gcolor2 = rs2.getString("color");
         rguest[8] = rs2.getString("guest9");
         rguest[9] = rs2.getString("guest10");
         rguest[10] = rs2.getString("guest11");
         rguest[11] = rs2.getString("guest12");
         rguest[12] = rs2.getString("guest13");
         rguest[13] = rs2.getString("guest14");
         rguest[14] = rs2.getString("guest15");
         rguest[15] = rs2.getString("guest16");
         rguest[16] = rs2.getString("guest17");
         rguest[17] = rs2.getString("guest18");
         rguest[18] = rs2.getString("guest19");
         rguest[19] = rs2.getString("guest20");
         rguest[20] = rs2.getString("guest21");
         rguest[21] = rs2.getString("guest22");
         rguest[22] = rs2.getString("guest23");
         rguest[23] = rs2.getString("guest24");
         rguest[24] = rs2.getString("guest25");
         rguest[25] = rs2.getString("guest26");
         rguest[26] = rs2.getString("guest27");
         rguest[27] = rs2.getString("guest28");
         rguest[28] = rs2.getString("guest29");
         rguest[29] = rs2.getString("guest30");
         rguest[30] = rs2.getString("guest31");
         rguest[31] = rs2.getString("guest32");
         rguest[32] = rs2.getString("guest33");
         rguest[33] = rs2.getString("guest34");
         rguest[34] = rs2.getString("guest35");
         rguest[35] = rs2.getString("guest36");

         //
         //  Check if course matches that specified in restriction
         //
         if (rcourse.equals( "-ALL-" ) || rcourse.equals( courseName1 ) || courseName1.equals( "-ALL-" )) {

            //
            //  We must check the recurrence for this day (Monday, etc.) and guest types
            //
            //     guestx = guest types specified for this hotel user
            //     rguestx = guest types from restriction gotten above
            //
            if ((grest_recurr.equalsIgnoreCase( "every " + day_name )) ||
                (grest_recurr.equalsIgnoreCase( "every day" )) ||
                ((grest_recurr.equalsIgnoreCase( "all weekdays" )) &&
                 (!day_name.equalsIgnoreCase( "saturday" )) &&
                 (!day_name.equalsIgnoreCase( "sunday" ))) ||
                ((grest_recurr.equalsIgnoreCase( "all weekends" )) &&
                 (day_name.equalsIgnoreCase( "saturday" ))) ||
                ((grest_recurr.equalsIgnoreCase( "all weekends" )) &&
                 (day_name.equalsIgnoreCase( "sunday" )))) {

               i = 0;
               while (i < parm.MAX_Guests) {     // check all guest types for this hotel user

                  if (!parm.guest[i].equals( "" )) {  // if guest type specified for user (must be at least 1)

                     i2 = 0;
                     ploop1:
                     while (i2 < parm.MAX_Guests) {     // check all guest types for this restriction

                        if ( rguest[i2].equals( parm.guest[i] )) {

                           if ((!parm.guest[i].equals( grest1 )) && (grest1.equals( "" ))) {

                              grest1 = parm.guest[i];   // indicate guest restriction for this user today
                              gcolor = gcolor2;         // set color 

                           } else {

                              if ((!parm.guest[i].equals( grest1 )) && (!parm.guest[i].equals( grest2 )) && (grest2.equals( "" ))) {

                                 grest2 = parm.guest[i];  // indicate guest restriction for this user today

                                 if (!gcolor2.equals( "" )) {
                                    gcolor = gcolor2;         // set color
                                 }

                              } else {

                                 if ((!parm.guest[i].equals( grest1 )) && (!parm.guest[i].equals( grest2 )) && (!parm.guest[i].equals( grest3 )) &&
                                     (grest3.equals( "" ))) {

                                    grest3 = parm.guest[i];   // indicate guest restriction for this user today

                                    if (!gcolor2.equals( "" )) {
                                       gcolor = gcolor2;         // set color
                                    }

                                 } else {

                                    if ((!parm.guest[i].equals( grest1 )) && (!parm.guest[i].equals( grest2 )) && (!parm.guest[i].equals( grest3 )) &&
                                        (!parm.guest[i].equals( grest4 )) && (grest4.equals( "" ))) {

                                       grest4 = parm.guest[i]; // indicate guest restriction for this user today
                                       
                                       if (!gcolor2.equals( "" )) {
                                          gcolor = gcolor2;         // set color
                                       }
                                    }
                                 }
                              }
                           }
                           break ploop1;
                        }
                        i2++;
                     }
                  }
                  i++;
               }        // end of WHILE hotel user guest types
            }
         }      // end of IF course matches
      }   // end of loop3 while loop (while guest restrictions exist)

      pstmt5.close();

      //
      //  set color if not specified
      //
      if (gcolor.equals( "" )) {

         gcolor = "F5F5DC";
      }


      //
      //   Statements to find any restrictions or events for today
      //
      String string7b = "";
      String string7c = "";
      
      if (courseName1.equals( "-ALL-" )) {
         string7b = "SELECT name, recurr, color FROM restriction2 WHERE sdate <= ? AND edate >= ? " +
                    "AND showit = 'Yes' ORDER BY stime";
      } else {
         string7b = "SELECT name, recurr, color FROM restriction2 WHERE sdate <= ? AND edate >= ? " +
                    "AND (courseName = ? OR courseName = '-ALL-') AND showit = 'Yes' ORDER BY stime";
      }

      if (courseName1.equals( "-ALL-" )) {
         string7c = "SELECT name, color, act_hr, act_min FROM events2b WHERE date = ? ORDER BY stime";
      } else {
         string7c = "SELECT name, color, act_hr, act_min FROM events2b WHERE date = ? " +
                    "AND (courseName = ? OR courseName = '-ALL-') ORDER BY stime";
      }

      PreparedStatement pstmt7b = con.prepareStatement (string7b);
      PreparedStatement pstmt7c = con.prepareStatement (string7c);

      //
      //  Scan the events, restrictions to build the legend
      //
      pstmt7b.clearParameters();          // clear the parms
      pstmt7b.setLong(1, date);
      pstmt7b.setLong(2, date);

      if (!courseName1.equals( "-ALL-" )) {
         pstmt7b.setString(3, courseName1);
      }
           
      rs = pstmt7b.executeQuery();      // find all matching restrictions, if any

      while (rs.next()) {

         rest = rs.getString(1);
         rest_recurr = rs.getString(2);
         rcolor = rs.getString(3);

         //
         //  We must check the recurrence for this day (Monday, etc.)
         //
         if ((rest_recurr.equals( "Every " + day_name )) ||          // if this day
             (rest_recurr.equalsIgnoreCase( "every day" )) ||        // or everyday
             ((rest_recurr.equalsIgnoreCase( "all weekdays" )) &&    // or all weekdays (and this is one)
               (!day_name.equalsIgnoreCase( "saturday" )) &&
               (!day_name.equalsIgnoreCase( "sunday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&    // or all weekends (and this is one)
              (day_name.equalsIgnoreCase( "saturday" ))) ||
             ((rest_recurr.equalsIgnoreCase( "all weekends" )) &&
              (day_name.equalsIgnoreCase( "sunday" )))) {


            if ((!rest.equals( rest1 )) && (rest1.equals( "" ))) {

               rest1 = rest;
               rcolor1 = rcolor;

               if (rcolor.equalsIgnoreCase( "default" )) {

                  rcolor1 = "#F5F5DC";
               }

            } else {

               if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (rest2.equals( "" ))) {

                  rest2 = rest;
                  rcolor2 = rcolor;

                  if (rcolor.equalsIgnoreCase( "default" )) {

                     rcolor2 = "#F5F5DC";
                  }

               } else {

                  if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (!rest.equals( rest3 )) && (rest3.equals( "" ))) {

                     rest3 = rest;
                     rcolor3 = rcolor;

                     if (rcolor.equalsIgnoreCase( "default" )) {

                        rcolor3 = "#F5F5DC";
                     }

                  } else {

                     if ((!rest.equals( rest1 )) && (!rest.equals( rest2 )) && (!rest.equals( rest3 )) &&
                         (!rest.equals( rest4 )) && (rest4.equals( "" ))) {

                        rest4 = rest;
                        rcolor4 = rcolor;

                        if (rcolor.equalsIgnoreCase( "default" )) {

                           rcolor4 = "#F5F5DC";
                        }
                     }
                  }
               }
            }
         }
      }                  // end of while
      pstmt7b.close();

      pstmt7c.clearParameters();          // clear the parms
      pstmt7c.setLong(1, date);

      if (!courseName1.equals( "-ALL-" )) {
         pstmt7c.setString(2, courseName1);
      }

      rs = pstmt7c.executeQuery();      // find all matching events, if any

      while (rs.next()) {

         event = rs.getString(1);
         ecolor = rs.getString(2);

         if ((!event.equals( event1 )) && (event1.equals( "" ))) {

            event1 = event;
            ecolor1 = ecolor;

            if (ecolor.equalsIgnoreCase( "default" )) {

               ecolor1 = "#F5F5DC";
            }

          } else {

            if ((!event.equals( event1 )) && (!event.equals( event2 )) && (event2.equals( "" ))) {

               event2 = event;
               ecolor2 = ecolor;

               if (ecolor.equalsIgnoreCase( "default" )) {

                  ecolor2 = "#F5F5DC";
               }
            }
         }

      }                  // end of while
      pstmt7c.close();


      //
      //  Build the HTML page to prompt user for a specific time slot
      //
      out.println("<HTML><!--Copyright notice:  This software (including any images, servlets, applets, photographs, animations, video, music and text incorporated into the software) ");
      out.println("is the proprietary property of ForeTees, LLC or its suppliers and its use, modification and distribution are protected ");
      out.println("and limited by United States copyright laws and international treaty provisions and all other applicable national laws. ");
      out.println("Reproduction is prohibited except for backup purposes.-->");
      out.println("<HEAD>");
      out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
      out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
      out.println("<meta http-equiv=\"Content-Style-Type\" content=\"text/css\">");
      out.println("<TITLE>Foretees Hotel Tee Sheet Page </TITLE>");
      out.println("<script language='JavaScript'>");          // Jump script
      out.println("<!--");

      out.println("function jumpToHref(anchorstr) {");

      out.println("if (location.href.indexOf(anchorstr)<0) {");

      out.println("location.href=anchorstr; }");
      out.println("}");
      out.println("// -->");
      out.println("</script>");                               // End of script

      out.println("</HEAD>");

      // include files for dynamic calendars
      out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/calv30-styles.css\">");
      out.println("<script type=\"text/javascript\" src=\"/" +rev+ "/calv30-scripts.js\"></script>");

//      out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/cal-styles.css\">");
//      out.println("<script language=\"javascript\" src=\"/" +rev+ "/cal-scripts.js\"></script>");


      out.println("<body onLoad='jumpToHref(\"#jump" + jump + "\");' bgcolor=\"#ccccaa\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\"></font><center>");

      out.println("<a name=\"jump0\"></a>");     // create a default jump label (start of page)

      out.println("<table border=\"0\" align=\"center\" width=\"95%\">");         // table for main page

      out.println("<tr><td valign=\"top\" align=\"center\">");

      //**********************************************************
      //  Build calendar for selecting a new day
      //**********************************************************

      //
      //  Get today's date and setup parms to use when building the calendar
      //
      Calendar cal2 = new GregorianCalendar();        // get todays date
      int year2 = cal2.get(Calendar.YEAR);
      int month2 = cal2.get(Calendar.MONTH);
      int day2 = cal2.get(Calendar.DAY_OF_MONTH);
      int day_num2 = cal2.get(Calendar.DAY_OF_WEEK);  // day of week (01 - 07)
      int cal_am_pm = cal.get(Calendar.AM_PM);        // current time
      int cal_hour = cal.get(Calendar.HOUR);
      int cal_hourDay = cal.get(Calendar.HOUR_OF_DAY);
      int cal_min = cal.get(Calendar.MINUTE);

      cal_time = (cal_hourDay * 100) + cal_min;

      cal_time = SystemUtils.adjustTime(con, cal_time);   // adjust the time

      if (cal_time < 0) {          // if negative, then we went back or ahead one day

         cal_time = 0 - cal_time;        // convert back to positive value

         if (cal_time < 100) {           // if hour is zero, then we rolled ahead 1 day

            //
            // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
            //
            cal.add(Calendar.DATE,1);                     // get next day's date

            year2 = cal.get(Calendar.YEAR);
            month2 = cal.get(Calendar.MONTH);
            day2 = cal.get(Calendar.DAY_OF_MONTH);
            day_num2 = cal.get(Calendar.DAY_OF_WEEK);        // day of week (01 - 07)

         } else {                        // we rolled back 1 day

            //
            // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
            //
            cal.add(Calendar.DATE,-1);                     // get yesterday's date

            year2 = cal.get(Calendar.YEAR);
            month2 = cal.get(Calendar.MONTH);
            day2 = cal.get(Calendar.DAY_OF_MONTH);
            day_num2 = cal.get(Calendar.DAY_OF_WEEK);        // day of week (01 - 07)
         }
      }

      int today2 = day2;                              // save today's number

      month2 = month2 + 1;                            // month starts at zero

      String mm = mm_table[month2];                   // month name

      int numDays = numDays_table[month2];            // number of days in month

      if (numDays == 0) {                             // if Feb

         int leapYear = year2 - 2000;
         numDays = feb_table[leapYear];               // get days in Feb
      }

      //
      //  put the 'days in advance' values in an array to be used when building the calendars below
      //
      advdays[0] = days1;
      advdays[1] = days2;
      advdays[2] = days3;
      advdays[3] = days4;
      advdays[4] = days5;
      advdays[5] = days6;
      advdays[6] = days7;

      //
      // determine days in advance for this day (day of sheet)
      //
      days = day_num;                   // get this day's number value (1 - 7)
      days--;                           // convert to index
      days = advdays[days];             // get days in advance

      int count = 0;                    // init day counter
      int col = 0;                       // init column counter
      int d = 0;                         // 'days in advance' value for current day of week
      int max = 90;                      // max # of days to display


      //
      //  If today, or the day before and after 5:00 PM MT, then do not allow members to access any tee times.
      //
      if ((index == 0 || (index == 1 && cal_time > 1700)) &&
           club.equals( "cordillera" )) {

         restrictAll = true;         // indicate no member access
      }

      //
      //  If multiple courses, then add a drop-down box for course names
      //
      if (multi != 0) {           // if multiple courses supported for this club

         String caldate = month + "/" + day + "/" + year;       // create date for _jump

         //
         //  use 2 forms so you can switch by clicking either a course or a date
         //
         if (courseCount < 5) {        // if < 5 courses, use buttons

            i = 0;
            courseName = course[i];      // get first course name from array

            out.println("<p><font size=\"3\">");
            out.println("<b>Select Course or Date:</b>&nbsp;&nbsp;");

            //while ((!courseName.equals( "" )) && (i < 6)) {
            while (i < courseCount) {    // allow one more for -ALL-

               out.println("<a href=\"/" +rev+ "/servlet/Hotel_sheet?jump=select&calDate=" +caldate+ "&course=" +course[i]+ "\" style=\"color:blue\" target=\"bot\" title=\"Switch to new course\" alt=\"" +course[i]+ "\">");
               out.println(course[i]+ "</a>");
               out.println("&nbsp;&nbsp;&nbsp;");

               i++;
               //courseName = course[i];      // get course name from array
            }
            out.println("</p>");

         } else {     // use drop-down menu

            out.println("<form action=\"/" +rev+ "/servlet/Hotel_sheet\" method=\"post\" name=\"cform\" target=\"bot\">");
            out.println("<input type=\"hidden\" name=\"jump\" value=\"select\">");
            out.println("<input type=\"hidden\" name=\"calDate\" value=\"" +caldate+ "\">");

            i = 0;
            courseName = course[i];      // get first course name from array

            out.println("<b>Course:</b>&nbsp;&nbsp;");
            out.println("<div id=\"awmobject1\">");                      // allow menus to show over this box
            out.println("<select size=\"1\" name=\"course\" onChange=\"document.cform.submit()\">");

            while ((!courseName.equals( "" )) && (i < cMax)) {

               if (courseName.equals( courseName1 )) {
                  out.println("<option selected value=\"" + courseName + "\">" + courseName + "</option>");
               } else {
                  out.println("<option value=\"" + courseName + "\">" + courseName + "</option>");
               }
               i++;
               if (i < cMax) {
                  courseName = course[i];      // get course name from array
               }
            }
            out.println("</select></div>");
            out.println("</form>");
         }
      } // end if multi


      //
      //  start a new form for the dates so you can switch by clicking either a course or a date
      //
      out.println("<form action=\"/" +rev+ "/servlet/Hotel_sheet\" method=\"post\" target=\"bot\" name=\"frmLoadDay\">");
      out.println("<input type=\"hidden\" name=\"calDate\" value=\"\">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" +courseName1+ "\">");
      out.println("<input type=\"hidden\" name=\"jump\" value=\"select\">");
      out.println("</form>");
  
      //
      //   Add calendars
      //
      out.println("<table align=center border=0 height=150>\n<tr valign=top>\n<td>");    // was 190 !!!

      out.println(" <div id=cal_elem_0 style=\"position: relative; top: 0px; left: 0px; width: 180px; height: 150px\"></div>\n");

      out.println("</td>\n<td>&nbsp; &nbsp;</td>\n<td>");

      out.println(" <div id=cal_elem_1 style=\"position: relative; top: 0px; left: 0px; width: 180px; height: 150px\"></div>\n");

      out.println("</td>\n<tr>\n</table>");

      Calendar cal_date = new GregorianCalendar(); //Calendar.getInstance();
      int cal_year = cal_date.get(Calendar.YEAR);
      int cal_month = cal_date.get(Calendar.MONTH) + 1;
      int cal_day = cal_date.get(Calendar.DAY_OF_MONTH);
      int cal_year2 = cal_year;
      int cal_month2 = cal_month;

      out.println("<script type=\"text/javascript\">");

      out.println("var g_cal_bg_color = '#F5F5DC';");
      out.println("var g_cal_header_color = '#8B8970';");
      out.println("var g_cal_border_color = '#8B8970';");

      out.println("var g_cal_count = 2;"); // number of calendars on this page
      out.println("var g_cal_year = new Array(g_cal_count - 1);");
      out.println("var g_cal_month = new Array(g_cal_count - 1);");
      out.println("var g_cal_beginning_month = new Array(g_cal_count - 1);");
      out.println("var g_cal_ending_month = new Array(g_cal_count - 1);");
      out.println("var g_cal_beginning_day = new Array(g_cal_count - 1);");
      out.println("var g_cal_ending_day = new Array(g_cal_count - 1);");
      out.println("var g_cal_beginning_year = new Array(g_cal_count - 1);");
      out.println("var g_cal_ending_year = new Array(g_cal_count - 1);");

      // set calendar date parts
      out.println("g_cal_month[0] = " + cal_month + ";");
      out.println("g_cal_year[0] = " + cal_year + ";");
      out.println("g_cal_beginning_month[0] = " + cal_month + ";");
      out.println("g_cal_beginning_year[0] = " + cal_year + ";");
      out.println("g_cal_beginning_day[0] = " + cal_day + ";");
      out.println("g_cal_ending_month[0] = " + cal_month + ";");
      out.println("g_cal_ending_day[0] = 31;");
      out.println("g_cal_ending_year[0] = " + cal_year + ";");

      cal_date.add(Calendar.MONTH, 1); // add a month
      cal_month = cal_date.get(Calendar.MONTH) + 1; // month is zero based
      cal_year = cal_date.get(Calendar.YEAR);
      out.println("g_cal_beginning_month[1] = " + cal_month + ";");
      out.println("g_cal_beginning_year[1] = " + cal_year + ";");
      out.println("g_cal_beginning_day[1] = 0;");
      cal_date.add(Calendar.MONTH, -1); // subtract a month

      cal_date.add(Calendar.YEAR, 1); // add a year
      cal_year = cal_date.get(Calendar.YEAR);
      cal_month = cal_date.get(Calendar.MONTH) + 1; // month is zero based
      out.println("g_cal_ending_month[1] = " + cal_month + ";");
      out.println("g_cal_ending_day[1] = " + cal_day + ";");
      out.println("g_cal_ending_year[1] = " + cal_year + ";");
      cal_date.add(Calendar.YEAR, -1); // subtract a year

      cal_date.add(Calendar.DAY_OF_MONTH, index); // add the # of days ahead of today this tee sheet is for
      if (cal_date.get(Calendar.MONTH) + 1 == cal_month2 && cal_date.get(Calendar.YEAR) == cal_year2) cal_date.add(Calendar.MONTH, 1);
      cal_year = cal_date.get(Calendar.YEAR);
      cal_month = cal_date.get(Calendar.MONTH) + 1; // month is zero based

      out.println("g_cal_month[1] = " + cal_month + ";");
      out.println("g_cal_year[1] = " + cal_year + ";");

      out.println("</script>");

      out.println("<script language=\"javascript\">\ndoCalendar('0');\n</script>");
      out.println("<script language=\"javascript\">\ndoCalendar('1');\n</script>");



      //**********************************************************
      //  Continue with instructions and tee sheet
      //**********************************************************

      if (index2 <= days) {                      // check max allowed days in advance for Hotels

         out.println("<table cols=\"1\" cellpadding=\"5\" bgcolor=\"#336633\" width=\"680\">");
         out.println("<tr><td align=\"left\"><font color=\"ffffff\" size=\"2\">");

         out.println("<b>Instructions:</b>  To select a tee time, just click on the button containing the time (1st column). ");
         out.println(" Special Events and Restrictions, if any, are colored (see legend below). ");
         out.println(" To display a different day's tee sheet, select the date from the calendar above.");

      } else {

         out.println("<table cols=\"1\" cellpadding=\"5\" bgcolor=\"#336633\" width=\"600\">");
         out.println("<tr><td align=\"left\"><font color=\"ffffff\" size=\"2\">");

         out.println("<b>Note:</b>&nbsp;&nbsp;Since this date is more than " + days + " days from today's date, ");
         out.println("you cannot reserve any times.  You are allowed to view this sheet for planning purposes only.");
      }
      out.println("</font></td></tr></table>");

      out.println("<p>Date:&nbsp;&nbsp;<b>" + day_name + "&nbsp;&nbsp;" + month + "/" + day + "/" + year + "</b>");

      if (!courseName1.equals( "" )) {

         out.println("&nbsp;&nbsp;&nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + courseName1 + "</b>");
      }

      out.println("</p><font size=\"2\">");

      //
      //  Display a note if Hotel not allowed to access tee times today
      //
      if (restrictAll == true) {

         out.println("<button type=\"button\" style=\"background:#F5F5DC\">Please contact the Golf Shop for tee times today.</button><br>");
      }


      out.println("<b>Tee Sheet Legend</b>");
      out.println("</font><font size=\"1\"><br>");

      if (!event1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + ecolor1 + "\">" + event1 + "</button>");
         out.println("&nbsp;&nbsp;&nbsp;&nbsp;");

         if (!event2.equals( "" )) {

            out.println("<button type=\"button\" style=\"background:" + ecolor2 + "\">" + event2 + "</button>");
            out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
         }
      }

      if (!rest1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + rcolor1 + "\">" + rest1 + "</button>");

         if (!rest2.equals( "" )) {

            out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
            out.println("<button type=\"button\" style=\"background:" + rcolor2 + "\">" + rest2 + "</button>");

            if (!rest3.equals( "" )) {

               out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
               out.println("<button type=\"button\" style=\"background:" + rcolor3 + "\">" + rest3 + "</button>");

               if (!rest4.equals( "" )) {

                  out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                  out.println("<button type=\"button\" style=\"background:" + rcolor4 + "\">" + rest4 + "</button>");
               }
            }
         }
      }

      if (!grest1.equals( "" )) {

         out.println("<button type=\"button\" style=\"background:" + gcolor + "\">Guest(s) Restricted: " + grest1 + " " + grest2 + " " + grest3 + " " + grest4 + "</button>");
      }

      if (!event1.equals( "" ) || !rest1.equals( "" ) || !grest1.equals( "" )) {

         out.println("<br>");
      }

      out.println("<b>F/B:</b>&nbsp;&nbsp;&nbsp;&nbsp;F = Front Nine,&nbsp;&nbsp;&nbsp;B = Back Nine,&nbsp;&nbsp;&nbsp;O = Open (for cross-overs),&nbsp;&nbsp;&nbsp;S = Shotgun Event<br>");

      out.println("<b>C/W:</b>&nbsp;&nbsp;&nbsp;&nbsp;");

      for (int ic=0; ic<16; ic++) {

         if (!parmc.tmodea[ic].equals( "" )) {
            out.println(parmc.tmodea[ic]+ " = " +parmc.tmode[ic]+ "&nbsp;&nbsp;&nbsp;");
         }
      }
      out.println("(__9 = 9 holes)");

      out.println("<table border=\"1\" bgcolor=\"#F5F5DC\" width=\"95%\">");    // tee sheet table
         out.println("<tr bgcolor=\"#336633\"><td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"2\">");
               out.println("<u><b>Time</b></u>");
               out.println("</font></td>");

            if (courseName1.equals( "-ALL-" )) {

               out.println("<td align=\"center\">");
                  out.println("<font color=\"#FFFFFF\" size=\"2\">");
                  out.println("<u><b>Course</b></u>");
               out.println("</font></td>");
            }

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"1\">");
               out.println("<u><b>F/B</b></u>");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"2\">");
               out.println("<u><b>Player 1</b></u> ");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"1\">");
               out.println("<u><b>C/W</b></u>");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"2\">");
               out.println("<u><b>Player 2</b></u> ");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"1\">");
               out.println("<u><b>C/W</b></u>");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"2\">");
               out.println("<u><b>Player 3</b></u> ");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"1\">");
               out.println("<u><b>C/W</b></u>");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"2\">");
               out.println("<u><b>Player 4</b></u> ");
               out.println("</font></td>");

            out.println("<td align=\"center\">");
               out.println("<font color=\"ffffff\" size=\"1\">");
               out.println("<u><b>C/W</b></u>");
               out.println("</font></td>");

            if (fivesALL != 0 ) {

               out.println("<td align=\"center\">");
                  out.println("<font color=\"ffffff\"  size=\"2\">");
                  out.println("<u><b>Player 5</b></u> ");
                  out.println("</font></td>");

               out.println("<td align=\"center\">");
                  out.println("<font color=\"ffffff\" size=\"1\">");
                  out.println("<u><b>C/W</b></u>");
                  out.println("</font></td>");
            }
            out.println("</tr>");

      //
      //  Get the tee sheet for this date and course
      //
      String courseNameT = "";
      String stringTee = "";
      
      if (courseName1.equals("-ALL-")) {
          
          stringTee = "" +
                  "SELECT hr, min, time, event, event_color, restriction, rest_color, player1, player2, " +
                     "player3, player4, p1cw, p2cw, p3cw, p4cw, in_use, event_type, hndcp1, hndcp2, hndcp3, " +
                     "hndcp4, fb, player5, p5cw, hndcp5, lottery, blocker, rest5, rest5_color, " +
                     "p91, p92, p93, p94, p95, courseName " +
                 "FROM teecurr2 " +
                 "WHERE date = ? ORDER BY time, courseName, fb";
      } else {
      
          stringTee = "" +
                  "SELECT hr, min, time, event, event_color, restriction, rest_color, player1, player2, " +
                     "player3, player4, p1cw, p2cw, p3cw, p4cw, in_use, event_type, hndcp1, hndcp2, hndcp3, " +
                     "hndcp4, fb, player5, p5cw, hndcp5, lottery, blocker, rest5, rest5_color, " +
                     "p91, p92, p93, p94, p95, courseName " +
                 "FROM teecurr2 " +
                 "WHERE date = ? AND courseName = ? ORDER BY time, fb";
      }
      pstmt = con.prepareStatement ( stringTee );

      pstmt.clearParameters();
      pstmt.setLong(1, date);
      if (!courseName1.equals("-ALL-")) pstmt.setString(2, courseName1);
      rs = pstmt.executeQuery();

      loop2:
      while (rs.next()) {

         hr = rs.getInt(1);
         min = rs.getInt(2);
         tee_time = rs.getInt(3);
         event = rs.getString(4);
         ecolor = rs.getString(5);
         rest = rs.getString(6);
         rcolor = rs.getString(7);
         player1 = rs.getString(8);
         player2 = rs.getString(9);
         player3 = rs.getString(10);
         player4 = rs.getString(11);
         p1cw = rs.getString(12);
         p2cw = rs.getString(13);
         p3cw = rs.getString(14);
         p4cw = rs.getString(15);
         in_use = rs.getInt(16);
         type = rs.getInt(17);
         hndcp1 = rs.getFloat(18);
         hndcp2 = rs.getFloat(19);
         hndcp3 = rs.getFloat(20);
         hndcp4 = rs.getFloat(21);
         fb = rs.getShort(22);
         player5 = rs.getString(23);
         p5cw = rs.getString(24);
         hndcp5 = rs.getFloat(25);
         lottery = rs.getString(26);
         blocker = rs.getString(27);
         rest5 = rs.getString(28);
         bgcolor5 = rs.getString(29);
         p91 = rs.getInt(30);
         p92 = rs.getInt(31);
         p93 = rs.getInt(32);
         p94 = rs.getInt(33);
         p95 = rs.getInt(34);
         courseNameT = rs.getString("courseName");

         //
         //  If course=ALL requested, then set 'fives' option according to this course
         //
         if (courseName1.equals( "-ALL-" )) {
               i = 0;
               loopall:
               while (i < cMax) {
                  if (courseNameT.equals( course[i] )) {
                     fives = fivesA[i];          // get the 5-some option for this course
                     break loopall;              // exit loop
                  }
                  i++;
               }
         }
         
         if (blocker.equals( "" )) {    // continue if tee time not blocked - else skip

            ampm = " AM";
            if (hr == 12) {
               ampm = " PM";
            }
            if (hr > 12) {
               ampm = " PM";
               hr = hr - 12;    // convert to conventional time
            }

            bgcolor = "#F5F5DC";                //default

            if (!event.equals("")) {
               bgcolor = ecolor;

            } else {

               if (!rest.equals("")) {
                  bgcolor = rcolor;
               }
            }

            if (bgcolor.equals("Default")) {
               bgcolor = "#F5F5DC";              //default
            }

            if (bgcolor5.equals( "" )) {
               bgcolor5 = bgcolor;              //same as others if not specified
            }

            if (p91 == 1) {          // if 9 hole round
               p1cw = p1cw + "9";
            }
            if (p92 == 1) {
               p2cw = p2cw + "9";
            }
            if (p93 == 1) {
               p3cw = p3cw + "9";
            }
            if (p94 == 1) {
               p4cw = p4cw + "9";
            }
            if (p95 == 1) {
               p5cw = p5cw + "9";
            }

            if (player1.equals("")) {
               p1cw = "";
            }
            if (player2.equals("")) {
               p2cw = "";
            }
            if (player3.equals("")) {
               p3cw = "";
            }
            if (player4.equals("")) {
               p4cw = "";
            }
            if (player5.equals("")) {
               p5cw = "";
            }

            g1 = 0;               // init guest indicators
            g2 = 0;
            g3 = 0;
            g4 = 0;
            g5 = 0;
            allow = true;         // init allow flag

            //
            //  Check if any player names are hotel guests for this hotel user.
            //  Change all other names to 'member' and don't allow access to these times.
            //
            if (!player1.equals( "" )) {

               i = 0;
               gloop1:
               while (i < 36) {

                  if ((!xguest[i].equals( "" )) && (player1.startsWith( xguest[i] ))) {

                     g1 = 1;       // indicate player1 is a hotel guest
                     break gloop1;
                  }
                  i++;
               }
               if (g1 == 0) {

                  player1 = "Member";       // change name
                  allow = false;            // do not allow access to tee time
               }
            }
            if (!player2.equals( "" )) {

               i = 0;
               gloop2:
               while (i < 36) {

                  if ((!xguest[i].equals( "" )) && (player2.startsWith( xguest[i] ))) {

                     g2 = 1;       // indicate player2 is a hotel guest
                     break gloop2;
                  }
                  i++;
               }
               if (g2 == 0) {

                  player2 = "Member";       // change name
                  allow = false;            // do not allow access to tee time
               }
            }
            if (!player3.equals( "" )) {

               i = 0;
               gloop3:
               while (i < 36) {

                  if ((!xguest[i].equals( "" )) && (player3.startsWith( xguest[i] ))) {

                     g3 = 1;       // indicate player3 is a hotel guest
                     break gloop3;
                  }
                  i++;
               }
               if (g3 == 0) {

                  player3 = "Member";       // change name
                  allow = false;            // do not allow access to tee time
               }
            }
            if (!player4.equals( "" )) {

               i = 0;
               gloop4:
               while (i < 36) {

                  if ((!xguest[i].equals( "" )) && (player4.startsWith( xguest[i] ))) {

                     g4 = 1;       // indicate player4 is a hotel guest
                     break gloop4;
                  }
                  i++;
               }
               if (g4 == 0) {

                  player4 = "Member";       // change name
                  allow = false;            // do not allow access to tee time
               }
            }
            if (!player5.equals( "" )) {

               i = 0;
               gloop5:
               while (i < 36) {

                  if ((!xguest[i].equals( "" )) && (player5.startsWith( xguest[i] ))) {

                     g5 = 1;       // indicate player5 is a hotel guest
                     break gloop5;
                  }
                  i++;
               }
               if (g5 == 0) {

                  player5 = "Member";       // change name
                  allow = false;            // do not allow access to tee time
               }
            }

            //
            //  Check if Hotel not allowed to access tee times today
            //
            if (restrictAll == true) {

               allow = false;            // not today!
            }

            //
            // check if we should allow user to select this slot
            // check max allowed days in advance, special event, lottery or cross-over time
            //
            if ((index2 > days) || (!event.equals("")) || (fb == 9) || (!lottery.equals(""))) {

               allow = false;

            }

            //
            //  if today's sheet and the tee time is less than the current time do not allow select
            //
            if ((index2 == 0) && (tee_time <= cal_time)) {

               allow = false;     // do not allow select

            }

            //
            //  Process the F/B parm    0 = Front 9, 1 = Back 9, 9 = none (open for cross-over)
            //
            sfb = "F";       // default Front 9
            sfb2 = "Front";       // default Front 9

            if (fb == 1) {

               sfb = "B";
               sfb2 = "Back";
            }

            if (fb == 9) {

               sfb = "O";
               sfb2 = "O";
            }

            if (type == shotgun) {

               sfb = "S";            // there's an event and its type is 'shotgun'
            }

            //
            //   Check guest restrictions for this hotel's guest types if slot available.
            //   Only block tee time if ALL guest types for this user are restricted.
            //
            if ((allow == true) && (in_use == 0)) {         // still ok and not in use?

               pstmt5 = con.prepareStatement (
                  "SELECT * " +
                  "FROM guestres2 WHERE sdate <= ? AND edate >= ? AND " +
                  "stime <= ? AND etime >= ?");

               pstmt5.clearParameters();        // clear the parms
               pstmt5.setLong(1, date);
               pstmt5.setLong(2, date);
               pstmt5.setInt(3, tee_time);
               pstmt5.setInt(4, tee_time);
               rs2 = pstmt5.executeQuery();      // execute the prepared stmt

               loop3:
               while (rs2.next()) {

                  grest_recurr = rs2.getString("recurr");
                  rguest[0] = rs2.getString("guest1");
                  rguest[1] = rs2.getString("guest2");
                  rguest[2] = rs2.getString("guest3");
                  rguest[3] = rs2.getString("guest4");
                  rguest[4] = rs2.getString("guest5");
                  rguest[5] = rs2.getString("guest6");
                  rguest[6] = rs2.getString("guest7");
                  rguest[7] = rs2.getString("guest8");
                  rcourse = rs2.getString("courseName");
                  rest_fb = rs2.getString("fb");
                  grest_color = rs2.getString("color");
                  rguest[8] = rs2.getString("guest9");
                  rguest[9] = rs2.getString("guest10");
                  rguest[10] = rs2.getString("guest11");
                  rguest[11] = rs2.getString("guest12");
                  rguest[12] = rs2.getString("guest13");
                  rguest[13] = rs2.getString("guest14");
                  rguest[14] = rs2.getString("guest15");
                  rguest[15] = rs2.getString("guest16");
                  rguest[16] = rs2.getString("guest17");
                  rguest[17] = rs2.getString("guest18");
                  rguest[18] = rs2.getString("guest19");
                  rguest[19] = rs2.getString("guest20");
                  rguest[20] = rs2.getString("guest21");
                  rguest[21] = rs2.getString("guest22");
                  rguest[22] = rs2.getString("guest23");
                  rguest[23] = rs2.getString("guest24");
                  rguest[24] = rs2.getString("guest25");
                  rguest[25] = rs2.getString("guest26");
                  rguest[26] = rs2.getString("guest27");
                  rguest[27] = rs2.getString("guest28");
                  rguest[28] = rs2.getString("guest29");
                  rguest[29] = rs2.getString("guest30");
                  rguest[30] = rs2.getString("guest31");
                  rguest[31] = rs2.getString("guest32");
                  rguest[32] = rs2.getString("guest33");
                  rguest[33] = rs2.getString("guest34");
                  rguest[34] = rs2.getString("guest35");
                  rguest[35] = rs2.getString("guest36");

                  //
                  //  Check if course matches that specified in restriction
                  //
                  if ((rcourse.equals( "-ALL-" )) || (rcourse.equals( courseNameT ))) {

                     //
                     //  We must check the recurrence for this day (Monday, etc.) and guest types
                     //
                     //     guestx = guest types specified for this hotel user
                     //     rguestx = guest types from restriction gotten above
                     //
                     if ((grest_recurr.equalsIgnoreCase( "every " + day_name )) ||
                         (grest_recurr.equalsIgnoreCase( "every day" )) ||
                         ((grest_recurr.equalsIgnoreCase( "all weekdays" )) &&
                          (!day_name.equalsIgnoreCase( "saturday" )) &&
                          (!day_name.equalsIgnoreCase( "sunday" ))) ||
                         ((grest_recurr.equalsIgnoreCase( "all weekends" )) &&
                          (day_name.equalsIgnoreCase( "saturday" ))) ||
                         ((grest_recurr.equalsIgnoreCase( "all weekends" )) &&
                          (day_name.equalsIgnoreCase( "sunday" )))) {

                        //
                        //  Now check if F/B matches
                        //
                        if ((rest_fb.equals( "Both" )) || (rest_fb.equals( sfb2 ))) {

                           block = false;                  // init to 'do not block' (allow)
                           i = 0;
                           ploop1:
                           while (i < 36) {     // check all guest types for this hotel user

                              if (!xguest[i].equals( "" )) {  // if guest type specified for user (must be at least 1)

                                 i2 = 0;
                                 while (i2 < 36) {     // check all guest types for this restriction

                                    if (xguest[i].equals( rguest[i2] )) {

                                       block = true;    // guest type in restriction - block this tee time
                                       break ploop1;
                                    }
                                    i2++;
                                 }
                              }
                              i++;
                           }

                           if (block == true) {      // block this slot ?

                              allow = false;                  // indicate guests restricted for this user
                              bgcolor = grest_color;               // set color for this slot
                              break loop3;                    // exit loop
                           }
                        }  // end of IF f/b matches
                     }
                  }      // end of IF course matches
               }   // end of loop3 while loop (while guest restrictions exist)

               pstmt5.close();

               //
               //  Custom check for Cordillera Canned Restrictions
               //
               if (club.equals( "cordillera" )) { 

                  if (dateShort > 413 && dateShort < 1030) {         // if this is within the custom date range
                                    
                     boolean cordallow = cordilleraCustom.checkCordillera(date, tee_time, courseNameT, "hotel"); // go check if this time is restricted (changed from courseName1 to courseNameT)
                       
                     if (cordallow == false) {                  // if restricted
                        bgcolor = gcolor;                       // set color for this slot
                        allow = false;                          // do allow access
                     }
                  }
               }
            }       // end of IF allow = true

            submit = "time:" + fb;       // create a name for the submit button

            out.println("<tr>");         // start of tee slot (row)

            j++;                                       // increment the jump label index (where to jump on page)
            out.println("<a name=\"jump" + j + "\"></a>"); // create a jump label for 'noshow' returns

            if ((allow == true) && (in_use == 0)) {         // can user select this slot and not in use?

               out.println("<form action=\"/" +rev+ "/servlet/Hotel_slot\" method=\"post\" target=\"_top\">");
               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<input type=\"hidden\" name=\"date\" value=\"" + date + "\">");
               out.println("<input type=\"hidden\" name=\"day\" value=\"" + day_name + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseNameT + "\">"); //  (changed from courseName1 to courseNameT)
               out.println("<input type=\"hidden\" name=\"jump\" value=\"" + j + "\">");

               if ((fives != 0 ) && (rest5.equals( "" ))) {   // if 5-somes and not restricted

                  out.println("<input type=\"hidden\" name=\"p5\" value=\"Yes\">");  // tell _slot to do 5's
               } else {
                  out.println("<input type=\"hidden\" name=\"p5\" value=\"No\">");
               }

               if (min < 10) {
                  out.println("<input type=\"submit\" name=\"" + submit + "\" id=\"" + submit + "\" value=\"" + hr + ":0" + min + ampm + "\" alt=\"submit\">");
               } else {
                  out.println("<input type=\"submit\" name=\"" + submit + "\" id=\"" + submit + "\" value=\"" + hr + ":" + min + ampm + "\" alt=\"submit\">");
               }

               out.println("</font></td>");
               out.println("</form>");

            } else {
               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">");
               if (type == shotgun) {
                     out.println("shotgun");
               } else {
                  if (min < 10) {
                     out.println(hr + ":0" + min + ampm);
                  } else {
                     out.println(hr + ":" + min + ampm);
                  }
               }
               out.println("</font></td>");
            }

            //
            //  Course Name
            //
            if (courseName1.equals( "-ALL-" )) {
                   
               // set tmp_i equal to course index #
               for (tmp_i = 0; tmp_i < courseCount; tmp_i++) {
                   if (courseNameT.equals(course[tmp_i])) break;                      
               }
               
               out.println("<td bgcolor=\"" + course_color[tmp_i] + "\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println(courseNameT);
               out.println("</font></td>");
            }
            
            //
            //  Front/Back indicator
            //
            out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println(sfb);
               out.println("</font></td>");

            //
            //  Add Player 1
            //
            out.println("<td bgcolor=\"" + bgcolor + "\" align=\"center\">");
            out.println("<font size=\"2\">");

            if (!player1.equals("")) {

               out.println(player1);

            } else {     // player is empty

               out.println("&nbsp;");
            }
            out.println("</font></td>");

            if ((!player1.equals("")) && (!player1.equalsIgnoreCase( "x" ))) {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"1\">");
               out.println(p1cw);
            } else {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("&nbsp;");
            }
            out.println("</font></td>");

            //
            //  Add Player 2
            //
            out.println("<td bgcolor=\"" + bgcolor + "\" align=\"center\">");
            out.println("<font size=\"2\">");

            if (!player2.equals("")) {

               out.println(player2);

            } else {     // player is empty

               out.println("&nbsp;");
            }
            out.println("</font></td>");

            if ((!player2.equals("")) && (!player2.equalsIgnoreCase( "x" ))) {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"1\">");
               out.println(p2cw);
            } else {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("&nbsp;");
            }
            out.println("</font></td>");

            //
            //  Add Player 3
            //
            out.println("<td bgcolor=\"" + bgcolor + "\" align=\"center\">");
            out.println("<font size=\"2\">");

            if (!player3.equals("")) {

               out.println(player3);

            } else {     // player is empty

               out.println("&nbsp;");
            }
            out.println("</font></td>");

            if ((!player3.equals("")) && (!player3.equalsIgnoreCase( "x" ))) {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"1\">");
               out.println(p3cw);
            } else {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("&nbsp;");
            }
            out.println("</font></td>");

            //
            //  Add Player 4
            //
            out.println("<td bgcolor=\"" + bgcolor + "\" align=\"center\">");
            out.println("<font size=\"2\">");

            if (!player4.equals("")) {

               out.println(player4);

            } else {     // player is empty

               out.println("&nbsp;");
            }
            out.println("</font></td>");

            if ((!player4.equals("")) && (!player4.equalsIgnoreCase( "x" ))) {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"1\">");
               out.println(p4cw);
            } else {
               out.println("<td bgcolor=\"white\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("&nbsp;");
            }
            out.println("</font></td>");

            //
            //  Add Player 5 if supported
            //
            if (fivesALL != 0) {        // if 5-somes supported on any course
                if (fives != 0) {

                   if (!rest5.equals( "" )) {       // if 5-somes are restricted

                      out.println("<td bgcolor=\"" + bgcolor5 + "\" align=\"center\">");
                      out.println("&nbsp;");

                   } else {

                      out.println("<td bgcolor=\"" + bgcolor + "\" align=\"center\">");
                      out.println("<font size=\"2\">");

                      if (!player5.equals("")) {

                         out.println(player5);

                      } else {     // player is empty

                         out.println("&nbsp;");
                      }
                   }
                   out.println("</font></td>");

                   if ((!player5.equals("")) && (!player5.equalsIgnoreCase( "x" ))) {
                      out.println("<td bgcolor=\"white\" align=\"center\">");
                      out.println("<font size=\"1\">");
                      out.println(p5cw);
                   } else {
                      out.println("<td bgcolor=\"white\" align=\"center\">");
                      out.println("<font size=\"2\">");
                      out.println("&nbsp;");
                   }
                   out.println("</font></td>");
                   
                } else {          // 5-somes supported on at least 1 course, but not this one (if course=ALL)

                     out.println("<td bgcolor=\"black\" align=\"center\">");   // no 5-somes
                     out.println("<font size=\"2\">");
                     out.println("&nbsp;");
                     out.println("</font></td>");
                     out.println("<td bgcolor=\"black\" align=\"center\">");
                     out.println("<font size=\"2\">");
                     out.println("&nbsp;");
                     out.println("</font></td>");
                }
            }
            out.println("</tr>");       // end of this row

         }  // end of IF blocker

      }  // end of while loop2

      pstmt.close();

         out.println("</table>");                   // end of tee sheet table
         out.println("</td></tr>");
         out.println("</table>");                   // end of main page table
      //
      //  End of HTML page
      //
      out.println("</center></body></html>");
      out.close();

   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<BR><BR><H2>Database Access Error</H2>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>" + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/hotel_mainleft.htm\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      out.close();
      return;
   }

 }  // end of doPost

}
