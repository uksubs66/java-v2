/***************************************************************************************     
 *   Proshop_mrest:  This servlet will process the 'Member Restrictions' request from
 *                    the Proshop's Config page.
 *
 *
 *   called by:  proshop menu (to doGet) and Proshop_mrest (to doPost from HTML built here)
 *
 *   created: 12/18/2001   Bob P.
 *
 *   last updated:
 *
 *        1/24/05   Ver 5 - change club2 to club5.
 *        7/21/04   Correct problem where the course name was not used in doPost on copy.
 *        6/18/04   Add 'Make Copy' option to allow pro to copy an existing rest.
 *        5/12/04   Add sheet= parm for call from Proshop_sheet.
 *       12/15/03   Add Show=yes/no for Eldorado CC. Option to show or not to show restriction
 *                  on tee sheet legend.
 *        7/18/03   Enhancements for Version 3 of the software.
 *        1/07/03   Enhancements for Version 2 of the software.
 *                  Add support for multi courses, memtypes and mship types and F/B option.
 *
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.parmClub;
import com.foretees.common.getClub;


public class Proshop_mrest extends HttpServlet {


   String zero = "00";

   String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

  
 //**************************************************
 // Process the initial request from Proshop_main
 //**************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           
   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();
        
   Statement stmt = null;
   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyPro(req, out);             // check for intruder

   if (session == null) {
     
      return;
   }

   Connection con = SystemUtils.getCon(session);                      // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }
     
   //
   //  Check if call is to copy an existing restriction
   //
   if (req.getParameter("copy") != null) {

      doCopy(out,con);        // process the copy request
      return;
   }

   //
   // Define some parms to use in the html
   //
   String name = "";       // name of restriction
   int s_hour = 0;         // start time hr
   int s_min = 0;          // start time min
   int e_hour = 0;         // end time hr
   int e_min = 0;          // end time min
   int s_year = 0;         // start year
   int s_month = 0;        // start month
   int s_day = 0;          // start day
   int e_year = 0;         // end year
   int e_month = 0;        // end month
   int e_day = 0;          // end day
   int multi = 0;             // day

   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   String recurr = "";     // recurrence
   String color = "";      // color for restriction displays
   String courseName = ""; // name of course
   String fb = "";         // Front/back Indicator
   String s_ampm = "";
   String e_ampm = "";

   boolean b = false;

   //
   //  First, see if multi courses are supported for this club
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT multi " +
                             "FROM club5");

      if (rs.next()) {

         multi = rs.getInt(1);
      }
      stmt.close();
   }
   catch (Exception ignore) {
   }

   //
   //  Build the HTML page to display the existing restrictions
   //
   out.println(SystemUtils.HeadTitle("Proshop Member Restrictions Page"));
   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");
        
      out.println("<table cellpadding=\"5\" bgcolor=\"#336633\" border=\"0\" align=\"center\">");
      out.println("<tr><td align=\"center\">");
      out.println("<font color=\"#FFFFFF\" size=\"3\">");
      out.println("<b>Member Restrictions</b><br>");
      out.println("</font>");
      out.println("<font color=\"#FFFFFF\" size=\"2\">");
      out.println("<br>To change or remove a restriction, click on the Select button within the restriction.");
      out.println("<br></td></tr></table>");
      out.println("<br><br>");

      out.println("<table border=\"2\" cellpadding=\"5\"><tr bgcolor=\"#F5F5DC\">");
      if (multi != 0) {           // if multiple courses supported for this club
         out.println("<td colspan=\"10\" align=\"center\">");
      } else {
         out.println("<td colspan=\"9\" align=\"center\">");
      }
      out.println("<font size=\"2\">");
      out.println("<p align=\"center\"><b>Active Member Restrictions</b></p>");
      out.println("</font></td></tr>");
      out.println("<tr bgcolor=\"#F5F5DC\"><td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Restriction Name</b></p>");
      out.println("</font></td>");
      if (multi != 0) {
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p><b>Course</b></p>");
         out.println("</font></td>");
      }
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Tees</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Start Date</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>End Date</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Start Time</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>End Time</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Recurrence</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Color</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p>&nbsp;</p>");      // empty for select button
      out.println("</font></td></tr>");

   //
   //  Get and display the existing restrictions (one table row per restriction)
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT * FROM restriction2 ORDER BY name");

      while (rs.next()) {

         b = true;                     // indicate restrictions exist

         name = rs.getString("name");
         s_month = rs.getInt("start_mm");
         s_day = rs.getInt("start_dd");
         s_year = rs.getInt("start_yy");
         s_hour = rs.getInt("start_hr");
         s_min = rs.getInt("start_min");
         e_month = rs.getInt("end_mm");
         e_day = rs.getInt("end_dd");
         e_year = rs.getInt("end_yy");
         e_hour = rs.getInt("end_hr");
         e_min = rs.getInt("end_min");
         recurr = rs.getString("recurr");
         color = rs.getString("color");
         courseName = rs.getString("courseName");
         fb = rs.getString("fb");

         //
         //  some values must be converted for display
         //
         s_ampm = " AM";         // default to AM
         if (s_hour > 12) {
            s_ampm = " PM";
            s_hour = s_hour - 12;                // convert to 12 hr clock value
         }

         if (s_hour == 12) {
            s_ampm = " PM";
         }

         e_ampm = " AM";         // default to AM
         if (e_hour > 12) {
            e_ampm = " PM";
            e_hour = e_hour - 12;                  // convert to 12 hr clock value
         }

         if (e_hour == 12) {
            e_ampm = " PM";
         }


         if (color.equals( "Default" )) {

            out.println("<tr bgcolor=\"#F5F5DC\">");
         } else {
            out.println("<tr bgcolor=" + color + ">");
         }
         out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_mrest\" target=\"bot\">");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +name+ "</p>");
         out.println("</font></td>");
         if (multi != 0) {
            out.println("<td align=\"center\">");
            out.println("<font size=\"2\"><p>" +courseName+ "</b></p>");
            out.println("</font></td>");
         }
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +fb+ "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +s_month+ "/" + s_day + "/" + s_year + "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +e_month+ "/" + e_day + "/" + e_year + "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         if (s_min < 10) {
            out.println("<font size=\"2\"><p>" + s_hour + ":0" + s_min + "  " + s_ampm + "</p>");
         } else {
            out.println("<font size=\"2\"><p>" + s_hour + ":" + s_min + "  " + s_ampm + "</p>");
         }
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         if (e_min < 10) {
            out.println("<font size=\"2\"><p>" + e_hour + ":0" + e_min + "  " + e_ampm + "</b></p>");
         } else {
            out.println("<font size=\"2\"><p>" + e_hour + ":" + e_min + "  " + e_ampm + "</b></p>");
         }
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +recurr+ "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +color+ "</p>");
         out.println("</font></td>");

         out.println("<input type=\"hidden\" maxlength=\"30\" name=\"name\" value=\"" + name + "\">");    // must pass whole name!!!!
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
         out.println("<td align=\"center\">");
         out.println("<p>");
         out.println("<input type=\"submit\" value=\"Select\">");
         out.println("</td></form></tr>");

      }  // end of while loop

      stmt.close();

      if (!b) {
        
         out.println("</font><font size=\"2\"><p>No Member Restrictions Currently Exist</p>");
      }
   }
   catch (Exception exc) {

      out.println("<BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");

   }  // end of try

   //
   //  End of HTML page
   //
   out.println("</table></font>");                   // end of mrest table
   out.println("</td></tr></table>");                // end of main page table
        
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_announce\">");
   out.println("<input type=\"submit\" value=\" Return \" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</center></font><br></body></html>");
   out.close();

 }  // end of doGet

 //
 //****************************************************************
 // Process the form request from Proshop_mrest page displayed above.
 //
 // Use the name provided to locate the restriction record and then display
 // the record to the user and prompt for edit or delete action. 
 //
 //****************************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Statement stmt = null;
   ResultSet rs = null;
     
   String [] month_table = { "inv", "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
                             "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

   HttpSession session = SystemUtils.verifyPro(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }
     
   boolean copy = false;

   long s_date = 0;
   long e_date = 0;
   int s_year = 0;
   int s_month = 0;
   int s_day = 0;
   int e_year = 0;
   int e_month = 0;
   int e_day = 0;
   int shr = 0;
   int smin = 0;
   int ehr = 0;
   int emin = 0;
   int multi = 0;        // multiple course support option
   int index = 0;
   int i = 0;

   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   String color = "";
   String recur = "";
   String fb = "";
   String show = "";
   String oldCourse = "";
   String courseName = "";
   String courseName2 = "";
   String sheet = "no";                 // default to NOT a call from Proshop_sheet

   //
   // Get the name parameter from the hidden input field
   //
   String name = req.getParameter("name");

   if (req.getParameter("sheet") != null) {

      sheet = req.getParameter("sheet");
   }

   if (req.getParameter("copy") != null) {

      copy = true;            // this is a copy request (from doCopy below)
   }
     
   String oldName = name;                // save original event name

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   String [] course = new String [parm.MAX_Courses];      // max of 20 courses per club

   String [] mem = new String [parm.MAX_Mems+1];            // max of 24 member types
   String [] smem = new String [parm.MAX_Mems+1];          

   String [] mship = new String [parm.MAX_Mships+1];        // max of 24 mship types
   String [] smship = new String [parm.MAX_Mships+1];   


   //
   // Get the restriction from the restriction table
   //
   try {

      PreparedStatement pstmt = con.prepareStatement (
               "SELECT * FROM restriction2 WHERE name = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, name);       // put the parm in stmt
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         //
         //  Found the restriction record - get it
         //
         s_date = rs.getLong("sdate");
         s_month = rs.getInt("start_mm");
         s_day = rs.getInt("start_dd");
         s_year = rs.getInt("start_yy");
         shr = rs.getInt("start_hr");
         smin = rs.getInt("start_min");
         e_date = rs.getLong("edate");
         e_month = rs.getInt("end_mm");
         e_day = rs.getInt("end_dd");
         e_year = rs.getInt("end_yy");
         ehr = rs.getInt("end_hr");
         emin = rs.getInt("end_min");
         recur = rs.getString("recurr");
         color = rs.getString("color");
         courseName = rs.getString("courseName");
         fb = rs.getString("fb");
         show = rs.getString("showit");
           
         for (i=1; i<parm.MAX_Mems+1; i++) {
            mem[i] = rs.getString("mem" +i);
         }
         for (i=1; i<parm.MAX_Mships+1; i++) {
            mship[i] = rs.getString("mship" +i);
         }

      } else {      // not found - try filtering the name

         name = SystemUtils.filter(name);
         oldName = name;                 // save original name

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, name);       // put the parm in stmt
         rs = pstmt.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            //
            //  Found the restriction record - get it
            //
            s_date = rs.getLong("sdate");
            s_month = rs.getInt("start_mm");
            s_day = rs.getInt("start_dd");
            s_year = rs.getInt("start_yy");
            shr = rs.getInt("start_hr");
            smin = rs.getInt("start_min");
            e_date = rs.getLong("edate");
            e_month = rs.getInt("end_mm");
            e_day = rs.getInt("end_dd");
            e_year = rs.getInt("end_yy");
            ehr = rs.getInt("end_hr");
            emin = rs.getInt("end_min");
            recur = rs.getString("recurr");
            color = rs.getString("color");
            courseName = rs.getString("courseName");
            fb = rs.getString("fb");
            show = rs.getString("showit");

            for (i=1; i<parm.MAX_Mems+1; i++) {
               mem[i] = rs.getString("mem" +i);
            }
            for (i=1; i<parm.MAX_Mships+1; i++) {
               mship[i] = rs.getString("mship" +i);
            }
         }
  
      }
      pstmt.close();              // close the stmt

      oldCourse = courseName;    // save course name in case it changes

      //
      //  check if multi-couse is yes
      //
      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT multi, mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
                             "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
                             "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24, " +
                             "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
                             "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
                             "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24 " +
                             "FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         multi = rs.getInt("multi");
           
         for (i=1; i<parm.MAX_Mems+1; i++) {
            smem[i] = rs.getString("mem" +i);
         }
         for (i=1; i<parm.MAX_Mships+1; i++) {
            smship[i] = rs.getString("mship" +i);
         }
      }

      stmt.close();

      if (multi != 0) {
         //
         //  Multiple courses - get the names for later
         //
         index = 0;

         while (index < parm.MAX_Courses) {

            course[index] = "";       // init the course array
            index++;
         }
         index = 0;

         //
         //  Get the names of all courses for this club
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT courseName " +
                                "FROM clubparm2 WHERE first_hr != 0");

         while (rs.next() && index < parm.MAX_Courses) {

            courseName2 = rs.getString(1);

            course[index] = courseName2;      // add course name to array
            index++;
         }
         stmt.close();
      }                                         
   }
   catch (Exception exc) {

      dbError(out);
      return;
   }

   String ssampm = "AM";     // AM or PM for display (start hour)
   String seampm = "AM";     // AM or PM for display (end hour)
   int sampm = 0;
   int eampm = 0;

   if (shr > 12) {
      
      shr = shr - 12;        // convert to 12 hour value
      ssampm = "PM";         // indicate PM
      sampm = 12;
   }

   if (shr == 12) {
      ssampm = "PM";         // indicate PM
   }

   if (ehr > 12) {

      ehr = ehr - 12;        // convert to 12 hour value
      seampm = "PM";         // indicate PM
      eampm = 12;
   }

   if (ehr == 12) {
      seampm = "PM";         // indicate PM
   }

   String alphaSmonth = month_table[s_month];  // get name for start month
   String alphaEmonth = month_table[e_month];  // get name for end month

   //
   // Database record found - output an edit page
   //
   out.println(SystemUtils.HeadTitle("Proshop Edit Member Restriction"));

   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td>");

      out.println("<table border=\"1\" cellpadding=\"5\" bgcolor=\"#336633\" align=\"center\">");
      out.println("<tr><td align=\"center\">");
      out.println("<font color=\"#FFFFFF\" size=\"2\">");
        
      if (copy == false) {
         out.println("<b>Edit Member Restriction</b><br>");
         out.println("<br>Change the desired information for the restriction below.<br>");
         out.println("Click on <b>Update</b> to submit the changes.");
         out.println("<br>Click on <b>Remove</b> to delete the restriction.");
      } else {
         out.println("<b>Copy Member Restriction</b><br>");
         out.println("<br>Change the desired information for the restriction below.<br>");
         out.println("Click on <b>Add</b> to create the new restriction.");
         out.println("<br><br><b>NOTE:</b> You must change the name of the restriction.");
      }
      out.println("</font></td></tr></table><br>");

      out.println("<table border=\"1\" bgcolor=\"#F5F5DC\">");
         if (sheet.equals( "yes" )) {
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_editmrest\" method=\"post\">");
         } else {
            if (copy == true) {
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_addmrest\" method=\"post\" target=\"bot\">");
               out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");
            } else {
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_editmrest\" method=\"post\" target=\"bot\">");
            }
         }
            out.println("<tr><td>");
               out.println("<font size=\"2\">");
               out.println("<p align=\"left\">&nbsp;&nbsp;Restriction name:&nbsp;&nbsp;&nbsp;");
               out.println("<input type=\"text\" name=\"rest_name\" value=\"" +name+ "\" size=\"30\" maxlength=\"30\">");
               if (copy == false) {
                  out.println("</input><br>&nbsp;&nbsp;&nbsp;* Must be unique");
               } else {
                  out.println("</input><br>&nbsp;&nbsp;&nbsp;* Must be changed!!");
               }
               out.println("<br><br>");

            if (multi != 0) {

               out.println("&nbsp;&nbsp;Select a Course:&nbsp;&nbsp;");
               out.println("<select size=\"1\" name=\"course\">");

               if (courseName.equals( "-ALL-" )) {             // if same as existing name

                  out.println("<option selected value=\"-ALL-\">ALL</option>");
               } else {
                  out.println("<option value=\"-ALL-\">ALL</option>");
               }
               index = 0;
               courseName2 = course[index];      // get course name from array

               while ((!courseName2.equals( "" )) && (index < parm.MAX_Courses)) {

                  if (courseName2.equals( courseName )) {             // if same as existing name

                     out.println("<option selected value=\"" + courseName + "\">" + courseName + "</option>");
                  } else {
                     out.println("<option value=\"" + courseName2 + "\">" + courseName2 + "</option>");
                  }
                  index++;
                  courseName2 = course[index];      // get course name from array
               }
               out.println("</select>");
               out.println("<br><br>");

            } else {

               out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
            }
              out.println("&nbsp;&nbsp;Tees:&nbsp;&nbsp;");
                out.println("<select size=\"1\" name=\"fb\">");
                if (fb.equals( "Both" )) {
                   out.println("<option selected value=\"Both\">Both</option>");
                } else {
                   out.println("<option value=\"Both\">Both</option>");
                }
                if (fb.equals( "Front" )) {
                   out.println("<option selected value=\"Front\">Front</option>");
                } else {
                   out.println("<option value=\"Front\">Front</option>");
                }
                if (fb.equals( "Back" )) {
                   out.println("<option selected value=\"Back\">Back</option>");
                } else {
                   out.println("<option value=\"Back\">Back</option>");
                }
              out.println("</select><br><br>");
                
               out.println("&nbsp;&nbsp;Start Date:&nbsp;&nbsp;&nbsp;");
                 out.println("Month:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"smonth\">");
                   if (s_month == 1) {
                      out.println("<option selected value=\"01\">JAN</option>");
                   } else {
                      out.println("<option value=\"01\">JAN</option>");
                   }
                   if (s_month == 2) {
                      out.println("<option selected value=\"02\">FEB</option>");
                   } else {
                      out.println("<option value=\"02\">FEB</option>");
                   }
                   if (s_month == 3) {
                      out.println("<option selected value=\"03\">MAR</option>");
                   } else {
                      out.println("<option value=\"03\">MAR</option>");
                   }
                   if (s_month == 4) {
                      out.println("<option selected value=\"04\">APR</option>");
                   } else {
                      out.println("<option value=\"04\">APR</option>");
                   }
                   if (s_month == 5) {
                      out.println("<option selected value=\"05\">MAY</option>");
                   } else {
                      out.println("<option value=\"05\">MAY</option>");
                   }
                   if (s_month == 6) {
                      out.println("<option selected value=\"06\">JUN</option>");
                   } else {
                      out.println("<option value=\"06\">JUN</option>");
                   }
                   if (s_month == 7) {
                      out.println("<option selected value=\"07\">JUL</option>");
                   } else {
                      out.println("<option value=\"07\">JUL</option>");
                   }
                   if (s_month == 8) {
                      out.println("<option selected value=\"08\">AUG</option>");
                   } else {
                      out.println("<option value=\"08\">AUG</option>");
                   }
                   if (s_month == 9) {
                      out.println("<option selected value=\"09\">SEP</option>");
                   } else {
                      out.println("<option value=\"09\">SEP</option>");
                   }
                   if (s_month == 10) {
                      out.println("<option selected value=\"10\">OCT</option>");
                   } else {
                      out.println("<option value=\"10\">OCT</option>");
                   }
                   if (s_month == 11) {
                      out.println("<option selected value=\"11\">NOV</option>");
                   } else {
                      out.println("<option value=\"11\">NOV</option>");
                   }
                   if (s_month == 12) {
                      out.println("<option selected value=\"12\">DEC</option>");
                   } else {
                      out.println("<option value=\"12\">DEC</option>");
                   }
                 out.println("</select>");

                 out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"sday\">");
                   if (s_day == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (s_day == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (s_day == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (s_day == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (s_day == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (s_day == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (s_day == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (s_day == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (s_day == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (s_day == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (s_day == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (s_day == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                   if (s_day == 13) {
                      out.println("<option selected value=\"13\">13</option>");
                   } else {
                      out.println("<option value=\"13\">13</option>");
                   }
                   if (s_day == 14) {
                      out.println("<option selected value=\"14\">14</option>");
                   } else {
                      out.println("<option value=\"14\">14</option>");
                   }
                   if (s_day == 15) {
                      out.println("<option selected value=\"15\">15</option>");
                   } else {
                      out.println("<option value=\"15\">15</option>");
                   }
                   if (s_day == 16) {
                      out.println("<option selected value=\"16\">16</option>");
                   } else {
                      out.println("<option value=\"16\">16</option>");
                   }
                   if (s_day == 17) {
                      out.println("<option selected value=\"17\">17</option>");
                   } else {
                      out.println("<option value=\"17\">17</option>");
                   }
                   if (s_day == 18) {
                      out.println("<option selected value=\"18\">18</option>");
                   } else {
                      out.println("<option value=\"18\">18</option>");
                   }
                   if (s_day == 19) {
                      out.println("<option selected value=\"19\">19</option>");
                   } else {
                      out.println("<option value=\"19\">19</option>");
                   }
                   if (s_day == 20) {
                      out.println("<option selected value=\"20\">20</option>");
                   } else {
                      out.println("<option value=\"20\">20</option>");
                   }
                   if (s_day == 21) {
                      out.println("<option selected value=\"21\">21</option>");
                   } else {
                      out.println("<option value=\"21\">21</option>");
                   }
                   if (s_day == 22) {
                      out.println("<option selected value=\"22\">22</option>");
                   } else {
                      out.println("<option value=\"22\">22</option>");
                   }
                   if (s_day == 23) {
                      out.println("<option selected value=\"23\">23</option>");
                   } else {
                      out.println("<option value=\"23\">23</option>");
                   }
                   if (s_day == 24) {
                      out.println("<option selected value=\"24\">24</option>");
                   } else {
                      out.println("<option value=\"24\">24</option>");
                   }
                   if (s_day == 25) {
                      out.println("<option selected value=\"25\">25</option>");
                   } else {
                      out.println("<option value=\"25\">25</option>");
                   }
                   if (s_day == 26) {
                      out.println("<option selected value=\"26\">26</option>");
                   } else {
                      out.println("<option value=\"26\">26</option>");
                   }
                   if (s_day == 27) {
                      out.println("<option selected value=\"27\">27</option>");
                   } else {
                      out.println("<option value=\"27\">27</option>");
                   }
                   if (s_day == 28) {
                      out.println("<option selected value=\"28\">28</option>");
                   } else {
                      out.println("<option value=\"28\">28</option>");
                   }
                   if (s_day == 29) {
                      out.println("<option selected value=\"29\">29</option>");
                   } else {
                      out.println("<option value=\"29\">29</option>");
                   }
                   if (s_day == 30) {
                      out.println("<option selected value=\"30\">30</option>");
                   } else {
                      out.println("<option value=\"30\">30</option>");
                   }
                   if (s_day == 31) {
                      out.println("<option selected value=\"31\">31</option>");
                   } else {
                      out.println("<option value=\"31\">31</option>");
                   }
                 out.println("</select>");

                 out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"syear\">");
                   if (s_year == 2002) {
                      out.println("<option selected value=\"2002\">2002</option>");
                   } else {
                      out.println("<option value=\"2002\">2002</option>");
                   }
                   if (s_year == 2003) {
                      out.println("<option selected value=\"2003\">2003</option>");
                   } else {
                      out.println("<option value=\"2003\">2003</option>");
                   }
                   if (s_year == 2004) {
                      out.println("<option selected value=\"2004\">2004</option>");
                   } else {
                      out.println("<option value=\"2004\">2004</option>");
                   }
                   if (s_year == 2005) {
                      out.println("<option selected value=\"2005\">2005</option>");
                   } else {
                      out.println("<option value=\"2005\">2005</option>");
                   }
                   if (s_year == 2006) {
                      out.println("<option selected value=\"2006\">2006</option>");
                   } else {
                      out.println("<option value=\"2006\">2006</option>");
                   }
                   if (s_year == 2007) {
                      out.println("<option selected value=\"2007\">2007</option>");
                   } else {
                      out.println("<option value=\"2007\">2007</option>");
                   }
                   if (s_year == 2008) {
                      out.println("<option selected value=\"2008\">2008</option>");
                   } else {
                      out.println("<option value=\"2008\">2008</option>");
                   }
                   if (s_year == 2009) {
                      out.println("<option selected value=\"2009\">2009</option>");
                   } else {
                      out.println("<option value=\"2009\">2009</option>");
                   }
                   if (s_year == 2010) {
                      out.println("<option selected value=\"2010\">2010</option>");
                   } else {
                      out.println("<option value=\"2010\">2010</option>");
                   }
                 out.println("</select><br><br>");
               out.println("&nbsp;&nbsp;End Date:&nbsp;&nbsp;&nbsp;&nbsp;");
                 out.println("Month:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"emonth\">");
                   if (e_month == 1) {
                      out.println("<option selected value=\"01\">JAN</option>");
                   } else {
                      out.println("<option value=\"01\">JAN</option>");
                   }
                   if (e_month == 2) {
                      out.println("<option selected value=\"02\">FEB</option>");
                   } else {
                      out.println("<option value=\"02\">FEB</option>");
                   }
                   if (e_month == 3) {
                      out.println("<option selected value=\"03\">MAR</option>");
                   } else {
                      out.println("<option value=\"03\">MAR</option>");
                   }
                   if (e_month == 4) {
                      out.println("<option selected value=\"04\">APR</option>");
                   } else {
                      out.println("<option value=\"04\">APR</option>");
                   }
                   if (e_month == 5) {
                      out.println("<option selected value=\"05\">MAY</option>");
                   } else {
                      out.println("<option value=\"05\">MAY</option>");
                   }
                   if (e_month == 6) {
                      out.println("<option selected value=\"06\">JUN</option>");
                   } else {
                      out.println("<option value=\"06\">JUN</option>");
                   }
                   if (e_month == 7) {
                      out.println("<option selected value=\"07\">JUL</option>");
                   } else {
                      out.println("<option value=\"07\">JUL</option>");
                   }
                   if (e_month == 8) {
                      out.println("<option selected value=\"08\">AUG</option>");
                   } else {
                      out.println("<option value=\"08\">AUG</option>");
                   }
                   if (e_month == 9) {
                      out.println("<option selected value=\"09\">SEP</option>");
                   } else {
                      out.println("<option value=\"09\">SEP</option>");
                   }
                   if (e_month == 10) {
                      out.println("<option selected value=\"10\">OCT</option>");
                   } else {
                      out.println("<option value=\"10\">OCT</option>");
                   }
                   if (e_month == 11) {
                      out.println("<option selected value=\"11\">NOV</option>");
                   } else {
                      out.println("<option value=\"11\">NOV</option>");
                   }
                   if (e_month == 12) {
                      out.println("<option selected value=\"12\">DEC</option>");
                   } else {
                      out.println("<option value=\"12\">DEC</option>");
                   }
                 out.println("</select>");

                 out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"eday\">");
                   if (e_day == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (e_day == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (e_day == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (e_day == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (e_day == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (e_day == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (e_day == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (e_day == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (e_day == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (e_day == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (e_day == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (e_day == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                   if (e_day == 13) {
                      out.println("<option selected value=\"13\">13</option>");
                   } else {
                      out.println("<option value=\"13\">13</option>");
                   }
                   if (e_day == 14) {
                      out.println("<option selected value=\"14\">14</option>");
                   } else {
                      out.println("<option value=\"14\">14</option>");
                   }
                   if (e_day == 15) {
                      out.println("<option selected value=\"15\">15</option>");
                   } else {
                      out.println("<option value=\"15\">15</option>");
                   }
                   if (e_day == 16) {
                      out.println("<option selected value=\"16\">16</option>");
                   } else {
                      out.println("<option value=\"16\">16</option>");
                   }
                   if (e_day == 17) {
                      out.println("<option selected value=\"17\">17</option>");
                   } else {
                      out.println("<option value=\"17\">17</option>");
                   }
                   if (e_day == 18) {
                      out.println("<option selected value=\"18\">18</option>");
                   } else {
                      out.println("<option value=\"18\">18</option>");
                   }
                   if (e_day == 19) {
                      out.println("<option selected value=\"19\">19</option>");
                   } else {
                      out.println("<option value=\"19\">19</option>");
                   }
                   if (e_day == 20) {
                      out.println("<option selected value=\"20\">20</option>");
                   } else {
                      out.println("<option value=\"20\">20</option>");
                   }
                   if (e_day == 21) {
                      out.println("<option selected value=\"21\">21</option>");
                   } else {
                      out.println("<option value=\"21\">21</option>");
                   }
                   if (e_day == 22) {
                      out.println("<option selected value=\"22\">22</option>");
                   } else {
                      out.println("<option value=\"22\">22</option>");
                   }
                   if (e_day == 23) {
                      out.println("<option selected value=\"23\">23</option>");
                   } else {
                      out.println("<option value=\"23\">23</option>");
                   }
                   if (e_day == 24) {
                      out.println("<option selected value=\"24\">24</option>");
                   } else {
                      out.println("<option value=\"24\">24</option>");
                   }
                   if (e_day == 25) {
                      out.println("<option selected value=\"25\">25</option>");
                   } else {
                      out.println("<option value=\"25\">25</option>");
                   }
                   if (e_day == 26) {
                      out.println("<option selected value=\"26\">26</option>");
                   } else {
                      out.println("<option value=\"26\">26</option>");
                   }
                   if (e_day == 27) {
                      out.println("<option selected value=\"27\">27</option>");
                   } else {
                      out.println("<option value=\"27\">27</option>");
                   }
                   if (e_day == 28) {
                      out.println("<option selected value=\"28\">28</option>");
                   } else {
                      out.println("<option value=\"28\">28</option>");
                   }
                   if (e_day == 29) {
                      out.println("<option selected value=\"29\">29</option>");
                   } else {
                      out.println("<option value=\"29\">29</option>");
                   }
                   if (e_day == 30) {
                      out.println("<option selected value=\"30\">30</option>");
                   } else {
                      out.println("<option value=\"30\">30</option>");
                   }
                   if (e_day == 31) {
                      out.println("<option selected value=\"31\">31</option>");
                   } else {
                      out.println("<option value=\"31\">31</option>");
                   }
                 out.println("</select>");

                 out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"eyear\">");
                   if (e_year == 2002) {
                      out.println("<option selected value=\"2002\">2002</option>");
                   } else {
                      out.println("<option value=\"2002\">2002</option>");
                   }
                   if (e_year == 2003) {
                      out.println("<option selected value=\"2003\">2003</option>");
                   } else {
                      out.println("<option value=\"2003\">2003</option>");
                   }
                   if (e_year == 2004) {
                      out.println("<option selected value=\"2004\">2004</option>");
                   } else {
                      out.println("<option value=\"2004\">2004</option>");
                   }
                   if (e_year == 2005) {
                      out.println("<option selected value=\"2005\">2005</option>");
                   } else {
                      out.println("<option value=\"2005\">2005</option>");
                   }
                   if (e_year == 2006) {
                      out.println("<option selected value=\"2006\">2006</option>");
                   } else {
                      out.println("<option value=\"2006\">2006</option>");
                   }
                   if (e_year == 2007) {
                      out.println("<option selected value=\"2007\">2007</option>");
                   } else {
                      out.println("<option value=\"2007\">2007</option>");
                   }
                   if (e_year == 2008) {
                      out.println("<option selected value=\"2008\">2008</option>");
                   } else {
                      out.println("<option value=\"2008\">2008</option>");
                   }
                   if (e_year == 2009) {
                      out.println("<option selected value=\"2009\">2009</option>");
                   } else {
                      out.println("<option value=\"2009\">2009</option>");
                   }
                   if (e_year == 2010) {
                      out.println("<option selected value=\"2010\">2010</option>");
                   } else {
                      out.println("<option value=\"2010\">2010</option>");
                   }
                 out.println("</select><br><br>");
               out.println("&nbsp;&nbsp;Start Time:");
               out.println("&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"start_hr\">");
                   if (shr == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (shr == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (shr == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (shr == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (shr == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (shr == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (shr == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (shr == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (shr == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (shr == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (shr == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (shr == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                 out.println("</select>");
                 out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
                    if (smin < 10) {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + smin + " name=\"start_min\">");
                    } else {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + smin + " name=\"start_min\">");
                    }
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"start_ampm\">");
                   if (ssampm.equals( "AM" )) {
                      out.println("<option selected value=\"00\">AM</option>");
                   } else {
                      out.println("<option value=\"00\">AM</option>");
                   }
                   if (ssampm.equals( "PM" )) {
                      out.println("<option selected value=\"12\">PM</option>");
                   } else {
                      out.println("<option value=\"12\">PM</option>");
                   }
                 out.println("</select><br><br>");
               out.println("&nbsp;&nbsp;End Time:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"end_hr\">");
                   if (ehr == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (ehr == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (ehr == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (ehr == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (ehr == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (ehr == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (ehr == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (ehr == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (ehr == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (ehr == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (ehr == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (ehr == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                 out.println("</select>");
                 out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
                    if (emin < 10) {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + emin + " name=\"end_min\">");
                    } else {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + emin + " name=\"end_min\">");
                    }
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"end_ampm\">");
                   if (seampm.equals( "AM" )) {
                      out.println("<option selected value=\"00\">AM</option>");
                   } else {
                      out.println("<option value=\"00\">AM</option>");
                   }
                   if (seampm.equals( "PM" )) {
                      out.println("<option selected value=\"12\">PM</option>");
                   } else {
                      out.println("<option value=\"12\">PM</option>");
                   }
                 out.println("</select><br><br>");
                 out.println("&nbsp;&nbsp;Recurrence:&nbsp;&nbsp;&nbsp;");
                 out.println("<select size=\"1\" name=\"recurr\">");
                if (recur.equalsIgnoreCase( "every day" )) {
                   out.println("<option selected value=\"Every Day\">Every Day</option>");
                } else {
                   out.println("<option value=\"Every Day\">Every Day</option>");
                }
                if (recur.equalsIgnoreCase( "every sunday" )) {
                   out.println("<option selected value=\"Every Sunday\">Every Sunday</option>");
                } else {
                   out.println("<option value=\"Every Sunday\">Every Sunday</option>");
                }
                if (recur.equalsIgnoreCase( "every monday" )) {
                   out.println("<option selected value=\"Every Monday\">Every Monday</option>");
                } else {
                   out.println("<option value=\"Every Monday\">Every Monday</option>");
                }
                if (recur.equalsIgnoreCase( "every tuesday" )) {
                   out.println("<option selected value=\"Every Tuesday\">Every Tuesday</option>");
                } else {
                   out.println("<option value=\"Every Tuesday\">Every Tuesday</option>");
                }
                if (recur.equalsIgnoreCase( "every wednesday" )) {
                   out.println("<option selected value=\"Every Wednesday\">Every Wednesday</option>");
                } else {
                   out.println("<option value=\"Every Wednesday\">Every Wednesday</option>");
                }
                if (recur.equalsIgnoreCase( "every thursday" )) {
                   out.println("<option selected value=\"Every Thursday\">Every Thursday</option>");
                } else {
                   out.println("<option value=\"Every Thursday\">Every Thursday</option>");
                }
                if (recur.equalsIgnoreCase( "every friday" )) {
                   out.println("<option selected value=\"Every Friday\">Every Friday</option>");
                } else {
                   out.println("<option value=\"Every Friday\">Every Friday</option>");
                }
                if (recur.equalsIgnoreCase( "every saturday" )) {
                   out.println("<option selected value=\"Every Saturday\">Every Saturday</option>");
                } else {
                   out.println("<option value=\"Every Saturday\">Every Saturday</option>");
                }
                if (recur.equalsIgnoreCase( "all weekdays" )) {
                   out.println("<option selected value=\"All Weekdays\">All Weekdays</option>");
                } else {
                   out.println("<option value=\"All Weekdays\">All Weekdays</option>");
                }
                if (recur.equalsIgnoreCase( "all weekends" )) {
                   out.println("<option selected value=\"All Weekends\">All Weekends</option>");
                } else {
                   out.println("<option value=\"All Weekends\">All Weekends</option>");
                }
                 out.println("</select></p>");
               out.println("<p align=\"center\">&nbsp;&nbsp;Groups to be Restricted<br>");
               out.println("<i>(specify Members to restrict or Membership Types to restrict, not both)</i></p>");

            out.println("<p align=\"left\">&nbsp;&nbsp;Members to be Restricted (select all that apply):<br>");

               //
               //  smemx = not null if this was specified in club db table (supported)
               //  memx = not null if this was specified in restriction
               //
               for (i=1; i<parm.MAX_Mems+1; i++) {

                  if (!smem[i].equals( "" )) {          // if supported and

                     out.println("<br>");
                     out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

                     if (!mem[i].equals( "" )) {        //    already checked

                        out.println("<input type=\"checkbox\" checked name=\"mem" +i+ "\" value=\"" + smem[i] + "\">&nbsp;&nbsp;" + smem[i]);
                     } else {
                        out.println("<input type=\"checkbox\" name=\"mem" +i+ "\" value=\"" + smem[i] + "\">&nbsp;&nbsp;" + smem[i]);
                     }
                  }
               }

            out.println("</p><p align=\"center\"><b>-OR-</b><br></p>");

            out.println("<p align=\"left\">&nbsp;&nbsp;Membership Types to be Restricted (select all that apply):<br>");

               //
               //  smshipx = not null if this was specified in club db table (supported)
               //  mshipx = not null if this was specified in restriction
               //
               for (i=1; i<parm.MAX_Mships+1; i++) {

                  if (!smship[i].equals( "" )) {          // if supported and

                     out.println("<br>");
                     out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

                     if (!mship[i].equals( "" )) {        //    already checked

                        out.println("<input type=\"checkbox\" checked name=\"mship" +i+ "\" value=\"" + smship[i] + "\">&nbsp;&nbsp;" + smship[i]);
                     } else {
                        out.println("<input type=\"checkbox\" name=\"mship" +i+ "\" value=\"" + smship[i] + "\">&nbsp;&nbsp;" + smship[i]);
                     }
                  }
               }

              out.println("<br>&nbsp;&nbsp;Show this restriction on Tee Sheet?:&nbsp;&nbsp;");
                out.println("<select size=\"1\" name=\"show\">");
                if (show.equals( "Yes" )) {
                   out.println("<option selected value=\"Yes\">Yes</option>");
                } else {
                   out.println("<option value=\"Yes\">Yes</option>");
                }
                if (show.equals( "No" )) {
                   out.println("<option selected value=\"No\">No</option>");
                } else {
                   out.println("<option value=\"No\">No</option>");
                }
              out.println("</select><br><br>");

               out.println("&nbsp;&nbsp;If Yes, Color to make this restriction on the tee sheet:&nbsp;&nbsp;");

                Common_Config.displayColorsAll(color, out);       // output the color options

                 out.println("<br>");
                 out.println("&nbsp;&nbsp;Click here to see the available colors:&nbsp;");
                 out.println("<a href=\"/" +rev+ "/proshop_color.htm\" target=\"_blank\">View Colors</a></p>");

               out.println("<input type=\"hidden\" name=\"oldName\" value=\"" + oldName + "\"></input>");
               out.println("<input type=\"hidden\" name=\"oldCourse\" value=\"" + oldCourse + "\"></input>");
               out.println("<input type=\"hidden\" name=\"sheet\" value=\"" + sheet + "\">");

               out.println("<p align=\"center\">");
         if (copy == false) {
            out.println("<input type=\"submit\" name=\"Update\" value=\"Update\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
            out.println("<input type=\"submit\" name=\"Delete\" value=\"Delete\" onclick=\"return confirm('Are you sure you want to delete this restriction?')\">");
         } else {
            out.println("<input type=\"submit\" name=\"Add\" value=\"Add\">");
         }
      out.println("</p></font></td></tr></form></table>");
      out.println("</td></tr></table>");                       // end of main page table
        
   out.println("<font size=\"2\">");
   if (!sheet.equals( "yes" )) {                      // if not call from Proshop_sheet
      out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_mrest\">");
      out.println("<input type=\"submit\" value=\"Cancel\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</input></form>");
   } else {
      out.println("<form><input type=\"button\" value=\"Cancel\" onClick='self.close();'>");
      out.println("</input></form>");
   }
   out.println("</font>");
   out.println("</center></font></body></html>");
   out.close();

 }   // end of doPost   


 // ***************************************************************************
 //  Process the copy request - display a selection list of existing rest's
 // ***************************************************************************

 private void doCopy(PrintWriter out, Connection con) {

   Statement stmt = null;
   ResultSet rs = null;

   //
   // Define some parms to use in the html
   //
   String name = "";       // name of restriction

   boolean b = false;

   //
   //  Build the HTML page to display the existing restrictions
   //
   out.println(SystemUtils.HeadTitle("Proshop Member Restrictions Page"));
   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");

   out.println("<table cellpadding=\"5\" bgcolor=\"#336633\" border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");
   out.println("<font color=\"#FFFFFF\" size=\"3\">");
   out.println("<b>Copy a Member Restriction</b><br>");
   out.println("</font>");
   out.println("<font color=\"#FFFFFF\" size=\"2\">");
   out.println("<b>Instructions:</b>&nbsp;&nbsp;Use this feature to create a new restriction by copying an existing restriction.<br>");
   out.println("Select the restriction you wish to copy from the list below.");
   out.println("</font></td></tr></table>");
   out.println("<br><br>");

   //
   //  Get and display the existing restrictions 
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT name FROM restriction2");

      if (rs.next()) {

         b = true;                     // indicate restrictions exist
      }
      stmt.close();

      if (b == true) {
        
         out.println("<font size=\"2\">");
         out.println("<p>Select the restriction you wish to copy.</p>");

         out.println("<form action=\"/" +rev+ "/servlet/Proshop_mrest\" method=\"post\" target=\"bot\">");
         out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");     // tell addmrest its a copy
         out.println("<select size=\"1\" name=\"name\">");

         //
         //  Do again to actually get the names
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT name FROM restriction2 ORDER BY name");

         while (rs.next()) {

            name = rs.getString("name");

            out.println("<option value=\"" +name+ "\">" +name+ "</option>");

         }  // end of while loop

         stmt.close();

         out.println("</select><br><br>");

         out.println("<input type=\"submit\" name=\"Continue\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form>");

      } else {            // no rest's exist

         out.println("<p><font size=\"2\">No Member Restrictions Currently Exist</p>");
      }
   }
   catch (Exception exc) {

      out.println("<BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");

   }  // end of try

   //
   //  End of HTML page
   //
   out.println("</td></tr></table>");                // end of main page table
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_mrest\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</center></font><br></body></html>");
   out.close();
 }


 // *********************************************************
 // Database Error
 // *********************************************************

 private void dbError(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Database Error"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><BR><H3>Database Access Error</H3>");
   out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
   out.println("<BR>Please try again later.");
   out.println("<BR><BR>If problem persists, contact customer support.");
   out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
   out.println("</CENTER></BODY></HTML>");
   out.close();
 }

}
