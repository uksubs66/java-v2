/***************************************************************************************
 *   Proshop_maintop:  This servlet will display the Proshop's navigation bar (Top of Page).
 *
 *
 *   called by:  proshop_welms
 *
 *   created:  7/22/2003   Bob P.
 *
 *
 *   last updated:
 *
 *     04/14/07  Congressional - add limited login for proshop9 (Tony Monagus - case #1112).
 *     07/20/06  Changes for TLT System
 *     10/11/04  Ver 5 - Change format to provide drop-down menus.
 *      4/30/04  RDP  Add club logo and move ForeTees logo.
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

public class Proshop_maintop extends HttpServlet {

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    //
    //  Prevent caching so sessions are not mangled
    //
    resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
    resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
    resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    Statement stmt = null;
    ResultSet rs = null;

    HttpSession session = SystemUtils.verifyPro(req, out);             // check for intruder
    if (session == null) return;

    Connection con = SystemUtils.getCon(session);                      // get DB connection

    if (con == null) {

        out.println(SystemUtils.HeadTitle("DB Connection Error"));
        out.println("<BODY><CENTER>");
        out.println("<BR><BR><H3>Database Connection Error</H3>");
        out.println("<BR><BR>Unable to connect to the Database.");
        out.println("<BR>Please try again later.");
        out.println("<BR><BR>If problem persists, contact customer support.");
        out.println("<BR><BR>");
        out.println("<a href=\"/" +rev+ "/servlet/Logout\" target=\"_top\">Return</a>");
        out.println("</CENTER></BODY></HTML>");
        return;
    }

    // Define parms
    int lottery = 0;             // lottery support = no

    String club = "";
    String zip = "";
    String user = "";

    club = (String)session.getAttribute("club");
    user = (String)session.getAttribute("user");
    zip = (String)session.getAttribute("zipcode");
    String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
    
    //
    //  See if we are in teh timeless tees mode
    //
    int tmp_tlt = (Integer)session.getAttribute("tlt");
    boolean IS_TLT = (tmp_tlt == 1) ? true : false;

    if (templott != null && !templott.equals( "" )) {

        lottery = Integer.parseInt(templott);
    }

    //
    //  Get this year
    //
    Calendar cal = new GregorianCalendar();       // get todays date
    int year = cal.get(Calendar.YEAR);            // get the year

    //
    //  Build the HTML page (main menu)
    //
    if (!club.equals( "congressional" ) || !user.equalsIgnoreCase( "proshop9" )) {     // if not proshop9 at Congressional
      
       out.println("<html><head>");
       out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
       out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
       out.println("<title> \"ForeTees Proshop Main Title Page\"</title>");

       out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees.css\" type=\"text/css\"></link>");
       out.println("<script language=\"JavaScript\" src=\"/" +rev+ "/web utilities/foretees.js\"></script>");

       out.println("</head>");

       out.println("<body leftmargin=\"0\" marginheight=\"0\" marginwidth=\"0\" topmargin=\"0\">");

       SystemUtils.getProshopMainMenu(req, out, lottery);

        out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#CCCCAA\">");
        out.print("<tr><td valign=\"middle\" width=\"10%\" align=\"left\">");
        //out.println("<p>&nbsp;&nbsp;&nbsp;<img src=\"/" +club+ "/images/logo.jpg\" border=0></p>");
        out.print("&nbsp;&nbsp;&nbsp;<img src=\"/" +club+ "/images/logo.jpg\" border=0>");
        out.print("</td>");

        out.print("<td valign=\"middle\" width=\"12%\" align=\"left\">");
         if (zip != null && !zip.equals( "" )) {     // if zipcode provided
            out.print("<a href=\"http://wwwa.accuweather.com/forecast.asp?partner=&zipcode=" +zip+ "\" target=\"_blank\">");
         } else {
            out.print("<a href=\"http://wwwa.accuweather.com/adcbin/public/golf_index.asp?partner=accuweather\" target=\"_blank\">");
         }
         out.print("<img src=\"/" +rev+ "/images/weather.gif\" border=0></a><br><br>");
        out.print("</td>");

        out.println("<td width=\"54%\" align=\"center\">");
           out.println("<font size=\"5\">" + ((IS_TLT) ? "Golf Shop Course Management" : "Golf Shop Tee Time Management") + "</font><br>");

        //output the Home, Logout/Exit, and Help links
        out.println("<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Proshop_announce\" target=\"bot\" >Home</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Proshop_probs\" target=\"bot\">Support</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Logout\" target=\"_top\" >Logout</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/proshop_help.htm\" target=\"_blank\" >Help</a>");

        out.println("<br><br><br></td>");
         out.print("<td width=\"24%\"align=\"middle\">");
          //out.print("<p>");
          out.print("<a href=\"http://www.foretees.com\" target=\"_blank\">");
          out.print("<img src=\"/" +rev+ "/images/foretees_nav.jpg\" border=0></a>");
          out.print("<br><font size=\"1\" color=\"#000000\">Copyright&nbsp;</font>");
          out.print("<font size=\"2\" color=\"#000000\">&#169;&nbsp;</font>");
          out.print("<font size=\"1\" color=\"#000000\">ForeTees, LLC<br>" +year+ " All rights reserved.</font>");
          //out.print("</p>");
        out.print("</td>");
       out.print("</tr>");
       out.println("</table>");
       out.println("</body></html>");

    } else {
      
       //
       //  Congressional - proshop9 (Tony Monagus call center) - display limited menu.
       //
       out.println("<html><head>");
       out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
       out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
       out.println("<title> \"ForeTees Proshop Main Title Page\"</title>");
       out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees.css\" type=\"text/css\"></link>");
       out.println("<script language=\"JavaScript\" src=\"/" +rev+ "/web utilities/foretees.js\"></script>");
       out.println("</head>");
       out.println("<body leftmargin=\"0\" marginheight=\"0\" marginwidth=\"0\" topmargin=\"0\">");
         
        out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#CCCCAA\">");
        out.println("<tr valign=\"top\" height=\"41\"><td valign=\"middle\" width=\"10%\" align=\"left\" rowspan=\"2\">");
        out.println("<p>&nbsp;&nbsp;&nbsp;<img src=\"/" +club+ "/images/logo.jpg\" border=0></p>");
        out.println("</td>");

        out.println("<td valign=\"middle\" width=\"12%\" align=\"left\" rowspan=\"2\">");
         if (zip != null && !zip.equals( "" )) {     // if zipcode provided
            out.println("<a href=\"http://wwwa.accuweather.com/forecast.asp?partner=&zipcode=" +zip+ "\" target=\"_blank\">");
         } else {
            out.println("<a href=\"http://wwwa.accuweather.com/adcbin/public/golf_index.asp?partner=accuweather\" target=\"_blank\">");
         }
         out.println("<img src=\"/" +rev+ "/images/weather.gif\" border=0></a><br><br>");
        out.println("</td>");
        out.println("<td width=\"54%\" align=\"center\">");
           out.println("<font size=\"5\">Golf Shop Tee Time Management</font><br>");

        //output the Home, Logout/Exit, and Help links
        out.println("<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Proshop_announce\" target=\"bot\" >Home</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Proshop_probs\" target=\"bot\">Support</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/servlet/Logout\" target=\"_top\" >Logout</a>");
        out.println("&nbsp;<label class=\"gblSep\">|</label>&nbsp;<a class=\"gblHref\" href=\"/" +rev+ "/proshop_help.htm\" target=\"_blank\" >Help</a>");

        out.println("</td>");
         out.println("<td width=\"24%\"align=\"middle\" rowspan=\"2\">");
          out.println("<p>");
          out.println("<a href=\"http://www.foretees.com\" target=\"_blank\">");
          out.println("<img src=\"/" +rev+ "/images/foretees_nav.jpg\" border=0></a>");
          out.println("<br><font size=\"1\" color=\"#000000\">Copyright&nbsp;</font>");
          out.println("<font size=\"2\" color=\"#000000\">&#169;&nbsp;</font>");
          out.println("<font size=\"1\" color=\"#000000\">ForeTees, LLC<br>" +year+ " All rights reserved.");
          out.println("</font></p>");
        out.println("</td>");
       out.println("</tr>");
          out.println("<tr height=\"41\" valign=\"bottom\">");
            out.println("<td align=\"center\">");
            out.println("<!-- Begin code to display images horizontally. -->");
             out.println("<a href=\"/" +rev+ "/servlet/Proshop_select\" target=\"bot\"><img name=\"Proshop Tee Times\" src=\"/" +rev+ "/images/ProTeeSheetsNoDrop.gif\" hspace=\"0\" border=\"0\" title=\"Make or Change Tee Times\" alt=\"Access the Tee Sheets\"></a>");
             out.println("<a href=\"/" +rev+ "/servlet/Proshop_events1\" target=\"bot\"><img name=\"Proshop Events\" src=\"/" +rev+ "/images/ProEventsNoDrop.gif\" hspace=\"0\" border=\"0\" title=\"View Events or Register Members for Events\" alt=\"Access the Events\"></a>");
             out.println("<a href=\"/" +rev+ "/servlet/Proshop_lesson\" target=\"bot\"><img name=\"Proshop Lessons\" src=\"/" +rev+ "/images/ProLessonsNoDrop.gif\" hspace=\"0\" border=\"0\" title=\"Manage Lessons\" alt=\"Manage Lessons\"></a>");
             out.println("<a href=\"/" +rev+ "/servlet/Proshop_services\" target=\"bot\"><img name=\"Proshop Services\" src=\"/" +rev+ "/images/ProSettingsNoDrop.gif\" hspace=\"0\" border=\"0\" title=\"Change User Settings\" alt=\"Proshop Settings\"></a>");
            out.println("</td>");
          out.println("</tr>");
       out.println("</table>");
       out.println("</body></html>");
    }

 }  // end of doGet

}
