/***************************************************************************************
 *   Member_evntSignUp:  This servlet will process a request to register a member for
 *                       an event.
 *
 *
 *
 *   called by:  Member_events
 *
 *
 *   created: 2/11/2003   Bob P.
 *
 *   last updated:
 *
 *       4/02/08   Surpess the c/w option for season long events
 *       3/27/08   Added support for new event fields, season, email1, email2 - Case 1372 & 1408
 *       3/07/08   Piedmont & Gallery - add pro emails to all notifications (cases 1395 & 1398).
 *      12/04/07   Berkeley Hall - Remove the trans mode of 'REC' and 'CMP' (Case 1341)
 *      11/30/07   Fixed guest associations when only 1 member included in signup
 *      10/15/07   Pinnacle Peak CC - Remove the trans mode of 'NC' (Case 1288)
 *       9/25/07   Add enforcement of new minimum sign-up size option
 *       8/20/07   Modified call to verifySlot.checkMemNotice
 *       6/26/07   When pulling a handicap from member2b get it from the g_hancap field instead of c_hancap
 *       4/25/07   Congressional - pass the date for the ourse Name Labeling.
 *       4/06/07   Do not include members that are inactive (new inact flag in member2b).
 *       3/20/07   Custom for Congressional - abstract the course name depending on the day (Course Name Labeling)
 *       2/27/07   Add new 'Member Notice' processing - display pro-defined message if found.
 *       2/15/07   Set the clubname and course name for getClub.getParms.
 *       9/11/06   Wellesley - add custom to force 'Tourney Guest' as the only guest type.
 *       3/17/06   Stanwich Club - add custom message in event signup confirmation.
 *       9/15/05   Medinah - do not show guest types that are not for events.
 *       5/13/05   Add processing for restrictions on events (member may not have access to event).
 *       4/01/05   Put the 'X' option by itself to avoid confusion with guest types.
 *       2/07/05   Replace 'back(1)' javascripts with a form to return to events2.
 *      12/09/04   Ver 5 - Change Member Name Alphabit table to common table.
 *      11/20/04   Ver 5 - allow for return to Member_teelist (add index=).
 *       9/20/04   Ver 5 - change getClub from SystemUtils to common.
 *       7/25/04   Make sure there is room in event before changing wait to registered after
 *                 a group is cancelled.
 *       2/16/04   Add support for configurable transportation modes.
 *       1/13/04   JAG  Modifications to match new color scheme
 *       7/18/03   Enhancements for Version 3 of the software.
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.parmSlot;
import com.foretees.common.verifySlot;
import com.foretees.common.parmEmail;
import com.foretees.common.sendEmail;
import com.foretees.common.parmClub;
import com.foretees.common.getClub;
import com.foretees.common.alphaTable;
import com.foretees.common.congressionalCustom;


public class Member_evntSignUp extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //
 //******************************************************************************
 //  doPost processing
 //******************************************************************************

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   //
   //  Prevent caching so sessions are not mangled
   //
   resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
   resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
   resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyMem(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   //
   //  Get this session's username and full name
   //
   String club = (String)session.getAttribute("club");
   String caller = (String)session.getAttribute("caller");
   String user = (String)session.getAttribute("user");
   String userName = (String)session.getAttribute("name");   // get users full name


   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY bgcolor=\"#ccccaa\">");
      out.println("<CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   // Process request according to which 'submit' button was selected
   //
   //      'id'      - a request from Member_events
   //      'cancel'  - a cancel request from self (return with no changes)
   //      'letter'  - a request to list member names (from self)
   //      'buddy'   - a request to display the Partner List (from self)
   //      'submitForm'  - a reservation request (from self)
   //      'remove'  - a 'cancel reservation' request (from self - Cancel Tee Time)
   //      'return'  - a return from verify
   //
   if (req.getParameter("cancel") != null) {

      cancelReq(req, out, con);                      // process cancel request
      return;
   }


   //
   //  if user submitting request to update or cancel the entry - go process
   //
   if ((req.getParameter("submitForm") != null) || (req.getParameter("remove") != null)) {

      verify(req, out, con, session, resp);            // process reservation requests request
      return;
   }

   //
   //   Request is from Member_events -or- its a letter or buddy request from self
   //
   String name = "";
   String pairings = "";
   String course = "";
   String act_ampm = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String pname = "";
   String sid = "";
   String sfb = "";
   String notes = "";
   String hides = "";
   String index = "";
   String season_tmode = "";

   int month  = 0;
   int day = 0;
   int year = 0;
   int act_hr = 0;
   int act_min = 0;
   int size = 0;
   int max = 0;
   int guests = 0;
   int count = 0;
   int count2 = 0;
   int in_use = 0;
   int id = 0;
   int fb = 0;
   int hide = 0;
   int xCount = 0;
   int x = 0;
   int i = 0;
   int nowc = 0;
   int time = 0;
   int c_time = 0;
   int gstOnly = 0;
   int season = 0;

   int [] tmode = new int [16];      // supported transportation modes for event

   long date = 0;
   long c_date = 0;
   float hndcp1 = 0;
   float hndcp2 = 0;
   float hndcp3 = 0;
   float hndcp4 = 0;
   float hndcp5 = 0;

   //
   //  arrays to hold partner list
   //
   String [] buddy = new String [25];            // max of 25 partners
   String [] bcw = new String [25];

   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

   boolean guestError = false;            // init error flag

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   //  parm block to hold the course parameters
   //
   parmCourse parmc = new parmCourse();          // allocate a parm block


   //
   //   Get the parms received
   //
   name = req.getParameter("name");
   course = req.getParameter("course");

   if (req.getParameter("index") != null) {         // if from Member_teelist

      index = req.getParameter("index");
   }

   try {

      //
      //   get the event requested
      //
      PreparedStatement stmt = con.prepareStatement (
         "SELECT * FROM events2b " +
         "WHERE name = ? AND courseName = ? ");

      stmt.clearParameters();        // clear the parms
      stmt.setString(1, name);
      stmt.setString(2, course);
      rs = stmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         date = rs.getLong("date");          // event date
         year = rs.getInt("year");
         month = rs.getInt("month");
         day = rs.getInt("day");
         act_hr = rs.getInt("act_hr");
         act_min = rs.getInt("act_min");
         pairings = rs.getString("pairings");
         size = rs.getInt("size");
         max = rs.getInt("max");
         guests = rs.getInt("guests");
         c_date = rs.getLong("c_date");         // cut-off date
         c_time = rs.getInt("c_time");
         gstOnly = rs.getInt("gstOnly");
         sfb = rs.getString("fb");
         season = rs.getInt("season");
         tmode[0] = rs.getInt("tmode1");
         tmode[1] = rs.getInt("tmode2");
         tmode[2] = rs.getInt("tmode3");
         tmode[3] = rs.getInt("tmode4");
         tmode[4] = rs.getInt("tmode5");
         tmode[5] = rs.getInt("tmode6");
         tmode[6] = rs.getInt("tmode7");
         tmode[7] = rs.getInt("tmode8");
         tmode[8] = rs.getInt("tmode9");
         tmode[9] = rs.getInt("tmode10");
         tmode[10] = rs.getInt("tmode11");
         tmode[11] = rs.getInt("tmode12");
         tmode[12] = rs.getInt("tmode13");
         tmode[13] = rs.getInt("tmode14");
         tmode[14] = rs.getInt("tmode15");
         tmode[15] = rs.getInt("tmode16");

      } else {

         out.println(SystemUtils.HeadTitle("Database Error"));
         out.println("<BODY bgcolor=\"#ccccaa\">");
         out.println("<CENTER>");
         out.println("<BR><BR><H3>Database Access Error</H3>");
         out.println("<BR><BR>Sorry, we are unable to process your request at this time.");
         out.println("<BR><BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your golf shop.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }   // end of IF event found

      stmt.close();

      //
      //  Get the Modes of Trans for this course
      //
      getParms.getCourse(con, parmc, course);

      //
      //  If Pinnacle Peak remove the trans mode of 'NC' (Case 1288)
      //
      if (club.equals( "pinnaclepeak" )) {

         for (i = 0; i < 16; i++) {

            if (parmc.tmodea[i].equalsIgnoreCase( "NC" )) parmc.tmodea[i] = "";
         }
      }
      
      //
      //  If Berkeley Hall remove the trans mode of 'REC' and 'CMP' (Case 1341)
      //
      if (club.equals( "berkeleyhall" )) {

         for (i = 0; i < 16; i++) {

            if (parmc.tmodea[i].equalsIgnoreCase( "REC" ) || parmc.tmodea[i].equalsIgnoreCase( "CMP" )) parmc.tmodea[i] = "";
         }
      }
      
      //
      // Get the first valid tmode option
      //
      tmode_loop:
      for (i=0; i<16; i++) {
        if (tmode[i] == 1) {
           if (!parmc.tmodea[i].equals( "" )) {
              season_tmode = parmc.tmodea[i];
              break tmode_loop;
           }
        }
      }

      //
      //  Create time values
      //
      time = (act_hr * 100) + act_min;       // actual time of event
        
      act_ampm = "AM";

      if (act_hr == 0) {

         act_hr = 12;                 // change to 12 AM (midnight)

      } else {

         if (act_hr == 12) {

            act_ampm = "PM";         // change to Noon
         }
      }
      if (act_hr > 12) {

         act_hr = act_hr - 12;
         act_ampm = "PM";             // change to 12 hr clock
      }

      //
      //  Override team size if proshop pairings (just in case)
      //
      if (!pairings.equalsIgnoreCase( "Member" )) {

         size = 1;       // set size to one for proshop pairings (size is # per team)
      }

      if (req.getParameter("new") != null) {     // if 'new' request
        
         //
         //  see if user is already signed up
         //
         PreparedStatement pstmtu = con.prepareStatement (
            "SELECT name FROM evntsup2b " +
            "WHERE name = ? AND courseName = ? AND (username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?) ");

         pstmtu.clearParameters();        // clear the parms
         pstmtu.setString(1, name);
         pstmtu.setString(2, course);
         pstmtu.setString(3, user);
         pstmtu.setString(4, user);
         pstmtu.setString(5, user);
         pstmtu.setString(6, user);
         pstmtu.setString(7, user);
         rs = pstmtu.executeQuery();      // execute the prepared pstmt

         if (rs.next()) {

            out.println(SystemUtils.HeadTitle("Event Error"));
            out.println("<BODY bgcolor=\"#ccccaa\">");
            out.println("<CENTER>");
            out.println("<BR><BR><H3>Event Sign Up Error</H3>");
            out.println("<BR><BR>Sorry, you are already registered for this event.");
            out.println("<BR><BR>Please check with the Golf Shop if you have any questions.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
         pstmtu.close();

         //
         //  Get the highest existing id from the sign up sheet and insert a new entry
         //
         id = getNewId(con, name, course, c_date, c_time);      // allocate a new entry

         if (id == 0) {

            out.println(SystemUtils.HeadTitle("Event Error"));
            out.println("<BODY bgcolor=\"#ccccaa\">");
            out.println("<CENTER>");
            out.println("<BR><BR><H3>Event Sign Up Error</H3>");
            out.println("<BR><BR>Sorry, we were unable to allocate a new entry for this event.");
            out.println("<BR><BR>Please try again later.");
            out.println("<BR><BR>If problem persists, notify the Golf Shop.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }

      } else {   // not 'new' request

         if ((req.getParameter("letter") != null) || (req.getParameter("buddy") != null) ||
             (req.getParameter("return") != null) || (req.getParameter("memNotice") != null)) {   // if user clicked on a name letter, or its a return from verify

            sid = req.getParameter("id");

         } else {

            //
            //    The name of the submit button contains the 'id' of the entry in the event sign up table
            //
            Enumeration enum1 = req.getParameterNames();     // get the parm name passed

            while (enum1.hasMoreElements()) {

               pname = (String) enum1.nextElement();             // get parm name

               if (pname.startsWith( "id" )) {

                  StringTokenizer tok = new StringTokenizer( pname, ":" );     // separate name around the colon

                  sid = tok.nextToken();                        // skip past 'id: '
                  sid = tok.nextToken();                        // skip past 'id: '
               }
            }
         }                             // end of IF letter or buddy

         id = Integer.parseInt(sid);                   // convert id from string

      }   // end of IF 'new' request

   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<BODY bgcolor=\"#ccccaa\">");
      out.println("<CENTER>");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR> id = " + id + "   sid = " + sid + "   pname = " + pname);
      out.println("<BR><BR>Exception: " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<font size=\"2\">");
      out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
      out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
      out.println("</form></font>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   //   Process both new and update requests (new entry has already been added)
   //
   //      id = id of entry to update
   //      name = name of event
   //      course = name of course
   //      user = username of this member
   //      userName = full name of this member
   //
   //   First, set this entry in_use if not already
   //
   if ((req.getParameter("letter") != null) || (req.getParameter("buddy") != null) ||
       (req.getParameter("return") != null) || (req.getParameter("memNotice") != null)) {   // if user clicked on a name letter, or return

      player1 = req.getParameter("player1");     // get the player info from the parms passed
      player2 = req.getParameter("player2");
      player3 = req.getParameter("player3");
      player4 = req.getParameter("player4");
      player5 = req.getParameter("player5");
      p1cw = req.getParameter("p1cw");
      p2cw = req.getParameter("p2cw");
      p3cw = req.getParameter("p3cw");
      p4cw = req.getParameter("p4cw");
      p5cw = req.getParameter("p5cw");
      notes = req.getParameter("notes");
      hides = req.getParameter("hide");

      //
      //  Convert hide from string to int
      //
      hide = 0;                       // init to No
      if (!hides.equals( "0" )) {     // if not zero
         hide = 1;
      }

   } else {

      synchronized(this) {

         try {

            PreparedStatement pstmt = con.prepareStatement (
               "SELECT in_use " +
               "FROM evntsup2b WHERE name = ? AND courseName = ? AND id = ? ");

            pstmt.clearParameters();        // clear the parms
            pstmt.setString(1, name);         // put the parm in pstmt
            pstmt.setString(2, course);
            pstmt.setInt(3, id);
            rs = pstmt.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               in_use = rs.getInt("in_use");

            }
            pstmt.close();

            if (in_use != 0) {              // if event slot already in use

               out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
               out.println("<BODY bgcolor=\"#ccccaa\">");
               out.println("<CENTER><BR><BR><H3>Event Entry Busy</H3>");
               out.println("<BR><BR>Sorry, but this entry is currently busy.<BR>");
               out.println("<BR>Please select another entry or try again later.");
               out.println("<BR><BR>");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
               out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
               out.println("</form></font>");
               out.println("</CENTER></BODY></HTML>");
               return;
            }

         }
         catch (Exception e1) {

            dbError(out, e1);
            return;
         }

         //
         //  Entry is not in use - set it in use now
         //
         try {

            PreparedStatement pstmt1 = con.prepareStatement (
               "UPDATE evntsup2b SET in_use = 1, in_use_by = ? WHERE name = ? AND courseName = ? AND id = ?");

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, user);         // put the parm in pstmt1
            pstmt1.setString(2, name);
            pstmt1.setString(3, course);
            pstmt1.setInt(4, id);
            count2 = pstmt1.executeUpdate();      // execute the prepared stmt

            pstmt1.close();

         }
         catch (Exception e2) {

            dbError(out, e2);
            return;
         }
      }              // end of synch

      //
      //  get the existing entry and its contents
      //
      try {

         PreparedStatement pstmt3 = con.prepareStatement (
            "SELECT * FROM evntsup2b " +
            "WHERE name = ? AND courseName = ? AND id = ?");

         pstmt3.clearParameters();        // clear the parms
         pstmt3.setString(1, name);
         pstmt3.setString(2, course);
         pstmt3.setInt(3, id);
         rs = pstmt3.executeQuery();      // execute the prepared pstmt

         while (rs.next()) {

            player1 = rs.getString("player1");
            player2 = rs.getString("player2");
            player3 = rs.getString("player3");
            player4 = rs.getString("player4");
            player5 = rs.getString("player5");
            p1cw = rs.getString("p1cw");
            p2cw = rs.getString("p2cw");
            p3cw = rs.getString("p3cw");
            p4cw = rs.getString("p4cw");
            p5cw = rs.getString("p5cw");
            notes = rs.getString("notes");
            hide = rs.getInt("hideNotes");

         }
         pstmt3.close();

      }
      catch (Exception e2) {

         dbError(out, e2);
         return;
      }
        

      //
      //**********************************************
      //   Check for Member Notice from Pro
      //**********************************************
      //
      if (sfb.equals( "Back" )) {      // if Event only on Back Tees
        
         fb = 1;
      }
        
      //
      //  Determine day of week from the event date
      //
      Calendar cal = new GregorianCalendar();       // get todays date

      cal.set(Calendar.YEAR, year);                 // change to requested date
      cal.set(Calendar.MONTH, month-1);
      cal.set(Calendar.DAY_OF_MONTH, day);

      int day_num = cal.get(Calendar.DAY_OF_WEEK);          // day of week (01 - 07)

      String day_name = day_table[day_num];            // get name for day
        
      //        
      //  Check for a Member Notice message from Pro
      //
      String memNotice = verifySlot.checkMemNotice(date, time, fb, course, day_name, "event", false, con);  // use date of event and actual start time

      if (!memNotice.equals( "" )) {      // if message to display

         //
         //  Display the Pro's Message and then prompt the user to either accept or return to the tee sheet
         //
         out.println("<HTML><HEAD>");
         out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
         out.println("<Title>Member Notice For Event Signup Request</Title>");
         out.println("</HEAD>");

         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

            out.println("<table border=\"0\" width=\"100%\" align=\"center\" valign=\"top\">");  // large table for whole page
            out.println("<tr><td valign=\"top\" align=\"center\">");
               out.println("<p>&nbsp;&nbsp;</p>");
               out.println("<p>&nbsp;&nbsp;</p>");
               out.println("<font size=\"3\">");
               out.println("<b>NOTICE FROM YOUR GOLF SHOP</b><br><br><br></font>");

            out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"3\">");
               out.println("<tr>");
               out.println("<td width=\"580\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<br>" + memNotice);
               out.println("</font></td></tr>");
               out.println("</table><br>");

               out.println("</font><font size=\"2\">");
               out.println("<br>Would you like to continue with this request?<br>");
               out.println("<br><b>Please select from the following. DO NOT use you browser's BACK button!</b><br><br>");

               out.println("<table border=\"0\" cols=\"1\" cellpadding=\"3\">");
               out.println("<tr><td align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" name=\"can\">");
               out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
               out.println("<input type=\"submit\" value=\"No - Return\" name=\"cancel\"></form>");

               out.println("</font></td>");

               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
               out.println("</font></td>");

               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">");
                  out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\">");
                  out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
                  out.println("<input type=\"hidden\" name=\"memNotice\" value=\"yes\">");
                  out.println("<input type=\"submit\" value=\"YES - Continue\"></form>");
               out.println("</font></td></tr>");
               out.println("</table>");

               out.println("</td>");
               out.println("</tr>");
            out.println("</table>");
         out.println("</font></center></body></html>");
         out.close();
         return;
      }
  
   }                // end of IF buddy or letter request

   //
   //  Ensure that there are no null player fields
   //
   if (player1 == null ) {
      player1 = "";
   }
   if (player2 == null ) {
      player2 = "";
   }
   if (player3 == null ) {
      player3 = "";
   }
   if (player4 == null ) {
      player4 = "";
   }
   if (player5 == null ) {
      player5 = "";
   }
   if (p1cw == null ) {
      p1cw = "";
   }
   if (p2cw == null ) {
      p2cw = "";
   }
   if (p3cw == null ) {
      p3cw = "";
   }
   if (p4cw == null ) {
      p4cw = "";
   }
   if (p5cw == null ) {
      p5cw = "";
   }

   //
   //   Get the 'X' parms for this event
   //
   try {

      PreparedStatement pstmtev = con.prepareStatement (
         "SELECT x FROM events2b " +
         "WHERE name = ? AND courseName = ? ");

      pstmtev.clearParameters();        // clear the parms
      pstmtev.setString(1, name);
      pstmtev.setString(2, course);
      rs = pstmtev.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         x = rs.getInt("x");
      }
      pstmtev.close();

   }
   catch (Exception ignore) {
   }

   //
   //  Set user's Name as first open player to be placed in name slot for them
   //
   if ((!player1.equals( userName )) && (!player2.equals( userName )) && (!player3.equals( userName )) && (!player4.equals( userName )) && (!player5.equals( userName ))) {

      if (player1.equals("")) {

         player1 = userName;

      } else {

         if (player2.equals("")) {

            player2 = userName;

         } else {

            if (player3.equals("")) {

               player3 = userName;

            } else {

               if (player4.equals("")) {

                  player4 = userName;

               } else {

                  if (player5.equals("")) {

                     player5 = userName;

                  }
               }
            }
         }
      }
   }

   //
   //  Build the HTML page to prompt user for names
   //
   out.println("<HTML>");
   out.println("<HEAD>");
   out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
   out.println("<Title>Member Event Sign Up Page</Title>");

   //
   //*******************************************************************
   //  User clicked on a letter - submit the form for the letter
   //*******************************************************************
   //
   out.println("<script language='JavaScript'>");            // Submit the form when clicking on a letter
   out.println("<!--");
   out.println("function subletter(x) {");

//      out.println("alert(x);");
   out.println("document.playerform.letter.value = x;");         // put the letter in the parm
   out.println("playerform.submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script

   //
   //*********************************************************************************
   //  Erase player name (erase button selected next to player's name)
   //
   //    Remove the player's name and shift any other names up starting at player1
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Erase name script
   out.println("<!--");

   out.println("function erasename(pos1) {");

   out.println("document.playerform[pos1].value = '';");           // clear the player field
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*********************************************************************************
   //   Move buddy script
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move buddy script
   out.println("<!--");

   out.println("function movebuddy(name, cw) {");

   if (size > 1) {
      out.println("var player1 = document.playerform.player1.value;");
      out.println("var player2 = document.playerform.player2.value;");
      if (size > 2) {
         out.println("var player3 = document.playerform.player3.value;");
      }
      if (size > 3) {
         out.println("var player4 = document.playerform.player4.value;");
      }
      if (size > 4) {
         out.println("var player5 = document.playerform.player5.value;");
      }

      if (size == 5) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3) && ( name != player4) && ( name != player5)) {");
      }
      if (size == 4) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3) && ( name != player4)) {");
      }
      if (size == 3) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3)) {");
      }
      if (size == 2) {
         out.println("if (( name != player1) && ( name != player2)) {");
      }
         out.println("if (player1 == '') {");                    // if player1 is empty
            out.println("document.playerform.player1.value = name;");
            out.println("document.playerform.p1cw.value = cw;");

         out.println("} else {");
         out.println("if (player2 == '') {");                    // if player2 is empty
            out.println("document.playerform.player2.value = name;");
            out.println("document.playerform.p2cw.value = cw;");

      if (size > 2) {
         out.println("} else {");
         out.println("if (player3 == '') {");                    // if player3 is empty
            out.println("document.playerform.player3.value = name;");
            out.println("document.playerform.p3cw.value = cw;");

         if (size > 3) {
            out.println("} else {");
            out.println("if (player4 == '') {");                    // if player4 is empty
               out.println("document.playerform.player4.value = name;");
               out.println("document.playerform.p4cw.value = cw;");

            if (size > 4) {
               out.println("} else {");

               out.println("if (player5 == '') {");                    // if player5 is empty
                  out.println("document.playerform.player5.value = name;");
                  out.println("document.playerform.p5cw.value = cw;");
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");
      }
      out.println("}");
      out.println("}");

      out.println("}");                  // end of if all players
   }
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*******************************************************************
   //  Erase text area - (Notes)      erasetext and movenotes
   //*******************************************************************
   //
   out.println("<script language='JavaScript'>");            // Erase text area script
   out.println("<!--");
   out.println("function erasetext(pos1) {");
   out.println("document.playerform[pos1].value = '';");           // clear the text field
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script

   out.println("<script language='JavaScript'>");             // Move Notes into textarea
   out.println("<!--");
   out.println("function movenotes() {");
   out.println("var oldnotes = document.playerform.oldnotes.value;");
   out.println("document.playerform.notes.value = oldnotes;");   // put notes in text area
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*********************************************************************************
   //  Move name script
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move name script
   out.println("<!--");

   out.println("function movename(namewc) {");

   out.println("del = ':';");                               // deliminator is a colon
   out.println("array = namewc.split(del);");                 // split string into 2 pieces (name, wc)
   out.println("var name = array[0];");
   out.println("var wc = array[1];");
   out.println("skip = 0;");

   if (size > 1) {
      out.println("var player1 = document.playerform.player1.value;");
      out.println("var player2 = document.playerform.player2.value;");
      if (size > 2) {
         out.println("var player3 = document.playerform.player3.value;");
      }
      if (size > 3) {
         out.println("var player4 = document.playerform.player4.value;");
      }
      if (size > 4) {
         out.println("var player5 = document.playerform.player5.value;");
      }

      out.println("if (( name != 'x') && ( name != 'X')) {");

      if (size == 5) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3) || ( name == player4) || ( name == player5)) {");
      }
      if (size == 4) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3) || ( name == player4)) {");
      }
      if (size == 3) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3)) {");
      }
      if (size == 2) {
         out.println("if (( name == player1) || ( name == player2)) {");
      }
            out.println("skip = 1;");
         out.println("}");
      out.println("}");

      out.println("if (skip == 0) {");

         out.println("if (player1 == '') {");                    // if player1 is empty
            out.println("document.playerform.player1.value = name;");
            out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
               out.println("document.playerform.p1cw.value = wc;");
            out.println("}");
         out.println("} else {");

         out.println("if (player2 == '') {");                    // if player2 is empty
            out.println("document.playerform.player2.value = name;");
            out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
               out.println("document.playerform.p2cw.value = wc;");
            out.println("}");

         if (size > 2) {
            out.println("} else {");
            out.println("if (player3 == '') {");                    // if player3 is empty
               out.println("document.playerform.player3.value = name;");
               out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                  out.println("document.playerform.p3cw.value = wc;");
               out.println("}");

            if (size > 3) {
               out.println("} else {");
               out.println("if (player4 == '') {");                    // if player4 is empty
                  out.println("document.playerform.player4.value = name;");
                  out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                     out.println("document.playerform.p4cw.value = wc;");
                  out.println("}");

               if (size > 4) {
                  out.println("} else {");
                  out.println("if (player5 == '') {");                    // if player5 is empty
                     out.println("document.playerform.player5.value = name;");
                     out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                        out.println("document.playerform.p5cw.value = wc;");
                     out.println("}");
                  out.println("}");
                }
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");
         out.println("}");

      out.println("}");                  // end of dup name chack
   }
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");                               // End of script

   //
   //*******************************************************************
   //  Move a Guest Name or 'X' into the tee slot
   //*******************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move Guest Name script
   out.println("<!--");

   out.println("function moveguest(namewc) {");

   out.println("var name = namewc;");

   out.println("var player1 = document.playerform.player1.value;");
   if (size > 1) {
      out.println("var player2 = document.playerform.player2.value;");
   }
   if (size > 2) {
      out.println("var player3 = document.playerform.player3.value;");
   }
   if (size > 3) {
      out.println("var player4 = document.playerform.player4.value;");
   }
   if (size > 4) {
      out.println("var player5 = document.playerform.player5.value;");
   }

      out.println("if (player1 == '') {");                    // if player1 is empty
         out.println("document.playerform.player1.value = name;");

      if (size > 1) {
         out.println("} else {");
         out.println("if (player2 == '') {");                    // if player2 is empty
            out.println("document.playerform.player2.value = name;");

         if (size > 2) {
            out.println("} else {");
            out.println("if (player3 == '') {");                    // if player3 is empty
               out.println("document.playerform.player3.value = name;");

            if (size > 3) {
               out.println("} else {");
               out.println("if (player4 == '') {");                    // if player4 is empty
                  out.println("document.playerform.player4.value = name;");

               if (size > 4) {
                  out.println("} else {");
                  out.println("if (player5 == '') {");                    // if player5 is empty
                     out.println("document.playerform.player5.value = name;");
                  out.println("}");
               }
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");
      }
      out.println("}");

   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");                               // End of script

   //*******************************************************************

   out.println("</HEAD>");
   out.println("<body onLoad=\"movenotes()\" bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\">");
   out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

   out.println("<table border=\"0\" width=\"100%\" valign=\"top\">");  // large table for whole page
   out.println("<tr><td valign=\"top\">");

   out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"336633\" align=\"center\" valign=\"top\">");
     out.println("<tr><td align=\"left\" width=\"300\">");
     out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0>");
     out.println("</td>");

     out.println("<td align=\"center\">");
     out.println("<font color=\"#ffffff\" size=\"5\">Member Event Sign Up</font>");
     out.println("</font></td>");

     out.println("<td align=\"center\" width=\"300\">");
     out.println("<font size=\"1\" color=\"#ffffff\">Copyright&nbsp;</font>");
     out.println("<font size=\"2\" color=\"#ffffff\">&#169;&nbsp;</font>");
     out.println("<font size=\"1\" color=\"#ffffff\">ForeTees, LLC <br> 2008 All rights reserved.");
     out.println("</font></td>");
   out.println("</tr></table>");

   out.println("<table border=\"0\" align=\"center\">");                           // table for main page
   out.println("<tr><td align=\"center\"><br>");

      out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"3\">");
         out.println("<tr>");
         out.println("<td width=\"620\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<b>Warning</b>:&nbsp;&nbsp;You have <b>6 minutes</b> to complete this event registration.");
                               out.println("&nbsp; If you want to return without changes, <b>do not ");
                               out.println("use your browser's BACK</b> button/option.&nbsp; Instead select the <b>Go Back</b> ");
                               out.println("option below.");
         out.println("</font></td></tr>");
      out.println("</table>");

      out.println("<font size=\"2\">");
      out.println("<br>Event:&nbsp;&nbsp;<b>" + name + "</b>&nbsp;&nbsp;");
      out.println("Date:&nbsp;&nbsp;<b>" + ((season == 0) ? month + "/" + day + "/" + year : "Season Long") + "</b>&nbsp;&nbsp;");
      if (season == 0) out.println("Time:&nbsp;&nbsp;<b>" + act_hr + ":" + SystemUtils.ensureDoubleDigit(act_min) + " " + act_ampm + "</b>");
      if (!course.equals( "" )) {
          
            if (club.equals("congressional")) {
                out.println(" &nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + congressionalCustom.getFullCourseName(date, day, course) + "</b>");
            } else {
                out.println(" &nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + course + "</b>");
            }
            
      }
      out.println("<br></font>");

      out.println("<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" align=\"center\">"); // table to contain 4 tables below

         out.println("<tr>");
         out.println("<td align=\"center\" valign=\"top\">");     // col for Instructions and Go Back button

            out.println("<font size=\"2\"><br><br><br>");
            out.println("<a href=\"#\" onClick=\"window.open ('/" +rev+ "/member_help_evnt_instruct.htm', 'newwindow', config='Height=580, width=680, toolbar=no, menubar=no, scrollbars=auto, resizable=no, location=no directories=no, status=no')\">");
            out.println("<img src=\"/" +rev+ "/images/instructions.gif\" border=0></a><br><br><br><br>");

            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" name=\"can\">");
            out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("Return<br>w/o Changes:<br>");
            out.println("<input type=\"submit\" value=\"Go Back\" name=\"cancel\"></form>");
         out.println("</font></td>");

         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" name=\"playerform\" id=\"playerform\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");

         out.println("<td align=\"center\" valign=\"top\" width=\"390\">");

            out.println("<table border=\"1\" bgcolor=\"#f5f5dc\" align=\"center\">");  // table for player selection   width=\"390\"
            out.println("<tr bgcolor=\"#336633\"><td align=\"center\">");
               out.println("<font color=\"#ffffff\" size=\"2\">");
               out.println("<b>Add or Remove Players</b><br>");
            out.println("</font></td></tr>");
            out.println("<tr><td align=\"center\">");
               out.println("<font size=\"2\"><br>");

               out.println("<nobr>&nbsp;<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player1')\" style=\"cursor:hand\">");
               out.println("Player 1:&nbsp;<input type=\"text\" id=\"player1\" name=\"player1\" value=\"" + player1 + "\" size=\"26\" maxlength=\"60\">");
               if (season == 0) {
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p1cw\" id=\"p1cw\">");
                 if (!p1cw.equals( "" )) {
                    out.println("<option selected value=" + p1cw + ">" + p1cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p1cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select> &nbsp;</nobr>");
               } else {
                 out.println("</nobr><input type=hidden name=p1cw value=\"" + season_tmode + "\"><br>");
               }

           if (size > 1) {

               out.println("<br>&nbsp;<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player2')\" style=\"cursor:hand\">");
               out.println("Player 2:&nbsp;<input type=\"text\" id=\"player2\" name=\"player2\" value=\"" + player2 + "\" size=\"26\" maxlength=\"60\">");
               if (season == 0) {
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p2cw\" id=\"p2cw\">");
                 if (!p2cw.equals( "" )) {
                    out.println("<option selected value=" + p2cw + ">" + p2cw + "</option>");
                 }
                 for (i=0; i<16; i++) {
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p2cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select>");
               } else {
                 out.println("<input type=hidden name=p2cw value=\"" + season_tmode + "\"><br>");
               }

           } else {

               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
           }
           if (size > 2) {

               out.println("<br>&nbsp;<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player3')\" style=\"cursor:hand\">");
               out.println("Player 3:&nbsp;<input type=\"text\" id=\"player3\" name=\"player3\" value=\"" + player3 + "\" size=\"26\" maxlength=\"60\">");
               if (season == 0) {  
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p3cw\" id=\"p3cw\">");
                 if (!p3cw.equals( "" )) {
                    out.println("<option selected value=" + p3cw + ">" + p3cw + "</option>");
                 }
                 for (i=0; i<16; i++) {
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p3cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select>");
               } else {
                 out.println("<input type=hidden name=p3cw value=\"" + season_tmode + "\"><br>");
               }

           } else {

               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
           }
           if (size > 3) {

               out.println("<br>&nbsp;<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player4')\" style=\"cursor:hand\">");
               out.println("Player 4:&nbsp;<input type=\"text\" id=\"player4\" name=\"player4\" value=\"" + player4 + "\" size=\"26\" maxlength=\"60\">");
               if (season == 0) {  
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p4cw\" id=\"p4cw\">");
                 if (!p4cw.equals( "" )) {
                    out.println("<option selected value=" + p4cw + ">" + p4cw + "</option>");
                 }
                 for (i=0; i<16; i++) {
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p4cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select>");
               } else {
                 out.println("<input type=hidden name=p4cw value=\"" + season_tmode + "\"><br>");
               }

           } else {

               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
           }
           if (size > 4) {

               out.println("<br>&nbsp;<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player5')\" style=\"cursor:hand\">");
               out.println("Player 5:&nbsp;<input type=\"text\" id=\"player5\" name=\"player5\" value=\"" + player5 + "\" size=\"26\" maxlength=\"60\">");
               if (season == 0) {  
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p5cw\" id=\"p5cw\">");
                 if (!p5cw.equals( "" )) {
                    out.println("<option selected value=" + p5cw + ">" + p5cw + "</option>");
                 }
                 for (i=0; i<16; i++) {
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p5cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select>");
               } else {
                 out.println("<input type=hidden name=p5cw value=\"" + season_tmode + "\"><br>");
               }
           } else {

               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
           }

               //
               //   Notes
               //
               //   Script will put any existing notes in the textarea (value= doesn't work)
               //
               out.println("<br><br><input type=\"hidden\" name=\"oldnotes\" value=\"" + notes + "\">"); // hold notes for script

               if (hide != 0) {      // if proshop wants to hide the notes, do not display the text box or notes

                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">"); // pass existing notes

               } else {

                  out.println("<br><img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasetext('notes')\" style=\"cursor:hand\" valign=top>");
                  out.println("Notes to Pro:&nbsp;<textarea name=\"notes\" id=\"notes\" cols=\"27\" rows=\"2\"></textarea>");
               }
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=" + hide + ">");

               out.println("<br><font size=\"1\">");
               for (i=0; i<16; i++) {
                  if (tmode[i] == 1) {       // if specified for event
                     if (!parmc.tmodea[i].equals( "" )) {
                        out.println(parmc.tmodea[i]+ " = " +parmc.tmode[i]+ "&nbsp;&nbsp;");
                     }
                  }
               }
               out.println("</font><br>");
               out.println("<input type=submit value=\"Cancel Entry\" name=\"remove\">&nbsp;&nbsp;&nbsp;");
               out.println("<input type=submit value=\"Submit\" name=\"submitForm\">");
               out.println("</font></td></tr>");
               out.println("</table>");
                 
            if (size > 1) {

               out.println("<p align=\"left\"><font size=\"2\">");
               out.println("<b>Note:</b>  If adding a guest, click on the proper guest indicator, then click in the ");
               out.println("player position immediately after the guest indicator ");
               out.println("and enter a space followed by the name of the guest and his/her club name.");
               out.println("</font></p>");

            } else {

               out.println("<p align=\"left\"><font size=\"2\">");
               out.println("<b>Note:</b>  The format of this event indicates that you may only register yourself ");
               out.println("for this event.");
               out.println("</font></p>");
            }

         out.println("</td>");                                // end of table and column

   if (size > 1) {    // do not display names, etc. if member is only one that can sign up

      out.println("<td align=\"center\" valign=\"top\">");

      // ********************************************************************************
      //   If we got control from user clicking on a letter in the Member List,
      //   then we must build the name list.
      // ********************************************************************************
      String letter = "";

      if (req.getParameter("letter") != null) {     // if user clicked on a name letter

         letter = req.getParameter("letter");

         if (!letter.equals( "Partner List" )) {      // if not Partner List request

            letter = letter + "%";

            String first = "";
            String mid = "";
            String last = "";
            String bname = "";
            String wname = "";
            String dname = "";
            String wc = "";

            out.println("<table border=\"1\" width=\"140\" bgcolor=\"#f5f5dc\" valign=\"top\">");      // name list
            out.println("<tr><td align=\"center\" bgcolor=\"#336633\">");
                  out.println("<font color=\"#ffffff\" size=\"2\">");
                  out.println("<b>Name List</b>");
                  out.println("</font></td>");
            out.println("</tr><tr>");
            out.println("<td align=\"center\">");
                  out.println("<font size=\"2\">");
                  out.println("Click on name to add");
               out.println("</font></td></tr>");

            try {

               PreparedStatement stmt2 = con.prepareStatement (
                        "SELECT name_last, name_first, name_mi, wc FROM member2b " +
                        "WHERE name_last LIKE ? AND inact = 0 ORDER BY name_last, name_first, name_mi");

               stmt2.clearParameters();               // clear the parms
               stmt2.setString(1, letter);            // put the parm in stmt
               rs = stmt2.executeQuery();             // execute the prepared stmt

               out.println("<tr><td align=\"left\"><font size=\"2\">");
               out.println("<select size=\"20\" name=\"bname\" onClick=\"movename(this.form.bname.value)\" style=\"cursor:hand\">");

               while(rs.next()) {

                  last = rs.getString(1);
                  first = rs.getString(2);
                  mid = rs.getString(3);
                  wc = rs.getString(4);           // walk/cart preference

                  nowc = 1;    // default to 'not found'

                  i = 0;
                  loopwc1:
                  while (i<16) {
                     if (tmode[i] == 1) {       // if specified for event
                        if (parmc.tmodea[i].equals( wc )) {
                           nowc = 0;
                           break loopwc1;
                        }
                     }
                     i++;
                  }

                  if (nowc != 0) {      // if wc not supported for this event

                     i = 0;
                     loopwc2:
                     while (i<16) {
                        if (tmode[i] == 1) {       // if specified for event
                           if (!parmc.tmodea[i].equals( "" )) {
                              wc = parmc.tmodea[i];                // change wc option for this event
                              break loopwc2;
                           }
                        }
                        i++;
                     }
                  }

                  if (mid.equals("")) {

                     bname = first + " " + last;
                     dname = last + ", " + first;
                  } else {

                     bname = first + " " + mid + " " + last;
                     dname = last + ", " + first + " " + mid;
                  }

                  wname = bname + ":" + wc;              // combine name:wc for script

                  out.println("<option value=\"" + wname + "\">" + dname + "</option>");
               }

               out.println("</select>");
               out.println("</font></td></tr>");

               stmt2.close();
            }
            catch (Exception ignore) {

            }
         }        // end of IF Partner List or Letter
      }           // end of IF letter parm

      if (letter.equals( "" ) || letter.equals( "Partner List" )) {  // if no letter or Partner List request

         String nameBud = "";
         int countBud = 0;

         //
         //     table for buddy list
         //
         //  Get the current buddy list for this user
         //
         try {

            PreparedStatement pstmt = con.prepareStatement (
                     "SELECT * FROM buddy WHERE username = ?");

            out.println("<table border=\"1\" width=\"160\" bgcolor=\"#f5f5dc\">");      // buddy list
            out.println("<tr><td align=\"center\" bgcolor=\"#336633\">");
            out.println("<font color=\"#ffffff\" size=\"2\">");
            out.println("<b>Partner List</b>");
            out.println("</font></td>");
            out.println("</tr><tr>");
            out.println("<td align=\"center\">");
            out.println("<font size=\"2\">");
            out.println("Click on name to add");
            out.println("</font></td></tr>");


            pstmt.clearParameters();            // clear the parms
            pstmt.setString(1, user);           // put username in statement
            rs = pstmt.executeQuery();          // execute the prepared stmt

            if (rs.next()) {

               buddy[0] = rs.getString("buddy1");
               buddy[1] = rs.getString("buddy2");
               buddy[2] = rs.getString("buddy3");
               buddy[3] = rs.getString("buddy4");
               buddy[4] = rs.getString("buddy5");
               buddy[5] = rs.getString("buddy6");
               buddy[6] = rs.getString("buddy7");
               buddy[7] = rs.getString("buddy8");
               buddy[8] = rs.getString("buddy9");
               buddy[9] = rs.getString("buddy10");
               buddy[10] = rs.getString("buddy11");
               buddy[11] = rs.getString("buddy12");
               buddy[12] = rs.getString("buddy13");
               buddy[13] = rs.getString("buddy14");
               buddy[14] = rs.getString("buddy15");
               buddy[15] = rs.getString("buddy16");
               buddy[16] = rs.getString("buddy17");
               buddy[17] = rs.getString("buddy18");
               buddy[18] = rs.getString("buddy19");
               buddy[19] = rs.getString("buddy20");
               buddy[20] = rs.getString("buddy21");
               buddy[21] = rs.getString("buddy22");
               buddy[22] = rs.getString("buddy23");
               buddy[23] = rs.getString("buddy24");
               buddy[24] = rs.getString("buddy25");
               bcw[0] = rs.getString("b1cw");
               bcw[1] = rs.getString("b2cw");
               bcw[2] = rs.getString("b3cw");
               bcw[3] = rs.getString("b4cw");
               bcw[4] = rs.getString("b5cw");
               bcw[5] = rs.getString("b6cw");
               bcw[6] = rs.getString("b7cw");
               bcw[7] = rs.getString("b8cw");
               bcw[8] = rs.getString("b9cw");
               bcw[9] = rs.getString("b10cw");
               bcw[10] = rs.getString("b11cw");
               bcw[11] = rs.getString("b12cw");
               bcw[12] = rs.getString("b13cw");
               bcw[13] = rs.getString("b14cw");
               bcw[14] = rs.getString("b15cw");
               bcw[15] = rs.getString("b16cw");
               bcw[16] = rs.getString("b17cw");
               bcw[17] = rs.getString("b18cw");
               bcw[18] = rs.getString("b19cw");
               bcw[19] = rs.getString("b20cw");
               bcw[20] = rs.getString("b21cw");
               bcw[21] = rs.getString("b22cw");
               bcw[22] = rs.getString("b23cw");
               bcw[23] = rs.getString("b24cw");
               bcw[24] = rs.getString("b25cw");

               countBud = 0;

               for (i = 0; i < 25; i++) {         // check all 25 partners

                  if (!buddy[i].equals("")) {

                     countBud++;                     // count buddies

                     //
                     //  make sure the CW option is supported for this event
                     //
                     nowc = 1;    // default to 'not found'

                     int i2 = 0;
                     loopbud1:
                     while (i2<16) {
                        if (tmode[i2] == 1) {       // if specified for event
                           if (parmc.tmodea[i2].equals( bcw[i] )) {
                              nowc = 0;
                              break loopbud1;
                           }
                        }
                        i2++;
                     }
                     if (nowc != 0) {      // if wc not supported for this event

                        i2 = 0;
                        loopbud2:
                        while (i2<16) {
                           if (tmode[i2] == 1) {       // if specified for event
                              if (!parmc.tmodea[i2].equals( "" )) {
                                 bcw[i] = parmc.tmodea[i2];                // change wc option for this event
                                 break loopbud2;
                              }
                           }
                           i2++;
                        }
                     }
                  }
               }
               if (countBud != 0) {

                  if (countBud < 2) {

                     countBud = 2;             // set size to at least 2
                  }
                  if (countBud > 20) {

                     countBud = 20;             // set size to no more than 20 showing at once (it will scroll)
                  }

                  out.println("<tr><td align=\"left\">");
                  out.println("<font size=\"2\">");
                  out.println("<select size=\"" + countBud + "\" name=\"bud\" onClick=\"movename(this.form.bud.value)\" style=\"cursor:hand\">");

                  for (i = 0; i < 25; i++) {         // check all 25 partners

                     if (!buddy[i].equals("")) {

                        nameBud = buddy[i] + ":" + bcw[i];                      // combine name:wc for script
                        out.println("<option value=\"" + nameBud + "\">" + buddy[i] + "</option>");
                     }
                  }
                  out.println("</select>");

               } else {

                  out.println("<tr><td align=\"center\" bgcolor=\"white\">");
                  out.println("<font size=\"2\">");
                  out.println("No names - <br>");
                  out.println("Select 'Partner List' <br>");
                  out.println("on main menu to add.");
               }

            } else {

               out.println("<tr><td align=\"center\" bgcolor=\"white\">");
               out.println("<font size=\"2\">");
               out.println("No names - <br>");
               out.println("Select 'Partner List' <br>");
               out.println("on main menu to add.");
            }

            out.println("</font></td></tr>");

         }
         catch (Exception exc) {             // SQL Error - ignore buddy list

         }
      }        // end of if letter display

      out.println("</table></td>");

      out.println("</td>");                                      // end of this column
      out.println("<td width=\"200\" valign=\"top\">");

      //
      //   Output the Alphabit Table for Members' Last Names
      //
      alphaTable.getTable(out, user);

      //
      //     Check the club db table for guests
      //
      try {
         parm.club = club;                   // set club name
         parm.course = course;               // and course name

         getClub.getParms(con, parm);        // get the club parms

      }
      catch (Exception exc) {             // SQL Error - ignore guest and x
      }

      if (x != 0) {                    // x value from event 

         //
         //  add a table for 'x'
         //
         out.println("<font size=\"1\"><br></font>");
         out.println("<table border=\"1\" width=\"140\" bgcolor=\"#F5F5DC\">");
            out.println("<tr bgcolor=\"#336633\">");
            out.println("<td align=\"center\">");
            out.println("<font color=\"#FFFFFF\" size=\"2\">");
            out.println("<b>Member TBD</b>");
            out.println("</font></td>");
         out.println("</tr>");
            out.println("<tr><td align=\"left\"><font size=\"1\" face=\"Helvetica, Arial, Sans-serif\">");
            out.println("Use 'X' to reserve a position for a Member.<br>");
            out.println("</font></td></tr>");
            out.println("<tr><td align=\"left\" bgcolor=\"#FFFFFF\">");
            out.println("<font size=\"2\">");
         out.println("&nbsp;&nbsp;<a href=\"javascript:void(0)\" onClick=\"moveguest('X')\">X</a>");
         out.println("</font></td></tr></table>");      // end of this table
      }

      //
      //  add a table for the Guest Types
      //
      out.println("<font size=\"1\"><br></font>");
      out.println("<table border=\"1\" bgcolor=\"#F5F5DC\">");
         out.println("<tr bgcolor=\"#336633\">");
         out.println("<td align=\"center\">");
         out.println("<font color=\"#FFFFFF\" size=\"2\">");
         out.println("<b>Guest Types</b>");
         out.println("</font></td>");
      out.println("</tr>");

      //
      //  first we must count how many fields there will be
      //
      xCount = 0;
      for (i = 0; i < parm.MAX_Guests; i++) {

         if (!parm.guest[i].equals( "" ) && parm.gOpt[i] == 0) {   // count the X and guest names

            xCount++;
         }
      }
      i = 0;
      if (xCount != 0) {                       // if guest names, display them in list

         if (club.equals( "medinahcc" ) || club.equals( "wellesley" )) {     // Medinah & Wellesley only use 1 guest type for events

            xCount = 2;             // set size to at least 2
              
         } else {

            if (xCount < 2) {

               xCount = 2;             // set size to at least 2
            }
            if (xCount > 8) {

               xCount = 8;             // set size to no more than 8 showing at once (it will scroll)
            }
         }
           
         out.println("<tr><td align=\"left\"><font size=\"1\" face=\"Helvetica, Arial, Sans-serif\">");
         out.println("<b>**</b> Add guests immediately<br><b>after</b> host member.<br>");
         out.println("</font><font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<select size=\"" + xCount + "\" name=\"xname\" onClick=\"moveguest(this.form.xname.value)\">");

         //
         //  If Medinah, then only display guest type for events
         //
         if (club.equals( "medinahcc" )) {

            out.println("<option value=\"Event Guest\">Event Guest</option>");

         } else {
           
            if (club.equals( "wellesley" )) {

               out.println("<option value=\"Tourney Guest\">Tourney Guest</option>");

            } else {

               for (i = 0; i < parm.MAX_Guests; i++) {

                  if (!parm.guest[i].equals( "" ) && parm.gOpt[i] == 0) {   // if guest name is open for members

                     out.println("<option value=\"" + parm.guest[i] + "\">" + parm.guest[i] + "</option>");
                  }
               }
            }
         }
         out.println("</select>");
         out.println("</font></td></tr></table>");      // end of this table

      } else {

         out.println("</table>");      // end the table if none specified
      }

      out.println("</td>");

   }  // end of IF size > 1

   out.println("</tr>");
   out.println("</form>");     // end of playerform
   out.println("</table>");      // end of large table containing 4 smaller tables

   out.println("</font></td></tr>");
   out.println("</table>");                      // end of main page table
   //
   //  End of HTML page
   //
   out.println("</td></tr>");
   out.println("</table>");                      // end of whole page table
   out.println("</font></body></html>");

 }   // end of doPost


 // *********************************************************
 //  Get a new id and set a new entry in the Event Sign Up db table
 // *********************************************************

 private synchronized int getNewId(Connection con, String name, String course, long date, int time) {


   Statement stmtm = null;
   ResultSet rs = null;


   int month = 0;
   int day = 0;
   int year = 0;
   int hr = 0;
   int min = 0;
   int id = 0;
   int r_time = 0;
   long r_date = 0;

   try {
      //
      //   Get current date and time
      //
      Calendar cal = new GregorianCalendar();        // get current date and time
      year = cal.get(Calendar.YEAR);
      month = cal.get(Calendar.MONTH);
      day = cal.get(Calendar.DAY_OF_MONTH);
      hr = cal.get(Calendar.HOUR_OF_DAY);
      min = cal.get(Calendar.MINUTE);

      //
      //  Build the 'time' string for display
      //
      //    Adjust the time based on the club's time zone (we are Central)
      //
      r_time = (hr * 100) + min;

      r_time = SystemUtils.adjustTime(con, r_time);       // adjust for time zone

      if (r_time < 0) {                // if negative, then we went back or ahead one day

         r_time = 0 - r_time;          // convert back to positive value

         if (r_time < 100) {           // if hour is zero, then we rolled ahead 1 day

            //
            // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
            //
            cal.add(Calendar.DATE,1);                     // get next day's date

            year = cal.get(Calendar.YEAR);
            month = cal.get(Calendar.MONTH);
            day = cal.get(Calendar.DAY_OF_MONTH);

         } else {                        // we rolled back 1 day

            //
            // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
            //
            cal.add(Calendar.DATE,-1);                     // get yesterday's date

            year = cal.get(Calendar.YEAR);
            month = cal.get(Calendar.MONTH);
            day = cal.get(Calendar.DAY_OF_MONTH);
         }
      }

      hr = r_time / 100;                // get adjusted hour
      min = r_time - (hr * 100);          // get minute value

      month = month + 1;                            // month starts at zero
      r_date = (year * 10000) + (month * 100) + day;

      //
      //   get the highest existing id
      //
      PreparedStatement stmt = con.prepareStatement (
         "SELECT MAX(id) FROM evntsup2b " +
         "WHERE name = ? AND courseName = ? ");

      stmt.clearParameters();        // clear the parms
      stmt.setString(1, name);
      stmt.setString(2, course);
      rs = stmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         id = rs.getInt(1);
         id++;                // set new id

      } else {                // must be first one

         id = 1;
      }
      stmt.close();

      //
      //  Create a new entry for this event
      //
      if (id != 0) {

         PreparedStatement pstmt = con.prepareStatement (
            "INSERT INTO evntsup2b " +
            "(name, courseName, player1, player2, player3, player4, player5, " +
            "username1, username2, username3, username4, username5, " +
            "p1cw, p2cw, p3cw, p4cw, p5cw, in_use, in_use_by, hndcp1, hndcp2, hndcp3, hndcp4, " +
            "hndcp5, notes, hideNotes, id, c_date, c_time, r_date, r_time, wait) " +
            "VALUES (?, ?, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, " +
            "'', 0, 0, 0, 0, 0, '', 0, ?, ?, ?, ?, ?, 0)");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, name);
         pstmt.setString(2, course);
         pstmt.setInt(3, id);
         pstmt.setLong(4, date);             // cut-off date
         pstmt.setInt(5, time);              // cut-off time
         pstmt.setLong(6, r_date);           // date registered
         pstmt.setInt(7, r_time);            // time registered

         pstmt.executeUpdate();

         pstmt.close();
      }

   }
   catch (Exception ignore) {

      id = 0;   // indicate failed
   }

   return id;
 }


 // *********************************************************
 //  Process reservation request from Proshop_slot (HTML)
 // *********************************************************

 private void verify(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session, HttpServletResponse resp) {


   Statement stmt = null;
   Statement stmtN = null;
   ResultSet rs = null;
   ResultSet rs2 = null;
   ResultSet rs7 = null;


   //
   //  Get this session's club, username and full name
   //
   String club = (String)session.getAttribute("club");
   String caller = (String)session.getAttribute("caller");
   String user = (String)session.getAttribute("user");
   String userName = (String)session.getAttribute("name");   // get users full name

   String in_use_by = "";

   String name = "";
   String course = "";
   String sid = "";
   String player = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String g1 = "";
   String g2 = "";
   String g3 = "";
   String g4 = "";
   String g5 = "";
   String oldPlayer1 = "";
   String oldPlayer2 = "";
   String oldPlayer3 = "";
   String oldPlayer4 = "";
   String oldPlayer5 = "";
   String oldUser1 = "";
   String oldUser2 = "";
   String oldUser3 = "";
   String oldUser4 = "";
   String oldUser5 = "";
   String oldp1cw = "";
   String oldp2cw = "";
   String oldp3cw = "";
   String oldp4cw = "";
   String oldp5cw = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String user1 = "";
   String user2 = "";
   String user3 = "";
   String user4 = "";
   String user5 = "";
   String fname1 = "";
   String lname1 = "";
   String mi1 = "";
   String fname2 = "";
   String lname2 = "";
   String mi2 = "";
   String fname3 = "";
   String lname3 = "";
   String mi3 = "";
   String fname4 = "";
   String lname4 = "";
   String mi4 = "";
   String fname5 = "";
   String lname5 = "";
   String mi5 = "";
   String act_ampm = "";
   String act_time = "";
   String wplayer1 = "";
   String wplayer2 = "";
   String wplayer3 = "";
   String wplayer4 = "";
   String wplayer5 = "";
   String wuser1 = "";
   String wuser2 = "";
   String wuser3 = "";
   String wuser4 = "";
   String wuser5 = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
   String memberName = "";
   String index = "";
   String email1 = "";
   String email2 = "";

   int id = 0;
   int reject = 0;
   int count = 0;
   int in_use = 0;
   int day = 0;
   int month = 0;
   int year = 0;
   int guests = 0;
   int eguests = 0;
   int x = 0;
   int xhrs = 0;
   int act_hr = 0;
   int act_min = 0;
   int adv_time = 0;
   int adv_date = 0;
   int i = 0;
   int etype = 0;
   int ind = 0;
   int xcount = 0;
   int sendemail = 0;
   int emailNew = 0;
   int emailMod = 0;
   int emailCan = 0;
   int members = 0;
   int teams = 0;
   int t = 0;
   int max = 0;
   int minsize = 0;
   int wait = 0;
   int checkWait = 0;
   int gi = 0;
   int holes = 0;
   int season = 0;

   float hndcp1 = 99;
   float hndcp2 = 99;
   float hndcp3 = 99;
   float hndcp4 = 99;
   float hndcp5 = 99;

   boolean guestError = false;            // init error flag
   boolean hit = false;                   // init error flag
   

   //
   //  Arrays to hold member & guest names to tie guests to members
   //
   String [] gstA = new String [5];     // guests
   String [] memA = new String [5];     // members
   String [] usergA = new String [5];   // guests' associated member (username)

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   // Get all the parameters entered
   //
   course = req.getParameter("course");        //  name of course
   name = req.getParameter("name");            //  name of event
   index = req.getParameter("index");        
   sid = req.getParameter("id");               //  id of event entry
   player1 = req.getParameter("player1");
   player2 = req.getParameter("player2");
   player3 = req.getParameter("player3");
   player4 = req.getParameter("player4");
   player5 = req.getParameter("player5");
   p1cw = req.getParameter("p1cw");
   p2cw = req.getParameter("p2cw");
   p3cw = req.getParameter("p3cw");
   p4cw = req.getParameter("p4cw");
   p5cw = req.getParameter("p5cw");
   String notes = req.getParameter("notes");                  // Notes
   String hides = req.getParameter("hide");                   // hide Notes

   //
   //  Convert date & time from string to int
   //
   try {
      id = Integer.parseInt(sid);
   }
   catch (NumberFormatException e) {
   }

   //
   //  Get the length of Notes (max length of 254 chars)
   //
   int notesL = 0;

   if (!notes.equals( "" )) {

      notesL = notes.length();       // get length of notes
   }

   //
   //  Check C/W's for null
   //
   if (p1cw == null) {
      p1cw = "";
   }
   if (p2cw == null) {
      p2cw = "";
   }
   if (p3cw == null) {
      p3cw = "";
   }
   if (p4cw == null) {
      p4cw = "";
   }
   if (p5cw == null) {
      p5cw = "";
   }
   if (player1 == null ) {
      player1 = "";
   }
   if (player2 == null ) {
      player2 = "";
   }
   if (player3 == null ) {
      player3 = "";
   }
   if (player4 == null ) {
      player4 = "";
   }
   if (player5 == null ) {
      player5 = "";
   }

   //
   //  Check if this entry is still 'in use' and still in use by this user??
   //
   //  This is necessary because the user may have gone away while holding this slot.  If the
   //  slot timed out (system timer), the slot would be marked 'not in use' and another
   //  user could pick it up.  The original holder could be trying to use it now.
   //
   try {

      PreparedStatement pstmt = con.prepareStatement (
         "SELECT player1, player2, player3, player4, player5, username1, username2, username3, " +
         "username4, username5, p1cw, p2cw, p3cw, p4cw, p5cw, in_use, in_use_by, wait " +
         "FROM evntsup2b WHERE name = ? AND  courseName = ? AND id = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, name);         // put the parm in pstmt
      pstmt.setString(2, course);
      pstmt.setInt(3, id);
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         oldPlayer1 = rs.getString("player1");
         oldPlayer2 = rs.getString("player2");
         oldPlayer3 = rs.getString("player3");
         oldPlayer4 = rs.getString("player4");
         oldPlayer5 = rs.getString("player5");
         oldUser1 = rs.getString("username1");
         oldUser2 = rs.getString("username2");
         oldUser3 = rs.getString("username3");
         oldUser4 = rs.getString("username4");
         oldUser5 = rs.getString("username5");
         oldp1cw = rs.getString("p1cw");
         oldp2cw = rs.getString("p2cw");
         oldp3cw = rs.getString("p3cw");
         oldp4cw = rs.getString("p4cw");
         oldp5cw = rs.getString("p5cw");
         in_use = rs.getInt("in_use");
         in_use_by = rs.getString("in_use_by");
         wait = rs.getInt("wait");
      }

      pstmt.close();

      if ((in_use == 0) || (!in_use_by.equals( user ))) {    // if entry not in use or not by this user

         out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
         out.println("<BODY bgcolor=\"#ccccaa\">");
         out.println("<CENTER><BR><BR><H1>Reservation Timer Expired</H1>");
         out.println("<BR><BR>Sorry, but this event entry has been returned to the system.<BR>");
         out.println("<BR>The system timed out and released it.");
         out.println("<font size=\"2\"><br><br>");
         out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      PreparedStatement pstmtev = con.prepareStatement (
         "SELECT year, month, day, type, act_hr, act_min, max, x, xhrs, holes, minsize, season, email1, email2 " +
         "FROM events2b " +
         "WHERE name = ? AND courseName = ? ");

      pstmtev.clearParameters();        // clear the parms
      pstmtev.setString(1, name);
      pstmtev.setString(2, course);
      rs = pstmtev.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         year = rs.getInt("year");       // get date & time for email msgs
         month = rs.getInt("month");
         day = rs.getInt("day");
         etype = rs.getInt("type");
         act_hr = rs.getInt("act_hr");
         act_min = rs.getInt("act_min");
         max = rs.getInt("max");
         minsize = rs.getInt("minsize");
         x = rs.getInt("x");
         xhrs = rs.getInt("xhrs");
         holes = rs.getInt("holes");
         season = rs.getInt("season");
         email1 = rs.getString("email1");
         email2 = rs.getString("email2");
      }
      pstmtev.close();

   }
   catch (Exception e) {

      dbError(out, e);
      return;
   }

   //
   //  Create time values for email msg below
   //
   act_ampm = " AM";

   if (act_hr == 0) {

      act_hr = 12;                 // change to 12 AM (midnight)

   } else {

      if (act_hr == 12) {

         act_ampm = " PM";         // change to Noon
      }
   }
   if (act_hr > 12) {

      act_hr = act_hr - 12;
      act_ampm = " PM";             // change to 12 hr clock
   }

   //
   //  convert time to hour and minutes for email msg
   //
   act_time = act_hr + ":" + SystemUtils.ensureDoubleDigit(act_min) + act_ampm;
   

   //
   //  If request is to 'Cancel This Res', then clear all fields for this slot
   //
   //  First, make sure user is already in the entry
   //
   if (req.getParameter("remove") != null) {

      try {
         PreparedStatement pstmt4 = con.prepareStatement (
            "SELECT id FROM evntsup2b WHERE (username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? " +
                       "OR username5 = ?) AND name = ? AND courseName = ? AND id = ?");


         pstmt4.clearParameters();        // clear the parms
         pstmt4.setString(1, user);
         pstmt4.setString(2, user);
         pstmt4.setString(3, user);
         pstmt4.setString(4, user);
         pstmt4.setString(5, user);
         pstmt4.setString(6, name);
         pstmt4.setString(7, course);
         pstmt4.setInt(8, id);
         rs = pstmt4.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            player1 = "";                  // set reservation fields to null
            player2 = "";
            player3 = "";
            player4 = "";
            player5 = "";
            p1cw = "";
            p2cw = "";
            p3cw = "";
            p4cw = "";
            p5cw = "";
            user1 = "";
            user2 = "";
            user3 = "";
            user4 = "";
            user5 = "";
            notes = "";

         } else {

            out.println(SystemUtils.HeadTitle("Procedure Error"));
            out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Procedure Error</H3>");
            out.println("<BR><BR>You cannot cancel an event entry that you are not part of.");
            out.println("<BR><BR>You must be a member currently on the team in order to cancel it.");
            out.println("<font size=\"2\"><br><br>");
            out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }

         pstmt4.close();

      }
      catch (Exception e4) {

         dbError(out, e4);
         return;
      }

      //
      //  if this team was not on the wait list, then set an idicator so we will process the wait list below.
      //
      if (wait == 0) {

         checkWait = 1;
      }
      wait = 0;          // init wait in cancelled entry

      emailCan = 1;      // send email notification for Cancel Request
      sendemail = 1;


   } else {

      //
      //  Normal reservation request
      //
      //
      //   Get the guest names specified for this club
      //
      try {
         parm.club = club;                 // set club name
         parm.course = course;             // and course name

         getClub.getParms(con, parm);      // get the club parms

      }
      catch (Exception ignore) {
      }

      //
      //   Remove any guest types that are null or not allowed for members - for tests below
      //
      if (club.equals( "wellesley" )) {

         parm.guest[0] = "Tourney Guest";       // only 1 guest type

         for (i = 1; i < parm.MAX_Guests; i++) {

            parm.guest[i] = "$@#!^&*";          // make so it won't match player field
         }       

      } else {
        
         for (i = 0; i < parm.MAX_Guests; i++) {

            if ((parm.guest[i].equals( "" )) || (parm.gOpt[i] != 0)) {

               parm.guest[i] = "$@#!^&*";      // make so it won't match player field
            }
         }         // end of while loop
      }

      //
      //  Check if any player names are guest names
      //
      gstA[0] = "";    // init guest array and indicators
      gstA[1] = "";
      gstA[2] = "";
      gstA[3] = "";
      gstA[4] = "";
      g1 = "";
      g2 = "";
      g3 = "";
      g4 = "";
      g5 = "";

      if (!player1.equals( "" )) {

         i = 0;
         loop1:
         while (i < parm.MAX_Guests) {

            if (player1.startsWith( parm.guest[i] )) {

               g1 = parm.guest[i];      // indicate player is a guest name and save name
               gstA[0] = player1;       // save guest value
               guests++;                // increment number of guests this slot
               break loop1;
            }
            i++;
         }         // end of while loop
      }
      if (!player2.equals( "" )) {

         i = 0;
         loop2:
         while (i < parm.MAX_Guests) {

            if (player2.startsWith( parm.guest[i] )) {

               g2 = parm.guest[i];      // indicate player is a guest name and save name
               gstA[1] = player2;       // save guest value
               guests++;                // increment number of guests this slot
               break loop2;
            }
            i++;
         }         // end of while loop
      }
      if (!player3.equals( "" )) {

         i = 0;
         loop3:
         while (i < parm.MAX_Guests) {

            if (player3.startsWith( parm.guest[i] )) {

               g3 = parm.guest[i];   // indicate player is a guest name and save name
               gstA[2] = player3;    // save guest value
               guests++;             // increment number of guests this slot
               break loop3;
            }
            i++;
         }         // end of while loop
      }
      if (!player4.equals( "" )) {

         i = 0;
         loop4:
         while (i < parm.MAX_Guests) {

            if (player4.startsWith( parm.guest[i] )) {

               g4 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[3] = player4;    // save guest value
               guests++;            // increment number of guests this slot
               break loop4;
            }
            i++;
         }         // end of while loop
      }
      if (!player5.equals( "" )) {

         i = 0;
         loop5:
         while (i < parm.MAX_Guests) {

            if (player5.startsWith( parm.guest[i] )) {

               g5 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[4] = player5;    // save guest value
               guests++;            // increment number of guests this slot
               break loop5;
            }
            i++;
         }         // end of while loop
      }

      //
      //  Make sure at least 1 player contains a member
      //
      if (((player1.equals( "" )) || (player1.equalsIgnoreCase( "x" )) || (!g1.equals( "" ))) &&
          ((player2.equals( "" )) || (player2.equalsIgnoreCase( "x" )) || (!g2.equals( "" ))) &&
          ((player3.equals( "" )) || (player3.equalsIgnoreCase( "x" )) || (!g3.equals( "" ))) &&
          ((player4.equals( "" )) || (player4.equalsIgnoreCase( "x" )) || (!g4.equals( "" ))) &&
          ((player5.equals( "" )) || (player5.equalsIgnoreCase( "x" )) || (!g5.equals( "" )))) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR>Required field has not been completed or is invalid.");
         out.println("<BR><BR>At least one player field must contain a member name.");
         out.println("<BR>If you want to cancel the event entry, use the 'Cancel Entry' button under the player fields.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
         out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
         out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
         out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
         out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
         out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
         out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
         out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
         out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
         out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
         out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
         out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      //  Check the number of X's against max specified by proshop
      //
      xcount = 0;

      if (player1.equalsIgnoreCase( "x" )) {

         xcount++;
      }

      if (player2.equalsIgnoreCase( "x" )) {

         xcount++;
      }

      if (player3.equalsIgnoreCase( "x" )) {

         xcount++;
      }

      if (player4.equalsIgnoreCase( "x" )) {

         xcount++;
      }

      if (player5.equalsIgnoreCase( "x" )) {

         xcount++;
      }

      if (xcount > x) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR>The number of X's requested (" + xcount + ") exceeds the number allowed (" + x + ").");
         out.println("<BR>Please try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
         out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
         out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
         out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
         out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
         out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
         out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
         out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
         out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
         out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
         out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
         out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      //  Make sure this signup has enough players as specified in the event conf
      //
      int players = 0;
      if (!player1.equals( "" )) players++;
      if (!player2.equals( "" )) players++;
      if (!player3.equals( "" )) players++;
      if (!player4.equals( "" )) players++;
      if (!player5.equals( "" )) players++;

      if (players < minsize) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR>The number of players (" + players + ") does not meet the required amount (" + minsize + ").");
         // if they haven't used their alloted # of X's, tell them they can use up to xcount amount of them
         if (xcount < x) out.println("<BR><BR>You're allowed to use " + xcount + " X's to hold player positions, but you must intend on filling them.");
         out.println("<BR>Please try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
         out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
         out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
         out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
         out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
         out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
         out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
         out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
         out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
         out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
         out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
         out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
      
      //
      //  Make sure a C/W was specified for all players
      //
      if (((!player1.equals( "" )) && (!player1.equalsIgnoreCase( "x" )) && (p1cw.equals( "" ))) ||
          ((!player2.equals( "" )) && (!player2.equalsIgnoreCase( "x" )) && (p2cw.equals( "" ))) ||
          ((!player3.equals( "" )) && (!player3.equalsIgnoreCase( "x" )) && (p3cw.equals( "" ))) ||
          ((!player4.equals( "" )) && (!player4.equalsIgnoreCase( "x" )) && (p4cw.equals( "" ))) ||
          ((!player5.equals( "" )) && (!player5.equalsIgnoreCase( "x" )) && (p5cw.equals( "" )))) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR>Required field has not been completed or is invalid.");
         out.println("<BR><BR>You must specify a Cart or Walk option for all players.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
         out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
         out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
         out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
         out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
         out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
         out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
         out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
         out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
         out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
         out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
         out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      //  Make sure there are no duplicate names
      //
      if ((!player1.equals( "" )) && (!player1.equalsIgnoreCase( "x" )) && (g1.equals( "" ))) {

         if ((player1.equalsIgnoreCase( player2 )) || (player1.equalsIgnoreCase( player3 )) || (player1.equalsIgnoreCase( player4 )) || (player1.equalsIgnoreCase( player5 ))) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR><b>" + player1 + "</b> was specified more than once.");
         out.println("<BR><BR>Please correct this and try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
         out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
         out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
         out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
         out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
         out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
         out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
         out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
         out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
         out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
         out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
         out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
         out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
         out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
         out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
         }
      }

      if ((!player2.equals( "" )) && (!player2.equalsIgnoreCase( "x" )) && (g2.equals( "" ))) {

         if ((player2.equalsIgnoreCase( player3 )) || (player2.equalsIgnoreCase( player4 )) || (player2.equalsIgnoreCase( player5 ))) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player2 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if ((!player3.equals( "" )) && (!player3.equalsIgnoreCase( "x" )) && (g3.equals( "" ))) {

         if ((player3.equalsIgnoreCase( player4 )) || (player3.equalsIgnoreCase( player5 ))) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player3 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if ((!player4.equals( "" )) && (!player4.equalsIgnoreCase( "x" )) && (g4.equals( "" ))) {

         if (player4.equalsIgnoreCase( player5 )) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player4 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      //
      //  Parse the names to separate first, last & mi
      //  (Member does not verify single tokens - check for x or guest) !!!!!!!!!!!
      //
      if ((!player1.equals( "" )) && (g1.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player1 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname1 = tok.nextToken();
            lname1 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname1 = tok.nextToken();
            mi1 = tok.nextToken();
            lname1 = tok.nextToken();
         }

         if ( tok.countTokens() == 1 ) {         // X not valid for player1

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player1 + "</b> is not allowed in the first player position.");
            out.println("<BR>Player 1 must be a valid member name.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if ((!player2.equals( "" )) && (g2.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player2 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player2.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname2 = tok.nextToken();
            lname2 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname2 = tok.nextToken();
            mi2 = tok.nextToken();
            lname2 = tok.nextToken();
         }
      }

      if ((!player3.equals( "" )) && (g3.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player3 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player3.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname3 = tok.nextToken();
            lname3 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname3 = tok.nextToken();
            mi3 = tok.nextToken();
            lname3 = tok.nextToken();
         }
      }

      if ((!player4.equals( "" )) && (g4.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player4 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player4.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname4 = tok.nextToken();
            lname4 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname4 = tok.nextToken();
            mi4 = tok.nextToken();
            lname4 = tok.nextToken();
         }
      }

      if ((!player5.equals( "" )) && (g5.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player5 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player5.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname5 = tok.nextToken();
            lname5 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname5 = tok.nextToken();
            mi5 = tok.nextToken();
            lname5 = tok.nextToken();
         }
      }

      members = 0;     // init number of members in res request

      //
      //  Get the usernames & hndcp's for players if matching name found
      //
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "SELECT username, g_hancap FROM member2b WHERE name_last = ? AND name_first = ? AND name_mi = ? AND inact = 0");

         if ((!fname1.equals( "" )) && (!lname1.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname1);
            pstmt1.setString(2, fname1);
            pstmt1.setString(3, mi1);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user1 = rs.getString(1);
               hndcp1 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request

            } else {

               invData(out, player1, player2, player3, player4, player5);                        // reject
               return;
            }
         }

         if ((!fname2.equals( "" )) && (!lname2.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname2);
            pstmt1.setString(2, fname2);
            pstmt1.setString(3, mi2);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user2 = rs.getString(1);
               hndcp2 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request

            } else {

               invData(out, player1, player2, player3, player4, player5);                        // reject
               return;
            }
         }

         if ((!fname3.equals( "" )) && (!lname3.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname3);
            pstmt1.setString(2, fname3);
            pstmt1.setString(3, mi3);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user3 = rs.getString(1);
               hndcp3 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request

            } else {

               invData(out, player1, player2, player3, player4, player5);                        // reject
               return;
            }
         }

         if ((!fname4.equals( "" )) && (!lname4.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname4);
            pstmt1.setString(2, fname4);
            pstmt1.setString(3, mi4);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user4 = rs.getString(1);
               hndcp4 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request

            } else {

               invData(out, player1, player2, player3, player4, player5);                        // reject
               return;
            }
         }

         if ((!fname5.equals( "" )) && (!lname5.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname5);
            pstmt1.setString(2, fname5);
            pstmt1.setString(3, mi5);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user5 = rs.getString(1);
               hndcp5 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request

            } else {

               invData(out, player1, player2, player3, player4, player5);                        // reject
               return;
            }
         }

         pstmt1.close();

      }
      catch (Exception e1) {

         dbError(out, e1);                        // reject
         return;
      }

      //
      //  Save the members' usernames for guest association
      //
      memA[0] = user1;
      memA[1] = user2;
      memA[2] = user3;
      memA[3] = user4;
      memA[4] = user5;

      //
      // **************************************
      //  Check for Restrictions in the Event - check all members
      // **************************************
      //
      try {
        
         String restPlayer = verifySlot.checkEventRests(user1, user2, user3, user4, user5, name, con);
       
         if (!restPlayer.equals( "" )) {        // if member (username) restricted from this event

            if (restPlayer.equals( user1 )) {
               restPlayer = player1;             // get player's name
            } else {
               if (restPlayer.equals( user2 )) {
                  restPlayer = player2;
               } else {
                  if (restPlayer.equals( user3 )) {
                     restPlayer = player3;
                  } else {
                     if (restPlayer.equals( user4 )) {
                        restPlayer = player4;
                     } else {
                        restPlayer = player5;
                     }
                  }
               }
            }

            out.println(SystemUtils.HeadTitle("Member Restricted - Reject"));
            out.println("<BODY bgcolor=\"#ccccaa\">");
            out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
            out.println("<hr width=\"40%\">");
            out.println("<BR><H3>Member Restricted For Event</H3><BR>");
            out.println("<BR><BR>Sorry, member " +restPlayer+ " is not allowed to participate in this event.");
            out.println("<BR><BR>Please remove this member and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }

      }
      catch (Exception e1) {

         dbError(out, e1);                        // reject
         return;
      }

      //
      // **************************************
      //  Check for max # of guests exceeded (per member)
      // **************************************
      //
      if (guests != 0) {      // if any guests were included

         try {
            PreparedStatement pstmtg = con.prepareStatement (
               "SELECT guests FROM events2b " +
               "WHERE name = ? AND courseName = ? ");

            pstmtg.clearParameters();        // clear the parms
            pstmtg.setString(1, name);
            pstmtg.setString(2, course);
            rs = pstmtg.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               eguests = rs.getInt("guests");
            }
            pstmtg.close();

            // if num of guests req'd (guests) > num allowed (eguests) per member
            //
            //       to get here guests is > 0
            //       eguests is 0 - 3
            //       members is 0 - 5
            //
            guestError = false;         // init error flag

            if ((eguests == 0) || (members == 0)) {      // no guests allowed or no members

               guestError = true;         // set error flag
            }

            if (members == 1) {

               if (guests > eguests) {     // if 1 member and more guests than allowed

                  guestError = true;         // set error flag
               }
            }
            if (members == 2) {

               if (eguests == 1) {

                  if (guests > 2) {             // if 1 allowed and more than 1 each

                     guestError = true;         // set error flag
                  }
               }
            }

            if (guestError == true) {      // if # of guests exceeded

               out.println(SystemUtils.HeadTitle("Max Num Guests Exceeded - Reject"));
               out.println("<BODY bgcolor=\"#ccccaa\">");
               out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><H3>Number of Guests Exceeded Limit</H3><BR>");
               out.println("<BR><BR>Sorry, the maximum number of guests allowed for the<BR>");
               out.println("event you are requesting is " + eguests + " per member.");
               out.println("<BR><BR>");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
               out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
               out.println("</form></font>");
               out.println("</CENTER></BODY></HTML>");
               return;
            }

         }
         catch (Exception e5) {

            dbError(out, e5);
            return;
         }
           
         //
         //  If Hazeltine National, then make sure member entered a guest's name after each guest type
         //
         if (club.equals( "hazeltine" )) {      // if Hazeltine National

            boolean error = false;

            int count2 = 0;
            count = 0;

            String gstname = "";
            String [] gName = new String [5];    // array to hold the Guest Names specified
            String [] gType = new String [5];    // array to hold the Guest Types specified

            i = 0;
            //
            //  init string arrays
            //
            for (i=0; i < 5; i++) {

               gName[i] = "";
               gType[i] = "";
            }

            //
            //  Determine which player positions need to be tested.
            //  Do not check players that have already been checked.
            //
            i = 0;

            if (!player1.equals( oldPlayer1 )) {     // if player name is new or has changed

               if (!g1.equals( "" )) {

                  gType[i] = g1;        // get guest type
                  gName[i] = player1;   // get name entered
                  i++;
               }
            }
            if (!player2.equals( oldPlayer2 )) {     // if player name is new or has changed

               if (!g2.equals( "" )) {

                  gType[i] = g2;        // get guest type
                  gName[i] = player2;   // get name entered
                  i++;
               }
            }
            if (!player3.equals( oldPlayer3 )) {     // if player name is new or has changed

               if (!g3.equals( "" )) {

                  gType[i] = g3;        // get guest type
                  gName[i] = player3;   // get name entered
                  i++;
               }
            }
            if (!player4.equals( oldPlayer4 )) {     // if player name is new or has changed

               if (!g4.equals( "" )) {

                  gType[i] = g4;        // get guest type
                  gName[i] = player4;   // get name entered
                  i++;
               }
            }
            if (!player5.equals( oldPlayer5 )) {     // if player name is new or has changed

               if (!g5.equals( "" )) {

                  gType[i] = g5;        // get guest type
                  gName[i] = player5;   // get name entered
                  i++;
               }
            }

            //
            //  Verify that a name was provided
            //
            i = 0;
            loopg1:
            while (i < 5) {

               if (!gType[i].equals( "" )) {          // if guest type specified

                  gstname = gName[i];                 // get player name specified

                  if (gstname.equals( gType[i] )) {   // if matches then can't be name

                     error = true;
                     break loopg1;
                  }
                  //
                  //  Use tokens to determine the number of words in each string.
                  //  There must be at least 2 extra words in the player name.
                  //
                  StringTokenizer tok = new StringTokenizer( gstname, " " );          // delimiter is a space
                  count = tok.countTokens();                                       // number of words in player name

                  StringTokenizer tok2 = new StringTokenizer( gType[i], " " );     // guest type
                  count2 = tok2.countTokens();                                     // number of words in guest type

                  if (count > count2) {

                     count = count - count2;          // how many more words in player name than guest type

                     if (count < 2) {                 // must be at least 2

                        error = true;
                        break loopg1;
                     }

                  } else {           // error

                     error = true;
                     break loopg1;
                  }

               } else {        // done when no guest type
                  break loopg1;
               }
               i++;
            }                  // end of while

            if (error == true) {

               out.println(SystemUtils.HeadTitle("Guest Name Not Provided - Reject"));
               out.println("<BODY bgcolor=\"ccccaa\">");
               out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><H3>Invalid Guest Request</H3><BR>");
               out.println("<BR><BR>Sorry, you must provide the full name of your guest(s).");
               out.println("<BR>Please enter a space followed by the guest's name immediately after the guest type");
               out.println("<BR>in the player field.  Click your mouse in the player field, move the cursor");
               out.println("<BR>to the end of the guest type, hit the space bar and then type the full name.");
               out.println("<BR><BR>");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
               out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
               out.println("</form></font>");
               out.println("</CENTER></BODY></HTML>");
               return;
            }
         }
      }      // end of if guests

      //
      //***********************************************************************************************
      //
      //    Now check if any of the players are already scheduled for this event
      //
      //***********************************************************************************************
      //
      try {

         hit = false;

         if ((!player1.equals( "" )) && (!player1.equalsIgnoreCase( "x" )) && (g1.equals( "" ))) {

            PreparedStatement pstmt21 = con.prepareStatement (
               "SELECT id FROM evntsup2b " +
               "WHERE (player1 = ? OR player2 = ? OR player3 = ? OR player4 = ? OR player5 = ?) AND " +
               "name = ? AND courseName = ? AND id != ?");

            pstmt21.clearParameters();        // clear the parms and check player 1
            pstmt21.setString(1, player1);
            pstmt21.setString(2, player1);
            pstmt21.setString(3, player1);
            pstmt21.setString(4, player1);
            pstmt21.setString(5, player1);
            pstmt21.setString(6, name);
            pstmt21.setString(7, course);
            pstmt21.setInt(8, id);
            rs = pstmt21.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               hit = true;                    // player already scheduled for this event
               player = player1;              // get player for message
            }
            pstmt21.close();
         }

         if ((!player2.equals( "" )) && (!player2.equalsIgnoreCase( "x" )) && (g2.equals( "" )) && (hit == false)) {

            PreparedStatement pstmt21 = con.prepareStatement (
               "SELECT id FROM evntsup2b " +
               "WHERE (player1 = ? OR player2 = ? OR player3 = ? OR player4 = ? OR player5 = ?) AND " +
               "name = ? AND courseName = ? AND id != ?");

            pstmt21.clearParameters();        // clear the parms and check player 2
            pstmt21.setString(1, player2);
            pstmt21.setString(2, player2);
            pstmt21.setString(3, player2);
            pstmt21.setString(4, player2);
            pstmt21.setString(5, player2);
            pstmt21.setString(6, name);
            pstmt21.setString(7, course);
            pstmt21.setInt(8, id);
            rs = pstmt21.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               hit = true;                    // player already scheduled for this event
               player = player2;              // get player for message
            }
            pstmt21.close();
         }

         if ((!player3.equals( "" )) && (!player3.equalsIgnoreCase( "x" )) && (g3.equals( "" )) && (hit == false)) {

            PreparedStatement pstmt21 = con.prepareStatement (
               "SELECT id FROM evntsup2b " +
               "WHERE (player1 = ? OR player2 = ? OR player3 = ? OR player4 = ? OR player5 = ?) AND " +
               "name = ? AND courseName = ? AND id != ?");

            pstmt21.clearParameters();        // clear the parms and check player 3
            pstmt21.setString(1, player3);
            pstmt21.setString(2, player3);
            pstmt21.setString(3, player3);
            pstmt21.setString(4, player3);
            pstmt21.setString(5, player3);
            pstmt21.setString(6, name);
            pstmt21.setString(7, course);
            pstmt21.setInt(8, id);
            rs = pstmt21.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               hit = true;                    // player already scheduled for this event
               player = player3;              // get player for message
            }
            pstmt21.close();
         }

         if ((!player4.equals( "" )) && (!player4.equalsIgnoreCase( "x" )) && (g4.equals( "" )) && (hit == false)) {

            PreparedStatement pstmt21 = con.prepareStatement (
               "SELECT id FROM evntsup2b " +
               "WHERE (player1 = ? OR player2 = ? OR player3 = ? OR player4 = ? OR player5 = ?) AND " +
               "name = ? AND courseName = ? AND id != ?");

            pstmt21.clearParameters();        // clear the parms and check player 4
            pstmt21.setString(1, player4);
            pstmt21.setString(2, player4);
            pstmt21.setString(3, player4);
            pstmt21.setString(4, player4);
            pstmt21.setString(5, player4);
            pstmt21.setString(6, name);
            pstmt21.setString(7, course);
            pstmt21.setInt(8, id);
            rs = pstmt21.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               hit = true;                    // player already scheduled for this event
               player = player4;              // get player for message
            }
            pstmt21.close();
         }

         if ((!player5.equals( "" )) && (!player5.equalsIgnoreCase( "x" )) && (g5.equals( "" )) && (hit == false)) {

            PreparedStatement pstmt21 = con.prepareStatement (
               "SELECT id FROM evntsup2b " +
               "WHERE (player1 = ? OR player2 = ? OR player3 = ? OR player4 = ? OR player5 = ?) AND " +
               "name = ? AND courseName = ? AND id != ?");

            pstmt21.clearParameters();        // clear the parms and check player 5
            pstmt21.setString(1, player5);
            pstmt21.setString(2, player5);
            pstmt21.setString(3, player5);
            pstmt21.setString(4, player5);
            pstmt21.setString(5, player5);
            pstmt21.setString(6, name);
            pstmt21.setString(7, course);
            pstmt21.setInt(8, id);
            rs = pstmt21.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               hit = true;                    // player already scheduled for this event
               player = player5;              // get player for message
            }
            pstmt21.close();
         }
      }
      catch (Exception e21) {

         dbError(out, e21);
         return;
      }

      if (hit == true) {          // if we hit on a duplicate res

         out.println(SystemUtils.HeadTitle("Member Restricted - Reject"));
         out.println("<BODY bgcolor=\"#ccccaa\">");
         out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
         out.println("<hr width=\"40%\">");
         out.println("<BR><BR><H3>Member Already Scheduled for Event</H3><BR>");
         out.println("<BR>Sorry, <b>" + player + "</b> is already scheduled to play in this event.<br><br>");
         out.println("Please remove this player and try again.<br>");
         out.println("Contact the proshop if you have any questions.<br>");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
            out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      //  Check if user has approved of the member/guest sequence (guest association)
      //
      //  If this skip is set, then we've already been through these tests.
      //
      if (req.getParameter("skip8") == null) {

         //
         //***********************************************************************************************
         //
         //    Now check the order of guests and members (guests must follow a member) - prompt to verify order
         //
         //***********************************************************************************************
         //
         if (guests > 0) {

            if (members > 0) {  // if at least one member (this should always be the case!)

               //
               //  Determine guest owners by order
               //
               gi = 0;
               memberName = "";

               while (gi < 5) {                  // cycle thru arrays and find guests/members

                  if (!gstA[gi].equals( "" )) {

                     usergA[gi] = memberName;       // get last players username
                  } else {
                     usergA[gi] = "";               // init array entry
                  }
                  if (!memA[gi].equals( "" )) {

                     memberName = memA[gi];        // get players username
                  }
                  gi++;
               }
               userg1 = usergA[0];        // set usernames for guests in teecurr
               userg2 = usergA[1];
               userg3 = usergA[2];
               userg4 = usergA[3];
               userg5 = usergA[4];
            }
            
            if (members > 1 || !g1.equals( "" )) {  // if multiple members OR slot 1 is a guest
               //
               //  At least one guest and one member have been specified.
               //  Prompt user to verify the order.
               //
               out.println(SystemUtils.HeadTitle("Guests Specified - Prompt"));
               out.println("<BODY bgcolor=\"#ccccaa\">");
               out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><BR><H3>Player/Guest Association Prompt</H3><BR>");
               out.println("Guests must be specified <b>immediately after</b> the member they belong to.<br><br>");

               if (!g1.equals( "" )) {    // if player1 is a guest

                  out.println("The first player position cannot contain a guest.  Please correct the order<br>");
                  out.println("of players.  This is what you requested:");

               } else {

                  out.println("Please verify that the following order is correct:");
               }
               out.println("<BR><BR>");
               out.println(player1 + " <BR>");
               out.println(player2 + " <BR>");
               if (!player3.equals( "" )) {
                  out.println(player3 + " <BR>");
               }
               if (!player4.equals( "" )) {
                  out.println(player4 + " <BR>");
               }
               if (!player5.equals( "" )) {
                  out.println(player5 + " <BR>");
               }

               if (g1.equals( "" )) {    // if player1 is not a guest

                  out.println("<BR>Would you like to process the request as is?");
               }

               //
               //  Return to _slot to change the player order
               //
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");

               if (g1.equals( "" )) {    // if player1 is not a guest

                  out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; \">");

               } else {
                  out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline;\">");
               }
               out.println("</form></font>");

               if (g1.equals( "" )) {    // if player1 is not a guest

                  //
                  //  Return to process the players as they are
                  //
                  out.println("<font size=\"2\">");
                  out.println("<form action=\"/" +rev+ "/servlet/Member_evntSignUp\" method=\"post\" target=\"_top\">");
                  out.println("<input type=\"hidden\" name=\"skip8\" value=\"yes\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"userg1\" value=\"" + userg1 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg2\" value=\"" + userg2 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg3\" value=\"" + userg3 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg4\" value=\"" + userg4 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg5\" value=\"" + userg5 + "\">");
                  out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
                  out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submitForm\">");
                  out.println("</form></font>");
               }
               out.println("</CENTER></BODY></HTML>");
               return;

            }   // end of IF more than 1 member OR guest in #1 slot
            
         }      // end of IF any guests specified

      } else {   // skip 8 requested
         //
         //  User has responded to the guest association prompt - process tee time request in specified order
         //
         userg1 = req.getParameter("userg1");
         userg2 = req.getParameter("userg2");
         userg3 = req.getParameter("userg3");
         userg4 = req.getParameter("userg4");
         userg5 = req.getParameter("userg5");
      }         // end of IF skip8


      //**************************************************************
      //  Verification Complete !!!!!!!!
      //**************************************************************
      //
      //  See if entry should be on wait list
      //
      if (wait == 0) {     // if not already on wait list

         if (oldPlayer1.equals( "" ) && oldPlayer2.equals( "" ) && oldPlayer3.equals( "" ) &&
             oldPlayer4.equals( "" ) && oldPlayer5.equals( "" )) {      // and new entry

            try {
               //
               //   see if event is full
               //
               PreparedStatement pstmtw = con.prepareStatement (
                  "SELECT player1, player2, player3, player4, player5 FROM evntsup2b " +
                  "WHERE name = ?");

               pstmtw.clearParameters();        // clear the parms
               pstmtw.setString(1, name);
               rs2 = pstmtw.executeQuery();      // execute the prepared pstmt

               while (rs2.next()) {

                  wplayer1 = rs2.getString("player1");
                  wplayer2 = rs2.getString("player2");
                  wplayer3 = rs2.getString("player3");
                  wplayer4 = rs2.getString("player4");
                  wplayer5 = rs2.getString("player5");

                  t = 0;

                  if (!wplayer1.equals( "" ) || !wplayer2.equals( "" ) || !wplayer3.equals( "" ) ||
                      !wplayer4.equals( "" ) || !wplayer5.equals( "" )) {
                     t = 1;
                  }
                  teams = teams + t;        // bump number of teams if any players
               }
               pstmtw.close();

            }
            catch (Exception ignore) {
            }
            if (teams >= max) {

               wait = 1;      // put on wait list
            }
         }
      }

      //
      //  process email requirements for this entry
      //
      sendemail = 0;         // init email flags
      
      //if (!email1.equals("") || !email2.equals("")) sendemail = 1;
      
      emailNew = 0;
      emailMod = 0;
      //
      //  If players changed, then init the no-show flag and send emails, else use the old no-show value
      //
      if (!player1.equals( oldPlayer1 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player2.equals( oldPlayer2 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player3.equals( oldPlayer3 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player4.equals( oldPlayer4 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player5.equals( oldPlayer5 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      //
      //   Set email type based on new or update request (cancel set above)
      //
      if ((!oldPlayer1.equals( "" )) || (!oldPlayer2.equals( "" )) || (!oldPlayer3.equals( "" )) ||
          (!oldPlayer4.equals( "" )) || (!oldPlayer5.equals( "" ))) {

         emailMod = 1;  // tee time was modified

      } else {

         emailNew = 1;  // tee time is new
      }

   }  // end of 'cancel this res' if - cancel will contain empty player fields

   //
   //  Verification complete -
   //  Update the entry in the event sign up table
   //
   try {

      PreparedStatement pstmt6 = con.prepareStatement (
         "UPDATE evntsup2b SET player1 = ?, player2 = ?, player3 = ?, player4 = ?, player5 = ?, " +
         "username1 = ?, username2 = ?, username3 = ?, username4 = ?, username5 = ?, p1cw = ?, " +
         "p2cw = ?, p3cw = ?, p4cw = ?, p5cw = ?,  in_use = 0, hndcp1 = ?, hndcp2 = ?, hndcp3 = ?, " +
         "hndcp4 = ?, hndcp5 = ?, notes = ?, wait = ?, " +
         "userg1 = ?, userg2 = ?, userg3 = ?, userg4 = ?, userg5 = ? " +
         "WHERE name = ? AND courseName = ? AND id = ?");

      pstmt6.clearParameters();        // clear the parms
      pstmt6.setString(1, player1);
      pstmt6.setString(2, player2);
      pstmt6.setString(3, player3);
      pstmt6.setString(4, player4);
      pstmt6.setString(5, player5);
      pstmt6.setString(6, user1);
      pstmt6.setString(7, user2);
      pstmt6.setString(8, user3);
      pstmt6.setString(9, user4);
      pstmt6.setString(10, user5);
      pstmt6.setString(11, p1cw);
      pstmt6.setString(12, p2cw);
      pstmt6.setString(13, p3cw);
      pstmt6.setString(14, p4cw);
      pstmt6.setString(15, p5cw);
      pstmt6.setFloat(16, hndcp1);
      pstmt6.setFloat(17, hndcp2);
      pstmt6.setFloat(18, hndcp3);
      pstmt6.setFloat(19, hndcp4);
      pstmt6.setFloat(20, hndcp5);
      pstmt6.setString(21, notes);
      pstmt6.setInt(22, wait);
      pstmt6.setString(23, userg1);
      pstmt6.setString(24, userg2);
      pstmt6.setString(25, userg3);
      pstmt6.setString(26, userg4);
      pstmt6.setString(27, userg5);

      pstmt6.setString(28, name);
      pstmt6.setString(29, course);
      pstmt6.setInt(30, id);

      pstmt6.executeUpdate();      // execute the prepared stmt

      pstmt6.close();

   }
   catch (Exception e6) {

      dbError(out, e6);
      return;
   }

   //
   //  Build the HTML page to confirm event registration for user
   //

   out.println(SystemUtils.HeadTitle("Member Event Sign Up Complete"));
   out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\">");
   out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

   out.println("<center><img src=\"/" +rev+ "/images/foretees.gif\"><hr width=\"40%\">");
   out.println("<font size=\"3\" face=\"Arial, Helvetica, Sans-serif\">");

   if (req.getParameter("remove") != null) {

      out.println("<p>&nbsp;</p><p>&nbsp;<b>Thank you!</b>&nbsp;&nbsp;The event entry has been cancelled.</p>");
   } else {

      out.println("<p>&nbsp;</p><p>&nbsp;<b>Thank you!</b>&nbsp;&nbsp;Your Event Registration has been accepted and processed.</p>");

      if (wait > 0) {            // if on wait list

         out.println("<br><br><b>Note:</b>  This team is currently on the wait list.");
      }

      if (xcount > 0 && xhrs > 0) {            // if any X's were specified

         out.println("<p>&nbsp;</p>All player positions reserved by an 'X' must be filled within " + xhrs + " hours of the tee time.");
         out.println("<br>If not, the system will automatically remove the X.<br>");
      }

      if (notesL > 254) {

      out.println("<p>&nbsp;</p><b>Notice:</b>&nbsp;&nbsp;The notes you entered exceeded 254 characters in length.  All characters beyond 254 will be truncated.</p>");
      }
        
      //
      //  Add custom message for The Stanwich Club
      //
      if (club.equals( "stanwichclub" )) {
        
         out.println("<br><br><b>*** IMPORTANT SENIORITY INFORMATION - PLEASE READ</b>");
         out.println("<br><br>Thank you for signing up for this tournament.<br>If your email is setup with ForeTees, you will receive a confirmation email.");
         out.println("<br><br><i>However, if the event is oversubscribed before the deadline date<br>(see tournament information page ");
         out.println("for deadline date of each event),<br>member seniority will determine a waitlist.</i>");
         out.println("<br><br>You will be contacted by the tournament coordinator<br>if you are placed on a waitlist due to seniority.");
      }

   }

   out.println("<p>&nbsp;</p></font>");
   out.println("<font size=\"2\">");
   out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
   out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
   out.println("</form></font>");

   //
   //  End of HTML page
   //
   out.println("</center></font></body></html>");

   try {

      resp.flushBuffer();      // force the repsonse to complete

   }
   catch (Exception ignore) {
   }


   //
   //***********************************************
   //  if entry was removed then check for a wait list
   //  and move a team up if possible
   //***********************************************
   //
   if (checkWait != 0) {

      teams = 0;

      try {

         //
         //   see if event is full
         //
         PreparedStatement pstmtw = con.prepareStatement (
            "SELECT player1, player2, player3, player4, player5 FROM evntsup2b " +
            "WHERE name = ? AND courseName = ? AND wait = 0");

         pstmtw.clearParameters();        // clear the parms
         pstmtw.setString(1, name);
         pstmtw.setString(2, course);
         rs2 = pstmtw.executeQuery();      // execute the prepared pstmt

         while (rs2.next()) {

            wplayer1 = rs2.getString("player1");
            wplayer2 = rs2.getString("player2");
            wplayer3 = rs2.getString("player3");
            wplayer4 = rs2.getString("player4");
            wplayer5 = rs2.getString("player5");

            t = 0;

            if (!wplayer1.equals( "" ) || !wplayer2.equals( "" ) || !wplayer3.equals( "" ) ||
                !wplayer4.equals( "" ) || !wplayer5.equals( "" )) {
               t = 1;
            }
            teams = teams + t;        // bump number of teams if any players
         }
         pstmtw.close();

         if (teams < max) {

            long wdate = 0;
            int wtime = 0;

            //
            //   get the earliest registration date on wait list
            //
            PreparedStatement stmtw1 = con.prepareStatement (
               "SELECT MIN(r_date) FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND wait != 0");

            stmtw1.clearParameters();        // clear the parms
            stmtw1.setString(1, name);
            stmtw1.setString(2, course);
            rs = stmtw1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               wdate = rs.getLong(1);
            }
            stmtw1.close();

            if (wdate != 0) {

               //
               //   get the earliest time on this reg date on wait list
               //
               PreparedStatement stmtw2 = con.prepareStatement (
                  "SELECT MIN(r_time) FROM evntsup2b " +
                  "WHERE name = ? AND courseName = ? AND r_date = ? AND wait != 0");

               stmtw2.clearParameters();        // clear the parms
               stmtw2.setString(1, name);
               stmtw2.setString(2, course);
               stmtw2.setLong(3, wdate);
               rs = stmtw2.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  wtime = rs.getInt(1);
               }
               stmtw2.close();


               if (wtime != 0) {

                  //
                  //   get the earliest time on this reg date on wait list
                  //
                  PreparedStatement stmtw4 = con.prepareStatement (
                     "SELECT username1, username2, username3, username4, username5, id " +
                     "FROM evntsup2b " +
                     "WHERE name = ? AND courseName = ? AND r_date = ? AND r_time = ? AND wait != 0");

                  stmtw4.clearParameters();        // clear the parms
                  stmtw4.setString(1, name);
                  stmtw4.setString(2, course);
                  stmtw4.setLong(3, wdate);
                  stmtw4.setInt(4, wtime);
                  rs = stmtw4.executeQuery();      // execute the prepared stmt

                  if (rs.next()) {

                     wuser1 = rs.getString("username1");
                     wuser2 = rs.getString("username2");
                     wuser3 = rs.getString("username3");
                     wuser4 = rs.getString("username4");
                     wuser5 = rs.getString("username5");
                     id = rs.getInt("id");
                  }
                  stmtw4.close();

                  PreparedStatement pstmtw3 = con.prepareStatement (
                     "UPDATE evntsup2b SET wait = 0 " +
                     "WHERE name = ? AND courseName = ? AND id = ?");

                  pstmtw3.clearParameters();        // clear the parms
                  pstmtw3.setString(1, name);
                  pstmtw3.setString(2, course);
                  pstmtw3.setInt(3, id);

                  count = pstmtw3.executeUpdate();      // execute the prepared stmt

                  pstmtw3.close();
               }
            }
         }
      }
      catch (Exception ignore) {
      }

   }     // end of IF checkWait


   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   if (sendemail != 0) {

      long date = (year * 10000) + (month * 100) + day;    // create event date value  
        
      //
      //  allocate a parm block to hold the email parms
      //
      parmEmail parme = new parmEmail();          // allocate an Email parm block

      //
      //  Set the values in the email parm block
      //
      parme.type = "event";         // type = event
      parme.date = date;
      parme.time = 0;
      parme.fb = 0;
      parme.mm = month;
      parme.dd = day;
      parme.yy = year;
      parme.season = season;

      parme.wuser1 = wuser1;     // set Event-only fields
      parme.wuser2 = wuser2;
      parme.wuser3 = wuser3;
      parme.wuser4 = wuser4;
      parme.wuser5 = wuser5;
      parme.name = name;
      parme.etype = etype;
      parme.act_time = act_time;
      parme.wait = wait;
      parme.checkWait = checkWait;

      parme.user = user;
      parme.emailNew = emailNew;
      parme.emailMod = emailMod;
      parme.emailCan = emailCan;

      parme.p91 = 0;     // doesn't matter for event
      parme.p92 = 0;
      parme.p93 = 0;
      parme.p94 = 0;
      parme.p95 = 0;

      parme.course = course;
      parme.day = "";

      parme.player1 = player1;
      parme.player2 = player2;
      parme.player3 = player3;
      parme.player4 = player4;
      parme.player5 = player5;

      parme.oldplayer1 = oldPlayer1;
      parme.oldplayer2 = oldPlayer2;
      parme.oldplayer3 = oldPlayer3;
      parme.oldplayer4 = oldPlayer4;
      parme.oldplayer5 = oldPlayer5;

      parme.user1 = user1;
      parme.user2 = user2;
      parme.user3 = user3;
      parme.user4 = user4;
      parme.user5 = user5;

      parme.olduser1 = oldUser1;
      parme.olduser2 = oldUser2;
      parme.olduser3 = oldUser3;
      parme.olduser4 = oldUser4;
      parme.olduser5 = oldUser5;

      parme.pcw1 = p1cw;
      parme.pcw2 = p2cw;
      parme.pcw3 = p3cw;
      parme.pcw4 = p4cw;
      parme.pcw5 = p5cw;

      parme.oldpcw1 = oldp1cw;
      parme.oldpcw2 = oldp2cw;
      parme.oldpcw3 = oldp3cw;
      parme.oldpcw4 = oldp4cw;
      parme.oldpcw5 = oldp5cw;
      
      //
      //  Customs - add pro email addresses for all event notifications
      //
      parme.emailpro1 = email1;
      parme.emailpro2 = email2;

      if (club.equals("piedmont")) {
         
         parme.emailpro1 = "rgraham@drivingclub.com";     // Robert Graham
      }

      if (club.equals("gallerygolf")) {
         
         parme.emailpro1 = "mikekarpe@pga.com";         // Mike Karpe
      }

            
      //
      //  Send the email
      //
      sendEmail.sendIt(parme, con);      // in common

   }     // end of IF sendemail
 }       // end of verify


 // ************************************************************************
 //  Process cancel request (Return w/o changes) from self
 // ************************************************************************

 private void cancelReq(HttpServletRequest req, PrintWriter out, Connection con) {


   int count = 0;
   int id  = 0;

   //
   // Get all the parameters entered
   //
   String name = req.getParameter("name");           //  name of event
   String course = req.getParameter("course");        //  name of course
   String sid = req.getParameter("id");               //  id of entry in evntsup table
   String index = req.getParameter("index");         

   //
   //  Convert the values from string to int
   //
   try {
      id = Integer.parseInt(sid);
   }
   catch (NumberFormatException e) {
      // ignore error
   }

   //
   //  Clear the 'in_use' flag for this entry
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "UPDATE evntsup2b SET in_use = 0 WHERE name = ? AND courseName = ? AND id = ?");

      pstmt1.clearParameters();        // clear the parms
      pstmt1.setString(1, name);
      pstmt1.setString(2, course);
      pstmt1.setInt(3, id);
      count = pstmt1.executeUpdate();      // execute the prepared stmt

      pstmt1.close();

   }
   catch (Exception ignore) {

   }

   //
   //  Prompt user to return to Member_events
   //
   out.println("<HTML>");
   out.println("<HEAD>");
   out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
   out.println("<Title>Member Event Registration Page</Title>");

   out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Member_jump?name=" +name+ "&course=" +course+ "&index=" +index+ "\">");
   out.println("</HEAD>");
   out.println("<BODY bgcolor=\"#ccccaa\">");
   out.println("<CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><BR><H3>Return/Cancel Requested</H3>");
   out.println("<BR><BR>Thank you, the event entry has been returned to the system without changes.");
   out.println("<BR><BR>");

   out.println("<font size=\"2\">");
   out.println("<form action=\"/" +rev+ "/servlet/Member_jump\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
   out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
   out.println("</form></font>");

   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 //  Database Error
 // *********************************************************

 private void dbError(PrintWriter out, Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>Exception: " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Invalid data received - reject request
 // *********************************************************

 private void invData(PrintWriter out, String p1, String p2, String p3, String p4, String p5) {


   if (p1.equals( "" )) {

      p1 = " ";             // use space instead of null
   }

   if (p2.equals( "" )) {

      p2 = " ";             // use space instead of null
   }

   if (p3.equals( "" )) {

      p3 = " ";             // use space instead of null
   }

   if (p4.equals( "" )) {

      p4 = " ";             // use space instead of null
   }

   if (p5.equals( "" )) {

      p5 = " ";             // use space instead of null
   }

   out.println(SystemUtils.HeadTitle("Invalid Data - Reject"));
   out.println("<BODY bgcolor=\"#ccccaa\"><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H3>Invalid Data Received</H3><BR>");
   out.println("<BR><BR>Sorry, a name you entered is not valid.<BR>");
   out.println("<BR>You entered:&nbsp;&nbsp;&nbsp;'" + p1 + "',&nbsp;&nbsp;&nbsp;'" + p2 + "',&nbsp;&nbsp;&nbsp;'" + p3 + "',&nbsp;&nbsp;&nbsp;'" + p4 + "',&nbsp;&nbsp;&nbsp;'" + p5 + "'");
   out.println("<BR><BR>");
   out.println("Please check the names and try again.");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");
   return;
 }

}
