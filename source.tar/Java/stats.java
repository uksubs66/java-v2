/***************************************************************************************
 *   Class file:    stats
 *
 *
 *   Called by:     called directly
 *
 *
 *   Created:       5/15/2006 by Paul
 *
 *
 *   Last Updated:  
 *
 *                  
 *                  
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import java.net.*;
import java.text.*;


public class stats extends HttpServlet {

    String rev = SystemUtils.REVLEVEL;                              // Software Revision Level (Version)
    
    
 //*****************************************************
 // Process the a get method on this page as a post call
 //*****************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    GregorianCalendar cal = new GregorianCalendar();
    DateFormat df_date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
    String display_date = df_date.format(cal.getTime());
    
    out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
    out.println("<html>");
    out.println("<head>");
    out.println(" <meta http-equiv=\"refresh\" content=\"120\">");
    out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">");
    out.println(" <meta http-equiv=\"Content-Language\" content=\"en-us\">");
    out.println("<title>Application Statistics</title>");
    out.println("</head>");
    out.println("<body bgcolor=white>");
    out.println("<font size=4><u>Application Statistics</u></font><br>");
    
    if (req.getParameter("live") != null) {

        displayLiveStats(req, out);
    }
    
    if (req.getParameter("db") != null) {

        displayDbStats(out);
    }
    
    if (req.getParameter("bounced") != null) {

        displayBouncedCount(req, out);
    }
    
    if (req.getParameter("logins") != null) {

        displayLoginStats(req, out);
    }
    
    if (req.getParameter("logins") != null && req.getParameter("graph") != null) {

        displayLoginHourGraph(req, out);
    }
    
    out.println("<p><font size=2>Node " + Common_Server.SERVER_ID + " reporting<br>" + display_date + "</font></p>");
    
    out.println("</body></html>");
    out.close();
    
 } // end of doGet routine
 
 
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

    PrintWriter out = resp.getWriter();
   
    URL url;
    URLConnection urlConn = null;
    DataOutputStream dataOut;
    DataInputStream dataIn;
    
    //url = new URL (getCodeBase().toString() + "test.php");
    url = new URL ("http://www.foretees.com/test.php");
    /*
    try { urlConn = url.openConnection(); }
    catch(Exception e) { out.println("Can not connect, " + e.toString()); out.close(); return; }
    if (urlConn == null) { out.println("Could not connect."); out.close(); return; }
    */
    urlConn.setDoInput(true);
    urlConn.setDoOutput(true);
    urlConn.setUseCaches(false);
    urlConn.setRequestProperty("Content-type", "application/x-www-form-urlencoded");
    dataOut = new DataOutputStream(urlConn.getOutputStream());
    String content;
    content = "name=" + URLEncoder.encode("Paul Thomas", "UTF-8");
    content += "&id=" + URLEncoder.encode("72", "UTF-8");
    dataOut.writeBytes(content);
    dataOut.flush();
    dataOut.close();
    dataIn = new DataInputStream(urlConn.getInputStream());
    String tmp;
    
    while ((tmp = dataIn.readLine()) != null) { out.println(tmp); }
    
    dataIn.close();
    
    out.close();
    
 } // end of doPost routine
 
 
 private void displayLoginStats(HttpServletRequest req, PrintWriter out) {
    
    /*
    out.println("<br><u>Activity by Hour for Node " + Common_Server.SERVER_ID + "</u><br>");

    for (int x=0;x<24;x++) {

        out.println("hr " + x + " " + SystemUtils.loginCountsPro[x] + "/" + SystemUtils.loginCountsMem[x] + "<br>");
    }
    */
     
    Connection con = null;          
    Statement stmt = null;
    ResultSet rs = null;

    NumberFormat nf;
    nf = NumberFormat.getNumberInstance();

    int today = 0;
    int today_pro = 0;
    int today_mem = 0;
    int today_memL = 0;
    int today_memR = 0;
    int this_month = 0;
    int last_month = 0;
    int last_month_ly = 0;
    double increase = 0;
    
    try {

        con = dbConn.Connect("v5");
        stmt = con.createStatement();
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND (user_type_id = 3 OR user_type_id = 4)");
        if (rs.next()) today_pro = rs.getInt(1);
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND user_type_id = 1");
        if (rs.next()) today_memL = rs.getInt(1);
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND user_type_id = 2");
        if (rs.next()) today_memR = rs.getInt(1);
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(now()) AND YEAR(entry_date) = YEAR(now())");
        if (rs.next()) this_month = rs.getInt(1);
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(DATE_ADD(now(), INTERVAL -1 MONTH)) AND YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 MONTH))");
        if (rs.next()) last_month = rs.getInt(1);
        
        rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(DATE_ADD(now(), INTERVAL -1 MONTH)) AND YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 YEAR))");
        if (rs.next()) last_month_ly = rs.getInt(1);
        
        rs.close();
        con.close();
    }
    catch (Exception exc) {
        out.println("<p>Database Error!");
        out.println("<br>Exception: "+ exc.getMessage() + "</p>");
        return;
    }

    today_mem = today_memR + today_memL;
    today = today_pro + today_mem;
    //increase = this_year / last_year;
    
    //DecimalFormat df = new DecimalFormat("#.##");
    //increase = ((df.format(this_month / last_month_ly) * 100) - 100);
    increase = last_month / last_month_ly;
    out.println("<!-- increase=" + increase + " -->");
    increase = (increase * 100) - 100;
    
    out.println("<br><u>Logins</u><br>");
    out.println("Today: " + nf.format(today) + " (" + nf.format(today_pro) + "P / " + nf.format(today_memL) + "L / " + nf.format(today_memR) + "R)<br>");
    //if (req.getParameter("logins").equals("1")) return; // if logins=1 then just show todays logins
    out.println("This Month: " + nf.format(this_month) + "<br>");
    out.println("Last Month: " + nf.format(last_month) + "<br>"); 
    out.println("Increase From LY: " + (increase) + "%<br>");     
     
    out.println("<!-- last_month_ly=" + last_month_ly + " -->"); 
    out.println("<!-- last_month / last_month_ly=" + (last_month / last_month_ly) + " -->");  
 }
 
 
 private void displayLoginHourGraph(HttpServletRequest req, PrintWriter out) {
     
    Connection con = null;           
    Statement stmt = null;
    ResultSet rs = null;
    
    int [] memLogins = new int [24];     // one per hour of day     
    int [] proLogins = new int [24];   
    int [] combinedLogins = new int [24];
    int user_type = 0;
    int logins = 0;
    int hour = 0;
    int tmp_highest = 0;
    int line = 0;
    int tmp_total = 0;
    double tmp = 0;
    String oldest_date= "";
    String tmp_hour = "";
    String sql = "";
    
    NumberFormat nf;
    nf = NumberFormat.getNumberInstance();

    try {
        
        con = dbConn.Connect("v5");
        stmt = con.createStatement();  
        /*
        rs = stmt.executeQuery("SELECT entry_date FROM login_stats ORDER BY entry_date ASC LIMIT 1");
        if (rs.next()) oldest_date = rs.getString(1);
        
        out.println("<br><u>Logins Since " + oldest_date + "</u>");
        */
        if (req.getParameter("logins").equals("1")) {
            sql = "SELECT hour, sum(login_count) AS logins FROM login_stats WHERE entry_date = now() GROUP BY hour";
        } else {
            sql = "SELECT hour, sum(login_count) AS logins FROM login_stats GROUP BY hour";
        }
        
        out.println("<br>");
        rs = stmt.executeQuery(sql);      // Max_connections
        
        while (rs.next()) {
            
            //user_type = rs.getInt("user_type_id");
            logins = rs.getInt("logins");
            hour = rs.getInt("hour");
            
            //if (user_type == 1 || user_type == 2) memLogins[hour] += logins;
            //if (user_type == 3 || user_type == 4) proLogins[hour] += logins;
            
            //combinedLogins[hour] = memLogins[hour] + proLogins[hour];
            combinedLogins[hour] = logins;
        }

        for (int x=0;x<24;x++) {
            
            if (tmp_highest < combinedLogins[x]) tmp_highest = combinedLogins[x];
        }
        
        out.println("<u>Logins by Hour</u><br>");
    
        out.println("<table cellpadding=0 cellspacing=0>");
            
        for (int x=0;x<24;x++) {
            
            try {
                line = ((combinedLogins[x] / tmp_highest) * 100);
                tmp = ((double)combinedLogins[x] / (double)tmp_highest) * 150;
                if (tmp < 1 && tmp > 0) tmp = 1; // make sure any thing greater than zero rounds up to 1
                tmp_hour = ((x < 12) ? x + " AM" : (x - 12) + " PM");
                if (x == 0) tmp_hour = "12 AM";
                if (x == 12) tmp_hour = "12 PM";

                if ((int)tmp > 0) {
                    out.println("<tr><td align=right nowrap>" + tmp_hour + "</td>");
                    out.println("<td nowrap>&nbsp;<img src=/v5/images/black.gif height=7 width=\"" + tmp + "\" border=0> &nbsp;"+nf.format(combinedLogins[x]) + "</td>");
                    out.println("</tr>");
                }
            } catch(Exception exc) {
                out.println("<tr><td align=right nowrap>" + tmp_hour + "</td>");
                out.println("<td nowrap>&nbsp;<img src=/v5/images/black.gif height=7 width=0 border=0> &nbsp;"+nf.format(combinedLogins[x]) + "</td>");
                out.println("</tr>");
            }
        }
        
        out.println("</table>");
        
        con.close();
        
    } catch (Exception exc) {
      out.println("<BR><BR>Database Error!");
      out.println("<BR>Exception: "+ exc.getMessage());
      return;
    }
    
 }
 
 
 private void displayDbStats(PrintWriter out) {

    Connection con = null;           
    Statement stmt = null;
    ResultSet rs = null;
    int max_connections = 0;
    int threads_connected = 0;
    int questions = 0;
    int uptime = 0;
    long bytes_in = 0;
    double bytes_out = 0;
    String size_in = "MB";
    String size_out = "MB";
    
    String err = "";
    
    try {
        
        con = dbConn.Connect("v5");
        stmt = con.createStatement(); 
        
        rs = stmt.executeQuery("show status like 'Max_used_connections'");      // Max_connections
        err = "max_connections";
        if (rs.next()) max_connections = rs.getInt(2);
        
        rs = stmt.executeQuery("show status like 'Threads_connected'");         // Threads_connected
        err = "threads_connected";
        if (rs.next()) threads_connected = rs.getInt(2);
        
        rs = stmt.executeQuery("show status like 'Questions'");                 // Questions
        err = "questions";
        if (rs.next()) questions = rs.getInt(2);
        
        rs = stmt.executeQuery("show status like 'Uptime'");                    // Uptime
        err = "uptime";
        if (rs.next()) uptime = rs.getInt(2);
        
        rs = stmt.executeQuery("show status like 'Bytes_received'");            // Bytes_received
        err = "bytes_in";
        if (rs.next()) bytes_in = rs.getLong(2);
        
        rs = stmt.executeQuery("show status like 'Bytes_sent'");                // Bytes_sent
        err = "bytes_out";
        if (rs.next()) bytes_out = rs.getDouble(2);
        con.close();

    } catch (Exception exc) { 
      out.println("<BR><BR>Database Error!");
      out.println("<BR>Exception: "+ err + " : " + exc.getMessage());
      return;
    }
   
    double qpers = (questions / uptime);
    
    bytes_in = bytes_in / 1024 / 1024; // convert to MB
    bytes_out = bytes_out / 1024 / 1024; // convert to MB
    
    if (bytes_in > 1024) {
        
        bytes_in = bytes_in / 1024;
        size_in = "GB";
    }
    
    if (bytes_out > 1024) {
        
        bytes_out = bytes_out / 1024;
        size_out = "GB";
    }
    
    out.println("<br><u>Master</u><br>");
    out.println("Con: " + threads_connected + "/" + max_connections + "<br>");
    out.println("Qsec: " + qpers + "<br>");
    out.println("Data: " + (int)bytes_in + size_in + "/" + (int)bytes_out + size_out + "<br>");
    
    
    // get slave status
    err = "Slave Status";
    String state = "";
    String slave_sql = "";
    String slave_io = "";
    String last_error = "";
    int last_errno = 0;
    int sec_behind = 0;
    
    try {
        
        con = dbConn_slave.Connect("xmail_bounces");
        stmt = con.createStatement(); 
        
        rs = stmt.executeQuery("show slave status;");
        if (rs.next()) {
            
            state = rs.getString("Slave_IO_State");
            slave_io = rs.getString("Slave_IO_Running");
            slave_sql = rs.getString("Slave_SQL_Running");
            last_error = rs.getString("Last_Error");
            last_errno = rs.getInt("Last_Errno");
            sec_behind = rs.getInt("Seconds_Behind_Master");
        }
        
        con.close();
        
    } catch (Exception exc) { 
      out.println("<BR><BR>Database Error!");
      out.println("<BR>Exception: "+ err + " : " + exc.getMessage());
      return;
    }
    
    out.println("<br><u>Slave</u><br>");
    out.println("Status: " + state + "<br>");
    if (!slave_io.equals("Yes") || !slave_sql.equals("Yes")) out.println("Slave IO/SQL Running: " + slave_io + " / " + slave_sql + "<br>");
    if (last_errno != 0 || !last_error.equals("")) out.println("Last Error: " + last_error + " (" + last_errno + ")<br>");
    out.println("Seconds Behind: " + sec_behind + "<br>");
    
 }
 
 
 private void displayLiveStats(HttpServletRequest req, PrintWriter out) {
  
    Connection con = null;
    Connection con2 = null;             
    Statement stmt = null;
    Statement stmt2 = null;
    ResultSet rs = null;
    ResultSet rs2 = null;

    NumberFormat nf;
    nf = NumberFormat.getNumberInstance();

    int count = 0;
    int total = 0;
    int num = 0;
    int in_use = 0;
    int today = 0;
    int this_month = 0;
    int last_month = 0;
/*    
    try {

        con2 = dbConn.Connect("v5");
        stmt = con2.createStatement();
        
        //rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now()");
        //if (rs.next()) today = rs.getInt(1);
        
        //rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(now())");
        //if (rs.next()) this_month = rs.getInt(1);
        
        //rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = (MONTH(now()) - 1)");
        //if (rs.next()) last_month = rs.getInt(1);
        
    }
    catch (Exception exc) {
        out.println("<p>Database Error!");
        out.println("<br>Exception: "+ exc.getMessage() + "</p>");
        return;
    }

    //
    //   Get each club's login count and total them
    //
    try {
      
        stmt2 = con2.createStatement();
        rs2 = stmt2.executeQuery("SELECT clubname FROM clubs ORDER BY clubname");

        while (rs2.next()) {

            count = 0;
            con = dbConn.Connect(rs2.getString(1));         // get a connection to this club's db
            stmt = con.createStatement();           // create a statement

            try {

                rs = stmt.executeQuery("SELECT logins FROM club5");          // get # of users logged in
                if (rs.next()) count = rs.getInt("logins");

            } catch (Exception ignore) { }

            stmt.close();

            // compute totals
            num++;                    // increment the club counter
            total += count;           // increment the total login counter
            if (count > 0) in_use++;  // only inc the in_use counter if there is someone logged into a club

            con.close();                           // close the connection to the club db

        } // while

        stmt2.close();
        con2.close();
        
    }
    catch (Exception exc) {
        out.println("<p>Database Error!");
        out.println("<br>Exception: "+ exc.getMessage() + "</p>");
        return;
    }    
*/
            
            
    // get the most recent # of sessions
    
    int sess1 = 0;
    int sess2 = 0;
    int threads = 0;
    int node1_now = 0;
    int node2_now = 0;
    int node3_now = 0;
    int node1_sum = 0;
    int node2_sum = 0;
    int node3_sum = 0;
    int node1_threads = 0;
    int node2_threads = 0;
    int node3_threads = 0;
    
    try { 
    
        URL url;
        URLConnection urlConn = null;
        DataOutputStream dataOut;
        DataInputStream dataIn;

        // get active sessions
        url = new URL ("http://216.243.184.81:8080/S1.html");
        
        try { urlConn = url.openConnection(); }
        catch(Exception e) { out.println("Can not connect, " + e.toString()); out.close(); return; }
        if (urlConn == null) { out.println("Could not connect."); out.close(); return; }
        
        dataIn = new DataInputStream(urlConn.getInputStream());
        
        String tmp;
/*
        while ((tmp = dataIn.readLine()) != null) { 

            sess1 += Integer.parseInt(tmp.trim());
        } // end while
*/
        
        if ((tmp = dataIn.readLine()) != null) node1_now = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node2_now = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node3_now = Integer.parseInt(tmp.trim());
        
        sess1 = node1_now + node2_now + node3_now;
        
        dataIn.close();
    
        
        // get total sessions
        url = new URL ("http://216.243.184.81:8080/S2.html");
        
        try { urlConn = url.openConnection(); }
        catch(Exception e) { out.println("Can not connect, " + e.toString()); out.close(); return; }
        if (urlConn == null) { out.println("Could not connect."); out.close(); return; }
        
        dataIn = new DataInputStream(urlConn.getInputStream());
        
        tmp = null;
/*
        while ((tmp = dataIn.readLine()) != null) { 

            sess2 += Integer.parseInt(tmp.trim());
        } // end while
*/
        
        if ((tmp = dataIn.readLine()) != null) node1_sum = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node2_sum = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node3_sum = Integer.parseInt(tmp.trim());
        
        sess2 = node1_sum + node2_sum + node3_sum;
        
        dataIn.close();
        
        
        // get total sessions
        url = new URL ("http://216.243.184.81:8080/S3.html");
        
        try { urlConn = url.openConnection(); }
        catch(Exception e) { out.println("Can not connect, " + e.toString()); out.close(); return; }
        if (urlConn == null) { out.println("Could not connect."); out.close(); return; }
        
        dataIn = new DataInputStream(urlConn.getInputStream());
        
        tmp = null;
/*
        while ((tmp = dataIn.readLine()) != null) { 

            sess2 += Integer.parseInt(tmp.trim());
        } // end while
*/
        
        if ((tmp = dataIn.readLine()) != null) node1_threads = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node2_threads = Integer.parseInt(tmp.trim());
        if ((tmp = dataIn.readLine()) != null) node3_threads = Integer.parseInt(tmp.trim());
        
        threads = node1_threads + node2_threads + node3_threads;
        
        dataIn.close();
        
    } catch (Exception exp) {
        
        SystemUtils.buildDatabaseErrMsg(exp.getMessage(), exp.toString(), out, false);
    }
    
    out.println("<br><u>Sessions</u><br>");
    //out.println("InUse: " + in_use + "/" + num + "<br>");
    //out.println("On: " + nf.format(total) + "<br>");
    //out.println("Today: " + nf.format(today) + "<br>");
    //out.println("This Month: " + nf.format(this_month) + "<br>");
    //out.println("Last Month: " + nf.format(last_month) + "<br>");
    out.println("Current: " + nf.format(sess1) + " (" + nf.format(node1_now) + " / " + nf.format(node2_now) + " / " + nf.format(node3_now) + ")<br>");
    out.println("Since Boot: " + nf.format(sess2) + " (" + nf.format(node1_sum) + " / " + nf.format(node2_sum) + " / " + nf.format(node3_sum) + ")<br>");
    out.println("Threads: " + nf.format(threads) + " (" + nf.format(node1_threads) + " / " + nf.format(node2_threads) + " / " + nf.format(node3_threads) + ")<br>");
    
 }
 
 private void displayBouncedCount(HttpServletRequest req, PrintWriter out) {
     
    Connection con = null;           
    Statement stmt = null;
    ResultSet rs = null;
     
    int bounced = 0;
    
    try {
        
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        con = DriverManager.getConnection("jdbc:mysql://216.243.184.88/xmail_bounces", "xmail_filters", "xmfilmail");
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT COUNT(*) FROM bounced;");
        if (rs.next()) {
            
            bounced = rs.getInt(1);
        }
        
        con.close();

    } catch (Exception exc) { 
      out.println("<BR><BR>Database Error!");
      out.println("<BR>Exception: Bounced - " + exc.getMessage());
      return;
    }
    
    out.println("<br><u>Emails</u><br>");
    out.println("Bounced Emails: " + bounced + "<br>");
    
 }
} // end servlet public class