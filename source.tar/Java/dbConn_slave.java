/***************************************************************************************
 *   dbConn_slave:  Make a connection to the slave database.
 *
 *   Called by:  Login
 *               SystemUtils
 *
 *
 *   Created:  6/25/2007
 *
 *
 *   Last updated:
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;


public class dbConn_slave {


/**
 //************************************************************************
 //
 //  Get the connection
 //
 //************************************************************************
 **/

 public synchronized static Connection Connect(String club)
        throws Exception {

   String user = SystemUtils.db_user;
   String password = SystemUtils.db_password;      

   //
   // ***********************************************************************
   //  Change this url based on which server it is. !!!!!!!!!!!!!!!!!!!!!!!
   //
   //      see also com/foretees/common/Connect.java !!!!!!!!!!!!!
   //
   // ***********************************************************************
   //
   
   String url = "jdbc:mysql://216.243.184.87/" + club;    // PUBLIC INTERFACE TO SLAVE DB
   
   Connection con = null;
   
   try {
   
      // Load the JDBC Driver

      // The newinstance() call is a work around for some Java implementations.
      Class.forName("com.mysql.jdbc.Driver").newInstance();

      // Connect to the DB.........
      con = DriverManager.getConnection(url, user, password);
      
   }
   catch (ClassNotFoundException e) {
   
      throw new Exception("ClassNotFound Error Getting Con: " + e.getMessage());
   }
   catch (SQLException e1) {
   
      throw new Exception("dbConn Error Getting Con: " + e1.getMessage());
   }
   
   return(con);
   
 }

}  // end of dbConn_slave class
