/***************************************************************************************
 *   verifyLesson:  This servlet will provide some common tee time request processing methods.
 *
 *       called by:  Proshop_lesson
 *                   Member_lesson
 *
 *
 *   created:  10/26/2004   Bob P.
 *
 *
 *   last updated:
 *
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.internet.*;
import javax.mail.*;
import javax.activation.*;


public class verifyLesson {

   private static String rev = ProcessConstants.REV;


/**
 //************************************************************************
 //
 //  checkInUse - check if Lesson Time is in use and if not, set it
 //
 //************************************************************************
 **/

 public synchronized static int checkInUse(long date, int time, int id, String ltype, String user, Connection con)
         throws Exception {


   PreparedStatement pstmt = null;
   ResultSet rs = null;

   int in_use = 0;
   int found = 0;
   int length = 0;
   int etime = 0;

   boolean ok = true;

   try {

      if (user.startsWith( "proshop" )) {      // if proshop

         //
         //  Proshop user - do all day
         //
         pstmt = con.prepareStatement (
            "SELECT in_use " +
            "FROM lessonbook5 WHERE proid = ? AND date = ? AND time = ?");    // check this specific time

         pstmt.clearParameters();        // clear the parms
         pstmt.setInt(1, id);
         pstmt.setLong(2, date);         // put the parm in pstmt
         pstmt.setInt(3, time);
         rs = pstmt.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            in_use = rs.getInt(1);
         }

         pstmt.close();

         if (in_use == 0) {              // if time Lesson NOT already in use - set it now (all day)

            pstmt = con.prepareStatement (
               "UPDATE lessonbook5 SET in_use = 1 WHERE proid = ? AND date = ?");

            pstmt.clearParameters();          // clear the parms
            pstmt.setInt(1, id);
            pstmt.setLong(2, date);
            pstmt.executeUpdate();            // execute the prepared stmt

            pstmt.close();
         }

      } else {     // Members - just do the lesson time(s)

         //
         //  First we need to determine how many time slots to check/set (based on lesson type)
         //
         pstmt = con.prepareStatement (
                 "SELECT length FROM lessontype5 WHERE proid = ? AND ltname = ?");

         pstmt.clearParameters();        // clear the parms
         pstmt.setInt(1, id);
         pstmt.setString(2, ltype);
         rs = pstmt.executeQuery();      // execute the prepared pstmt

         if (rs.next()) {

            length = rs.getInt(1);
         }
         pstmt.close();

         //
         //  Now determine end time
         //
         etime = getEndTime(time, length);   // get end of lesson time

         ok = true;           // init flag

         //
         //  Check each time slot
         //
         pstmt = con.prepareStatement (
            "SELECT in_use " +
            "FROM lessonbook5 WHERE proid = ? AND date = ? AND time >= ? AND time < ?");

         pstmt.clearParameters();     
         pstmt.setInt(1, id);
         pstmt.setLong(2, date);       
         pstmt.setInt(3, time);
         pstmt.setInt(4, etime);
         rs = pstmt.executeQuery();   

         while (rs.next()) {

            in_use = rs.getInt(1);
              
            if (in_use > 0) {             // if busy
              
               ok = false;
            }
         }
         pstmt.close();

         if (ok == true) {              // if time Lesson NOT already in use - set it now

            pstmt = con.prepareStatement (
               "UPDATE lessonbook5 SET in_use = 1 WHERE proid = ? AND date = ? AND time >= ? AND time < ?");

            pstmt.clearParameters();          // clear the parms
            pstmt.setInt(1, id);
            pstmt.setLong(2, date);
            pstmt.setInt(3, time);
            pstmt.setInt(4, etime);
            pstmt.executeUpdate();            // execute the prepared stmt

            pstmt.close();

            in_use = 0;                       // return 'Good' value

         } else {

            in_use = 1;                       // return 'Busy' value
         }
      }
   }
   catch (Exception e) {

      throw new UnavailableException("Error checking in-use - verifyLesson.checkInUse " + e.getMessage());
   }

   return(in_use);
 }


 // *********************************************************
 //  determine time value for lesson length
 // *********************************************************

 private static int getEndTime(int time, int ltlength) {


   int hr = 0;
   int min = 0;

   //
   //  add the length field to the time field
   //
   hr = time / 100;            // get hr
   min = time - (hr * 100);    // get minute

   min += ltlength;            // add length to minutes

   if (min > 59) {             // if exceeded next hour

      hr++;                    // get next hour (most likely won't exceed midnight)
      min -= 60;               // adjust minute
   }

   time = (hr * 100) + min;    // get new time

   return(time);

 }   // end of getEndTime

}  // end of verifyLesson class

