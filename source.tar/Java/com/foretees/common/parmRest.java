/***************************************************************************************
 *   parmRest:  This class will define a parameter block object to be used for Restriction Parms.
 *
 *
 *   called by:  Member_sheet
 *
 *   created: 8/02/2004   Bob P.
 *
 *   last updated:
 *              
 *              04-16-2007  Increased MAX and arrays from 40 to 60
 *
 *
 ***************************************************************************************
 */

package com.foretees.common;


public class parmRest {

   //
   //  parms to identify the user and tee sheet for each request
   //
   public String user = "";
   public String mship = "";
   public String mtype = "";
   public String course = "";
   public String day = "";
   public long date = 0;
   public int MAX = 60;                // max number of entries

   //
   //  Arrays to hold the Restrictions for the member displaying the tee sheet (allow up to 40)
   //
   public String [] courseName = new String [60];
   public String [] color = new String [60];
   public String [] fb = new String [60];
   public int [] stime = new int [60];
   public int [] etime = new int [60];

}  // end of class
