/***************************************************************************************     
 *   Proshop_runroster:  This is a temp servlet used to force the roster sync to run.
 *
 *         ************* ONLY used to force the roster sync to run ***************
 *
 *   called by:  proshop_runroster.htm
 *
 *   created: 5/26/2006   Bob P.
 *
 *
 ***************************************************************************************
 */
   
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

public class Proshop_runroster extends HttpServlet {
                      

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //*****************************************************
 // Process the initial request from proshop_runroster.htm
 //*****************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           

   resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
   resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
   resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();


   HttpSession session = SystemUtils.verifyPro(req, out);             // check for intruder

   if (session == null) {
     
      return;
   }

   try{

      Common_sync.rosterSync();       // call method to check for rosters

   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("Roster Sync Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H1>Error Calling Roster Sync</H1>");
      out.println("<BR><BR>Error = " + e1.getMessage());
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   out.println(SystemUtils.HeadTitle("Roster Sync Complete"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><BR><H1>Roster Sync Has Been Executed</H1>");
   out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
   out.println("</CENTER></BODY></HTML>");

 }  // end of doGet

}
