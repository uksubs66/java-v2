/***************************************************************************************     
 *   Unsubscribe.java:  This servlet will provide members with quick management of their
 * 				email preferences via links in outgoing emails.
 *
 *
 *
 *   called by:  External Links
 *
 ***************************************************************************************
 */
    
import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.foretees.common.StringEncrypter;

public class Unsubscribe extends HttpServlet {
                           

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

     // demov4 = FeZo4zBkuvE=
     
     
    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    
    String clubName = "";
    String decryptedClub = "";
    String encryptedClub = req.getParameter("club");
    
    if (encryptedClub == null) {
        out.println("Missing club name. [1]");
    }

    encryptedClub = encryptedClub.trim();

    if (encryptedClub.equals("")) {
        out.println("Empty club name. [2]");
    }

    if (req.getParameter("crypt") != null) {

        String encryptedString = "";
        
        try {

            StringEncrypter encrypter = new StringEncrypter( StringEncrypter.DES_ENCRYPTION_SCHEME, StringEncrypter.DEFAULT_ENCRYPTION_KEY );
            encryptedString = encrypter.encrypt( encryptedClub );

            out.println(encryptedClub + "=" + encryptedString);
            
        } catch (Exception e) {
            out.println("ERROR1: " + e.getMessage() );
        }
        
        out.println("<br>");
        
        try {

            StringEncrypter encrypter = new StringEncrypter( StringEncrypter.DES_ENCRYPTION_SCHEME, StringEncrypter.DEFAULT_ENCRYPTION_KEY );
            String decryptedString = encrypter.decrypt( encryptedString );

            out.println(encryptedString + "=" + decryptedString);
            
        } catch (Exception e) {
            out.println("ERROR2: " + e.getMessage() );
        }
        
    }

    if (!encryptedClub.equals("")) {
        
        try {

            StringEncrypter encrypter = new StringEncrypter( StringEncrypter.DES_ENCRYPTION_SCHEME, StringEncrypter.DEFAULT_ENCRYPTION_KEY );
            decryptedClub = encrypter.decrypt( encryptedClub );
            
        } catch (Exception e) {
            out.println("ERROR3: " + e.getMessage() );
        }
            
        try {
            
            con = dbConn.Connect(decryptedClub);
            stmt = con.createStatement();              // create a statement
            rs = stmt.executeQuery("SELECT clubName FROM club5");
            if (rs.next()) clubName = rs.getString(1);
            stmt.close();
            
        } catch (Exception e) {
            out.println("ERROR4: " + e.getMessage() );
        }

        out.println("<p>" + clubName + "</p>");
        
        
        
        if (req.getParameter("memNum") != null && req.getParameter("email") != null) {
            
            String memNum = req.getParameter("memNum");
            String email = req.getParameter("email");
            int i = 0;
            int emailOpt = 0;
            String email1 = "";
            String email2 = "";
            String fullName = "";
            
            try {
                
                PreparedStatement pstmt = con.prepareStatement("SELECT emailOpt, email, email2, CONCAT(name_first, ' ', name_last) AS fullName FROM member2b WHERE memNum = ? AND (email = ? OR email2 = ?);");
                pstmt.clearParameters();
                pstmt.setString(1, memNum);
                pstmt.setString(2, email);
                pstmt.setString(3, email);
                rs = pstmt.executeQuery();

                while (rs.next()) {
                    
                    emailOpt = rs.getInt("emailOpt");
                    email1 = rs.getString("email");
                    email2 = rs.getString("email2");
                    fullName = rs.getString("fullName");
                    
                    i++;
                }
            
                pstmt.close();
                
            } catch (Exception e) {
                out.println("ERROR5: " + e.getMessage() );
            }
            
            // make sure there is only 1 matching member, or reject it
            if (i > 1) {
                
                out.println("<p>Unable to isolate your member record.</p>");
                out.close();
                return;
            }
            
            out.println("<form>");
            out.println("<input type=hidden name=process value=yes>");
            out.println("<table>");
//            out.println("<tr>");
//                out.println("<td>Member Name: </td><td>" + fullName + "</td>");
//            out.println("</tr>");
            out.println("<tr>");
                out.println("<td>Receive Notifications: </td><td><select name=emailOpt1 size=1><option value=0" + ((emailOpt == 0) ? " selected" : "") + ">No<option value=1" + ((emailOpt == 1) ? " selected" : "") + ">Yes</select></td>");
            out.println("</tr>");
            out.println("<tr>");
                out.println("<td>Email Address #1: </td><td><input type=text name=email1 value=\"" + email1 + "\" size=48></td>");
            out.println("</tr>");
            out.println("<tr>");
                out.println("<td>Email Address #2: </td><td><input type=text name=email2 value=\"" + email2 + "\" size=48></td>");
            out.println("</tr>");
            out.println("<tr><td align=center colspan=2><input type=submit value='Update'></td></tr>");
            out.println("</form>");
            
        } else {
            

            out.println("<form method=get>");
            out.println("<br>Please enter your member number:");
            out.println("<input type=text name=memNum value=''>");
            out.println("<br>Please enter your email address:");
            out.println("<input type=text name=email value=''>");
            out.println("<input type=hidden name=club value='" + encryptedClub + "'>");
            //out.println("<input type=hidden name=club2 value='" + decryptedClub + "'>");
            out.println("<br><input type=submit value='Lookup'>");
            out.println("</form>");
        
        }
    }

 }

}