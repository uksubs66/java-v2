/***************************************************************************************
 *   Member_services:  This servlet will process the 'change password' request from
 *                     Member's services page.
 *
 *
 *   called by:  member_main.htm
 *
 *   created: 12/05/2001   Bob P.
 *
 *   last updated:      ******* keep this accurate *******
 *
 *        4/10/08   Dorset FC - allow them to change email addresses.  They use MF but not Roster Sync.
 *        2/10/08   Remove AGT referrences - not used.
 *        2/10/08   Marbella - do not allow members to change their mode of trans (case 1380).       
 *        9/12/07   Make sure CE clubs use roster sync.
 *        9/07/07   Do not allow AMY CE roster sync clubs to change their emails.
 *        6/26/07   Hide course hdcp box if using GHIN, provide them a link to Member_handicaps get course hdcp
 *        6/07/07   Do not allow some CE roster sync clubs to change their emails.
 *        4/04/07   Increase the password field from 10 to 15.
 *        3/25/07   Changes for hdcp - club_num & assoc_num are now strings not integers
 *        3/19/07   Changes for allowing/disallowing changing hncp values depending on hdcpSystem specified for club
 *        1/20/07   Allow for Interlachen Spa users - do not allow them to change all options.
 *       10/20/06   Allow for AGT users - do not allow them to change all options.
 *       10/09/06   Changes for email bounce indication
 *        9/23/06   Enhancements for TLT version - Add SystemLingo support
 *        7/04/06   Minor verbiage change
 *       11/04/05   Pelicans Nest - send an email to the admin whenever a member changes their email address.
 *        9/02/05   RDP - change call to isEmailValid - only pass the email address.
 *        7/07/05   MFirst - do not allow members to change their emails.
 *        6/24/05   Blackhawk - do not allow members to change their mode of trans.
 *       11/15/04   Ver 5 - Add 2nd email address and 2 phone numbers.
 *        7/14/04   Do not show handicaps for Old Oaks.
 *        2/06/04   Add support for configurable transportation modes.
 *        1/13/04   JAG Modifications to match the new color scheme
 *        7/18/03   Enhancements for Version 3 of the software.
 *       10/04/02   Added handicaps to parms that can be updated.
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;                
import java.sql.*;

// foretees imports
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.FeedBack;
import com.foretees.member.Member;
import com.foretees.member.MemberHelper;
import com.foretees.common.parmEmail;
import com.foretees.common.sendEmail;
import com.foretees.client.SystemLingo;


public class Member_services extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 //
 // Process the initial call from member_main.htm
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Connection con = null;                 // init DB objects
   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyMem(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   //
   //  get the club name
   //
   String user = (String)session.getAttribute("user");   // get username
   String club = (String)session.getAttribute("club");      // get club name
   String caller = (String)session.getAttribute("caller");   // get caller's name

   con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   String email = "";
   String email2 = "";
   String wc = "";         // trans mode name
   String wca = "";        // trans mode acronym
   String phone1 = "";
   String phone2 = "";
   String owc = "";
   String course = "";
   String ghin = "";

   int rsync = 0;
   int emailOpt = 0;
   int email_bounced = 0;
   int email2_bounced = 0;

   float c_hancap = 0;
   float g_hancap = 0;


   Statement stmtc = null;

   //
   //  parm block to hold the course parameters
   //
   parmCourse parmc = new parmCourse();          // allocate a parm block

   //
   // check which (if any) handicap system is used for this club
   //
   String hdcpSystem = "";
   String club_num = "";
   String club_assoc = "";
   
   try {

       Statement stmt = con.createStatement();
       rs = stmt.executeQuery("SELECT hdcpSystem, rsync FROM club5;");
       if (rs.next()) {
           hdcpSystem = rs.getString("hdcpSystem");
           rsync = rs.getInt("rsync");
       }
    
   } catch (Exception exc) {
        
       SystemUtils.buildDatabaseErrMsg("Error loading up club information.", exc.getMessage(), out, false);
       return;
   }
   
   if (!club.equals( "interlachenspa" )) {  // skip if Interlachen Spa

      try {
         //
         //  Get the walk/cart options available for this club
         //
         getParms.getCourse(con, parmc, course);    // course not used yet

      }
      catch (Exception e1) {

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 1</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Error: " + e1.getMessage());
         out.println("<BR><BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your club manager.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
   }

   //
   //  See if we are in timeless tees mode
   //
   int tmp_tlt = (Integer)session.getAttribute("tlt");
   boolean IS_TLT = (tmp_tlt == 1) ? true : false;
    
   // setup our custom sytem text veriables
   SystemLingo sysLingo = new SystemLingo();
   sysLingo.setLingo(IS_TLT);
   
   //
   //  Get the current info for this user
   //
   try {

      PreparedStatement stmt = con.prepareStatement (
              "SELECT " +
                  "m.email, m.c_hancap, m.g_hancap, m.wc, m.emailOpt, m.ghin, m.email2, m.phone1, m.phone2, m.email_bounced, m.email2_bounced, " +
                  "cn.club_num, ca.assoc_num " +
              "FROM member2b m " +
              "LEFT OUTER JOIN hdcp_club_num cn ON cn.hdcp_club_num_id = m.hdcp_club_num_id " +
              "LEFT OUTER JOIN hdcp_assoc_num ca ON ca.hdcp_assoc_num_id = m.hdcp_assoc_num_id " +
              "WHERE m.username = ?");

      stmt.clearParameters();            // clear the parms
      stmt.setString(1, user);           // put username in statement
      rs = stmt.executeQuery();          // execute the prepared stmt

      if (rs.next()) {

         email = rs.getString("email");
         c_hancap = rs.getFloat("c_hancap");
         g_hancap = rs.getFloat("g_hancap");
         wca = rs.getString("wc");
         emailOpt = rs.getInt("emailOpt");
         ghin = rs.getString("ghin");
         email2 = rs.getString("email2");
         phone1 = rs.getString("phone1");
         phone2 = rs.getString("phone2");
         email_bounced = rs.getInt("email_bounced");
         email2_bounced = rs.getInt("email2_bounced");
         club_num = rs.getString("club_num");
         club_assoc = rs.getString("assoc_num");
      }
      stmt.close();

   }
   catch (Exception exc) {             // SQL Error

      out.println(SystemUtils.HeadTitle("DB Access Error"));
      out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
      out.println("<BR><BR><H2>Database Access Error 2</H2>");
      out.println("<BR><BR>Unable to process database change at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;

   }

   int i = 0;
     
   if (!club.equals( "interlachenspa" )) {  // skip if Interlachen Spa

      //
      //  if Piedmont Driving Club, remove 2 trans modes that are for events only
      //
      if (club.equals( "piedmont" )) {

         for (i = 0; i < parmc.tmode_limit; i++) {

            if (parmc.tmodea[i].equalsIgnoreCase( "cfc" ) || parmc.tmodea[i].equalsIgnoreCase( "wwc" )) {

               parmc.tmodea[i] = "";      // remove it
            }
         }
      }

      //
      //  Make sure the user's c/w option is still supported (pro may have changed config)
      //
      i = 0;
      loopi1:
      while (i < parmc.tmode_limit) {

         if (parmc.tmodea[i].equals( wca )) {

            wc = parmc.tmode[i];
            break loopi1;
         }
         i++;
      }
      if (i > parmc.tmode_limit-1) {       // if we went all the way without a match

         wca = parmc.tmodea[0];    // default to first option
         wc = parmc.tmode[0];
      }

      owc = wc;      // save the wc option
      i = 0;
   }

   //
   //  output a html page to prompt user for changes - wait for doPost entry
   //
   out.println(SystemUtils.HeadTitle2("Member Services"));
      out.println("<script>");
      out.println("<!--");
      if (caller.equals( "none" )) out.println("function cursor(){document.f.oldpw.focus();}");
      out.println("function resetBounceFlags(){" +
              " var frm = document.forms['f'];" +
              " frm.resetBounceFlags.value = '1';" +
              " frm.submit();" +
              "}");
      
      out.println("// -->");
      out.println("</script>");
   out.println("</head>");

   out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\" onLoad=cursor()>");
   SystemUtils.getMemberSubMenu(req, out, caller);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
   out.println("<CENTER>");

      out.println("<form action=\"/" +rev+ "/servlet/Member_services\" method=\"post\" target=\"bot\" name=\"f\" id=\"f\">");
         out.println("<input type=\"hidden\" name=\"resetBounceFlags\" value=\"0\">");

         out.println("<table align=\"center\" border=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"10\"><tr>");
         out.println("<td align=\"center\" bgcolor=\"#336633\"><font color=\"ffffff\" size=\"2\">");

         out.println("Use this page to change your personal settings.");
         out.println("<br>Only change the fields you want to update.");
         out.println("<br>Click on 'Submit' to process the change.</font></td>");
         out.println("</tr>");

         if (caller.equals( "none" )) {   // if user did not come from MemFirst or other web site
            out.println("<tr><td>");
            out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<p>Current Password:&nbsp;&nbsp;");
            out.println("<input type=\"password\" name=\"oldpw\" id=\"oldpw\" size=\"15\" maxlength=\"15\">");
            out.println("&nbsp;&nbsp;&nbsp;&nbsp;Only enter password information if you wish to change it.<p>");
            out.println("<p>&nbsp;&nbsp;&nbsp;&nbsp;New Password:&nbsp;&nbsp;<input type=\"password\" name=\"newpw\" size=\"15\" maxlength=\"15\">");
            out.println("&nbsp;&nbsp;&nbsp;(4 - 15 characters)</p>");
            out.println("<p>Confirm New Password:&nbsp;&nbsp;<input type=\"password\" name=\"newpwc\" size=\"15\" maxlength=\"15\"></p>");
            out.println("</font></td></tr>");
         }

         out.println("<tr><td><font size=\"2\">");

         if ((caller.equals( "MEMFIRST" ) || (caller.equals( "CLUBESSENTIAL" ) && rsync == 1)) && !club.equals("dorsetfc")) {   // if user came from MemFirst or CE - no email address changes

            out.println("<p>&nbsp;&nbsp;&nbsp;Email Addresses:&nbsp;&nbsp;");
            
            if (email.equals("") && email2.equals("")) {
                
                out.println("<i>None</i>");
            } else {
                
                out.println("Primary = " +
                        "" + ((email_bounced!=0) ? "<font color=red>" : "") + "<i>" +email+ "</i>" + ((email_bounced!=0) ? " *</font>" : ""));
                out.println("&nbsp;&nbsp;Secondary = " +
                        "" + ((email2_bounced!=0) ? "<font color=red>" : "") + "<i>" +email2+ "</i>" + ((email2_bounced!=0) ? " *</font>" : ""));
                if (email_bounced != 0 || email2_bounced != 0) 
                    out.println("<br><br>&nbsp;&nbsp;&nbsp;<b>Note:</b> The address above in red with an * after it has recently failed " +
                                "and needs to be corrected<br>&nbsp;&nbsp;&nbsp;before we attempt to send you further emails.  If the email address " +
                                "is correct, then <a href=\"javascript:resetBounceFlags()\">click here</a> to reset your" +
                                "<br>&nbsp;&nbsp;&nbsp;email bounce indicator.</i>");
            }
            
            out.println("<br><br>&nbsp;&nbsp;&nbsp;To add or change your email addresses, please refer to your club's web site.");
            out.println("<br>&nbsp;&nbsp;&nbsp;ForeTees will use the email addresses from your account on that site.");
            
            out.println("</p>");
            out.println("<input type=\"hidden\" name=\"email\" value=\"" + email + "\">");
            out.println("<input type=\"hidden\" name=\"old_email\" value=\"" + email + "\">");
            out.println("<input type=\"hidden\" name=\"email2\" value=\"" + email2 + "\">");
            out.println("<input type=\"hidden\" name=\"old_email2\" value=\"" + email2 + "\">");

         } else {
             
            out.println("<p>&nbsp;&nbsp;&nbsp;Email Addresses:&nbsp;&nbsp;Primary&nbsp;");
            out.println("<input type=\"text\" name=\"email\" size=\"28\" maxlength=\"50\" value=\"" + email +"\"" + ((email_bounced!=0) ? " style=\"background-color: red\"" : "") + ">");
            out.println("<input type=\"hidden\" name=\"old_email\" value=\"" + email + "\">");
            out.println("&nbsp;&nbsp;Secondary&nbsp;");
            out.println("<input type=\"text\" name=\"email2\" size=\"28\" maxlength=\"50\" value=\"" + email2 +"\"" + ((email2_bounced!=0) ? " style=\"background-color: red\"" : "") + ">");
            out.println("<input type=\"hidden\" name=\"old_email2\" value=\"" + email2 + "\">");
            out.println("</p>");
            if (email_bounced != 0 || email2_bounced != 0) 
                out.println("&nbsp;&nbsp;&nbsp;<b>Important!</b> &nbsp;<i>The address above in red has recently failed and needs to be " +
                            "corrected before we attempt<br>&nbsp;&nbsp;&nbsp;to use it to send you further communications.  If the email address " +
                        "is correct, then <a href=\"javascript:resetBounceFlags()\">click here</a> to reset your" +
                        "<br>&nbsp;&nbsp;&nbsp;email bounce indicator.</i>");
            
         }

         if (email.equals("") && email2.equals("")) {
             
             out.println("<input type=hidden name=emailOpt value=No>");
         } else {
             
             out.println("<p>&nbsp;&nbsp;&nbsp;Do you wish to receive email alerts ");
             if (club.equals( "interlachenspa" )) {
                out.println("of your schedule changes?&nbsp;&nbsp;");    // Spa users
             } else {
                out.println("of your " + sysLingo.TEXT_tee_times + "?&nbsp;&nbsp;");
             }
             out.println("<select size=\"1\" name=\"emailOpt\">");
              out.println("<option" + ((emailOpt == 1) ? " selected" : "") + ">Yes</option>");
              out.println("<option" + ((emailOpt != 1) ? " selected" : "") + ">No</option>");
             out.println("</select></p>");
         }
         out.println("</font></td></tr>");

         if (!club.equals( "blackhawk" ) && !club.equals( "marbellacc" ) && !club.equals( "interlachenspa" )) {  // skip if Blackhawk CC or Marbella

            out.println("<tr><td><font size=\"2\">");
            out.println("<p>&nbsp;&nbsp;&nbsp;Default Mode of Transportation Preference:&nbsp;&nbsp;");
              out.println("<select size=\"1\" name=\"walk_cart\">");

              for (i=0; i<16; i++) {        // get all c/w options

                 if (!parmc.tmodea[i].equals( "" )) {
                    if (wca.equals( parmc.tmodea[i] )) {
                       out.println("<option selected value=" + wca + ">" + wc + "</option>");
                    } else {
                       out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmode[i]+ "</option>");
                    }
                 }
              }
              out.println("</select></p>");
            out.println("</font></td></tr>");
         }

         out.println("<tr><td><font size=\"2\">");
         out.println("<p>&nbsp;&nbsp;&nbsp;Phone Numbers:&nbsp;&nbsp;Primary&nbsp;");
         out.println("<input type=\"text\" name=\"phone1\" size=\"14\" maxlength=\"24\" value=\"" +phone1+"\">");
           
         out.println("&nbsp;&nbsp;&nbsp;&nbsp;Alternate&nbsp;");
         out.println("<input type=\"text\" name=\"phone2\" size=\"14\" maxlength=\"24\" value=\"" +phone2+"\">");
         out.println("</p></font></td></tr>");


         if (!club.equals( "oldoaks" ) && !club.equals( "interlachenspa" )) {  // skip if Old Oaks or Spa
            
            boolean tmp_allow = true;
            String tmp_hdcp = "";
            
            if (hdcpSystem.equalsIgnoreCase("ghin")) tmp_allow = false;
             
            out.println("<tr><td>");
               out.println("<font size=\"2\">");
               out.println("<p>&nbsp;&nbsp;&nbsp;Handicaps:");
               
               if (!hdcpSystem.equalsIgnoreCase( "ghin" )) {
                                  
                   out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Course&nbsp;&nbsp;");

                   if (c_hancap > 0) {
                       tmp_hdcp = "+" + c_hancap;
                   } else {
                       if (c_hancap <= 0) {
                           c_hancap = 0 - c_hancap;                       // convert to non-negative
                       }
                       tmp_hdcp = "" + c_hancap;
                   }

                   if (hdcpSystem.equalsIgnoreCase( "Other" )) {
                       out.println("<input type=\"text\" name=\"c_hancap\" value=\"" + tmp_hdcp + "\" size=\"6\" maxlength=\"6\">");
                   } else {
                       out.println("<b>" + tmp_hdcp + "</b>");
                   }
               }
               out.println(" &nbsp;&nbsp;&nbsp;&nbsp;USGA&nbsp;&nbsp;");
               tmp_hdcp = "";
               if (g_hancap > 0) {
                   tmp_hdcp = "+" + g_hancap;
               } else {
                   if (g_hancap <= 0) {
                       g_hancap = 0 - g_hancap;                       // convert to non-negative
                   }
                   tmp_hdcp = "" + g_hancap;
               }
                   
               if (hdcpSystem.equalsIgnoreCase( "Other" )) {
                   out.println("<input type=\"text\" name=\"g_hancap\" value=\"" + tmp_hdcp + "\" size=\"6\" maxlength=\"6\">");
               } else {
                   out.println("<b>" + tmp_hdcp + "</b>");
               }
               
               /*
               if (g_hancap == -99) {
                  out.println("<input type=\"text\" name=\"g_hancap\" size=\"6\" maxlength=\"6\" " + tmp_allow + ">");
               } else {
                  if (g_hancap > 0) {
                     out.println("<input type=\"text\" name=\"g_hancap\" value=\"+" + g_hancap + "\" size=\"6\" maxlength=\"6\" " + tmp_allow + ">");
                  } else {
                     if (g_hancap <= 0) {
                        g_hancap = 0 - g_hancap;                       // convert to non-negative
                     }
                     out.println("<input type=\"text\" name=\"g_hancap\" value=\"" + g_hancap + "\" size=\"6\" maxlength=\"6\" " + tmp_allow + ">");
                  }
               }
               */
                              
               if (hdcpSystem.equalsIgnoreCase( "ghin" )) {
                   
                   out.println("&nbsp; &nbsp; &nbsp; &nbsp;<a href=\"/" + rev + "/servlet/Member_handicaps?todo=view\">Click here to see your course handicap.</a><br>");
               }
               
               if (!ghin.equals( "" )) {            // if ghin # provided, display it (do not allow them to change it)
                  
                  out.println("<br>&nbsp;&nbsp;&nbsp;Your Handicap # is: <b>" +ghin+ "</b>");
                  out.println("<br><br>&nbsp;&nbsp;&nbsp;Assigned Club Number: <b>" + club_num + "</b>");
                  out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Assigned Club Association Number: <b>" + club_assoc + "</b>");
               }
               
               out.println("</p>");
            out.println("</font></td>");
            out.println("</tr>");
         }
      out.println("</table>");                  // end of main page table

      out.println("<input type=\"hidden\" name=\"old_wc\" value=\"" + owc + "\">");
      out.println("<br>");
      out.println("<input type=\"submit\" value=\"Submit\">");

      out.println("</form>");

   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Member_announce\">");
   out.println("<input type=\"submit\" value=\"Cancel\" style=\"text-decoration:underline;\">");
   out.println("</input></form></font>");

   out.println("</center></font></body></html>");

 }


 //
 //******************************************************************************
 // Process the form request from member_services.htm (built by doGet above)
 //******************************************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Connection con = null;                 // init DB objects
   ResultSet rs = null;

   Member member = new Member();

   HttpSession session = SystemUtils.verifyMem(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   int count = 0;
   int emailOpt = 0;
   int length = 0;

   String user = (String)session.getAttribute("user");   // get username
   String club = (String)session.getAttribute("club");      // get club name
   String caller = (String)session.getAttribute("caller");   // get caller's name
     
   String wc = "";
   String old_wc = "";
   String scourse = "";       // course hndcp
   String susga = "";         // usga hndcp

   float course = -99;     // default hndcp's
   float usga = -99;


   //
   // Get all parameters entered
   //
   String email = req.getParameter("email");
   String email2 = req.getParameter("email2");
   String old_email = req.getParameter("old_email");
   String old_email2 = req.getParameter("old_email2");
   String semailOpt = req.getParameter("emailOpt");      // email option
   String phone1 = req.getParameter("phone1");
   String phone2 = req.getParameter("phone2");
   String sresetBounceFlags = req.getParameter("resetBounceFlags");
   boolean resetBounceFlags = (sresetBounceFlags.equals("1"));
   
   String curr_password = "";
   String old_password = "";
   String new_password = "";
   String conf_password = "";

   if (req.getParameter("walk_cart") != null) {         // if parm specified

      wc = req.getParameter("walk_cart");                  // walk/cart preference
   }

   if (req.getParameter("old_wc") != null) {         // if parm specified

      old_wc = req.getParameter("old_wc");                 // old walk/cart preference
   }

   if (req.getParameter("oldpw") != null) {         // if old pw specified, then process newpw

      old_password = req.getParameter("oldpw");
      new_password = req.getParameter("newpw");
      conf_password = req.getParameter("newpwc");
   }

   if (req.getParameter("c_hancap") != null) {      

      scourse = req.getParameter("c_hancap");       // course hndcp
   }
   if (req.getParameter("g_hancap") != null) {

      susga = req.getParameter("g_hancap");         // usga hndcp
   }

   //
   //  convert numeric fields
   //
   if (!scourse.equals("")) {

      if ((scourse.startsWith("+")) || (scourse.startsWith("-"))) {

         length = scourse.length();       // get length of parm value

         if (length < 2) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error</H2>");
            out.println("<BR><BR>The data you entered is incorrect.");
            out.println("<BR>The handicap must contain a numeric value.");
            out.println("<BR>The '+' or '-' must be followed be a number value.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</input></form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      try {

         course = Float.parseFloat(scourse);               // course handicap

      }
      catch (Exception exc) {             // SQL Error

            out.println(SystemUtils.HeadTitle("DB Access Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error 2</H2>");
            out.println("<BR><BR>Handicap entry is invalid.");
            out.println("<BR>The handicap must contain a numeric value.");
            out.println("<BR>The '+' or '-' must be followed be a number value.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
            out.println("</CENTER></BODY></HTML>");
            return;
      }

      if ((!scourse.startsWith("+")) && (!scourse.startsWith("-"))) {

         course = 0 - course;                    // make it a negative hndcp (normal)
      }
   }

   if (!susga.equals("")) {

      if ((susga.startsWith("+")) || (susga.startsWith("-"))) {

         length = susga.length();       // get length of parm value

         if (length < 2) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error</H2>");
            out.println("<BR><BR>The data you entered is incorrect.");
            out.println("<BR>The handicap must contain a numeric value.");
            out.println("<BR>The '+' or '-' must be followed be a number value.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</input></form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      try {

         usga = Float.parseFloat(susga);                   // usga handicap

      }
      catch (Exception exc) {             // SQL Error

            out.println(SystemUtils.HeadTitle("DB Access Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error 2</H2>");
            out.println("<BR><BR>Handicap entry is invalid.");
            out.println("<BR>The handicap must contain a numeric value.");
            out.println("<BR>The '+' or '-' must be followed be a number value.");
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
            out.println("</CENTER></BODY></HTML>");
            return;
      }

      if ((!susga.startsWith("+")) && (!susga.startsWith("-"))) {

         usga = 0 - usga;                       // make it a negative hndcp (normal)
      }
   }

   if (semailOpt.equals( "Yes" )) {

      emailOpt = 1;

   } else {

      emailOpt = 0;
   }

   if (!club.startsWith( "demov" )) {        // do not change emailOpt if demo site

      try {

         PreparedStatement stmte = con.prepareStatement (
               "UPDATE member2b SET emailOpt = ? WHERE username = ?");

         stmte.clearParameters();            // clear the parms
         stmte.setInt(1, emailOpt);
         stmte.setString(2, user);           // put username in statement
         count = stmte.executeUpdate();  // execute the prepared stmte

         stmte.close();

      }
      catch (Exception exc) {             // SQL Error

            out.println(SystemUtils.HeadTitle("DB Access Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Database Access Error 2</H2>");
            out.println("<BR><BR>Unable to process database change at this time.");
            out.println("<BR>Exception: "+ exc.getMessage());
            out.println("<BR>Please try again later.");
            out.println("<BR><BR>If problem persists, contact your club manager.");
            out.println("<BR><BR>");
            out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
            out.println("</CENTER></BODY></HTML>");
            return;
      }
   }      // end of if demo site


   int pw_length = new_password.length();               // length of new password

   if (pw_length != 0) {

      try {

         PreparedStatement stmt = con.prepareStatement (
                  "SELECT password FROM member2b WHERE username = ?");   // get member's pw...

         stmt.clearParameters();            // clear the parms
         stmt.setString(1, user);           // put username in statement
         rs = stmt.executeQuery();          // execute the prepared stmt

         if (rs.next()) {

            curr_password = rs.getString("password");
         }
         stmt.close();

      }
      catch (Exception exc) {             // SQL Error

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 1</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your system administrator.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }

      //
      // Verify the passwords
      //
      if ((old_password.equalsIgnoreCase( curr_password )) && (new_password.equalsIgnoreCase(conf_password)) &&
          (pw_length > 3) && (pw_length < 16)) {


         if (!club.startsWith( "demov" )) {        // do not change pw if demo site

            try {

               PreparedStatement stmt = con.prepareStatement (
                     "UPDATE member2b SET password = ? WHERE username = ?");

               // Set member's new pw

               stmt.clearParameters();            // clear the parms
               stmt.setString(1, new_password);   // put the password in statement
               stmt.setString(2, user);           // put username in statement
               count = stmt.executeUpdate();  // execute the prepared stmt

               stmt.close();

            }
            catch (Exception exc) {             // SQL Error

                  out.println(SystemUtils.HeadTitle("DB Access Error"));
                  out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
                  out.println("<BR><BR><H2>Database Access Error 2</H2>");
                  out.println("<BR><BR>Unable to process database change at this time.");
                  out.println("<BR>Exception: "+ exc.getMessage());
                  out.println("<BR>Please try again later.");
                  out.println("<BR><BR>If problem persists, contact your club manager.");
                  out.println("<BR><BR>");
                  out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
                  out.println("</CENTER></BODY></HTML>");
                  return;
            }
         }      // end of if demo site

      } else {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Data Entry Error</H2>");
         out.println("<BR><BR>The data you entered is incorrect.");
         out.println("<BR>The Current Password must equal the Password that you logged in with.");
         out.println("<BR>The New Password must be at least 4 characters but no more than 15 characters.");
         out.println("<BR>Avoid special characters as some are not accepted.");
         out.println("<BR><BR>Please try again.");
         out.println("<BR>If problem persists, please contact your club manager.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
         out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
         out.println("</input></form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }
   }

   if (resetBounceFlags || !email.equalsIgnoreCase( old_email ) || !email2.equalsIgnoreCase( old_email2 )) {  // if either email address has changed

      if (!email.equals( "" )) {      // if specified
        
         FeedBack feedback = (member.isEmailValid(email));
           
         if (!feedback.isPositive()) {    // if error

            String emailError = feedback.get(0);             // get error message 

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error</H2>");
            out.println("<BR><BR>The primary email address you entered is invalid.");
            out.println("<BR>" +emailError);
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</input></form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if (!email2.equals( "" )) {      // if specified

         FeedBack feedback = (member.isEmailValid(email2));

         if (!feedback.isPositive()) {    // if error

            String emailError = feedback.get(0);             // get error message

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
            out.println("<BR><BR><H2>Data Entry Error</H2>");
            out.println("<BR><BR>The secondary email address you entered is invalid.");
            out.println("<BR>" +emailError);
            out.println("<BR><BR>Please try again.");
            out.println("<BR>If problem persists, please contact your club manager.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
            out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
            out.println("</input></form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      
      
      try {

         String tmp_sql = "UPDATE member2b SET email = ?, email2 = ?";

         if (resetBounceFlags || email.equals( "" ) || (!email.equals( "" ) && !email.equalsIgnoreCase(old_email))) {
            tmp_sql += ", email_bounced = 0";
         }

         if (resetBounceFlags || email2.equals( "" ) || (!email2.equals( "" ) && !email2.equalsIgnoreCase(old_email2))) {
            tmp_sql += ", email2_bounced = 0";
         }

         tmp_sql += " WHERE username = ?";

         PreparedStatement pstmt4 = con.prepareStatement ( tmp_sql );
         pstmt4.clearParameters();

         pstmt4.setString(1, email);        // set email address
         pstmt4.setString(2, email2);        // set email address 2
         pstmt4.setString(3, user); 

         count = pstmt4.executeUpdate();    
         pstmt4.close();
            
        /*  old code
         PreparedStatement pstmt4 = con.prepareStatement (
               "UPDATE member2b SET email = ?, email2 = ? WHERE username = ?");

         pstmt4.clearParameters();            // clear the parms
         pstmt4.setString(1, email);
         pstmt4.setString(2, email2);
         pstmt4.setString(3, user);
         count = pstmt4.executeUpdate();          // execute the prepared pstmt4

         pstmt4.close();
        */
      }
      catch (Exception exc) {             // SQL Error

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 3</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your club administrator.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }
        
      //
      //  Email has changed - if Westchester, send an email notification to the club so they can update their records.
      //
      if (club.equals( "westchester" )) {        
  
         sendWestEmail(email, email2, user, con);
      }

      //
      //  Email has changed - if Pelicans Nest, send an email notification to the club so they can update their records.
      //
      if (club.equals( "pelicansnest" )) {

         sendPNestEmail(email, email2, user, con);
      }

   }

   if (!wc.equals( old_wc )) {       // if the w/c pref has changed

      try {

         PreparedStatement pstmt5 = con.prepareStatement (
               "UPDATE member2b SET wc = ? WHERE username = ?");

         pstmt5.clearParameters();                // clear the parms
         pstmt5.setString(1, wc);
         pstmt5.setString(2, user);
         count = pstmt5.executeUpdate();          // execute the prepared pstmt5

         pstmt5.close();

         session.setAttribute("wc", wc);          // save member's new walk/cart pref (for _slot)
      }
      catch (Exception exc) {             // SQL Error

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 3</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your club administrator.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }
   }

   if ((!phone1.equals("")) || (!phone2.equals(""))) {   // if a phone # specified

      try {

         PreparedStatement pstmt6 = con.prepareStatement (
               "UPDATE member2b SET phone1 = ?, phone2 = ? WHERE username = ?");

         pstmt6.clearParameters();                // clear the parms
         pstmt6.setString(1, phone1);
         pstmt6.setString(2, phone2);
         pstmt6.setString(3, user);
         count = pstmt6.executeUpdate();          // execute the prepared pstmt6

         pstmt6.close();

      }
      catch (Exception exc) {             // SQL Error

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 3</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your club administrator.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
   }

   if ((!susga.equals("")) && (!scourse.equals(""))) {

      try {

         PreparedStatement pstmt6 = con.prepareStatement (
               "UPDATE member2b SET c_hancap = ?, g_hancap = ? WHERE username = ?");

         pstmt6.clearParameters();                // clear the parms
         pstmt6.setFloat(1, course);
         pstmt6.setFloat(2, usga);
         pstmt6.setString(3, user);
         count = pstmt6.executeUpdate();          // execute the prepared pstmt6

         pstmt6.close();
      }
      catch (Exception exc) {             // SQL Error

         out.println(SystemUtils.HeadTitle("DB Access Error"));
         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<BR><BR><H2>Database Access Error 3</H2>");
         out.println("<BR><BR>Unable to process database change at this time.");
         out.println("<BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact your club administrator.");
         out.println("<BR><BR>");
         out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
   }

   out.println(SystemUtils.HeadTitle("Member Settings Changed"));
   out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
   out.println("<BR><BR><H3>Your Personal Settings Have Been Changed</H3>");

   if (club.startsWith( "demov" )) {        // do not change pw if demo site

      out.println("<BR>Thank you.  For demo purposes the password has not been changed.");
      out.println("<BR><BR>");
   }

   if (!new_password.equals( "" ) && !new_password.equals( old_password )) {

      if (caller.equals( "none" )) {        // if user did not come from MemFirst or other web site

         out.println("<BR><BR>You have changed your password. Be sure to use the new password next time you login.");
      } else {
         out.println("<BR><b>Notice:</b> You have changed your password.  This password is not used when you enter");
         out.println("<BR>ForeTees from your club's web site.  Refer to instructions from your club's web site for");
         out.println("<BR>changing that password.  You will only use the ForeTees password when entering");
         out.println("<BR>ForeTees directly (via the ForeTees Login Page).");
      }
   }
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Member_services\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;\">");
   out.println("</form>");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Member_announce\">");
   out.println("<input type=\"submit\" value=\"Home\" style=\"text-decoration:underline;\">");
   out.println("</form></font>");
   out.println("</CENTER></BODY></HTML>");

   //
   // Done - return.......
   //
 }

 // ************************************************************************
 //  Process custom to send an email notification for Westchester CC
 // ************************************************************************

 private void sendWestEmail(String email, String email2, String user, Connection con) {


   //
   //  allocate a parm block to hold the email parms
   //
   parmEmail parme = new parmEmail();          // allocate an Email parm block

   //
   //  Set the values in the email parm block
   //
   parme.type = "Westchester";         // type = Westchester
   parme.user = user;
   parme.player1 = email;
   parme.player2 = email2;

   //
   //  Send the email
   //
   sendEmail.sendWestEmail(parme, con);      // send an email to Westchester

 }
   
 // ************************************************************************
 //  Process custom to send an email notification for Pelicans Nest GC
 // ************************************************************************

 private void sendPNestEmail(String email, String email2, String user, Connection con) {


   //
   //  allocate a parm block to hold the email parms
   //
   parmEmail parme = new parmEmail();          // allocate an Email parm block

   //
   //  Set the values in the email parm block
   //
   parme.type = "PelicansNest";         // type 
   parme.user = user;
   parme.player1 = email;
   parme.player2 = email2;

   //
   //  Send the email
   //
   sendEmail.sendWestEmail(parme, con);      // send an email to Pelicans Nest (use same as Westchester)

 }

}
