/***************************************************************************************     
 *   Logout:  This servlet will process a logout request.
 *
 *   called by:  all to logout of system
 *
 *   created: 6/13/2002   Bob P.
 *
 *   last updated:
 *
 *        5/10/07   Added serverId to connerror output
 *        2/07/07   Return to Greeley CC login page if user is from Greeley (they share the Fort Collins db).
 *        2/06/07   Change index2.htm to index.htm to allow for new login pages.
 *        3/06/06   Remove calls to SystemUtils.sessionLog - log the event here.
 *        9/22/05   Add a login log to track all logins and logouts.
 *        1/24/05   Ver 5 - change club2 to club5.
 *        7/18/03   Enhancements for Version 3 of the software.
 *        9/18/02   Enhancements for Version 2 of the software.
 *
 *
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

public class Logout extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //*****************************************************
 // Perform doGet processing - someone is logging out
 //*****************************************************

 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           
   //
   //  Prevent caching so sessions are not mangled
   //
   resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
   resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
   resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   //
   //  Get user's session
   //
   HttpSession session = null;

   session = req.getSession(false);  // Get user's session object (no new one)

   if (session == null) {

     Connerror(out);              // go process connection error......
     return;
   }

   //
   //  Get the name of the club for user
   //
   String club = (String)session.getAttribute("club");       // get club name
   String caller = (String)session.getAttribute("caller");   // get caller's name
   String user = (String)session.getAttribute("user");       // get user
   String omit = "";
   String msg = "User Logout";
     
   if (club.equals( "" )) {
     
     Connerror(out);              // go process connection error......
     return;
   }

   //
   //  Release the connection if it exists
   //
   Connection con = null;

   //
   // Get the connection holder saved in the session object
   //
   ConnHolder holder = (ConnHolder) session.getAttribute("connect");

   if (holder != null) {

      con = holder.getConn();      // get the connection 
   }


   //
   //  If Fort Collins - check for Greeley user (must change club name for Greeley - they share).
   //
   if (club.equals( "fortcollins" )) {        // if normal foretees user
     
      if (user.startsWith( "proshop" ) || user.startsWith( "admin" ) || user.startsWith( "support" )) {    // if NOT member

         if (user.equalsIgnoreCase( "proshop4" ) || user.equalsIgnoreCase( "proshop5" )) {    // if Greeley Proshop user

            club = "greeleycc";
         }
           
      } else {        // must be member
        
         String mtype = (String)session.getAttribute("mtype");       // get mtype

         if (!mtype.equals( "" ) && mtype != null) {                 // if specified
           
            if (mtype.endsWith( "Greeley" )) {                // if Greeley member

               club = "greeleycc";
            }
         }
      }
   }

   //
   //  Exit
   //
   if (caller.equals( "none" )) {        // if normal foretees user

      //
      //  Trace all logouts
      //
      sessionLog(msg, user, omit, club, omit, con);                   // log it

      out.println("<HTML><HEAD><Title>Logout Confirmation Page</Title>");
      out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" + club + "/index.htm\" target=\"_top\">");
      out.println("</HEAD>");
      out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
      out.println("<hr width=\"40%\">");
      out.println("<p>&nbsp;</p>");
      out.println("<BR><BR><H2>Logout Processed</H2><BR>");
      out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"12\"><tr><td align=\"center\">");
      out.println("Thank you for using ForeTees.");
      out.println("</td></tr></table><br>");
      out.println("<br><br><font size=\"2\">");
      out.println("<form method=\"get\" action=\"/" + club + "/index.htm\" target=\"_top\">");
      out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</input></form></font>");
      out.println("</CENTER></BODY></HTML>");

   } else {      // caller from remote site

      //
      //  Trace all logouts
      //
      sessionLog(msg, user, omit, club, caller, con);                   // log it

      out.println("<HTML><HEAD><Title>Exit Confirmation Page</Title>");
      out.println("</HEAD>");
      out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
      out.println("<hr width=\"40%\">");
      out.println("<p>&nbsp;</p>");
      out.println("<BR><BR><H2>System Exit Processed</H2><BR>");
      out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"12\"><tr><td align=\"center\">");
      out.println("Thank you for using ForeTees.");
      out.println("<BR><BR>Click on the 'Return' button below to close this window");
      out.println("<BR>and return to your member services site.");
      out.println("</td></tr></table><br>");
      out.println("<br><br><font size=\"2\">");
      out.println("<form><input type=\"button\" value=\"RETURN\" style=\"text-decoration:underline; background:#8B8970\" onClick='self.close();'></form>");
      out.println("</font>");
      out.println("</CENTER></BODY></HTML>");
   }

   if (con != null) {

      //
      //  Adjust the number of users logged in
      //
      countLogout(con);

      try {

         con.rollback();    // abandon any unfinished transactions

         con.close();       // return/close the connection (it should already be closed!!)

      }
      catch (SQLException e) {
      }
   }

 }


 //************************************************************************
 //
 //  sessionLog - logs each time a user logs out - to a text file
 //
 //************************************************************************

 private void sessionLog(String msg, String user, String pw, String club, String caller, Connection con) {


   if (con != null) {

      //
      //   Get current month
      //
      Calendar cal = new GregorianCalendar();                      // get todays date
      int year = cal.get(Calendar.YEAR);
      int month = cal.get(Calendar.MONTH) +1;
      int daynum = cal.get(Calendar.DAY_OF_MONTH);

      long date = (year * 10000) + (month * 100) + daynum;         // date value for today

      String sdate = String.valueOf(new java.util.Date());         // get date and time string

      //
      //  Build the message
      //
      msg = msg + " User=" +user+ ", PW=" +pw+ ", Club=" +club+ ", Caller=" +caller;

      try {
        
         //
         //  Save the session message in the db table
         //
         PreparedStatement pstmt = con.prepareStatement (
              "INSERT INTO sessionlog (date, sdate, msg) " +
              "VALUES (?,?,?)");

         pstmt.clearParameters();        // clear the parms
         pstmt.setLong(1, date);
         pstmt.setString(2, sdate);
         pstmt.setString(3, msg);
         pstmt.executeUpdate();          // execute the prepared stmt

         pstmt.close();   // close the stmt

      }
      catch (Exception e) {
      }
   }

 }  // end of sessionLog


 // ***************************************************************
 //  countLogout
 //
 //      Track the number of users logged in for each club.
 //
 // ***************************************************************

 private void countLogout(Connection con) {


   Statement stmt = null;
   ResultSet rs = null;

   int count = 0;


   try {
      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT logins FROM club5");          // get # of users logged in

      if (rs.next()) {

         count = rs.getInt("logins");
      }
      stmt.close();

      //
      //  adjust the count if not already zero
      //
      if (count > 0) {
        
         count--;
      }

      PreparedStatement pstmt = con.prepareStatement (
               "UPDATE club5 SET logins = ?");                  // set new count

      pstmt.clearParameters();
      pstmt.setInt(1, count);
      pstmt.executeUpdate();

      pstmt.close();

   }
   catch (Exception ignore) {
   }
 }


 // *********************************************************
 // Connection error - inform user ....
 // *********************************************************

 private void Connerror(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Connection Error - Logout"));
   out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H2>Connection Error</H2><BR>");
   out.println("<BR>Sorry, we are unable to direct you to your point of entry at this time.<BR>");
   out.println("<BR>Either your session was lost or you never logged in to begin with.<BR>");
   out.println("<BR><BR>Server: " + Common_Server.SERVER_ID);
   out.println("</CENTER></BODY></HTML>");
     
 }

}
