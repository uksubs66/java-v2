/***************************************************************************************
 *   Support_upgrade:  This servlet will process the upgrade request from Support's Upgrade page.
 *
 *
 *       Adds a column to a db table for ALL clubs
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;


public class Support_updatedb extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)
 
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

    String support = "support";             // valid username

    HttpSession session = null;
    session = req.getSession(false);  // Get user's session object (no new one)

    if (session == null) {

        invalidUser(out);            // Intruder - reject
        return;
    }

   String userName = (String)session.getAttribute("user");   // get username
   
   if (!userName.equals( support )) {

      invalidUser(out);            // Intruder - reject
      return;
   }
   
   out.println("<HTML><HEAD><TITLE>Database Upgrade</TITLE></HEAD>");
   out.println("<BODY><CENTER><H3>WARNING: PERMENT DATABASE CHANGES PENDING!</H3>");
   out.println("<BR><BR>Click 'Run' to start the job.");
   out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A><BR><BR>");
   
   out.println("<form method=post><input type=submit value=\"Update\" onclick=\"return confirm('Are you sure?')\">");
   out.println(" <input type=hidden value=\"update\" name=\"todo\"></form>");
   
   out.println("<form method=post><input type=submit value=\"  Test  \">");
   out.println(" <input type=hidden value=\"test\" name=\"todo\"></form>");
   
   out.println("</CENTER></BODY></HTML>");
   
   out.close();
   
 }
 

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();
    //PrintWriter out = new PrintWriter(resp.getOutputStream());


    String support = "support";             // valid username

    HttpSession session = null;
    session = req.getSession(false);  // Get user's session object (no new one)
    if (session == null) {

        invalidUser(out);            // Intruder - reject
        return;
    }

   String userName = (String)session.getAttribute("user");   // get username

   if (!userName.equals( support )) {

      invalidUser(out);            // Intruder - reject
      return;
   }

   String action = "";
   if (req.getParameter("todo") != null) action = req.getParameter("todo");
   
   if (action.equals("update")) {
       
       doUpdate(out);
       return;
   }
   
   if (action.equals("test")) {
       
       doTest(out);
       return;
   }
   
   out.println("<p>Nothing to do.</p>todo="+action);
   
 }


 private void doUpdate(PrintWriter out) {
     

    Connection con1 = null;                  // init DB objects
    Connection con2 = null;
    PreparedStatement pstmt = null;
    Statement stmt1 = null;
    Statement stmt2 = null;
    Statement stmt3 = null;
    ResultSet rs1 = null;
    ResultSet rs2 = null;
    ResultSet rs3 = null;

    out.println("<HTML><HEAD><TITLE>Database Update</TITLE></HEAD>");
    out.println("<BODY><H3>Starting DB Update...</H3>");
    out.flush();

    String club = "";

    try {

        con1 = dbConn.Connect(rev);
    } catch (Exception exc) {

        // Error connecting to db....
        out.println("<BR><BR>Unable to connect to the DB.");
        out.println("<BR>Exception: "+ exc.getMessage());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        return;
    }
    
/*
    try {
    // ADD TIMESTAMP TO ERROR LOG
    //stmt2.executeUpdate("ALTER TABLE errorlog ADD err_timestamp datetime");
            
    stmt1 = con1.createStatement();
    
    // BOB ONLY!!!
    stmt1.executeUpdate("" +
        "CREATE TABLE login_stats IF NOT EXISTS ( " +                                        
            "login_stat_entry_id int(11) NOT NULL auto_increment, " +                                  
            "entry_date date, " +                                                        
            "hour tinyint(4), " +                                                        
            "node tinyint(4), " +                                                         
            "user_type_id int(11), " +                                                   
            "login_count int(11), " +                                                    
            "PRIMARY KEY (login_stat_entry_id), " +
            "UNIQUE KEY entry_date (entry_date, hour, node, user_type_id) " +
        ") ENGINE=MyISAM;");
            
            
    stmt1.executeUpdate("" +
        "CREATE TABLE user_types IF NOT EXISTS ( " +
            "user_type_id int(11) NOT NULL auto_increment, " + 
            "user_type varchar(32) NOT NULL default '', " + 
            "PRIMARY KEY (user_type_id) " + 
        ") ENGINE=MyISAM;");

    stmt1.executeUpdate("" + 
        "INSERT INTO user_types VALUES " + 
            "(1,'Member'), " + 
            "(2,'Remote'), " + 
            "(3,'Proshop'), " + 
            "(4,'Admin'), " + 
            "(5,'Support'), " + 
            "(6,'Sales');");

   }
   catch (Exception e) {

      // Error connecting to db....

      out.println("<BR><BR><H3>Fatal Error!</H3>");
      out.println("Error performing update to v5.");
      out.println("<BR>Exception: "+ e.getMessage());
      out.println("<BR>Message: "+ e.toString());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</BODY></HTML>");
      out.close();
      return;
   }
*/
    //
    // Get the club names from the 'clubs' table
    //
    //  Process each club in the table
    //
    int x1 = 0;
    int x2 = 277;
    int i = 0;
   
    boolean skip = true;
    
    try {

        stmt1 = con1.createStatement();
        rs1 = stmt1.executeQuery("SELECT clubname FROM clubs ORDER BY clubname");

        while (rs1.next()) {

            x1++; 

            club = rs1.getString(1);                // get a club name
            con2 = dbConn.Connect(club);            // get a connection to this club's db
            stmt2 = con2.createStatement();         // create a statement
            stmt3 = con2.createStatement();         // create another statement

            out.println("<br><br>");
            out.print("[" + x1 + "/" + x2 + "] Starting " + club);
            out.flush();
            
            
            
            
            stmt2.executeUpdate("ALTER TABLE events2b CHANGE gender gender tinyint NOT NULL default 0");
            
            /*
            
            stmt2.executeUpdate("ALTER TABLE club5 " +
                                 "ADD smtp_addr varchar(50) NOT NULL default '', " +
                                 "ADD smtp_port smallint NOT NULL default 25, " +
                                 "ADD smtp_auth tinyint NOT NULL default 0, " +
                                 "ADD smtp_user varchar(50) NOT NULL default '', " +
                                 "ADD smtp_pass varchar(32) NOT NULL default '', " +
                                 "ADD email_from varchar(50) NOT NULL default '', " +
                                 "ADD email_from_pro varchar(50) NOT NULL default '', " +
                                 "ADD email_from_mem varchar(50) NOT NULL default '';");
            
            stmt2.executeUpdate("ALTER TABLE member2b ADD tflag varchar(4) NOT NULL default '';");
            
            stmt2.executeUpdate("ALTER TABLE mship5 ADD tflag varchar(4) NOT NULL default '';");
            
            stmt2.executeUpdate("ALTER TABLE teecurr2 " +
                                 "ADD tflag1 varchar(9) NOT NULL default '', " +
                                 "ADD tflag2 varchar(9) NOT NULL default '', " +
                                 "ADD tflag3 varchar(9) NOT NULL default '', " +
                                 "ADD tflag4 varchar(9) NOT NULL default '', " +
                                 "ADD tflag5 varchar(9) NOT NULL default '';");
            
            stmt2.executeUpdate("ALTER TABLE guest5 ADD revenue tinyint NOT NULL default 0;");
            
            stmt2.executeUpdate("ALTER TABLE teepast2 " + 
                                 "ADD pos1 tinyint NOT NULL default 0, " + 
                                 "ADD pos2 tinyint NOT NULL default 0, " + 
                                 "ADD pos3 tinyint NOT NULL default 0, " + 
                                 "ADD pos4 tinyint NOT NULL default 0, " + 
                                 "ADD pos5 tinyint NOT NULL default 0");
            
            stmt2.executeUpdate("ALTER TABLE events2b " +
                                 "ADD gender varchar(6) NOT NULL default '', " +
                                 "ADD email1 varchar(50) NOT NULL default '', " +
                                 "ADD email2 varchar(50) NOT NULL default '', " +
                                 "ADD season tinyint NOT NULL default 0, " +
                                 "ADD export_type tinyint NOT NULL default 0;");
            
            stmt2.executeUpdate("ALTER TABLE lottery3 " +
                                 "ADD minsbefore smallint NOT NULL default 120, " +
                                 "ADD minsafter smallint NOT NULL default 120, " +
                                 "ADD allowmins tinyint NOT NULL default 0;");
            
            */
            
            // add alternating week field to custom_sheets table
            //stmt2.executeUpdate("ALTER TABLE custom_sheets ADD eo_week tinyint NOT NULL default 0;");
            
            
            /*
            
            // add cutoffDays & cutoffTime to club5 table
            stmt2.executeUpdate("ALTER TABLE club5 ADD cutoffDays tinyint NOT NULL default 99;");
            stmt2.executeUpdate("ALTER TABLE club5 ADD cutoffTime smallint NOT NULL default 0;");
            
            
            stmt2.executeUpdate("CREATE TABLE custom_sheets (" + 
                                "custom_sheet_id int(11) NOT NULL auto_increment," + 
                                "name varchar(32) NOT NULL default ''," + 
                                "course varchar(30) NOT NULL default ''," + 
                                "start_date int(11) NOT NULL default '0'," + 
                                "end_date int(11) NOT NULL default '0'," + 
                                "sunday tinyint(4) NOT NULL default '0'," + 
                                "monday tinyint(4) NOT NULL default '0'," + 
                                "tuesday tinyint(4) NOT NULL default '0'," + 
                                "wednesday tinyint(4) NOT NULL default '0'," + 
                                "thursday tinyint(4) NOT NULL default '0'," + 
                                "friday tinyint(4) NOT NULL default '0'," + 
                                "saturday tinyint(4) NOT NULL default '0'," + 
                                "stime smallint(6) NOT NULL default '0'," + 
                                "etime smallint(6) NOT NULL default '0'," + 
                                "alt tinyint(4) NOT NULL default '0'," + 
                                "betwn tinyint(4) NOT NULL default '0'," + 
                                "PRIMARY KEY  (custom_sheet_id)," + 
                                "UNIQUE KEY name (name)" + 
                                ") ENGINE=MyISAM");
            
            
            stmt2.executeUpdate("CREATE TABLE custom_tee_times (" + 
                                "custom_tee_time_id int(11) NOT NULL auto_increment," + 
                                "custom_sheet_id int(11) NOT NULL default '0'," + 
                                "time int(11) NOT NULL default '0'," + 
                                "fb smallint(6) NOT NULL default '0'," + 
                                "PRIMARY KEY  (custom_tee_time_id)," + 
                                "UNIQUE KEY ind1 (custom_sheet_id,time,fb)" + 
                                ") ENGINE=MyISAM");
            */
            
            
            // add fb field to teereport4 table
            //stmt2.executeUpdate("ALTER TABLE teereport4 ADD fb CHAR(1);");
            
            
            // change score_postings 'score' field to a smallint
            //stmt2.executeUpdate("ALTER TABLE score_postings CHANGE score score smallint NOT NULL default 0;");
            
            // add max_originations to club5 table
            //stmt2.executeUpdate("ALTER TABLE club5 ADD max_originations tinyint NOT NULL default 0;");
            
            // change score_postings 'type' field length from 1 to 2
            //stmt2.executeUpdate("ALTER TABLE score_postings CHANGE type type VARCHAR(2) NOT NULL default '';");
            
            //if (!club.equals("demov4")) stmt2.executeUpdate("ALTER TABLE events2b ADD minsize tinyint NOT NULL default 0;");
    
            /*
            if (club.equals("santaana")) skip = false;
            
            if (!skip) {
            
                stmt2.executeUpdate("ALTER TABLE club5 ADD emailPass varchar(16) NOT NULL default '';");
                stmt2.executeUpdate("ALTER TABLE member2b ADD gender enum('','M','F') NOT NULL, ADD pri_indicator tinyint NOT NULL default '0';");
            }
            */
            //stmt2.executeUpdate("ALTER TABLE mem_notice ADD proside tinyint NOT NULL default 0;");

/*            
            // redifine the double fields as double(n,n) fields
            stmt2.executeUpdate("ALTER TABLE member2b MODIFY g_hancap double(3,1);");
            
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp1 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp2 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp3 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp4 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp5 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp6 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp7 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp8 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp9 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE evntsup2b MODIFY hndcp10 double(3,1);");
            
            stmt2.executeUpdate("ALTER TABLE teecurr2 MODIFY hndcp1 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE teecurr2 MODIFY hndcp2 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE teecurr2 MODIFY hndcp3 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE teecurr2 MODIFY hndcp4 double(3,1);");
            stmt2.executeUpdate("ALTER TABLE teecurr2 MODIFY hndcp5 double(3,1);");
*/            
            
            // add moved flag to event signups table
            //stmt2.executeUpdate("ALTER TABLE evntsup2b ADD moved tinyint NOT NULL default 0;");
            
/*
            // add index to lreqs3 table
            stmt2.executeUpdate("CREATE INDEX name ON lreqs3 (name);");
            stmt2.executeUpdate("CREATE INDEX date ON lreqs3 (date);");
            stmt2.executeUpdate("CREATE INDEX in_use ON lreqs3 (in_use);");
            
            // and index to lottery3 table
            stmt2.executeUpdate("CREATE UNIQUE INDEX name ON lottery3 (name);");
            stmt2.executeUpdate("CREATE INDEX dates ON lottery3 (sdate,edate);");
            
            // add index to clubparm2 table
            stmt2.executeUpdate("CREATE UNIQUE INDEX courseName ON clubparm2 (courseName);");
            
            // and index to restriction2 table
            stmt2.executeUpdate("DROP INDEX ind1 ON restriction2;");
            stmt2.executeUpdate("DROP INDEX ind2 ON restriction2;");
            stmt2.executeUpdate("DROP INDEX ind3 ON restriction2;");
            stmt2.executeUpdate("CREATE UNIQUE INDEX name ON restriction2 (name);");
            stmt2.executeUpdate("CREATE INDEX dates ON restriction2 (sdate,edate);");
            stmt2.executeUpdate("CREATE INDEX courseName ON restriction2 (courseName(10));");
            
            // add index to lessonbook5 table
            stmt2.executeUpdate("CREATE UNIQUE INDEX recid ON lessonbook5 (recid);");
            stmt2.executeUpdate("DROP INDEX ind4 ON lessonbook5;");
            stmt2.executeUpdate("DROP INDEX ind3 ON lessonbook5;");
            stmt2.executeUpdate("DROP INDEX ind2 ON lessonbook5;");
            stmt2.executeUpdate("DROP INDEX ind1 ON lessonbook5;");
            stmt2.executeUpdate("CREATE INDEX date ON lessonbook5 (date);");
            stmt2.executeUpdate("CREATE INDEX in_use ON lessonbook5 (in_use);");
*/            
            
            //stmt2.executeUpdate("CREATE UNIQUE INDEX mship ON mship5 (mship);");
            //stmt2.executeUpdate("CREATE UNIQUE INDEX guest ON guest5 (guest);");
            
            /*
            // Add fields for new seamless login interface 
            stmt2.executeUpdate("ALTER TABLE club5 " +
                               "ADD rsync tinyint NOT NULL default '0', ADD seamless tinyint NOT NULL default '0', " +
                               "ADD zipcode varchar(5) NOT NULL, ADD primaryif tinyint NOT NULL default '0', " +
                               "ADD mnum tinyint NOT NULL default '0', ADD mapping tinyint NOT NULL default '0', " +
                               "ADD stripzero tinyint NOT NULL default '0'");
             */
            
            
            // increase size of score field from tinyint to smallint
            //stmt2.executeUpdate("ALTER TABLE score_postings MODIFY score smallint;");
            
            /*
             *  make all member2b tables unique if possible
            rs2 = stmt2.executeQuery("select count(*) from (select count(*) as c from (select username from member2b) as t group by username) as t2 where c > 1;");
            
            if (rs2.next()) {
                
                // if no dups found
                if (rs2.getInt(1) == 0) {
                    
                    try {

                        stmt3.executeUpdate("ALTER TABLE member2b DROP INDEX ind1;");
                        stmt3.executeUpdate("ALTER TABLE member2b ADD UNIQUE ind1 (username);");
                        stmt3.close();
                        
                    } catch (Exception exp) {
                        out.println("<br>Error updating index for " + club + ".  Exception=" + exp.toString());
                    }
                    
                } // end if == 0
            
            } // end if rs2
            
            */
            
            //stmt2.executeUpdate("ALTER TABLE score_postings ADD tee_id int NOT NULL default 0");
            
            
            
            //stmt2.executeUpdate("ALTER TABLE mship5 ADD viewdays smallint NOT NULL default 30");
            
            
            /*
            // fix '0' emails addresses
            stmt2.executeUpdate("UPDATE member2b SET email = '' WHERE email = '0';");
            stmt2.executeUpdate("UPDATE member2b SET email2 = '' WHERE email2 = '0';");
            // if email is empty but email2 isn't, then move in into email instead
            stmt2.executeUpdate("UPDATE member2b SET email = email2 WHERE email = '' AND email2 <> '';");
            // if emai1 and email2 are the same, then clear email2 field
            stmt2.executeUpdate("UPDATE member2b SET email2 = '' WHERE email = email2;");
            */
            
            //stmt2.executeUpdate("ALTER TABLE teepast2 ADD custom_string varchar(20) NOT NULL default '';");
            //stmt2.executeUpdate("ALTER TABLE teepast2 ADD custom_int int NOT NULL default 0;");
            
            
            
            //stmt2.executeUpdate("ALTER TABLE teecurr2 ADD lottery_email int NOT NULL default 0;");
            
            
            
            /*
            // increase mname field in teehist table
            stmt2.executeUpdate("ALTER TABLE teehist CHANGE mname mname varchar(50);");


            // teecurr2 changes
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_disp1 varchar(10) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_disp2 varchar(10) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_disp3 varchar(10) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_disp4 varchar(10) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_disp5 varchar(10) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_string varchar(20) NOT NULL default '';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD custom_int int NOT NULL default 0;");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD create_date datetime NOT NULL default '0000-00-00 00:00:00';");
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD last_mod_date datetime NOT NULL default '0000-00-00 00:00:00';");


            // teepast2 changes
            stmt2.executeUpdate("ALTER TABLE teepast2 ADD create_date datetime NOT NULL default '0000-00-00 00:00:00';");
            stmt2.executeUpdate("ALTER TABLE teepast2 ADD last_mod_date datetime NOT NULL default '0000-00-00 00:00:00';");
            
            
            // add new member2b fields
            //stmt2.executeUpdate("ALTER TABLE member2b ADD inact tinyint NOT NULL default '0'");
            //stmt2.executeUpdate("ALTER TABLE member2b ADD billable tinyint NOT NULL default '1'");
            //stmt2.executeUpdate("ALTER TABLE member2b ADD last_sync_date date NOT NULL default '0000-00-00'");
            
            
            // add unique index to lreqs3 table
            //stmt2.executeUpdate("CREATE UNIQUE INDEX id ON lreqs3 (id);");
*/
            
/*            
            // change assoc_num & club_num to varchar from int
            stmt2.executeUpdate("ALTER TABLE hdcp_assoc_num CHANGE assoc_num assoc_num varchar(8);");
            stmt2.executeUpdate("ALTER TABLE hdcp_club_num CHANGE club_num club_num varchar(8);");
            
            // add unique index to score_postings table
            stmt2.executeUpdate("CREATE UNIQUE INDEX entry ON score_postings (hdcpNum,date,score,type);");
*/            
            
            // change evntsup2 itinerary field from varchar to text
            //stmt2.executeUpdate("ALTER TABLE events2b CHANGE itin itin TEXT;");
            
            // drop hdcp fields from club5
            //stmt2.executeUpdate("ALTER TABLE club5 DROP COLUMN clubNum, DROP COLUMN clubAssocNum;");
            
/*
            stmt2.executeUpdate("ALTER TABLE member2b ADD hdcp_club_num_id int NOT NULL default '0'");
            stmt2.executeUpdate("ALTER TABLE member2b ADD hdcp_assoc_num_id int NOT NULL default '0'");
            stmt2.executeUpdate("ALTER TABLE member2b ADD default_tee_id int NOT NULL default '0'");
            stmt2.executeUpdate("ALTER TABLE member2b ADD default_holes tinyint NOT NULL default '0'");
            stmt2.executeUpdate("ALTER TABLE member2b ADD displayHdcp tinyint NOT NULL default '0'");
            
            
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS hdcp_assoc_num ( " + 
                  "hdcp_assoc_num_id int(11) NOT NULL auto_increment, " +
                  "assoc_num int(11) NOT NULL, " +
                  "assoc_name varchar(16) NOT NULL, " +
                  "PRIMARY KEY (hdcp_assoc_num_id) " +
                ") ENGINE=MyISAM;");
            
            
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS hdcp_club_num ( " +
                 "hdcp_club_num_id int(11) NOT NULL auto_increment, " +
                 "club_num int(11) NOT NULL, " +
                 "club_name varchar(16) NOT NULL, " +
                 "PRIMARY KEY (hdcp_club_num_id) " + 
               ") ENGINE=MyISAM;");
/*                    
                    
            
            // BOB ONLY!!!
            //stmt2.executeUpdate("ALTER TABLE member2b ADD email_bounced tinyint(4) NOT NULL default '0'");
            //stmt2.executeUpdate("ALTER TABLE member2b ADD email2_bounced tinyint(4) NOT NULL default '0'");
                       
            
            
            //out.println("<br>Updating club5"); 
            /*
            stmt2.executeUpdate("ALTER TABLE club5 ADD nwindow_starttime time");
            stmt2.executeUpdate("ALTER TABLE club5 ADD nwindow_endtime time");
            stmt2.executeUpdate("ALTER TABLE club5 ADD notify_interval tinyint NOT NULL");
            
            stmt2.executeUpdate("ALTER TABLE club5 ADD hdcpSystem varchar(8) NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD clubNum varchar(8) NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD clubAssocNum varchar(8) NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD allowMemPost tinyint NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD lastHdcpSync datetime NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD hdcpStartDate date NOT NULL");
            stmt2.executeUpdate("ALTER TABLE club5 ADD hdcpEndDate date NOT NULL");
            */
            
            /*
            // Add notification tables for TLT system
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS notifications ( " +                                    
                    "notification_id int(11) NOT NULL auto_increment, " +              
                    "created_by varchar(32) NOT NULL, " +                              
                    "created_datetime datetime NOT NULL, " +                           
                    "req_datetime datetime NOT NULL default '0000-00-00 00:00:00', " + 
                    "course_id int(11) NOT NULL default '0', " +                       
                    "in_use_by varchar(15) NOT NULL default '', " +                    
                    "in_use_at datetime NOT NULL default '0000-00-00 00:00:00', " +    
                    "hideNotes tinyint(4) NOT NULL default '0', " +                    
                    "notes text, " +                                                   
                    "converted tinyint(4) NOT NULL default '0', " +                    
                    "converted_at datetime NOT NULL default '0000-00-00 00:00:00', " + 
                    "converted_by varchar(15) NOT NULL default '', " +                 
                    "teecurr_id int(11) NOT NULL default '0', " +                      
                    "teepast_id int(11) NOT NULL default '0', " +                      
                    "PRIMARY KEY (notification_id) " +                           
                ") ENGINE=MyISAM;");
            
            
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS notifications_players ( " + 
                     "notification_player_id int(11) NOT NULL auto_increment, " + 
                     "notification_id int(11) NOT NULL default '0', " + 
                     "username varchar(12) NOT NULL default '', " + 
                     "cw varchar(4) NOT NULL default '', " + 
                     "player_name varchar(64) NOT NULL default '', " + 
                     "9hole tinyint(4) NOT NULL default '0', " + 
                     "pos tinyint(4) NOT NULL default '0', " + 
                     "PRIMARY KEY (notification_player_id), " + 
                     "UNIQUE KEY pos (notification_id, pos) " + 
                ") ENGINE=MyISAM;");
            
            
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS score_postings (" + 
                    "posting_id int(11) NOT NULL auto_increment, " +
                    "hdcpNum varchar(15) NOT NULL, " +
                    "date date NOT NULL, " +
                    "score tinyint(4) NOT NULL, " +
                    "type varchar(1) NOT NULL, " +
                    "hdcpIndex double(3,1) NOT NULL, " +
                    "PRIMARY KEY (posting_id), " +
                    "KEY hdcpNum (hdcpNum) " +
                ") ENGINE=MyISAM;");
            
            
            stmt2.executeUpdate("" +
                "CREATE TABLE IF NOT EXISTS tees (" +
                    "tee_id int(11) NOT NULL auto_increment, " + 
                    "course_id int(11) NOT NULL, " +
                    "tee_name varchar(24) NOT NULL, " +
                    "tee_rating18 double(3,1) NOT NULL, " +
                    "tee_slope18 int(11) NOT NULL, " +
                    "tee_ratingF9 double(3,1) NOT NULL, " +
                    "tee_slopeF9 int(11) NOT NULL, " +
                    "tee_ratingB9 double(3,1) NOT NULL, " +
                    "tee_slopeB9 int(11) NOT NULL, " +
                    "PRIMARY KEY  (tee_id) " +
                ") ENGINE=MyISAM;");
            */
            
            /*
             * GET ALL CLUBS THAT HAVE MORE THAN ONE COURSE
            rs2 = stmt2.executeQuery("SELECT COUNT(*) AS total FROM clubparm2");
            
            while (rs2.next()) {
                
               if (rs2.getInt(1) > 1) {
                   
                   out.println("<br>" + club + " has " + rs2.getInt(1));
                   i++;
               }
            }
            
            */
            
            
            //  START auto_blocker UPDATES
            
            //stmt2.executeUpdate("ALTER TABLE teecurr2 ADD auto_blocked TINYINT NOT NULL");
            //stmt2.executeUpdate("UPDATE teecurr2 SET auto_blocked = 1 WHERE blocker = \"Auto-Blocker\""); // probably not needed but why not...
            
            //  END auto_blocked UPDATE
            
            
            
            
            
            // START adv email updates member2b table
            
            /*
            out.print("<br>Updating member2b");
            out.flush();
            
            stmt2.executeUpdate("CREATE TABLE t1 LIKE member2b");
            stmt2.executeUpdate("DROP INDEX ind1 ON t1");
            stmt2.executeUpdate("DROP INDEX ind2 ON t1");
            stmt2.executeUpdate("DROP INDEX ind3 ON t1");
            stmt2.executeUpdate("ALTER TABLE t1 ADD member_id INT AUTO_INCREMENT PRIMARY KEY FIRST;");
            //stmt2.executeUpdate("ALTER TABLE t1 ADD email_teetimes INT;");
            stmt2.executeUpdate("ALTER TABLE t1 ADD email_proshop INT;");
            stmt2.executeUpdate("ALTER TABLE t1 ADD email_members INT;");
            stmt2.executeUpdate("ALTER TABLE t1 ADD email_bounce_hard INT;");
            stmt2.executeUpdate("ALTER TABLE t1 ADD email_bounce_soft INT;");
            stmt2.executeUpdate("ALTER TABLE t1 ADD private_tt INT;");
            stmt2.executeUpdate("CREATE INDEX username ON t1 (username)");
            stmt2.executeUpdate("CREATE INDEX m_ship ON t1 (m_ship)");
            stmt2.executeUpdate("CREATE INDEX m_type ON t1 (m_type)");
            stmt2.executeUpdate("CREATE INDEX memNum ON t1 (memNum)");
            stmt2.executeUpdate("CREATE INDEX webid ON t1 (webid)");
            stmt2.executeUpdate("INSERT INTO t1 (username, password, name_last, name_first, name_mi, m_ship, m_type, email, count, c_hancap, g_hancap, wc, message, emailOpt, memNum, ghin, locker, bag, birth, posid, msub_type, email2, phone1, phone2, name_pre, name_suf, webid) (SELECT * FROM member2b ORDER BY username, password, name_last, name_first, name_mi, m_ship, m_type, email, count, c_hancap, g_hancap, wc, message, emailOpt, memNum, ghin, locker, bag, birth, posid, msub_type, email2, phone1, phone2, name_pre, name_suf, webid);");
            stmt2.executeUpdate("DROP TABLE member2b");
            stmt2.executeUpdate("ALTER TABLE t1 RENAME member2b");
            
            
            out.print(", done.");
             */
            /*
            out.println("<br>Updating clubparm2");  
            out.flush();
            
            stmt2.executeUpdate("CREATE TABLE t1 LIKE clubparm2");
            stmt2.executeUpdate("ALTER TABLE t1 ADD clubparm_id INT AUTO_INCREMENT PRIMsARY KEY FIRST");
            stmt2.executeUpdate("INSERT INTO t1 (courseName,first_hr,first_min,last_hr,last_min,betwn,xx,alt,fives,tmode1,tmodea1,tmode2,tmodea2,tmode3,tmodea3,tmode4,tmodea4,tmode5,tmodea5,tmode6,tmodea6,tmode7,tmodea7,tmode8,tmodea8,tmode9,tmodea9,tmode10,tmodea10,tmode11,tmodea11,tmode12,tmodea12,tmode13,tmodea13,tmode14,tmodea14,tmode15,tmodea15,tmode16,tmodea16,t9pos1,tpos1,t9pos2,tpos2,t9pos3,tpos3,t9pos4,tpos4,t9pos5,tpos5,t9pos6,tpos6,t9pos7,tpos7,t9pos8,tpos8,t9pos9,tpos9,t9pos10,tpos10,t9pos11,tpos11,t9pos12,tpos12,t9pos13,tpos13,t9pos14,tpos14,t9pos15,tpos15,t9pos16,tpos16,courseid,tOpt1,tOpt2,tOpt3,tOpt4,tOpt5,tOpt6,tOpt7,tOpt8,tOpt9,tOpt10,tOpt11,tOpt12,tOpt13,tOpt14,tOpt15,tOpt16) (SELECT * FROM clubparm2 ORDER BY courseName,first_hr,first_min,last_hr,last_min,betwn,xx,alt,fives,tmode1,tmodea1,tmode2,tmodea2,tmode3,tmodea3,tmode4,tmodea4,tmode5,tmodea5,tmode6,tmodea6,tmode7,tmodea7,tmode8,tmodea8,tmode9,tmodea9,tmode10,tmodea10,tmode11,tmodea11,tmode12,tmodea12,tmode13,tmodea13,tmode14,tmodea14,tmode15,tmodea15,tmode16,tmodea16,t9pos1,tpos1,t9pos2,tpos2,t9pos3,tpos3,t9pos4,tpos4,t9pos5,tpos5,t9pos6,tpos6,t9pos7,tpos7,t9pos8,tpos8,t9pos9,tpos9,t9pos10,tpos10,t9pos11,tpos11,t9pos12,tpos12,t9pos13,tpos13,t9pos14,tpos14,t9pos15,tpos15,t9pos16,tpos16,courseid,tOpt1,tOpt2,tOpt3,tOpt4,tOpt5,tOpt6,tOpt7,tOpt8,tOpt9,tOpt10,tOpt11,tOpt12,tOpt13,tOpt14,tOpt15,tOpt16)");
            stmt2.executeUpdate("DROP TABLE clubparm2");
            stmt2.executeUpdate("ALTER TABLE t1 RENAME clubparm2");
            */
             
            
            /*
            //  START PACE OF PLAY UPDATES
            
            
            out.println("<br>Updating club5"); 
            stmt2.executeUpdate("ALTER TABLE club5 ADD paceofplay tinyint NOT NULL default '0'");
            */
            /*
            out.println("<br>Updating teepast2"); 
            
            stmt2.executeUpdate("CREATE TABLE t1 LIKE teepast2");
            stmt2.executeUpdate("DROP INDEX ind1 ON t1");
            stmt2.executeUpdate("DROP INDEX ind2 ON t1");
            stmt2.executeUpdate("DROP INDEX ind3 ON t1");
            stmt2.executeUpdate("DROP INDEX ind4 ON t1");
            stmt2.executeUpdate("DROP INDEX ind5 ON t1");
            stmt2.executeUpdate("ALTER TABLE t1 ADD teecurr_id INT NULL FIRST");
            stmt2.executeUpdate("ALTER TABLE t1 ADD teepast_id INT AUTO_INCREMENT PRIMARY KEY FIRST");
            stmt2.executeUpdate("ALTER TABLE t1 ADD pace_status_id INT NOT NULL default '0'");
            stmt2.executeUpdate("CREATE UNIQUE INDEX teecurr_id ON t1 (teecurr_id)");
            stmt2.executeUpdate("CREATE INDEX pace_status_id ON t1 (pace_status_id)");
            stmt2.executeUpdate("CREATE INDEX date ON t1 (date)");
            stmt2.executeUpdate("CREATE INDEX time ON t1 (time)");
            stmt2.executeUpdate("CREATE INDEX fb ON t1 (fb)");
            stmt2.executeUpdate("CREATE INDEX courseName ON t1 (courseName)");
            stmt2.executeUpdate("CREATE INDEX mm ON t1 (mm)");
            stmt2.executeUpdate("CREATE INDEX yy ON t1 (yy)");
            stmt2.executeUpdate("CREATE INDEX player1 ON t1 (player1)");
            stmt2.executeUpdate("CREATE INDEX player2 ON t1 (player2)");
            stmt2.executeUpdate("CREATE INDEX player3 ON t1 (player3)");
            stmt2.executeUpdate("CREATE INDEX player4 ON t1 (player4)");
            stmt2.executeUpdate("CREATE INDEX player5 ON t1 (player5)");
            stmt2.executeUpdate("CREATE INDEX username1 ON t1 (username1)");
            stmt2.executeUpdate("CREATE INDEX username2 ON t1 (username2)");
            stmt2.executeUpdate("CREATE INDEX username3 ON t1 (username3)");
            stmt2.executeUpdate("CREATE INDEX username4 ON t1 (username4)");
            stmt2.executeUpdate("CREATE INDEX username5 ON t1 (username5)");
            stmt2.executeUpdate("INSERT INTO t1 (date, mm, dd, yy, day, hr, min, time, event, event_color, restriction, rest_color, player1, player2, player3, player4, username1, username2, username3, username4, p1cw, p2cw, p3cw, p4cw, show1, show2, show3, show4, fb, player5, username5, p5cw, show5, courseName, proNew, proMod, memNew, memMod, mNum1, mNum2, mNum3, mNum4, mNum5, userg1, userg2, userg3, userg4, userg5, hotelNew, hotelMod, orig_by, conf, notes, p91, p92, p93, p94, p95) (SELECT * FROM teepast2 ORDER BY date, mm, dd, yy, day, hr, min, time, event, event_color, restriction, rest_color, player1, player2, player3, player4, username1, username2, username3, username4, p1cw, p2cw, p3cw, p4cw, show1, show2, show3, show4, fb, player5, username5, p5cw, show5, courseName, proNew, proMod, memNew, memMod, mNum1, mNum2, mNum3, mNum4, mNum5, userg1, userg2, userg3, userg4, userg5, hotelNew, hotelMod, orig_by, conf, notes, p91, p92, p93, p94, p95);");
            stmt2.executeUpdate("DROP TABLE teepast2");
            stmt2.executeUpdate("ALTER TABLE t1 RENAME teepast2");
            
            out.print(", done.");
            */
            
            
            /*
            out.println("<br>Updating teecurr2"); 
            out.flush();
            
            stmt2.executeUpdate("ALTER TABLE teecurr2 ADD pace_status_id INT NOT NULL default '0'");
            stmt2.executeUpdate("CREATE INDEX pace_status_id ON teecurr2 (pace_status_id)");
            
            */
            /*
            out.print(", done.");
            out.println("<br>Creating pace_status"); 
            out.flush();
            
            stmt2.executeUpdate("CREATE TABLE pace_status (" +
                                "pace_status_id int NOT NULL auto_increment, " +
                                "pace_status_sort int default NULL, " +
                                "pace_status_name varchar(16) default NULL, " +
                                "pace_status_color varchar(16) default NULL, " +
                                "pace_leeway double default NULL, " +
                                "PRIMARY KEY (pace_status_id) " +
                                ") ENGINE=MyISAM");
            
            out.print(", populating defaults"); 
            out.flush();
            
            stmt2.executeUpdate("INSERT INTO pace_status (pace_status_sort, pace_status_name, pace_status_color, pace_leeway) VALUES " +
                                "(\"1\", \"On Pace\", \"green\", \"0.045\"), " +
                                "(\"2\", \"Falling Behind\", \"yellow\", \"0.09\"), " + 
                                "(\"3\", \"Behind\", \"pink\", \"0.12\")");
            
            
            out.print(", done.");
            out.println("<br>Creating pace_entries"); 
            out.flush();
                     
            stmt2.executeUpdate("CREATE TABLE pace_entries (" +
                                "pace_entry_id int(11) NOT NULL auto_increment," +
                                "teecurr_id int(11) default NULL," +
                                "hole_number tinyint(4) default NULL," +
                                "invert tinyint(4) default NULL," +
                                "hole_timestamp time default NULL," +
                                "PRIMARY KEY (pace_entry_id), " +
                                "UNIQUE KEY teecurr_id (teecurr_id, hole_number)" +
                                ") ENGINE=MyISAM");
            
            out.print(", done.");
            out.print("dropping pace_bechmarks.");
            stmt2.executeUpdate("DROP TABLE pace_benchmarks");
            
            
            out.print(", done.");
            out.println("<br>Creating pace_benchmarks"); 
             
            stmt2.executeUpdate("CREATE TABLE pace_benchmarks (" +
                                "pace_benchmark_id int(11) NOT NULL auto_increment," +
                                "clubparm_id int(11) default NULL," +
                                "hole_number tinyint(4) default NULL," +
                                "hole_pace int(11) default NULL," +
                                "invert tinyint(4) default NULL," +
                                "PRIMARY KEY (pace_benchmark_id), " +
                                "UNIQUE KEY clubparm_id (clubparm_id, hole_number)" +
                                ") ENGINE=MyISAM");
            //stmt2.executeUpdate("CREATE INDEX clubparm_id ON pace_benchmarks (clubparm_id)");
            
            */
            
            
            // END OF PACE OF PLAY UPDATES
            
            
            
            
            
            
            
            
            
            // STRART POS field lengthing updates
            /*
            
            stmt2.executeUpdate("ALTER TABLE guest5 CHANGE gstItem gstItem varchar(20)");
            stmt2.executeUpdate("ALTER TABLE guest5 CHANGE gst9Item gst9Item varchar(20)");
            
            stmt2.executeUpdate("ALTER TABLE mship5 CHANGE mpos mpos varchar(20)");
            stmt2.executeUpdate("ALTER TABLE mship5 CHANGE mposc mposc varchar(20)");
            stmt2.executeUpdate("ALTER TABLE mship5 CHANGE m9posc m9posc varchar(20)");
            stmt2.executeUpdate("ALTER TABLE mship5 CHANGE mshipItem mshipItem varchar(20)");
            stmt2.executeUpdate("ALTER TABLE mship5 CHANGE mship9Item mship9Item varchar(20)");
            
            */
            // END OF POS field lengthing updates
            
            
            
            
            
            
            
            /*
            out.println("<br>Creating user_types"); 
            out.flush();
            
            stmt2.executeUpdate("CREATE TABLE user_types (" +
                                "user_type_id int(11) NOT NULL auto_increment," +
                                "user_type varchar(32) NOT NULL," +
                                "PRIMARY KEY (user_type_id) " +
                                ") ENGINE=MyISAM");
                    
            out.print(", populating defaults"); 
            out.flush();
            
            stmt2.executeUpdate("INSERT INTO user_types (user_type) VALUES " +
                                "(\"Member\"), " +
                                "(\"Remote\"), " + 
                                "(\"Proshop\"), " + 
                                "(\"Admin\"), " + 
                                "(\"Support\"), " + 
                                "(\"Sales\") ");
                    
            out.print(", done.");
            out.flush();
            /*
/*
            // stmt2.executeUpdate("ALTER TABLE lessonbook5 ADD recid INTEGER NOT NULL AUTO_INCREMENT, ADD INDEX ind4 (recid)");
            
            // CREATE TABLE t1 LIKE teecurr2;
            // ALTER TABLE t1 ADD teetime_id INT AUTO_INCREMENT PRIMARY KEY FIRST;
            // INSERT INTO t1 SELECT * FROM teecurr2 ORDER BY date, mm, dd, tt, day, hr, min, time, event, event_color, restriction, rest_color, player1, player2, player3, player4, username1, username2, username3, username4, p1cw, p2cw, p3cw, p4cw, first, in_use, in_use_by, event_type, hndcp1, hndcp2, hndcp3, hndcp4, show1, show2, show3, show4, fb, player5, username5, p5cw, hndcp5, show5, notes, hideNotes, lottery, courseName, blocker, proNew, proMod, memNew, memMod, rest5, rest5_color, mNum1, mNum2, mNum3, mNum4, mNum5, lottery_color, userg1, userg2, userg3, userg4, userg5, hotelNew, hotelMod, orig_by, conf, p91, p92, p93, p94, p95, pos1, pos2, pos3, pos4, pos5, hole;
            
         stmt2.executeUpdate("CREATE TABLE t1 LIKE teecurr2");
         out.print(".");
         //out.flush();
         //resp.flushBuffer();
         stmt2.executeUpdate("DROP INDEX ind1 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("DROP INDEX ind2 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("DROP INDEX ind3 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("DROP INDEX ind4 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("DROP INDEX ind5 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("DROP INDEX ind6 ON t1");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("ALTER TABLE t1 ADD teecurr_id INT AUTO_INCREMENT PRIMARY KEY FIRST;");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX date ON t1 (date)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX time ON t1 (time)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX fb ON t1 (fb)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX courseName ON t1 (courseName)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX in_use ON t1 (in_use)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX blocker ON t1 (blocker)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX lottery ON t1 (lottery)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX mm ON t1 (mm)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX dd ON t1 (dd)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX yy ON t1 (yy)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX player1 ON t1 (player1)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX player2 ON t1 (player2)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX player3 ON t1 (player3)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX player4 ON t1 (player4)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX player5 ON t1 (player5)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX username1 ON t1 (username1)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX username2 ON t1 (username2)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX username3 ON t1 (username3)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX username4 ON t1 (username4)");
         out.print(".");
         //out.flush();
         stmt2.executeUpdate("CREATE INDEX username5 ON t1 (username5)");
         out.print(".(inserting)");
         out.flush();
         stmt2.executeUpdate("INSERT INTO t1 (date, mm, dd, yy, day, hr, min, time, event, event_color, restriction, rest_color, player1, player2, player3, player4, username1, username2, username3, username4, p1cw, p2cw, p3cw, p4cw, first, in_use, in_use_by, event_type, hndcp1, hndcp2, hndcp3, hndcp4, show1, show2, show3, show4, fb, player5, username5, p5cw, hndcp5, show5, notes, hideNotes, lottery, courseName, blocker, proNew, proMod, memNew, memMod, rest5, rest5_color, mNum1, mNum2, mNum3, mNum4, mNum5, lottery_color, userg1, userg2, userg3, userg4, userg5, hotelNew, hotelMod, orig_by, conf, p91, p92, p93, p94, p95, pos1, pos2, pos3, pos4, pos5, hole) (SELECT * FROM teecurr2 ORDER BY date, mm, dd, yy, day, hr, min, time, event, event_color, restriction, rest_color, player1, player2, player3, player4, username1, username2, username3, username4, p1cw, p2cw, p3cw, p4cw, first, in_use, in_use_by, event_type, hndcp1, hndcp2, hndcp3, hndcp4, show1, show2, show3, show4, fb, player5, username5, p5cw, hndcp5, show5, notes, hideNotes, lottery, courseName, blocker, proNew, proMod, memNew, memMod, rest5, rest5_color, mNum1, mNum2, mNum3, mNum4, mNum5, lottery_color, userg1, userg2, userg3, userg4, userg5, hotelNew, hotelMod, orig_by, conf, p91, p92, p93, p94, p95, pos1, pos2, pos3, pos4, pos5, hole);");
         out.print(".");
         out.flush();
         stmt2.executeUpdate("DROP TABLE teecurr2");
         out.print(".");
         out.flush();
         stmt2.executeUpdate("ALTER TABLE t1 RENAME teecurr2");
         out.print(". &nbsp; Done.");
         out.flush();
*/
         stmt2.close(); 
         con2.close();
         
      } // loop all clubs
      
      //out.println("<br>" + i + " clubs have more than one course.");
            
      stmt1.close();
      con1.close();
      
   }
   catch (Exception e) {

      // Error connecting to db....

      out.println("<BR><BR><H3>Fatal Error!</H3>");
      out.println("Error performing update to club '" + club + "'.");
      out.println("<BR>Exception: "+ e.getMessage());
      out.println("<BR>Message: "+ e.toString());
      out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
      out.println("</BODY></HTML>");
      out.close();
      return;
   }

   out.println("<BR><BR>Upgrade Finished!  The upgrade is complete for all clubs.");
   out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>");
   out.println("</CENTER></BODY></HTML>");
   //out.flush();
   //out.close();
    
 }
 
 
 
 private void doTest(PrintWriter out) {

    Connection con1 = null;                  // init DB objects
    Connection con2 = null;
    Statement stmt1 = null;
    Statement stmt2 = null;
    PreparedStatement pstmt = null;
    ResultSet rs1 = null;
    ResultSet rs2 = null;
    ResultSet rs3 = null;

    int i = 0;
    int t = 0;
    int c = 0;
    boolean found = false;
    String club = "";
    
    out.println("<HTML><HEAD><TITLE>Database Test</TITLE></HEAD>");
    out.println("<BODY><H3>Starting DB Test...</H3>");
    out.flush();

    
    /*
    
    try {

        con1 = dbConn.Connect("v5");
        stmt1 = con1.createStatement();
        rs1 = stmt1.executeQuery("SELECT clubname FROM clubs ORDER BY clubname");

        while (rs1.next()) {

            c++;
            club = rs1.getString(1);                // get a club name
            con2 = dbConn.Connect(club);             // get a connection to this club's db
            stmt2 = con2.createStatement();           // create a statement
            i = 0;
            found = false;
            
            // find out how many clubs have members with same name
            //rs2 = stmt2.executeQuery("select * from (select fullname, count(*) as c from (select CONCAT_WS(' ,', name_first, name_mi, name_last) as fullname from member2b)as t group by fullname) as t2 where c > 1;");
            rs2 = stmt2.executeQuery("select count(*) as c, date, event from teepast2 where courseName = \"-ALL-\" GROUP by date with rollup;");
            
            
            while (rs2.next()) {

                if (!found) {
                    out.print("<p><b><font size=+1><u>" + club + "</u></font></b><p>");
                    out.println("<table border=1>");
                    found = true;
                    t++;
                }
                
                if (rs2.getString("date") == null) {
                    
                    out.println("<tr><td colspan=3><i>" + rs2.getString("c") + " total tee times with -ALL- in courseName</i></td></tr>");
                } else {
                    
                    out.println("<tr><td>" + rs2.getString("c") + " x</td><td>" + rs2.getString("date") + "</td><td>" + rs2.getString("event") + "&nbsp;</td></tr>");            
                }
                
            }
            
            
            if (found) out.println("</table><hr>");
            
            stmt2.close(); 
            con2.close();
            
            out.flush();

        } // loop all clubs

        out.println("<p><i>Found " + t + " of " + c + " clubs that contain -ALL- in their teepast2 table.</i></p>");

        stmt2.close(); 
        con2.close();
        stmt1.close();
        con1.close();

    } catch (Exception e) {

        // Error connecting to db....
        out.println("<BR><BR><H3>Fatal Error!</H3>");
        out.println("Error performing update to club '" + club + "'.");
        out.println("<BR>Exception: "+ e.getMessage());
        out.println("<BR>Message: "+ e.toString());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        out.close();
        return;
    }
    
    
    
    
    
    
    
    /*
    try {

        con1 = dbConn.Connect("demov4");
    } catch (Exception exc) {

        // Error connecting to db....
        out.println("<BR><BR>Unable to connect to the DB.");
        out.println("<BR>Exception: "+ exc.getMessage());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        return;
    }

    String sql = "SELECT DATE_FORMAT('20060701', '%W %M %D, %Y') AS d1";
    out.println("<p>"+sql+"</p>");
    
    try {
        
        stmt1 = con1.createStatement();
        rs1 = stmt1.executeQuery(sql);
     
        if (rs1.next()) {
            
            out.print("d1="+rs1.getString(1));
        }
        
    } catch (Exception e) {

        // Error connecting to db....
        out.println("<BR><BR><H3>Fatal Error!</H3>");
        out.println("<BR>Loop: "+ i);
        out.println("<BR>Exception: "+ e.getMessage());
        out.println("<BR>Message: "+ e.toString());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        out.close();
        return;
    }
    */
    
    
    
    
    /*
    String test = "233";
    int test3 = 233;
    String test2 = "";
    int i = 0;
    try {
        
        pstmt = con1.prepareStatement("SELECT * FROM member2b WHERE username = ?");
        pstmt.clearParameters();
        pstmt.setInt(1, test3);
        rs1 = pstmt.executeQuery();
        
        while (rs1.next()) {

            test2 = rs1.getString("username");
            out.println("<br>" + i + " Found " + test2);
            i++;
        }

        pstmt.close();
        con1.close();

    } catch (Exception e) {

        // Error connecting to db....
        out.println("<BR><BR><H3>Fatal Error!</H3>");
        out.println("<BR>Loop: "+ i);
        out.println("<BR>Exception: "+ e.getMessage());
        out.println("<BR>Message: "+ e.toString());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        out.close();
        return;
    }
    */
    

    int tmp_total = 0;
 
    try {

        con1 = dbConn.Connect(rev);
    } catch (Exception exc) {

        // Error connecting to db....
        out.println("<BR><BR>Unable to connect to the DB.");
        out.println("<BR>Exception: "+ exc.getMessage());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        return;
    }
    
    try {

        stmt1 = con1.createStatement();
        rs1 = stmt1.executeQuery("SELECT clubname FROM clubs ORDER BY clubname");

        while (rs1.next()) {

            club = rs1.getString(1);                // get a club name
            con2 = dbConn.Connect(club);             // get a connection to this club's db
            stmt2 = con2.createStatement();           // create a statement
            i = 0;
            found = false;
            
            
/*            
            //rs2 = stmt2.executeQuery("SELECT * FROM (SELECT count(*) AS c, id FROM lreqs3 group by id) AS t WHERE c > 1;");
            rs2 = stmt2.executeQuery("select * from member2b where (email <> '' and email not like '%@%') OR (email2 <> '' and email2 not like '%@%');");
            
            while (rs2.next()) {
                
                if (!found) {
                    out.print("<p><b><font size=+1><u>" + club + "</u></font></b><p>");
                    out.println("<table border=1>");
                    out.println("<tr><td>Username</td><td>Email 1</td><td>Email 2</td></tr>");
                    found = true;
                    t++;
                }
                
                out.println("<tr><td>" + rs2.getString("username") + "</td><td>" + rs2.getString("email") + "</td><td>" + rs2.getString("email2") + "</td></tr>");
                i++;
                
            }
            
            if (found) out.println("</table><p><i>Found " + i + " bad email addresses.</i></p><hr>");
            
*/
            
/*
    // CHECK FOR DUPLICATE MEMBER NAMES
    
            // find out how many clubs have members with same name
            //rs2 = stmt2.executeQuery("select * from (select fullname, count(*) as c from (select CONCAT_WS(' ,', name_first, name_mi, name_last) as fullname from member2b)as t group by fullname) as t2 where c > 1;");
            rs2 = stmt2.executeQuery("select * from (select username, fullname, count(*) as c from (select username, CONCAT_WS(' ,', name_first, name_mi, name_last) as fullname from member2b) as t group by username) as t2 where c > 1");
            
            
            while (rs2.next()) {

                if (!found) {
                    out.print("<p><b><font size=+1><u>" + club + "</u></font></b><p>");
                    out.println("<table border=1>");
                    found = true;
                    t++;
                }
                
                //out.println("<tr><td>" + rs2.getString("c") + " x</td><td>" + rs2.getString("username") + "</td></tr>");
                out.println("<tr><td colspan=2>" + rs2.getString("c") + " \"" + rs2.getString("username") + "\" usernames</td></tr>");
                out.println("<tr><td></td><td>name</td><td>memNum</td><td>posid</td><td>webid</td><td>ghin</td><td>count</td></tr>");
                i++;
                
                pstmt = con2.prepareStatement("SELECT CONCAT_WS(' ', name_first, name_last) as fullname, webid, memNum, count, posid, ghin FROM member2b WHERE username = ?;");
                pstmt.clearParameters();
                pstmt.setString(1, rs2.getString("username"));
                rs3 = pstmt.executeQuery();
                
                while (rs3.next()) {
                    
                    out.println("<tr><td></td><td>" + rs3.getString("fullname") + "</td><td>" + rs3.getString("memNum") + "</td><td>" + rs3.getString("posid") + "</td><td>" + rs3.getString("webid") + "</td><td>" + rs3.getString("ghin") + "</td><td>" + rs3.getString("count") + "</td></tr>");
                }
                
                out.println("<tr><td colspan=4></td></tr>");
            
            }
            
            
            if (found) out.println("</table><p><i>Found " + i + " duplicate usernames.</i></p>&nbsp;<br><hr>");
            
    
            
            stmt2.close(); 
            con2.close();
            
            out.flush();
            
            tmp_total = tmp_total + i;
*/
                    
/*            
            // FIND ALL DISABLED EMAIL ADDRESSES
            rs2 = stmt2.executeQuery("SELECT COUNT(*) FROM member2b WHERE email_bounced <> 0 OR email2_bounced <> 0;");
            
            i = 0;
            if (rs2.next()) {
                i = rs2.getInt(1);
                t++;
                tmp_total += i;
                
                if (i!=0) out.println("<br>" + club + " has " + i + " disabled emails.");
            }
*/            
  
            
/*            
          // Find clubs that scanTee failed on  
            rs2 = stmt2.executeQuery("select max(date) from teepast2;");
            if (rs2.next()) {
                i = rs2.getInt(1);
                if (i != 20070614) out.println("<br>" + club + " teepast2 most recent date is " + i + ".");
            }
*/
            
            
/*            
            // FIND ALL CLUBS USING LOTTERY
            rs2 = stmt2.executeQuery("SELECT lottery, clubName FROM club5 WHERE clubName <> '';");
            if (rs2.next()) {
                i = rs2.getInt(1);
                if (i == 1) out.println("<br>" + rs2.getString(2) + "  (" + club + ") is configured to use lottery.");
            }
*/            
           
/*            
            // FIND CLUBS WITH DUPLICATE RESTRICTION NAMES
            rs2 = stmt2.executeQuery("SELECT * FROM (SELECT name, COUNT(*) AS c FROM (SELECT name FROM restriction2) AS t GROUP BY name) AS t2 WHERE c > 1;");           
            
            while ( rs2.next() ) {

                if (!found) {
                    out.print("<br><br><b><font size=+1><u>" + club + "</u></font></b>");
                    found = true;
                }
                
                out.println("<br>&nbsp;" + rs2.getInt("c") + "&nbsp;&nbsp;" + rs2.getString("name"));
                
            }

            stmt2.close(); 
            con2.close();
            
            out.flush();            
*/
                    
            
/*
            // FIND CLUBS WITH DUPLICATE RESTRICTION NAMES
            rs2 = stmt2.executeQuery("SELECT name FROM restriction2 WHERE name <> TRIM(name);");           
            
            while ( rs2.next() ) {

                if (!found) {
                    out.print("<br><br><b><font size=+1><u>" + club + "</u></font></b>");
                    found = true;
                }
                
                out.println("<br>&nbsp;" + rs2.getString("name"));
                
            }
*/
            
            
            // FIND CLUBS WITH NON UNIQUE USERNAME FIELDS IN MEMBER TABLE
            rs2 = stmt2.executeQuery("show index from member2b;");           
            
            while ( rs2.next() ) {

                if (rs2.getString("Non_unique").equals("1") && rs2.getString("Column_name").equals("username")) {
                    out.print("<br><b>" + club + "</b>");
                }
            }
            
            
            stmt2.close(); 
            con2.close();
            
            out.flush();     
        
        } // loop all clubs

        //out.println("<p><i>Found " + tmp_total + " total in " + t + " clubs.</i></p>");

        stmt2.close(); 
        con2.close();
        stmt1.close();
        con1.close();

    } catch (Exception e) {

        // Error connecting to db....
        out.println("<BR><BR><H3>Fatal Error!</H3>");
        out.println("Error performing update to club '" + club + "'.");
        out.println("<BR>Exception: "+ e.getMessage());
        out.println("<BR>Message: "+ e.toString());
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>.");
        out.println("</BODY></HTML>");
        out.close();
        return;
    }
    
   out.println("<BR><BR>Test Finished!  The test is complete for all clubs.");
   out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A>");
   out.println("</CENTER></BODY></HTML>");
   
 }
 
  
 // *********************************************************
 // Illegal access by user - force user to login....
 // *********************************************************

 private void invalidUser(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Access Error - Redirect"));
   out.println("<BODY><CENTER><img src=\"/v5/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H2>Access Error</H2><BR>");
   out.println("<BR><BR>Sorry, you must login before attempting to access these features.<BR>");
   out.println("<BR><BR>Please <A HREF=\"/v5/servlet/Logout\">login</A>");
   out.println("</CENTER></BODY></HTML>");

 }

}
