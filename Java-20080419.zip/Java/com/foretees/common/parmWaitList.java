/***************************************************************************************
 *   parmWaitList:  This class will define a paramter block object to be used for the wait list.
 *
 *
 *   called by:  several
 *
 *   created: 04/19/2008   Paul S.
 *
 *   last updated:
 *
 *
 ***************************************************************************************
 */

package com.foretees.common;


public class parmWaitList {


    public String name = "";
    public String course = "";
    
    public int wait_list_id = 0;
    
    public int start_date = 0;
    public int start_time = 0;
    public int end_date = 0;
    public int end_time = 0;
    
    public int sunday = 0;
    public int monday = 0;
    public int tuesday = 0;
    public int wednesday = 0;
    public int thursday = 0;
    public int friday = 0;
    public int saturday = 0;
    
    public int max_list_size = 0;
    public int max_team_size = 0;
    
    public int member_access = 0;
    public int member_view = 0;
    
    public int auto_assign = 0;
    
    public int allow_guests = 0;
    public int allow_x = 0;
    
    public int enabled = 0;
    
}