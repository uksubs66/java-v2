/***************************************************************************************
 *   verifySlot:  This servlet will provide some common tee time request processing methods.
 *
 *       called by:  Member_waitlist_slot
 *                   Proshop_waitlist_slot
 *
 *
 *   created:  4/19/2008   Paul S.
 *
 *
 *   last updated:
 *
 *
 */

package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

 
public class verifyWLSlot {

   private static String rev = ProcessConstants.REV;

   
/**
 //************************************************************************
 //
 //  checkInUse - check if wait list entry is in use and if not, set it
 //               and return the parm block populated with the entry info
 //
 //************************************************************************
 **/

 public static int checkInUse(int signup_id, String user, parmSlot slotParms, Connection con, PrintWriter out)
         throws Exception {


    PreparedStatement pstmt = null;
    Statement stmt = null;
    ResultSet rs = null;

    int in_use = 1; // default to busy
    int count = 0;

    //
    //  Verify the input parms, if absent then return as if the slot is busy
    //
    if (signup_id != 0 && user != null && !user.equals( "" )) {

        try {

            out.println("<!-- Checking wait list signup #" + signup_id + " to see if it's busy by " + user + " -->");
            //
            //   Set the entry as busy, IF it is not already
            //
            pstmt = con.prepareStatement (
                "UPDATE wait_list_signups SET in_use_by = ?, in_use_at = now() WHERE wait_list_signup_id = ? AND in_use_by = ''");
                
            pstmt.clearParameters();
            pstmt.setString(1, user);
            pstmt.setInt(2, signup_id);
            count = pstmt.executeUpdate();
            pstmt.close();
         
            //
            //  If the above was successful, then we now own this notifcation
            //
            if (count > 0) {

                out.println("<!-- Was not busy.  Making it busy now. -->");
            
                pstmt = con.prepareStatement (
                   "SELECT wls.*, c.courseName, " +
                        "DATE_FORMAT(wls.created_datetime, '%m/%d/%Y at %l:%i %p') AS created_at, " +
                        "DATE_FORMAT(wls.req_datetime, '%W') AS day_name, " +
                        "DATE_FORMAT(wls.req_datetime, '%Y%m%d') AS date, " +
                        "DATE_FORMAT(wls.req_datetime, '%e') AS dd, " +
                        "DATE_FORMAT(wls.req_datetime, '%c') AS mm, " +
                        "DATE_FORMAT(wls.req_datetime, '%Y') AS yy, " +
                        "DATE_FORMAT(wls.req_datetime, '%k%i') AS time " +
                   "FROM wait_list_signups wls, clubparm2 c " +
                   "WHERE wls.wait_list_signup_id = ? AND c.clubparm_id = n.course_id");

                pstmt.clearParameters();
                pstmt.setInt(1, signup_id);
                rs = pstmt.executeQuery();

                if (rs.next()) {

                   slotParms.req_datetime = rs.getString( "req_datetime" );
                   slotParms.wait_list_id = rs.getInt( "wait_list_id" );
                   slotParms.dd = rs.getInt( "dd" );
                   slotParms.mm = rs.getInt( "mm" );
                   slotParms.yy = rs.getInt( "yy" );
                   slotParms.date = rs.getInt( "date" );
                   slotParms.time = rs.getInt( "time" );
                   slotParms.course_id = rs.getInt( "course_id" );
                   slotParms.course = rs.getString( "courseName" );
                   slotParms.last_user = rs.getString( "in_use_by" );
                   slotParms.in_use = (slotParms.last_user.equals("") || slotParms.last_user.equalsIgnoreCase( user )) ? 0 : 1; //rs.getInt( "in_use" );
                   slotParms.hideNotes = rs.getInt( "hideNotes" );
                   slotParms.notes = rs.getString( "notes" );
                   slotParms.converted = rs.getInt( "converted" );
                   slotParms.orig_by = rs.getString( "created_by" );
                   slotParms.orig_at = rs.getString( "created_at" );
                   slotParms.day = rs.getString( "day_name" );
                }

                out.println("<!-- B4: in_use=" + in_use + " | slotParms.in_use="+ slotParms.in_use + " -->");
                
                in_use = slotParms.in_use;
                
                // if in use by self then allow
                //if (!slotParms.last_user.equalsIgnoreCase( user )) in_use = 1;
                        
                pstmt = con.prepareStatement (
                   "SELECT * " +
                   "FROM wait_list_signups_players " +
                   "WHERE wait_list_signup_id = ? " +
                   "ORDER BY pos");

                pstmt.clearParameters();
                pstmt.setInt(1, signup_id);
                rs = pstmt.executeQuery();

                if (rs.next()) {

                    slotParms.player1 = rs.getString( "player_name" );
                    slotParms.user1 = rs.getString( "username" );
                    slotParms.p1cw = rs.getString( "cw" );
                    slotParms.p91 = rs.getInt( "9hole" );
                    slotParms.players = 1;
                }
                
                if (rs.next()) {

                    slotParms.player2 = rs.getString( "player_name" );
                    slotParms.user2 = rs.getString( "username" );
                    slotParms.p2cw = rs.getString( "cw" );
                    slotParms.p92 = rs.getInt( "9hole" );
                    slotParms.players = 2;
                }
                
                if (rs.next()) {

                    slotParms.player3 = rs.getString( "player_name" );
                    slotParms.user3 = rs.getString( "username" );
                    slotParms.p3cw = rs.getString( "cw" );
                    slotParms.p93 = rs.getInt( "9hole" );
                    slotParms.players = 3;
                }
                
                if (rs.next()) {

                    slotParms.player4 = rs.getString( "player_name" );
                    slotParms.user4 = rs.getString( "username" );
                    slotParms.p4cw = rs.getString( "cw" );
                    slotParms.p94 = rs.getInt( "9hole" );
                    slotParms.players = 4;
                }
                
                if (rs.next()) {

                    slotParms.player5 = rs.getString( "player_name" );
                    slotParms.user5 = rs.getString( "username" );
                    slotParms.p5cw = rs.getString( "cw" );
                    slotParms.p95 = rs.getInt( "9hole" );
                    slotParms.players = 5;
                }
                
            } else {
                out.println("<!-- Unable to make busy -->");
            }// end if count > 0

            pstmt.close();

          }
          catch (SQLException e) {

             throw new Exception("Error checking in-use - verifyWLSlot.checkInUse - SQL Exception: " + e.getMessage());
          }
          catch (Exception e) {

             throw new Exception("Error checking in-use - verifyWLSlot.checkInUse - Exception: " + e.getMessage());
          }
        
       } // end if 

   return(in_use);
 }

}
