/***************************************************************************************
 *   MemberHelper:  This utility class contains methods to get information for gathering
 *                 information necessary to create and edit members
 *
 *
 *   created: 10/03/2003   jag
 *
 *
 *   last updated:
 *
 *            03/15/2007 Add hdcp club & association numbers
 *            10/06/2006 pts modified email retrieving query to only return if _bounced flags are 0
 *             9/02/2005 rdp verify the email addresses before adding to list
 *             1/24/2005 rdp changed cub db table from club2 to club5 for ver 5
 *             1/11/2005 jag added method to get all email addresses for a particular user
 *             1/20/2004 jag added method to query database for member names
 *
 *
 *
 ***************************************************************************************
 */

package com.foretees.member;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.http.*;


import com.foretees.client.attribute.Checkbox;
import com.foretees.client.attribute.SelectionList;
import com.foretees.client.action.ActionHelper;
import com.foretees.client.ScriptHelper;
import com.foretees.client.form.FormModel;
import com.foretees.client.layout.LayoutModel;
import com.foretees.member.Member;
import com.foretees.client.table.RowModel;
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.FeedBack;


/**
 ***************************************************************************************
 *
 *  This helper class contains methods for commonly used functions related to
 *  creating and editing members.
 *
 ***************************************************************************************
 **/

public class MemberHelper {

  public static final int NUM_MEMBER_TYPES = 24;
  public static final int NUM_MEMBERSHIPS = 24;
  public static final int NUM_HOTEL_GUEST_TYPES = 36;
  public static final int NUM_GUEST_TYPES = 36;
  public static final int NUM_MEMBER_SUB_TYPES = 8;      // for Hazeltine Natl - Custom


  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the  hdcp club numbers for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/
  
  public static SelectionList getHdcpClubNums(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] clubNums = new String [20];

    if (type == null || type.equals("")) type = member.HDCP_CLUB_NUM;

    SelectionList sl = new SelectionList(type, member.HDCP_CLUB_NUM_LABEL, true);
    boolean isSelected = false;

    ResultSet rs = stmtc.executeQuery("SELECT * FROM hdcp_club_num");

    sl.addOption("", "0", isSelected);
    
    while (rs.next()) {

          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( rs.getString("hdcp_club_num_id") )) isSelected = true;
          sl.addOption(rs.getString("club_num"), rs.getString("hdcp_club_num_id"), isSelected);
        
    }

    stmtc.close();

    return sl;

  }
  
  
  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the hdcp club association numbers for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/
  
  public static SelectionList getHdcpAssocNums(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] assocNums = new String [20];

    if (type == null || type.equals("")) type = member.HDCP_ASSOC_NUM;

    SelectionList sl = new SelectionList(type, member.HDCP_ASSOC_NUM_LABEL, true);
    boolean isSelected = false;

    ResultSet rs = stmtc.executeQuery("SELECT * FROM hdcp_assoc_num");

    sl.addOption("", "0", isSelected);
          
    while (rs.next()) {

          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( rs.getString("hdcp_assoc_num_id") )) isSelected = true;
          sl.addOption(rs.getString("assoc_num"), rs.getString("hdcp_assoc_num_id"), isSelected);
        
    }

    stmtc.close();

    return sl;

  }
  
  
  public static SelectionList getGenderTypes(String selected, String type) {
        
    Member member = new Member();
    
    if (selected == null) selected = "";
    if (type == null || type.equals("")) type = member.GENDER;
    
    SelectionList sl = new SelectionList(type, member.GENDER_LABEL, true);
    
    sl.addOption("", "0", selected.equals(""));
    sl.addOption("M", "M", selected.equals("M"));
    sl.addOption("F", "F", selected.equals("F"));
    
    return sl;
    
  }
  
  
  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the member types for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberTypes(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] memType = new String [NUM_MEMBER_TYPES];     // member types

    if (type == null || type.equals("")) type = member.MEM_TYPE;

    SelectionList sl = new SelectionList(type, member.MEM_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    ResultSet rs = stmtc.executeQuery("SELECT mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
                                      "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
                                      "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24 " +
                              "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      for (int i=0; i<NUM_MEMBER_TYPES; i++) {
        memType[i] = rs.getString(i+1);
        if (memType[i] != null && !(memType[i].equals("")))
        {
          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( memType[i] )) isSelected = true;
          sl.addOption(memType[i], memType[i], isSelected);
        }
      }
    }

    stmtc.close();

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the member sub-types for Hazeltine Natl
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberSubTypes(Connection con, String selected, String type) throws SQLException {


    if (selected == null) selected = "";

    Member member = new Member();
    String [] memSubType = new String [NUM_MEMBER_SUB_TYPES];     // member sub-types

    if (type == null || type.equals("")) type = member.MEM_SUB_TYPE;

    SelectionList sl = new SelectionList(type, member.MEM_SUB_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    memSubType[0] = "";

       isSelected = false;
       sl.addOption(memSubType[0], memSubType[0], isSelected);

    memSubType[1] = "After Hours";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[1] )) isSelected = true;
       sl.addOption(memSubType[1], memSubType[1], isSelected);

    memSubType[2] = "18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[2] )) isSelected = true;
       sl.addOption(memSubType[2], memSubType[2], isSelected);

    memSubType[3] = "9 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[3] )) isSelected = true;
       sl.addOption(memSubType[3], memSubType[3], isSelected);

    memSubType[4] = "AH-18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[4] )) isSelected = true;
       sl.addOption(memSubType[4], memSubType[4], isSelected);

    memSubType[5] = "AH-9 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[5] )) isSelected = true;
       sl.addOption(memSubType[5], memSubType[5], isSelected);

    memSubType[6] = "AH-9/18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[6] )) isSelected = true;
       sl.addOption(memSubType[6], memSubType[6], isSelected);

    memSubType[7] = "9/18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[7] )) isSelected = true;
       sl.addOption(memSubType[7], memSubType[7], isSelected);

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the membership types for the club
  *
  * @param sl the selection list that contains the membership types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberShips(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();
    String [] memship = new String [NUM_MEMBERSHIPS];     // member types

    if (type == null || type.equals("")) type = member.MEMSHIP_TYPE;

    SelectionList sl = new SelectionList(type, member.MEMSHIP_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    ResultSet rs = stmtc.executeQuery("SELECT " +
                              "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
                                      "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
                                      "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24 " +
                              "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      for (int i=0; i<NUM_MEMBERSHIPS; i++) {
        memship[i] = rs.getString(i+1);
        if (memship[i] != null && !(memship[i].equals("")))
        {
          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( memship[i] )) isSelected = true;
          sl.addOption(memship[i], memship[i], isSelected);
        }
      }
    }

    stmtc.close();

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list that contains all the transportation options
  * available for the club
  *
  * @param con the database connection to use to query for the member types and membership types
  * @param selected the string containing the selected transportation option
  *
  ***************************************************************************************
  **/

  public static SelectionList getWalkCartOptions(Connection con, String selected) throws Exception
  {

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();

    //
    //  parm block to hold the course parameters
    //
    parmCourse parmc = new parmCourse();          // allocate a parm block

    //
    //  Get the walk/cart options available for this club
    //
    getParms.getCourseTrans(con, parmc);



    SelectionList walkCart = new SelectionList(member.WALK_CART, member.WALK_CART_LABEL, false);
    boolean isSelected = false;

    for (int i=0; i<16; i++) {        // get all c/w options (tmodea = acronym, tmode = full name)

       if (!parmc.tmodea[i].equals( "" )) {

          isSelected = selected.equals( parmc.tmodea[i] );
          walkCart.addOption(parmc.tmode[i], parmc.tmodea[i], isSelected);
       }
    }

    return walkCart;
  }


  /**
  ***************************************************************************************
  *
  * This method will return a selection list that contains all the guest types available
  * for the club
  *
  * @param con the database connection to use to query for the member types and membership types
  * @param selected the string array containing all the values selected for this hotel user
  ***************************************************************************************
  **/

  public static RowModel getGuestTypes(Connection con, String[] selected) throws SQLException
  {

    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

    // Get Guest Types from the club db
    guestTypes = getGuestTypesFromDB(con);

    RowModel guests = new RowModel();
    guests.setId("guestRow");

    if (guestTypes.length > 0) {

      boolean isSelected = false;

      for (int i=0; i<NUM_GUEST_TYPES; i++)
      {
        String type = guestTypes[i];
        if (type != null && !(type.equals("")))
        {
          isSelected = isSelectedGuestType(selected, type);

          Checkbox cb = new Checkbox((Member.GUEST_TYPE_REQ + (i+1)), type, type, isSelected);
          guests.add(cb, "frm");
        }
      }

    }
    return guests;
  }


  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the selected values
  * @param theValue the value to test if selected
  ***************************************************************************************
  **/

  private static boolean isSelectedGuestType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the selected values
  * @param theValue the value to test if selected
  ***************************************************************************************
  **/

  private static boolean isSelectedMemType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the string array containing the selected values
  * @param theValue the value to scan the string array with
  ***************************************************************************************
  **/

  private static boolean isSelectedMShipType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method will take all of the selected guest types and set them as values in the
  * sql statement (for Hotel Users)
  *
  * @param req the http request object reference 
  * @param stmt reference to the stmt object that is being manipulated by this method
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static void setGuestTypesInStatement(HttpServletRequest req,  PreparedStatement stmt, PrintWriter out) throws SQLException
  {

    int colEntryStart = 13;      // first guest type column in table

    for (int i=0; i<NUM_HOTEL_GUEST_TYPES; i++)
    {

        String type = req.getParameter(Member.GUEST_TYPE_REQ + (i + 1));

        if (type != null && !(type.equals("")))
        {
          stmt.setString(i+colEntryStart, type);
        }
        else
        {
          stmt.setString(i+colEntryStart, "");
        }

    }

  }

  /**
  ***************************************************************************************
  *
  * This method will get all the guest types for a given club
  *
  * @param con the database connection
  *
  ***************************************************************************************
  **/

  private static String[] getGuestTypesFromDB (Connection con) throws SQLException
  {

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

   // Get Guest Types from the club db
    Statement stmtc = con.createStatement();        // create a statement
    ResultSet rs = stmtc.executeQuery("SELECT guest1, guest2, guest3, guest4, guest5, guest6, guest7, guest8, " +
                            "guest9, guest10, guest11, guest12, guest13, guest14, guest15, guest16, guest17, " +
                            "guest18, guest19, guest20, guest21, guest22, guest23, guest24, guest25, guest26, " +
                            "guest27, guest28, guest29, guest30, guest31, guest32, guest33, guest34, guest35, " +
                            "guest36 " +
                            "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      guestTypes[0] = rs.getString(1);
      guestTypes[1] = rs.getString(2);
      guestTypes[2] = rs.getString(3);
      guestTypes[3] = rs.getString(4);
      guestTypes[4] = rs.getString(5);
      guestTypes[5] = rs.getString(6);
      guestTypes[6] = rs.getString(7);
      guestTypes[7] = rs.getString(8);
      guestTypes[8] = rs.getString(9);
      guestTypes[9] = rs.getString(10);
      guestTypes[10] = rs.getString(11);
      guestTypes[11] = rs.getString(12);
      guestTypes[12] = rs.getString(13);
      guestTypes[13] = rs.getString(14);
      guestTypes[14] = rs.getString(15);
      guestTypes[15] = rs.getString(16);
      guestTypes[16] = rs.getString(17);
      guestTypes[17] = rs.getString(18);
      guestTypes[18] = rs.getString(19);
      guestTypes[19] = rs.getString(20);
      guestTypes[20] = rs.getString(21);
      guestTypes[21] = rs.getString(22);
      guestTypes[22] = rs.getString(23);
      guestTypes[23] = rs.getString(24);
      guestTypes[24] = rs.getString(25);
      guestTypes[25] = rs.getString(26);
      guestTypes[26] = rs.getString(27);
      guestTypes[27] = rs.getString(28);
      guestTypes[28] = rs.getString(29);
      guestTypes[29] = rs.getString(30);
      guestTypes[30] = rs.getString(31);
      guestTypes[31] = rs.getString(32);
      guestTypes[32] = rs.getString(33);
      guestTypes[33] = rs.getString(34);
      guestTypes[34] = rs.getString(35);
      guestTypes[35] = rs.getString(36);
    }

    stmtc.close();

    return guestTypes;
  }


  /**
  ***************************************************************************************
  *
  * This method will add the guest types to the form provided
  *
  * @param con the database connection
  * @param selected the string array containing the guest types currently selected
  * @param form the form to be updated
  *
  ***************************************************************************************
  **/

  public static void addGuestTypesToForm(Connection con, String[] selected, FormModel form) throws SQLException
  {

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

    if (con == null) throw new SQLException("Invalid connection");

    // Get Guest Types from the club db
    guestTypes = getGuestTypesFromDB(con);

    RowModel guests1 = new RowModel();
    RowModel guests2 = new RowModel();
    RowModel guests3 = new RowModel();
    RowModel guests4 = new RowModel();
    RowModel guests5 = new RowModel();
    RowModel guests6 = new RowModel();
    guests1.setId("guestRow1");
    guests2.setId("guestRow2");
    guests3.setId("guestRow3");
    guests4.setId("guestRow4");
    guests5.setId("guestRow5");
    guests6.setId("guestRow6");

    LayoutModel layout = new LayoutModel();
    layout.setId("guestTypes");
    layout.setNumColumns(form.getNumColumns());


    if (guestTypes.length > 0) {

      boolean isSelected = false;

      for (int i=0; i<NUM_GUEST_TYPES; i++)
      {
        String type = guestTypes[i];
        if (type != null && !(type.equals("")))
        {
          isSelected = isSelectedGuestType(selected, type);

          Checkbox cb = new Checkbox((Member.GUEST_TYPE_REQ + (i+1)), type, type, isSelected);

          if (i < NUM_GUEST_TYPES - 30) {

            guests1.add(cb, "frm");

          } else {

            if (i < NUM_GUEST_TYPES - 24) {

              guests2.add(cb, "frm");

            } else {

              if (i < NUM_GUEST_TYPES - 18) {

                guests3.add(cb, "frm");

              } else {

                if (i < NUM_GUEST_TYPES - 12) {

                  guests4.add(cb, "frm");

                } else {

                  if (i < NUM_GUEST_TYPES - 6) {

                    guests5.add(cb, "frm");

                  } else {

                    guests6.add(cb, "frm");
                  }
                }
              }
            }
          }
        }   // end of IF type
      }     // end of FOR loop

    }      // end of IF length > 0

    layout.addRow(guests1);

    if (guests2.size() > 0)
    {
      layout.addRow(guests2);
    }
    if (guests3.size() > 0)
    {
      layout.addRow(guests3);
    }
    if (guests4.size() > 0)
    {
      layout.addRow(guests4);
    }
    if (guests5.size() > 0)
    {
      layout.addRow(guests5);
    }
    if (guests6.size() > 0)
    {
      layout.addRow(guests6);
    }

    form.addRow(layout);


  }  // end of addGuestTypesToForm

  /**
  ***************************************************************************************
  *
  * This method will retrieve members from the member database based on the letter provided.
  * if the letter passed in is null or empty, all members will be returned.
  *
  * @param con the database connection
  * @param theLetter the letter to use for the query
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static SelectionList queryMembersWithEmailAddresses(Connection con, String theLetter, PrintWriter out) throws SQLException
  {

    String letter = theLetter;

    if (letter.equalsIgnoreCase( ActionHelper.VIEW_ALL )) {

      letter = "%";        // all names
    } else {

       letter = letter + "%";
    }

    PreparedStatement stmt = null;
    SelectionList names = new SelectionList("listOfNames", "Name List", false);


    try {                            // Get all columns from member table for names requested

      stmt = con.prepareStatement (
               "SELECT * FROM member2b WHERE name_last LIKE ? AND (email NOT LIKE ? OR email2 NOT LIKE ?) ORDER BY name_last, name_first, name_mi");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, letter);            // put the parm in stmt
      stmt.setString(2, "");
      stmt.setString(3, "");
      ResultSet rs = stmt.executeQuery();            // execute the prepared stmt


      while(rs.next()) {


        String lastname = rs.getString("name_last");
        String firstname = rs.getString("name_first");
        String middleinitial = rs.getString("name_mi");

        //escape special characters in the username
        String username = rs.getString("username");
        String escName = ScriptHelper.escapeSpecialCharacters(username);

        String displayName = lastname + ", " + firstname + " " + middleinitial;

        names.addOption(displayName, username, false);
      }
    }
    catch (SQLException exc) {

        throw exc;
    }
    finally{
       stmt.close();
    }

    return names;

  }

  /**
  ***************************************************************************************
  *
  * This method will return the display name for the specified user.
  *
  * @param con the database connection
  * @param theUserName the username for the query
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static String getMemberDisplayName(Connection con, String theUserName, PrintWriter out) throws SQLException
  {

    PreparedStatement stmt = null;
    String displayName = "";

    try {                            // Get all columns from member table for names requested

      stmt = con.prepareStatement (
               "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, theUserName);
      ResultSet rs = stmt.executeQuery();            // execute the prepared stmt

      while(rs.next()) {


        String lastname = rs.getString("name_last");
        String firstname = rs.getString("name_first");
        String middleinitial = rs.getString("name_mi");

        displayName = lastname + ", " + firstname + " " + middleinitial;

      }
    }
    catch (SQLException exc) {

        throw exc;
    }
    finally{
       stmt.close();
    }

    return displayName;

  }

  /**
  ***************************************************************************************
  *
  * This method will return true if the specified user has an email address.
  *
  * @param username the username for the query
  * @param con the database connection reference
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static boolean hasEmailAddress(String username, Connection con, PrintWriter out)
  {
      boolean hasEmailAddress = false;
      try
      {
            //"SELECT email, email2 FROM member2b WHERE username = ?"
        PreparedStatement stmt = con.prepareStatement (
            "SELECT (" +
                "SELECT email FROM member2b WHERE username = ? AND email_bounced = 0" +
            ") AS email1, (" +
                "SELECT email2 FROM member2b WHERE username = ? AND email2_bounced = 0" +
            ") AS email2");

        stmt.clearParameters();
        stmt.setString(1, username);
        stmt.setString(2, username);
        ResultSet mrs = stmt.executeQuery();

        if (mrs.next())
        {

          String email1 = mrs.getString("email1");
          String email2 = mrs.getString("email2");

          if ( (email1 != null && !(email1.equals(""))) || (email2 != null && !(email2.equals(""))) ) {

             hasEmailAddress = true;
          }
        }

        stmt.close();
      }
      catch (Exception exc)
      {
      }

      return hasEmailAddress;
  }

  /**
  ***************************************************************************************
  *
  * This method will return one email address for the given user.  IF the email one has a value
  * it will return that one.  If it doesn't have a value but the email2 does, it will return that value
  *
  * @param con the database connection
  * @param theUserName the username for the query
  *
  ***************************************************************************************
  **/

  public static String getEmailAddress(String username, Connection con, PrintWriter out)
  {
    ArrayList emailAddresses = getEmailAddresses (username, con, out);
    String email = "";
    int count = 0;
    while (count < emailAddresses.size() && email.equals(""))
    {
      email = (String)emailAddresses.get(count);
      count++;
    }

    return email;
  }

  /**
  ***************************************************************************************
  *
  * This method will return the email addresses for the given user.
  *
  * @param con the database connection
  * @param theUserName the username for the query
  *
  ***************************************************************************************
  **/

  public static ArrayList getEmailAddresses(String username, Connection con, PrintWriter out)
  {
    PreparedStatement stmt = null;
    ResultSet mrs = null;
    ArrayList email = new ArrayList();

    Member member = new Member();

    String emailAddress = "";


    try
    {
      if (username.startsWith( "proshop" )) {            // if proshop user

         stmt = con.prepareStatement (
              "SELECT email FROM club5 WHERE clubName != ''");

         stmt.clearParameters();                   // clear the parms
         mrs = stmt.executeQuery();      // execute the prepared stmt

         if (mrs.next())
         {
           email.add(mrs.getString("email"));
         }

         stmt.close();

      } else {

              //"SELECT email, email2 FROM member2b WHERE username = ?"
         stmt = con.prepareStatement (
                 "SELECT (" +
                    "SELECT email FROM member2b WHERE username = ? AND email_bounced = 0" +
                 ") AS email1, (" +
                    "SELECT email2 FROM member2b WHERE username = ? AND email2_bounced = 0" +
                 ") AS email2");

         stmt.clearParameters();                   // clear the parms
         stmt.setString(1, username);             // put the parm in stmt
         stmt.setString(2, username);             // put the parm in stmt
         mrs = stmt.executeQuery();      // execute the prepared stmt

         if (mrs.next())
         {
           
           emailAddress = mrs.getString("email1");     // get email address

           if (!emailAddress.equals( "" ) && emailAddress != null) {     // if present
             
              FeedBack feedback = (member.isEmailValid(emailAddress));   // verify the address

              if (feedback.isPositive()) {          // if valid

                 email.add(emailAddress);           // add it
              }
           }

           emailAddress = mrs.getString("email2");     // get email address #2

           if (!emailAddress.equals( "" ) && emailAddress != null) {     // if present

              FeedBack feedback = (member.isEmailValid(emailAddress));   // verify the address

              if (feedback.isPositive()) {          // if valid

                 email.add(emailAddress);           // add it
              }
           }

         } // end if rs

         stmt.close();
      }
    }
    catch (Exception exc)
    {
    }

    return email;
  }


}
