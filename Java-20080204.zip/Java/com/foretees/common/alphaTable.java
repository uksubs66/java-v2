/***************************************************************************************
 *   alphaTable:  This servlet will output the member name selection tables.
 *
 *
 *   created:  12/09/2004   Bob P.
 *
 *
 *   last updated:
 *
 *       9/18/07   Congressional - sort member names by last, first, mi (case 1181)
 *       9/18/07   Belle Haven CC - display the member number next to each member name (case 1253).
 *       8/28/07   Tavistock CC - display the member number next to each member name (case 1232).
 *       8/28/07   Mirasol CC - display the member number next to each member name (case 1227).
 *       7/19/07   Do not include members that are 'excluded' (new billable flag in member2b).
 *       6/01/07   Los Coyotes - remove this - change the order that names are listed.
 *       5/31/07   Los Coyotes - change the order that names are listed.
 *       5/24/07   Blackhawk CC (CA) - display the member number next to each member name (case 1177).
 *       5/11/07   CC of Virginia - do custom name list like Medinah (case 1166).
 *       4/27/07   Muirfield - display the member number next to each member name (case 1145).
 *       4/27/07   Congressional CC - display the member number next to each member name (case 1153).
 *       4/20/07   Los Coyotes - add gender to end of name for display - nameList (case #1120).
 *       4/09/07   Do not show the X under guestList for lotteries
 *       4/06/07   Do not include members that are inactive (new inact flag in member2b).
 *       3/28/07   CC of Virginia - add custom to add mnum to end of name for display only.
 *       2/15/07   Updated nameList method to accept new boolean ghinOnly for only showing members w/ ghin #
 *       2/07/07   Change Greeley CC to Fort Collins (they share).
 *       1/16/07   Greeley CC - add custom to add mnum to end of name for display only.
 *       1/11/07   Royal Oaks Houston - add custom to add mnum to end of name for display only.
 *       9/11/06   Wellesley - add custom to force 'Tourney Guest' as the only guest type.
 *       7/18/06   nameList method - do custom name list for Oswego Lake like we did for Medinah.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;


public class alphaTable {

   private static String rev = ProcessConstants.REV;


/**
 //************************************************************************
 //
 //  Output Table for Member Name Selection
 //
 //      called by:  Member_slot
 //                  Member_lott         (not yet)
 //                  Member_evntSignUp   (not yet)
 //                  Member_buddy        (not yet)
 //
 //                  Proshop_slot
 //                  Proshop_lott
 //                  Proshop_evntSignUp
 //
 //************************************************************************
 **/

 public static void getTable(PrintWriter out, String user) {


   out.println("<table border=\"1\" bgcolor=\"#F5F5DC\">");
      out.println("<tr bgcolor=\"#336633\">");
         out.println("<td colspan=\"6\" align=\"center\">");
            out.println("<font color=\"#FFFFFF\" size=\"2\">");
            out.println("<b>Member List</b>");
            out.println("</font></td>");
      out.println("</tr><tr>");
         out.println("<input type=\"hidden\" name=\"letter\" value=\"\">");  // empty for script to complete
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterA.jpg\" border=\"0\" onClick=\"subletter('A')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterB.jpg\" border=\"0\" onClick=\"subletter('B')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterC.jpg\" border=\"0\" onClick=\"subletter('C')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterD.jpg\" border=\"0\" onClick=\"subletter('D')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterE.jpg\" border=\"0\" onClick=\"subletter('E')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterF.jpg\" border=\"0\" onClick=\"subletter('F')\"></td>");
      out.println("</tr><tr>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterG.jpg\" border=\"0\" onClick=\"subletter('G')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterH.jpg\" border=\"0\" onClick=\"subletter('H')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterI.jpg\" border=\"0\" onClick=\"subletter('I')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterJ.jpg\" border=\"0\" onClick=\"subletter('J')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterK.jpg\" border=\"0\" onClick=\"subletter('K')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterL.jpg\" border=\"0\" onClick=\"subletter('L')\"></td>");
      out.println("</tr><tr>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterM.jpg\" border=\"0\" onClick=\"subletter('M')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterN.jpg\" border=\"0\" onClick=\"subletter('N')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterO.jpg\" border=\"0\" onClick=\"subletter('O')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterP.jpg\" border=\"0\" onClick=\"subletter('P')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterQ.jpg\" border=\"0\" onClick=\"subletter('Q')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterR.jpg\" border=\"0\" onClick=\"subletter('R')\"></td>");
      out.println("</tr><tr>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterS.jpg\" border=\"0\" onClick=\"subletter('S')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterT.jpg\" border=\"0\" onClick=\"subletter('T')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterU.jpg\" border=\"0\" onClick=\"subletter('U')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterV.jpg\" border=\"0\" onClick=\"subletter('V')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterW.jpg\" border=\"0\" onClick=\"subletter('W')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterX.jpg\" border=\"0\" onClick=\"subletter('X')\"></td>");
      out.println("</tr><tr>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterY.jpg\" border=\"0\" onClick=\"subletter('Y')\"></td>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/letterZ.jpg\" border=\"0\" onClick=\"subletter('Z')\"></td>");
              
         if (user.startsWith( "proshop" )) {
            out.println("<td align=\"center\" colspan=\"4\">");
            out.println("<img src=\"/" +rev+ "/images/letterAll.jpg\" border=\"0\" onClick=\"subletter('List All')\"></td>");

         } else {

            if (user.equals( "buddy" )) {       // if from Member_buddy

               out.println("<td align=\"center\"></td>");
               out.println("<td align=\"center\"></td>");
               out.println("<td align=\"center\"></td>");
               out.println("<td align=\"center\"></td>");

            } else {                            // a member

               out.println("<td align=\"center\" colspan=\"4\">");
               out.println("<img src=\"/" +rev+ "/images/letterPL.jpg\" border=\"0\" onClick=\"subletter('Partner List')\"></td>");
            }
         }
      out.println("</tr>");
      out.println("</table>");
        
 }       // end of getTable


/**
 //************************************************************************
 //
 //  Output Table for Member Class Selection
 //
 //      called by: 
 //                  Proshop_slot
 //                  Proshop_slotm
 //                  Proshop_lott
 //                  Proshop_evntSignUp
 //
 //************************************************************************
 **/

 public static void typeOptions(String club, String mshipOpt, String mtypeOpt, PrintWriter out, Connection con) {


   mTypeArrays mArrays = new mTypeArrays();     // setup for mship and mtype arrays 

   int maxMems = mArrays.MAX_Mems;
   int maxMships = mArrays.MAX_Mships;
   int i = 0;


   try {

      //
      //  Get the mship types and mtypes for this club
      //
      mArrays = getClub.getMtypes(mArrays, con);         // skip it all if this fails

      //
      //  Now build a table with the drop-down box selections
      //
      out.println("<br><table border=\"1\" bgcolor=\"#F5F5DC\">");
      out.println("<tr bgcolor=\"#336633\">");
      out.println("<td colspan=\"6\" align=\"center\">");
      out.println("<font color=\"#FFFFFF\" size=\"2\">");
      out.println("<b>By Member Class</b>");
      out.println("</font></td>");
      out.println("</tr>");

      out.println("<tr>");
      out.println("<td align=\"left\">");
      out.println("<font size=\"1\">");
      out.println("Membership: ");
//           out.println("<select size=\"1\" name=\"mshipopt\" onChange=\"document.playerform.submit()\">");
         out.println("<select size=\"1\" name=\"mshipopt\" onChange=\"this.form.submit()\">");
         if (mshipOpt.equals( "ALL" )) {
            out.println("<option selected value=\"ALL\">ALL</option>");
         } else {
            out.println("<option value=\"ALL\">ALL</option>");
         }
         i = 0;
         while (i < maxMships && !mArrays.mship[i].equals( "" )) {

            if (mshipOpt.equals( mArrays.mship[i] )) {
               out.println("<option selected value=\"" +mArrays.mship[i]+ "\">" +mArrays.mship[i]+ "</option>");
            } else {
               out.println("<option value=\"" +mArrays.mship[i]+ "\">" +mArrays.mship[i]+ "</option>");
            }
            i++;
         }
         out.println("</select>");
      out.println("</font></td>");
      out.println("</tr>");

      out.println("<tr>");
      out.println("<td align=\"left\">");
      out.println("<font size=\"1\">");

      out.println("Member Type: ");
//           out.println("<select size=\"1\" name=\"mtypeopt\" onChange=\"document.playerform.submit()\">");
         out.println("<select size=\"1\" name=\"mtypeopt\" onChange=\"this.form.submit()\">");
         if (mtypeOpt.equals( "ALL" )) {
            out.println("<option selected value=\"ALL\">ALL</option>");
         } else {
            out.println("<option value=\"ALL\">ALL</option>");
         }
         i = 0;
         while (i < maxMems && !mArrays.mem[i].equals( "" )) {

            if (mtypeOpt.equals( mArrays.mem[i] )) {
               out.println("<option selected value=\"" +mArrays.mem[i]+ "\">" +mArrays.mem[i]+ "</option>");
            } else {
               out.println("<option value=\"" +mArrays.mem[i]+ "\">" +mArrays.mem[i]+ "</option>");
            }
            i++;
         }
         out.println("</select>");
      out.println("</font></td>");
      out.println("</tr>");
      out.println("</table>");

   }
   catch (Exception e) {
   }        

 }          // end of typeOptions method


/**
 //************************************************************************
 //
 //  Output Table for Member Name List
 //
 //      called by:
 //                  Proshop_slot
 //                  Proshop_slotm
 //                  Proshop_lott
 //                  Proshop_evntSignUp
 //
 //************************************************************************
 **/

 public static void nameList(String club, String letter, String mshipOpt, String mtypeOpt, boolean ghinOnly, 
                             parmCourse parmc, PrintWriter out, Connection con) {


String err= "0";

   ResultSet rs = null;

   String first = "";
   String mid = "";
   String last = "";
   String name = "";
   String wname = "";
   String dname = "";
   String mtype = "";
   String mship = "";
   String mnum = "";
   String lastMnum = "";
   String wc = "";

   String [] mtypeA = new String [20];            // arrays to hold family names to put in order (Medinah)
   String [] mNameA = new String [20];
   String [] dNameA = new String [20];

   int i = 0;
   int indexM = 0;

   // include the dynamic search box scripts
   out.println("<script type=\"text/javascript\" src=\"/" +rev+ "/dyn-search.js\"></script>");
     
   out.println("<table border=\"1\" width=\"140\" bgcolor=\"#F5F5DC\" valign=\"top\">");      // name list
   out.println("<tr><td align=\"center\" bgcolor=\"#336633\">");
   out.println("<font color=\"#FFFFFF\" size=\"2\">");
   out.println("<b>Name List</b>");
   out.println("</font></td>");
   out.println("</tr>");
   
   // output dynamic search box
   out.println("<tr>");
   out.println("<td align=\"center\">");
   out.println("<input type=text name=DYN_search onkeyup=\"DYN_triggerChange()\" onclick=\"this.select()\" value=\"Quick Search Box\">");
   out.println("</td></tr>");
   
   out.println("<tr><td align=\"center\">");
   out.println("<font size=\"2\">");
   out.println("Click on name to add");
   out.println("</font></td></tr>");

   try {

      PreparedStatement stmt2 = null;
        
      String orderby = "name_last, memNum, name_first, name_mi";      // normal order of names
        
      if (club.equals( "congressional" )) {
  
        orderby = "name_last, name_first, name_mi";                  // special order for Congressional
      }
      
    //  if (club.equals( "loscoyotes" )) {
  
    //     orderby = "name_last, name_first, name_mi";                  // special order for Los Coyotes
    //  }


      if ((mshipOpt.equals( "" ) || mshipOpt.equals( "ALL" ) || mshipOpt == null) &&
          (mtypeOpt.equals( "" ) || mtypeOpt.equals( "ALL" ) || mtypeOpt == null)) {   // if both are ALL or not provided

         stmt2 = con.prepareStatement (
               "SELECT name_last, name_first, name_mi, m_ship, m_type, wc, memNum FROM member2b " +
               "WHERE " + ((ghinOnly) ? "ghin <> '' AND" : "") + " name_last LIKE ? AND inact = 0 AND billable = 1 " +
               "ORDER BY " +orderby);

         stmt2.clearParameters();
         stmt2.setString(1, letter);

      } else {      // at least one is specified

         if (!mshipOpt.equals( "" ) && !mshipOpt.equals( "ALL" ) && mshipOpt != null &&
             !mtypeOpt.equals( "" ) && !mtypeOpt.equals( "ALL" ) && mtypeOpt != null) {   // if both were specified

            stmt2 = con.prepareStatement (
                  "SELECT name_last, name_first, name_mi, m_ship, m_type, wc, memNum FROM member2b " +
                  "WHERE " + ((ghinOnly) ? "ghin <> '' AND" : "") + " name_last LIKE ? AND m_ship = ? AND m_type = ? AND inact = 0 AND billable = 1 " +
                  "ORDER BY " +orderby);

            stmt2.clearParameters();
            stmt2.setString(1, letter);
            stmt2.setString(2, mshipOpt);
            stmt2.setString(3, mtypeOpt);

         } else {      // only one is specified

            if (!mshipOpt.equals( "" ) && !mshipOpt.equals( "ALL" ) && mshipOpt != null) {     // its mship

               stmt2 = con.prepareStatement (
                     "SELECT name_last, name_first, name_mi, m_ship, m_type, wc, memNum FROM member2b " +
                     "WHERE " + ((ghinOnly) ? "ghin <> '' AND" : "") + " name_last LIKE ? AND m_ship = ? AND inact = 0 AND billable = 1 " +
                     "ORDER BY " +orderby);

               stmt2.clearParameters();
               stmt2.setString(1, letter);
               stmt2.setString(2, mshipOpt);

            } else {             // its mtype

               stmt2 = con.prepareStatement (
                     "SELECT name_last, name_first, name_mi, m_ship, m_type, wc, memNum FROM member2b " +
                     "WHERE " + ((ghinOnly) ? "ghin <> '' AND" : "") + " name_last LIKE ? AND m_type = ? AND inact = 0 AND billable = 1 " +
                     "ORDER BY " +orderby);

               stmt2.clearParameters();               // clear the parms
               stmt2.setString(1, letter);            // put the parm in stmt
               stmt2.setString(2, mtypeOpt);
            }
         }
      }

      rs = stmt2.executeQuery();             // execute the prepared stmt

      out.println("<tr><td align=\"left\"><font size=\"2\">");
      out.println("<div id=\"awmobject1\">");
      out.println("<select size=\"25\" name=\"bname\" onClick=\"movename(this.form.bname.value)\" style=\"cursor:hand\">");
      
      while(rs.next()) {
          
         last = rs.getString(1);
         first = rs.getString(2);
         mid = rs.getString(3);
         mship = rs.getString(4);
         mtype = rs.getString(5);
         wc = rs.getString(6);           // walk/cart preference
         mnum = rs.getString(7);

         i = 0;
         loopi3:
         while (i < 16) {             // make sure wc is supported

            if (parmc.tmodea[i].equals( wc )) {

               break loopi3;
            }
            i++;
         }
         if (i > 15) {       // if we went all the way without a match

            wc = parmc.tmodea[0];    // use default option
         }

         if (mid.equals("")) {

            name = first + " " + last;
            dname = last + ", " + first;
         } else {

            name = first + " " + mid + " " + last;
            dname = last + ", " + first + " " + mid;
         }

         wname = name + ":" + wc;              // combine name:wc for script

         //
         //  Custom - add mnum to end of name for display only
         //
         if (club.equals( "royaloakscc" ) || club.equals( "fortcollins" ) || club.equals( "virginiacc" ) ||
             club.equals( "congressional" ) || club.equals( "muirfield" ) || club.equals( "blackhawk" ) ||
             club.equals( "mirasolcc" ) || club.equals( "tavistockcc" ) || club.equals( "bellehaven" )) {

            dname = dname + " " + mnum;              // add mnum for display - do not move to slot
         }

         //
         //  Los Coyotes - add gender to end of name for display only
         //
         if (club.equals( "loscoyotes" )) {

            if (mtype.endsWith( "Female" ) || mtype.endsWith( "Ladies" )) {

               dname = dname + " " +mnum+ "-F";            // Female

            } else {

               dname = dname + " " +mnum+ "-M";            // Male
            }
         }

         //
         //  If club wants ordered display, then group family members together in an array, then display them
         //              according to their mtype (primary, spouse or dependent).
         //
         if (club.equals( "medinahcc" ) || club.equals( "oswegolake" ) || club.equals( "virginiacc" )) {

            //
            //  Medinah - group by Primary Member, Spouse, then Dependents
            //
            if (club.equals( "medinahcc" )) {

               if (!lastMnum.equals( "" ) && !mnum.equals( lastMnum )) {      // if new family

                  //
                  //  New family - output the last family members and save the new one
                  //
                  mloop1:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].endsWith( "Member" )) {    // find Primary member

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:red\">" + dNameA[i] + "&nbsp;&nbsp;" + lastMnum + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop1;              // exit loop
                     }
                  }

                  mloop2:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].endsWith( "Spouse" )) {    // find the Spouse

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:blue\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop2;              // exit loop
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" )) {                    // the rest must be dependents

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:green\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  indexM = 0;                         // start over - new family
               }

               mtypeA[indexM] = mtype;               // save mtype for this member
               mNameA[indexM] = wname;               // save member name and wc value
               dNameA[indexM] = dname;               // save display name
               lastMnum = mnum;                      // set this family's mnum

               indexM++;                             // prepare for next name
            }

            //
            //  If Oswego Lake, Adult Male, Adult Female, then Dependents
            //
            if (club.equals( "oswegolake" )) {

               if (!lastMnum.equals( "" ) && !mnum.equals( lastMnum )) {      // if new family

                  //
                  //  New family - output the last family members and save the new one
                  //
                  mloop1:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Male" )) {    // find Primary member

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:red\">" + dNameA[i] + "&nbsp;&nbsp;" + lastMnum + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop1;              // exit loop
                     }
                  }

                  mloop2:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && (mtypeA[i].endsWith( "Ladies" ) || mtypeA[i].equals( "Adult Female" ))) {  // find the Spouse

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:blue\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop2;              // exit loop
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" )) {                    // the rest must be dependents

                        out.println("<option value=\"" + mNameA[i] + "\" style=\"color:green\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  indexM = 0;                         // start over - new family
               }

               mtypeA[indexM] = mtype;               // save mtype for this member
               mNameA[indexM] = wname;               // save member name and wc value
               dNameA[indexM] = dname;               // save display name
               lastMnum = mnum;                      // set this family's mnum

               indexM++;                             // prepare for next name
            }

            //
            //  If Virginia CC, Adult Male, Adult Female, Senior Male, Senior Female, Student Male, Student Female,
            //                  Young Adult Male, Young Adult Female, Junior Male, Junior Female
            //
            if (club.equals( "virginiacc" )) {

               if (!lastMnum.equals( "" ) && !mnum.equals( lastMnum )) {      // if new family

                  //
                  //  New family - output the last family members and save the new one
                  //
                  mloop1:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Male" )) {             // Adult Male

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop1;              // exit loop
                     }
                  }

                  mloop2:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Female" )) {          // Adult Female

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop2;              // exit loop
                     }
                  }

                  mloop3:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Senior Male" )) {          // Senior Male 

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop3;              // exit loop
                     }
                  }

                  mloop4:
                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Senior Female" )) {          // Senior Female

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                        break mloop4;              // exit loop
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Student Male" )) {          // Student Male

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Student Female" )) {          // Student Female

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Young Adult Male" )) {          // Young Adult Male

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Young Adult Female" )) {          // Young Adult Female

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Junior Male" )) {          // Junior Male

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  for (i = 0; i < indexM; i++) {

                     if (!mtypeA[i].equals( "" )) {                    // the rest must be Junior Females

                        out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
                        mtypeA[i] = "";            // remove it
                     }
                  }

                  indexM = 0;                         // start over - new family
               }

               mtypeA[indexM] = mtype;               // save mtype for this member
               mNameA[indexM] = wname;               // save member name and wc value
               dNameA[indexM] = dname;               // save display name
               lastMnum = mnum;                      // set this family's mnum

               indexM++;                             // prepare for next name
            }


         } else {   // NOT a club that wants special order

            if (club.equals( "merion" ) && mship.equals( "House" )) {        // if Merion and member is a House member

               out.println("<option value=\"" + wname + "\" style=\"color:red\">" + dname + "</option>");

            } else {

               out.println("<option value=\"" + wname + "\">" + dname + "</option>");    // Normal display
            }
         }
           
      }            // end of WHILE members


      if (club.equals( "medinahcc" )) {

         //
         //  Medinah - make sure we get the last family done
         //
         mloop3:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].endsWith( "Member" )) {    // find Primary member

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:red\">" + dNameA[i] + "&nbsp;&nbsp;" + mnum + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop3;              // exit loop
            }
         }

         mloop4:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].endsWith( "Spouse" )) {    // find the Spouse

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:blue\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop4;              // exit loop
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" )) {                    // the rest must be dependents

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:green\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }
      }
           
      if (club.equals( "oswegolake" )) {

         //
         //  Oswego Lake - make sure we get the last family done
         //
         mloop5:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Male" )) {    // find Primary member

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:red\">" + dNameA[i] + "&nbsp;&nbsp;" + mnum + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop5;              // exit loop
            }
         }

         mloop6:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && (mtypeA[i].endsWith( "Ladies" ) || mtypeA[i].equals( "Adult Female" ))) {  // find the Spouse

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:blue\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop6;              // exit loop
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" )) {                    // the rest must be dependents

               out.println("<option value=\"" + mNameA[i] + "\" style=\"color:green\">&nbsp;&nbsp;&nbsp;" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }
      }    

      if (club.equals( "virginiacc" )) {

         //
         //  CC of Virginia - make sure we get the last family done
         //
         mloop7:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Male" )) {             // Adult Male

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop7;              // exit loop
            }
         }

         mloop8:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Adult Female" )) {          // Adult Female

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop8;              // exit loop
            }
         }

         mloop9:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Senior Male" )) {          // Senior Male

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop9;              // exit loop
            }
         }

         mloop10:
         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "Senior Female" ) && mtypeA[i].equals( "" )) {          // Senior Female

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
               break mloop10;              // exit loop
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Student Male" )) {          // Student Male

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Student Female" )) {          // Student Female

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Young Adult Male" )) {          // Young Adult Male

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Young Adult Female" )) {          // Young Adult Female

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" ) && mtypeA[i].equals( "Junior Male" )) {          // Junior Male

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }

         for (i = 0; i < indexM; i++) {

            if (!mtypeA[i].equals( "" )) {                    // the rest must be Junior Females

               out.println("<option value=\"" + mNameA[i] + "\">" + dNameA[i] + "</option>");
               mtypeA[i] = "";            // remove it
            }
         }
      }

      //
      //  End the row
      //
      out.println("</select>");
      out.println("</div>");
      out.println("</font></td></tr>");

      stmt2.close();
   }
   catch (Exception ex) {
       out.println("ERROR: " + err + ", " + ex.toString());
   }

   out.println("</table></td>");

 }          // end of nameList method


/**
 //************************************************************************
 //
 //  Output Table for Guest List (and X)
 //
 //      called by:
 //                  Proshop_slot
 //                  Proshop_slotm
 //                  Proshop_lott
 //                  Proshop_evntSignUp
 //
 //************************************************************************
 **/

 public static void guestList(String club, String course, String day_name, int time, parmClub parm, boolean lottery, PrintWriter out, Connection con) {


   int i = 0;
   int x = 0;
   int xCount = 0;


   out.println("<br><table border=\"1\" bgcolor=\"#F5F5DC\">");
      out.println("<tr bgcolor=\"#336633\">");
      out.println("<td align=\"center\">");
         out.println("<font color=\"#FFFFFF\" size=\"2\">");
         if (club.equals( "lakewood" )) {
            out.println("<b>Player Options</b>");
         } else {
            out.println("<b>Guest Types</b>");
         }
         out.println("</font></td>");
      out.println("</tr>");
   //
   //     Check the club db table for X and Guest parms specified by proshop
   //
   try {
       
      getClub.getParms(con, parm);        // get the club parms

      x = parm.x;

      if (lottery) x = 0;
      
      //
      //  first we must count how many fields there will be
      //
      xCount = 0;
        
      if (club.equals( "wellesley" ) && day_name.equals( "" )) {      // if Wellesley and an event

         xCount = 3;            // only 2 guest types
           
      } else {
        
         if (x != 0) xCount = 1;
         
         for (i = 0; i < 36; i++) {

            if (!parm.guest[i].equals( "" )) xCount++;
         }
         
      }
        
      i = 0;
      if (xCount != 0) {

         if (xCount < 2) {

            xCount = 2;             // set size to at least 2
         }
         if (xCount > 10) {

            xCount = 10;             // set size to no more than 10 showing at once (it will scroll)
         }
         out.println("<tr><td align=\"left\"><font size=\"1\" face=\"Helvetica, Arial, Sans-serif\">");
         out.println("<b>**</b> Add guests immediately<br>&nbsp;&nbsp;&nbsp;&nbsp;<b>after</b> host member.<br>");
         out.println("</font><font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");

         out.println("<select size=\"" + xCount + "\" name=\"xname\" onClick=\"moveguest(this.form.xname.value)\" style=\"cursor:hand\">");
         if (x != 0) {
            out.println("<option value=\"X\">X</option>");
         }
           
         if (club.equals( "wellesley" ) && day_name.equals( "" )) {      // if Wellesley and an event

            out.println("<option value=\"Outing Guest\">Outing Guest</option>");     // only 2 guest types
            out.println("<option value=\"Tourney Guest\">Tourney Guest</option>");  

         } else {

            for (i = 0; i < 36; i++) {

               if (!parm.guest[i].equals( "" )) {   // if guest name

                  boolean medinahSkip = false;

                  //
                  //  If Medinah, then only display guest types for the specified course
                  //
                  if (club.equals( "medinahcc" ) && !day_name.equals( "" )) {      // if Medinah and NOT an event

                     if (parm.guest[i].equals( "B4 11am on no3" ) ||
                         parm.guest[i].startsWith( "*Guest" ) || parm.guest[i].equals( "Unaccom1" ) ||
                         parm.guest[i].equals( "Unaccom2" ) || parm.guest[i].equals( "Unaccom3" )) {

                        medinahSkip = true;
                     }
                  }

                  if (medinahSkip == false) {

                     out.println("<option value=\"" + parm.guest[i] + "\">" + parm.guest[i] + "</option>");
                  }
               }
            }
         }
         out.println("</select>");
         out.println("</font></td></tr></table>");      // end of this table and column

      } else {

         out.println("</table>");      // end the table and column if none specified
      }

   }
   catch (Exception exc) {             // SQL Error - ignore guest and x

      out.println("</table>");
   }

 }          // end of guestList method


}  // end of alphaTable class

