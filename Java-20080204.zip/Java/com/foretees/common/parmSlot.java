/***************************************************************************************
 *   parmSlot:  This class will define a paramter block object to be used for tee time verification.
 *
 *
 *   called by:  Proshop_slot
 *               Proshop_slotm
 *               Proshop_lott
 *               Proshop_dlott
 *               Proshop_devnt
 *               Proshop_insert
 *               Proshop_oldsheets
 *               Member_slot
 *               Member_slotm
 *               Member_lott
 *
 *   created: 1/12/2004   Bob P.
 *
 *   last updated: 
 *
 *                  6/27/2007  Add event string
 *                  4/13/2007  Add custom_int, custom_string and custom_dispx for custom fields in teecurr.
 *                 12/09/2005  Add suppressEmails string.
 *
 *
 ***************************************************************************************
 */
   
package com.foretees.common;


public class parmSlot {

   public boolean error = false;
   public boolean hit = false;
   public boolean hit2 = false;
   public boolean hit3 = false;
     
   public int MAX_Guests = Labels.MAX_GUESTS;         // IN Labels
   public int MAX_Mems = Labels.MAX_MEMS;
   public int MAX_Mships = Labels.MAX_MSHIPS;
   public int MAX_Tmodes = Labels.MAX_TMODES;

   public long date = 0;

   public int in_use = 0;
   public int time = 0;
   public int time2 = 0;       // time of existing tee time (1 player with 2 times in a day)
   public int stime = 0;
   public int etime = 0;
   public int fb = 0;
   public int mm = 0;
   public int dd = 0;
   public int yy = 0;
   public int inval1 = 0;
   public int inval2 = 0;
   public int inval3 = 0;
   public int inval4 = 0;
   public int inval5 = 0;
   public int members = 0;
   public int players = 0;
   public int hide = 0;
   public int mins_before = 0;
   public int mins_after = 0;
   public int beforei = 0;
   public int afteri = 0;
   public int ftime = 0;
   public int ltime = 0;
   public int groups = 0;
   public int grps = 0;
   public int i3 = 0;
   public int guests = 0;
   public int memNew = 0;
   public int memMod = 0;
   public int proNew = 0;
   public int proMod = 0;
   public int grest_num = 0;
   public int ind = 0;            // numeric value of index
   public int p91 = 0;            // 9 hole indicators
   public int p92 = 0;
   public int p93 = 0;
   public int p94 = 0;
   public int p95 = 0;

   public int rnds = 0;
   public int hrsbtwn = 0;

   public int custom_int = 0;

   //public int chkin1 = 0;  // should be safe to delete these now
   //public int chkin2 = 0;
   //public int chkin3 = 0;
   //public int chkin4 = 0;
   //public int chkin5 = 0;
   
   // parms used by Proshop_insert
   public int from_player = 0;
   public int to_player = 0;
   public int from_time = 0;
   public int to_time = 0;
   public int from_fb = 0;
   public int to_fb = 0;
   public String to_course = "";
   public String from_course = "";
   public String to_from = "";
   public String to_to = "";
   public String sendEmail = "";
     

   public short rfb = 0;
   public short show1 = 0;
   public short show2 = 0;
   public short show3 = 0;
   public short show4 = 0;
   public short show5 = 0;

   public short pos1 = 0;
   public short pos2 = 0;
   public short pos3 = 0;
   public short pos4 = 0;
   public short pos5 = 0;

   public float hndcp1 = 0;
   public float hndcp2 = 0;
   public float hndcp3 = 0;
   public float hndcp4 = 0;
   public float hndcp5 = 0;

   public String course = "";
   public String returnCourse = "";
   public String course2 = "";            // course name for error msg
   public String day = "";
   public String player = "";
   public String period = "";
   public String rest_name = "";
   public String hides = "";
   public String notes = "";
   public String index = "";
   public String p5 = "";
   public String p5rest = "";
   public String rest5 = "";
   public String jump = "";
   public String sfb = "";
   public String in_use_by = "";
   public String orig_by = "";
   public String conf = "";
   public String club = "";
   public String user = "";
   public String last_user = "";
   public String gplayer = "";              // guest player in error - Member_slot
   public String grest_per = "";            // guest restriction per option (Member or Tee Time)
   public String lottery = "";
   public String lottery_type = "";
   public String suppressEmails = "";            // guest restriction per option (Member or Tee Time)
   public String event = "";

   public String player1 = "";
   public String player2 = "";
   public String player3 = "";
   public String player4 = "";
   public String player5 = "";

   public String oldPlayer1 = "";
   public String oldPlayer2 = "";
   public String oldPlayer3 = "";
   public String oldPlayer4 = "";
   public String oldPlayer5 = "";

   public String user1 = "";
   public String user2 = "";
   public String user3 = "";
   public String user4 = "";
   public String user5 = "";

   public String userg1 = "";   //  member usernames associated with guests
   public String userg2 = "";
   public String userg3 = "";
   public String userg4 = "";
   public String userg5 = "";

   public String mem1 = "";     // member names used for Unaccompanied Guests (tied to userg above)
   public String mem2 = "";
   public String mem3 = "";
   public String mem4 = "";
   public String mem5 = "";

   public String oldUser1 = "";
   public String oldUser2 = "";
   public String oldUser3 = "";
   public String oldUser4 = "";
   public String oldUser5 = "";

   public String p1cw = "";
   public String p2cw = "";
   public String p3cw = "";
   public String p4cw = "";
   public String p5cw = "";

   public String oldp1cw = "";
   public String oldp2cw = "";
   public String oldp3cw = "";
   public String oldp4cw = "";
   public String oldp5cw = "";

   public String mNum1 = "";
   public String mNum2 = "";
   public String mNum3 = "";
   public String mNum4 = "";
   public String mNum5 = "";

   public String pnum1 = "";
   public String pnum2 = "";
   public String pnum3 = "";
   public String pnum4 = "";
   public String pnum5 = "";

   public String mship = "";
   public String mship1 = "";
   public String mship2 = "";
   public String mship3 = "";
   public String mship4 = "";
   public String mship5 = "";

   public String mtype = "";
   public String mtype1 = "";
   public String mtype2 = "";
   public String mtype3 = "";
   public String mtype4 = "";
   public String mtype5 = "";

   public String mstype1 = "";      // member sub_type
   public String mstype2 = "";
   public String mstype3 = "";
   public String mstype4 = "";
   public String mstype5 = "";

   public String fname1 = "";
   public String lname1 = "";
   public String mi1 = "";
   public String fname2 = "";
   public String lname2 = "";
   public String mi2 = "";
   public String fname3 = "";
   public String lname3 = "";
   public String mi3 = "";
   public String fname4 = "";
   public String lname4 = "";
   public String mi4 = "";
   public String fname5 = "";
   public String lname5 = "";
   public String mi5 = "";

   public String g1 = "";
   public String g2 = "";
   public String g3 = "";
   public String g4 = "";
   public String g5 = "";

   //
   //  Custom fields for making custom processing easier
   //
   public String custom_string = "";
   public String custom_disp1 = "";
   public String custom_disp2 = "";
   public String custom_disp3 = "";
   public String custom_disp4 = "";
   public String custom_disp5 = "";

   //
   //  guest array for Member_lott
   //
   public String [] gstA = new String [5];     // guests (entire player name)
   public String [] g = new String [5];        // guest type of player position (if guest)

}  // end of class
