/***************************************************************************************
 *   getParms:  This servlet will provide some common methods to get Course parms.
 *
 *
 *
 *   created:  2/06/2004   Bob P.
 *
 *
 *   last updated:
 *
 *      2/07/07 RDP  If Greeley CC, make sure that GC is first mode of trans listed.
 *     11/05/04 RDP  Allow for course to be -ALL-, get all modes of trans.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class getParms {


/**
 //************************************************************************
 //
 //  Get the Course parms
 //
 //************************************************************************
 **/

 public static void getCourse(Connection con, parmCourse parm, String course)
         throws Exception {


   PreparedStatement pstmtc = null;
   ResultSet rs = null;


   //
   //  get the Course's parameters
   //
   try {

      if (course.equals( "-ALL-" ) || course.equals( "" )) {

         pstmtc = con.prepareStatement (
            "SELECT * " +
            "FROM clubparm2");

         pstmtc.clearParameters();        // clear the parms

      } else {

         pstmtc = con.prepareStatement (
            "SELECT * " +
            "FROM clubparm2 WHERE courseName = ?");

         pstmtc.clearParameters();        // clear the parms
         pstmtc.setString(1, course);
      }

      rs = pstmtc.executeQuery();      // execute the prepared stmt

      if (rs.next()) {                        

         parm.courseName = rs.getString("courseName");
         parm.first_hr = rs.getInt("first_hr");
         parm.first_min = rs.getInt("first_min");
         parm.last_hr = rs.getInt("last_hr");
         parm.last_min = rs.getInt("last_min");
         parm.betwn = rs.getInt("betwn");
         parm.xx = rs.getInt("xx");
         parm.alt = rs.getInt("alt");
         parm.fives = rs.getInt("fives");
         parm.tmode[0] = rs.getString("tmode1");
         parm.tmodea[0] = rs.getString("tmodea1");
         parm.tmode[1] = rs.getString("tmode2");
         parm.tmodea[1] = rs.getString("tmodea2");
         parm.tmode[2] = rs.getString("tmode3");
         parm.tmodea[2] = rs.getString("tmodea3");
         parm.tmode[3] = rs.getString("tmode4");
         parm.tmodea[3] = rs.getString("tmodea4");
         parm.tmode[4] = rs.getString("tmode5");
         parm.tmodea[4] = rs.getString("tmodea5");
         parm.tmode[5] = rs.getString("tmode6");
         parm.tmodea[5] = rs.getString("tmodea6");
         parm.tmode[6] = rs.getString("tmode7");
         parm.tmodea[6] = rs.getString("tmodea7");
         parm.tmode[7] = rs.getString("tmode8");
         parm.tmodea[7] = rs.getString("tmodea8");
         parm.tmode[8] = rs.getString("tmode9");
         parm.tmodea[8] = rs.getString("tmodea9");
         parm.tmode[9] = rs.getString("tmode10");
         parm.tmodea[9] = rs.getString("tmodea10");
         parm.tmode[10] = rs.getString("tmode11");
         parm.tmodea[10] = rs.getString("tmodea11");
         parm.tmode[11] = rs.getString("tmode12");
         parm.tmodea[11] = rs.getString("tmodea12");
         parm.tmode[12] = rs.getString("tmode13");
         parm.tmodea[12] = rs.getString("tmodea13");
         parm.tmode[13] = rs.getString("tmode14");
         parm.tmodea[13] = rs.getString("tmodea14");
         parm.tmode[14] = rs.getString("tmode15");
         parm.tmodea[14] = rs.getString("tmodea15");
         parm.tmode[15] = rs.getString("tmode16");
         parm.tmodea[15] = rs.getString("tmodea16");
         parm.t9pos[0] = rs.getString("t9pos1");
         parm.tpos[0] = rs.getString("tpos1");
         parm.t9pos[1] = rs.getString("t9pos2");
         parm.tpos[1] = rs.getString("tpos2");
         parm.t9pos[2] = rs.getString("t9pos3");
         parm.tpos[2] = rs.getString("tpos3");
         parm.t9pos[3] = rs.getString("t9pos4");
         parm.tpos[3] = rs.getString("tpos4");
         parm.t9pos[4] = rs.getString("t9pos5");
         parm.tpos[4] = rs.getString("tpos5");
         parm.t9pos[5] = rs.getString("t9pos6");
         parm.tpos[5] = rs.getString("tpos6");
         parm.t9pos[6] = rs.getString("t9pos7");
         parm.tpos[6] = rs.getString("tpos7");
         parm.t9pos[7] = rs.getString("t9pos8");
         parm.tpos[7] = rs.getString("tpos8");
         parm.t9pos[8] = rs.getString("t9pos9");
         parm.tpos[8] = rs.getString("tpos9");
         parm.t9pos[9] = rs.getString("t9pos10");
         parm.tpos[9] = rs.getString("tpos10");
         parm.t9pos[10] = rs.getString("t9pos11");
         parm.tpos[10] = rs.getString("tpos11");
         parm.t9pos[11] = rs.getString("t9pos12");
         parm.tpos[11] = rs.getString("tpos12");
         parm.t9pos[12] = rs.getString("t9pos13");
         parm.tpos[12] = rs.getString("tpos13");
         parm.t9pos[13] = rs.getString("t9pos14");
         parm.tpos[13] = rs.getString("tpos14");
         parm.t9pos[14] = rs.getString("t9pos15");
         parm.tpos[14] = rs.getString("tpos15");
         parm.t9pos[15] = rs.getString("t9pos16");
         parm.tpos[15] = rs.getString("tpos16");
      }
      pstmtc.close();

      //
      //  determine how many tmodes are actually specified - save count
      //
      parm.tmode_count = 0;
        
      for (int i = 0; i < parm.tmode_limit; i++) {
        
         if (!parm.tmodea[i].equals( "" )) {    // if specified
           
            parm.tmode_count++;
         }
      }

   }
   catch (Exception e) {

      throw new Exception("Error getting tmode info - getParms.getCourse " + e.getMessage());
   }

 }   // end of getCourse method


/**
 //************************************************************************
 //
 //  Get the Transportation Modes for a single course
 //
 //************************************************************************
 **/

 public static void getTmodes(Connection con, parmCourse parm, String course)
         throws Exception {


   ResultSet rs = null;
   PreparedStatement pstmtc = null;

   //
   //  get the Course's tmode parameters 
   //
   try {

      if (course.equals( "-ALL-" ) || course.equals( "" )) {
        
         pstmtc = con.prepareStatement (
            "SELECT tmode1, tmodea1, tmode2, tmodea2, tmode3, tmodea3, tmode4, tmodea4, tmode5, tmodea5, " +
            "tmode6, tmodea6, tmode7, tmodea7, tmode8, tmodea8, tmode9, tmodea9, tmode10, tmodea10, tmode11, tmodea11, " +
            "tmode12, tmodea12, tmode13, tmodea13, tmode14, tmodea14, tmode15, tmodea15, tmode16, tmodea16 " +
            "FROM clubparm2");

         pstmtc.clearParameters();        // clear the parms

      } else {

         pstmtc = con.prepareStatement (
            "SELECT tmode1, tmodea1, tmode2, tmodea2, tmode3, tmodea3, tmode4, tmodea4, tmode5, tmodea5, " +
            "tmode6, tmodea6, tmode7, tmodea7, tmode8, tmodea8, tmode9, tmodea9, tmode10, tmodea10, tmode11, tmodea11, " +
            "tmode12, tmodea12, tmode13, tmodea13, tmode14, tmodea14, tmode15, tmodea15, tmode16, tmodea16 " +
            "FROM clubparm2 WHERE courseName = ?");
              
         pstmtc.clearParameters();        // clear the parms
         pstmtc.setString(1, course);
      }

      rs = pstmtc.executeQuery();      // execute the prepared stmt

      if (rs.next()) {               

         parm.tmode[0] = rs.getString("tmode1");
         parm.tmodea[0] = rs.getString("tmodea1");
         parm.tmode[1] = rs.getString("tmode2");
         parm.tmodea[1] = rs.getString("tmodea2");
         parm.tmode[2] = rs.getString("tmode3");
         parm.tmodea[2] = rs.getString("tmodea3");
         parm.tmode[3] = rs.getString("tmode4");
         parm.tmodea[3] = rs.getString("tmodea4");
         parm.tmode[4] = rs.getString("tmode5");
         parm.tmodea[4] = rs.getString("tmodea5");
         parm.tmode[5] = rs.getString("tmode6");
         parm.tmodea[5] = rs.getString("tmodea6");
         parm.tmode[6] = rs.getString("tmode7");
         parm.tmodea[6] = rs.getString("tmodea7");
         parm.tmode[7] = rs.getString("tmode8");
         parm.tmodea[7] = rs.getString("tmodea8");
         parm.tmode[8] = rs.getString("tmode9");
         parm.tmodea[8] = rs.getString("tmodea9");
         parm.tmode[9] = rs.getString("tmode10");
         parm.tmodea[9] = rs.getString("tmodea10");
         parm.tmode[10] = rs.getString("tmode11");
         parm.tmodea[10] = rs.getString("tmodea11");
         parm.tmode[11] = rs.getString("tmode12");
         parm.tmodea[11] = rs.getString("tmodea12");
         parm.tmode[12] = rs.getString("tmode13");
         parm.tmodea[12] = rs.getString("tmodea13");
         parm.tmode[13] = rs.getString("tmode14");
         parm.tmodea[13] = rs.getString("tmodea14");
         parm.tmode[14] = rs.getString("tmode15");
         parm.tmodea[14] = rs.getString("tmodea15");
         parm.tmode[15] = rs.getString("tmode16");
         parm.tmodea[15] = rs.getString("tmodea16");
      }
      pstmtc.close();

   }
   catch (Exception e) {

      throw new Exception("Error getting guest info - getParms.getTmodes " + e.getMessage());
   }

   if (course.equals( "Greeley CC" )) {      // Greeley CC course is at Fort Collins (they share)

      String tmode = parm.tmode[0];          // save first entry          
      String tmodea = parm.tmodea[0];
        
      //
      //  Make sure the GC is first in list so it will be the defualt
      //
      if (!tmodea.equals( "GC" )) {       // if not GC
        
         loop1:  
         for (int i=1; i<16; i++) {       // loop through list starting with #2
           
            if (parm.tmodea[i].equals( "GC" )) {

               parm.tmode[0] = parm.tmode[i];          // put the full name in #1
               parm.tmodea[0] = "GC";                  // set short name 
                 
               parm.tmodea[i] = tmodea;                // put #1 here (swap)
               parm.tmode[i] = tmode;             
                 
               break loop1;
            }
         }
      }
   }

 }   // end of getTmodes method


/**
 //************************************************************************
 //
 //  Get the Transportation Modes for all courses
 //
 //************************************************************************
 **/

 public static void getCourseTrans(Connection con, parmCourse parm)
         throws Exception {


   ResultSet rs = null;

   String tmode = "";
   String tmodea = "";
     
   int i = 0;
   int i2 = 0;
   int i3 = 0;
   int zero = 0;

   boolean found = false;

   //
   //  init the parm save areas
   //
   for (i3 = 0; i3 < parm.tmode_limit; i3++) {

       parm.tmode[i3] = "";
       parm.tmodea[i3] = "";
   }

   //
   //  get all Course's Mode of Trans Options 
   //
   try {

      PreparedStatement pstmtc = con.prepareStatement (
         "SELECT tmode1, tmodea1, tmode2, tmodea2, tmode3, tmodea3, tmode4, tmodea4, tmode5, tmodea5, " +
         "tmode6, tmodea6, tmode7, tmodea7, tmode8, tmodea8, tmode9, tmodea9, tmode10, tmodea10, tmode11, tmodea11, " +
         "tmode12, tmodea12, tmode13, tmodea13, tmode14, tmodea14, tmode15, tmodea15, tmode16, tmodea16 " +
         "FROM clubparm2 WHERE first_hr > ?");

      pstmtc.clearParameters();        // clear the parms
      pstmtc.setInt(1, zero);
      rs = pstmtc.executeQuery();      // execute the prepared stmt

      while (rs.next()) {

         i2 = 1;
           
         for (i = 0; i < parm.tmode_limit; i++) {       // get all 16 tmode pairs

            tmode = rs.getString(i2);
            tmodea = rs.getString(i2+1);

            if (!tmodea.equals( "" )) {                     // if specified
              
               found = false;
                 
               //
               //  check if tmode already exists in parm block
               //
               for (i3 = 0; i3 < parm.tmode_limit; i3++) {

                  if (tmodea.equals( parm.tmodea[i3] )) {             // if already exists

                     found = true;
                  }
               }

               if (found == false) {          // if not found

                  i3 = 0;
                  loop1:
                  while (i3 < parm.tmode_limit) {

                     if (parm.tmode[i3].equals( "" )) {        // if spot is open

                        parm.tmode[i3] = tmode;
                        parm.tmodea[i3] = tmodea;
                        break loop1;
                     }
                     i3++;
                  }
               }
            }
              
            i2 += 2;
         }                // end of FOR
      }                   // end of WHILE
      pstmtc.close();

   }
   catch (Exception e) {

      throw new Exception("Error getting guest info - getParms.getCourseTrans " + e.getMessage());
   }

 }   // end of getCourseTrans method

}  // end of getParms class

