/**************************************************************************************************************
 *   cordilleraCustom:  This will provide the common methods for processing custom requests for Cordillera CC.
 *
 *       called by:  Hotel_sheet
 *                   Member_sheet
 *
 *
 *   created:  2/01/2006   Bob P.
 *
 *
 *   last updated:
 *
 *             1/25/07 Corrected times for 2007.
 *             1/09/07 Adjusted times for 2007 per Penti's request.
 *             2/28/06 Adjusted times on 6/25 and 7/28 per Penti's request.
 *
 **************************************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class cordilleraCustom {


/**
 // *********************************************************
 //  Check for custom hotel guest restrictions for Cordillera
 // *********************************************************
 **/

 public static boolean checkCordillera(long date, int time, String course, String caller) {



   boolean allow = true;        // default return status to 'ok'
   boolean hit = false;

   int stime = 1059;      // earliest time to check
   int etime = 1451;      // latest time to check

   int stime1 = 1059;     // 11:00 - 2:50    (time range 1)
   int etime1 = 1451;

   int stime2 = 1429;     // 2:30 - 2:50     (time range 2)
   int etime2 = 1451;

   int stime3 = 1329;     // 1:30 - 2:50     (time range 3)
   int etime3 = 1451;

   int stime4 = 1329;     // 1:30 - 1:50     (time range 4)
   int etime4 = 1351;

   int stime5 = 1059;     // 11:00 - 2:10    (time range 5)
   int etime5 = 1411;

   int stime6 = 1329;     // 1:30 - 1:40     (time range 6)
   int etime6 = 1341;

   int stime7 = 1409;     // 2:10 - 2:50     (time range 7)
   int etime7 = 1451;

   int mstime = 1200;     // 12:00 - 1:30    (Member Times - ok for members, not for hotel guests)
   int metime = 1329;

   //
   //  Patterns (a, b, c)  where:
   //
   //        course:   Mountain        Valley         Summit
   //                  --------        ------         ------
   //
   //    time range:      a              b              c
   //
   //
   //  Process:  If the requested tee time is between 11:00 and 3:00, then check for the
   //            above listed restricted times based on the course and date.  If a match is
   //            found, then allow or disallow the request based on the user (hotel or member).
   //            These times are restricted for hotel guests and the other times in this time
   //            frame are ok.  These times are ok for members, but the other times in this time
   //            frame are restricted for members.           
   //
   //         1.  Only check times between 11:00 AM and 3:00 PM each day (and never on the Short Course).
   //         2.  Check if time is a �Member Only Time� (based on course, dates and times in spreadsheet).
   //         3.  If time is a �Member Only Time�, then do not allow Hotel Guests
   //         4.  If time is NOT a �Member Only Time� and it is between 12:00 & 2:50 PM, then DO NOT allow members.
   //
   //****************************************************************************************************************
   //  NOTE:  The blacked out times in the spreadsheet are 'For Members Only'.  The other times are 'Lodge Times'!!!
   //         hit = true is set if the time falls in the blacked out range.
   //****************************************************************************************************************
   //
   //
   //********************************************************************************************************************
   //

   //
   //  Only check if the tee time is between 11:00 and 3:00
   //
   if (time > stime && time < etime && !course.equals( "Short" )) {     // if restricted time and NOT the Short course

      //
      //  Check if requested tee time is restricted for hotel guests - based on date, time and course
      //
      if (date == 20070911 || date == 20070917) {

         //
         //     Pattern = 1-1-2
         //
         if (course.equals( "Mountain" ) || course.equals( "Valley" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Summit" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if ((date > 20070412 && date < 20070525) || date == 20070720 || (date > 20071007 && date < 20071029)) {  // changed 3/16/07 per pro (7/20)

         //
         //     Pattern = 1-2-1
         //
         if (course.equals( "Mountain" ) || course.equals( "Summit" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) && date != 20071028) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 20070910 || date == 20070912 || date == 20070914) {

         //
         //     Pattern = 1-2-3
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime3 && time < etime3) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070621 || date == 20070816 || date == 20070830 ||
          date == 20070831 || date == 20070906) {

         //
         //     Pattern = 1-2-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070604 || date == 20070729 || date == 20070802 || date == 20070811 || date == 20070819 || date == 20070913) { // changed 3/16/07 (8/02)

         //
         //     Pattern = 1-3-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070603 || date == 20070606 || date == 20070610 || date == 20070613 || date == 20070617 ||
          date == 20070620 || date == 20070627 || date == 20070701 || date == 20070704 || date == 20070708 ||
          date == 20070711 || date == 20070712 || date == 20070715 || date == 20070718 || date == 20070722 ||
          date == 20070725 || date == 20070801 || date == 20070805 || date == 20070808 || date == 20070812 ||
          date == 20070815 || date == 20070826 || date == 20070829 || date == 20070902 ||
          date == 20070905 || date == 20070909 || date == 20070916 || date == 20070923) {

         //
         //     Pattern = 1-4-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) && date != 20070923) {

               if (time > stime4 && time < etime4) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
                    
            } else {

               if (course.equals( "Summit" )) {

                  if ((time > stime2 && time < etime2)) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070616) {

         //
         //     Pattern = 1-5-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime5 && time < etime5) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070719) {             // changed 3/16/07 per pro

         //
         //     Pattern = 2-1-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) || course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 20070728 || date == 20070804 || date == 20070810 || date == 20070818 || date == 20070824 ||
          date == 20070918 || date == 20070920) {

         //
         //     Pattern = 2-1-3
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime3 && time < etime3) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070601 || date == 20070607 || date == 20070608 || date == 20070611 || date == 20070618 || 
          date == 20070622 || date == 20070625 || date == 20070628 || date == 20070629 ||
          date == 20070702 || date == 20070706 || date == 20070709 || date == 20070713 || date == 20070716 ||
          date == 20070723 || date == 20070730 || date == 20070806 || date == 20070813 ||
          date == 20070820 || date == 20070827 || date == 20070903 || date == 20070907) {

         //
         //     Pattern = 2-1-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                                // indicate we hit a restricted time
            }
                 
         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                                // indicate we hit a restricted time
               }

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                                // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070726) {

         //
         //     Pattern = 2-2-1
         //
         if (course.equals( "Mountain" ) || course.equals( "Valley" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 20070525 || date == 20070527 || date == 20070529 || 
          date == 20070721 || date == 20070727 || date == 20070822 || date == 20070924 ||
          date == 20070926 || date == 20070928 || date == 20070930 || date == 20071001 || date == 20071003 ||
          date == 20071005 || date == 20071007) {

         //
         //     Pattern = 2-3-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070908) {

         //
         //     Pattern = 2-4-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime4 && time < etime4) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070919) {

         //
         //     Pattern = 3-1-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070803) {    // changed 3/16/07 per pro

         //
         //     Pattern = 3-1-3
         //
         if (course.equals( "Mountain" ) || course.equals( "Summit" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 20070526 || date == 20070528 || date == 20070530 || date == 20070531 || date == 20070809 || date == 20070823 || date == 20070925 ||
          date == 20070927 || date == 20070929 || date == 20071002 || date == 20071004 || date == 20071006) {

         //
         //     Pattern = 3-2-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if ((time > stime2 && time < etime2) || date == 2007100) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070921) {

         //
         //     Pattern = 4-1-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) || course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 20070817) {

         //
         //     Pattern = 4-1-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070602 || date == 20070605 || date == 20070609 || date == 20070612 || date == 20070614 ||
          date == 20070619 || date == 20070623 || date == 20070624 || date == 20070626 || date == 20070630 ||
          date == 20070703 || date == 20070705 || date == 20070707 || date == 20070710 || date == 20070714 ||
          date == 20070717 || date == 20070724 || date == 20070731 || date == 20070807 || date == 20070814 ||
          date == 20070821 || date == 20070825 || date == 20070828 || date == 20070901 || date == 20070904 ||
          date == 20070915 || date == 20070922) {

         //
         //     Pattern = 4-2-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) && date != 20070922) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 20070615) {

         //
         //     Pattern = 5-1-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime5 && time < etime5) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }


      //
      //  Now process the request according to the caller; hotel or member
      //
      //      Member:  if we hit on a time, then member is ok, else they might be restricted
      //
      //      Hotel:   if we hit on a time, then hotel guests are restricted, else they are ok
      //
      allow = true;                // default to ok
        
      if (caller.equals( "hotel" )) {
        
         if (hit == true) {        // if this is a 'Member Only' time
           
            allow = false;         // hotel guests are restricted
         }
           
      } else {                    // member
        
         if (hit == false) {                           // if NOT a 'Member Only' time

            if (time < mstime || time > metime) {      // if a 'Lodge Time' (noon - 2:50)
              
               allow = false;                          // members are restricted
            }
         }
      }

   }           // end of IF within time frame (11:00 - 3:00)

   return(allow);

 }  // end of checkCordillera

}  // end of cordilleraCustom class

