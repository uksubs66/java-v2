/***************************************************************************************
 *   Proshop_evntSignUp:  This servlet will process a request to register a member for
 *                        an event.
 *
 *
 *
 *   called by:  Proshop_events2
 *
 *
 *   created: 2/18/2003   Bob P.
 *
 *   last updated:
 *
 *       9/25/07   Add enforcement of new minimum sign-up size option
 *       8/20/07   Added Member Notice proshop side display as a configurable option (per notice basis)
 *       8/08/07   Muirfield & Inverness GC - Added Member Notice display to Proshop side
 *       7/27/07   Add option to suppress emails for the signup.
 *       6/28/07   Do not meta-refresh the reply when team is on wait list (let pro read the message).
 *       6/26/07   When pulling a handicap from member2b get it from the g_hancap field instead of c_hancap
 *       6/21/07   Do not send emails if event has already passed.
 *       4/25/07   Congressional - pass the date for the ourse Name Labeling.
 *       4/09/07   Modified call to alphaTable.guestList to pass new boolean parameter
 *       3/20/07   Custom for Congressional - abstract the course name depending on the day (Course Name Labeling)
 *       2/15/07   Modified the call to alphaTable.nameList to include new boolean for ghin integration
 *       2/15/07   Set the clubname and course name for getClub.getParms.
 *       1/16/07   Royal Oaks Houston - always set 'hidenotes' to Yes.
 *       6/09/06   Added confirmation to cancel request
 *       3/07/06   Add ability to list names by mship and/or mtype groups.
 *       2/28/06   Merion - color 'House' members' names red in the name lists.
 *       9/15/05   Medinah - do not show guest types that are not for events.
 *       5/16/05   Add processing for restrictions on events (member may not have access to event).
 *      11/16/04   Ver 5 - Improve layout to provide quicker access to member names.
 *       9/16/04   Ver 5 - change getClub from SystemUtils to common.
 *       7/25/04   Make sure there is room in event before changing wait to registered after
 *                 a group is cancelled.
 *       6/10/04   Add 'List All' option to member list to list all members for name selection.
 *       6/01/04   Remove error when pro enters a guest name without the guest type.
 *       2/16/04   Add support for configurable transportation modes.
 *       7/18/03   Enhancements for Version 3 of the software.
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.parmCourse;
import com.foretees.common.parmClub;
import com.foretees.common.getParms;
import com.foretees.common.getClub;
import com.foretees.common.parmSlot;
import com.foretees.common.verifySlot;
import com.foretees.common.parmEmail;
import com.foretees.common.sendEmail;
import com.foretees.common.alphaTable;
import com.foretees.common.congressionalCustom;


public class Proshop_evntSignUp extends HttpServlet {
                         

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)


 //
 //******************************************************************************
 //  doPost processing
 //******************************************************************************

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   //
   //  Prevent caching so sessions are not mangled
   //
   resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
   resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
   resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyPro(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   //
   //  Get this session's username 
   //
   String club = (String)session.getAttribute("club");
   String user = (String)session.getAttribute("user");
   String mshipOpt = (String)session.getAttribute("mshipOpt");
   String mtypeOpt = (String)session.getAttribute("mtypeOpt");

   if (mshipOpt.equals( "" ) || mshipOpt == null) {

      mshipOpt = "ALL";
   }
   if (mtypeOpt.equals( "" ) || mtypeOpt == null) {

      mtypeOpt = "ALL";
   }



   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact support.");
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   // Process request according to which 'submit' button was selected
   //
   //      'id'      - a request from Proshop_events2
   //      'cancel'  - a cancel request from self (return with no changes)
   //      'letter'  - a request to list member names (from self)
   //      'submitForm'  - a reservation request (from self)
   //      'remove'  - a 'cancel reservation' request (from self - Cancel Tee Time)
   //      'return'  - a return from verify (from a skip)
   //
   if (req.getParameter("cancel") != null) {

      cancelReq(req, out, con);                      // process cancel request
      return;
   }


   //
   //  if user submitting request to update or cancel the entry - go process
   //
   if ((req.getParameter("submitForm") != null) || (req.getParameter("remove") != null)) {

      verify(req, out, con, session, resp);                 // process reservation requests request
      return;
   }


   //
   //  Get this year
   //
   Calendar cal = new GregorianCalendar();       // get todays date
   int thisYear = cal.get(Calendar.YEAR);            // get the year


   //
   //   Request is from Proshop_events2 -or- its a letter or buddy request from self
   //
   String name = "";
   String pairings = "";
   String course = "";
   String act_ampm = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String pname = "";
   String sid = "";
   String notes = "";
   String hides = "no";
   String sfb = "";
   String index = "";

   int month  = 0;
   int day = 0;
   int year = 0;
   int act_hr = 0;
   int act_min = 0;
   int size = 0;
   int max = 0;
   int guests = 0;
   int count = 0;
   int count2 = 0;
   int in_use = 0;
   int id = 0;
   int hide = 0;
   int xCount = 0;
   int x = 0;
   int i = 0;
   int nowc = 0;
   int time = 0;
   int c_time = 0;
   int fb = 0;

   int [] tmode = new int [16];      // supported transportation modes for event

   long date = 0;
   long c_date = 0;
   float hndcp1 = 0;
   float hndcp2 = 0;
   float hndcp3 = 0;
   float hndcp4 = 0;
   float hndcp5 = 0;

   boolean guestError = false;            // init error flag
   
   String [] day_table = { "inv", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
   
   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   //
   //  parm block to hold the course parameters
   //
   parmCourse parmc = new parmCourse();          // allocate a parm block


   //
   //   Get the parms received
   //
   name = req.getParameter("name");
   course = req.getParameter("course");

   String suppressEmails = "no";
   if (req.getParameter("suppressEmails") != null) {

      suppressEmails = req.getParameter("suppressEmails");
   }
   
   //
   //   Save club info in club parm table
   //
   parm.club = club;
   parm.course = course;


   try {

      //
      //  First, count the number of players already signed up 
      //
      PreparedStatement pstmt = con.prepareStatement (
         "SELECT player1, player2, player3, player4, player5 FROM evntsup2b " +
         "WHERE name = ? AND courseName = ? ");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, name);
      pstmt.setString(2, course);
      rs = pstmt.executeQuery();      // execute the prepared pstmt

      while (rs.next()) {

         player1 = rs.getString(1);
         player2 = rs.getString(2);
         player3 = rs.getString(3);
         player4 = rs.getString(4);
         player5 = rs.getString(5);

         if (!player1.equals( "" )) {

            count++;
         }
         if (!player2.equals( "" )) {

            count++;
         }
         if (!player3.equals( "" )) {

            count++;
         }
         if (!player4.equals( "" )) {

            count++;
         }
         if (!player5.equals( "" )) {

            count++;
         }
      }
      pstmt.close();

      //
      //   get the event requested
      //
      PreparedStatement stmt = con.prepareStatement (
         "SELECT * FROM events2b " +
         "WHERE name = ? AND courseName = ? ");

      stmt.clearParameters();        // clear the parms
      stmt.setString(1, name);
      stmt.setString(2, course);
      rs = stmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         date = rs.getLong("date");
         year = rs.getInt("year");
         month = rs.getInt("month");
         day = rs.getInt("day");
         act_hr = rs.getInt("act_hr");
         act_min = rs.getInt("act_min");
         pairings = rs.getString("pairings");
         size = rs.getInt("size");
         max = rs.getInt("max");
         guests = rs.getInt("guests");
         c_date = rs.getLong("c_date");
         c_time = rs.getInt("c_time");
         sfb = rs.getString("fb");
         tmode[0] = rs.getInt("tmode1");
         tmode[1] = rs.getInt("tmode2");
         tmode[2] = rs.getInt("tmode3");
         tmode[3] = rs.getInt("tmode4");
         tmode[4] = rs.getInt("tmode5");
         tmode[5] = rs.getInt("tmode6");
         tmode[6] = rs.getInt("tmode7");
         tmode[7] = rs.getInt("tmode8");
         tmode[8] = rs.getInt("tmode9");
         tmode[9] = rs.getInt("tmode10");
         tmode[10] = rs.getInt("tmode11");
         tmode[11] = rs.getInt("tmode12");
         tmode[12] = rs.getInt("tmode13");
         tmode[13] = rs.getInt("tmode14");
         tmode[14] = rs.getInt("tmode15");
         tmode[15] = rs.getInt("tmode16");

      } else {

         out.println(SystemUtils.HeadTitle("Database Error"));
         out.println("<BODY><CENTER>");
         out.println("<BR><BR><H3>Database Access Error</H3>");
         out.println("<BR><BR>Sorry, we are unable to process your request at this time.");
         out.println("<BR><BR>Please try again later.");
         out.println("<BR><BR>If problem persists, contact support.");
         out.println("<BR><BR>");
         out.println("<a href=\"javascript:history.back(1)\">Return</a>");
         out.println("</CENTER></BODY></HTML>");
         return;

      }   // end of IF event found

      stmt.close();

      //
      //  Get the Modes of Trans for this course
      //
      getParms.getCourse(con, parmc, course);

      //
      //  Create time values
      //
      time = (act_hr * 100) + act_min;       // actual time of event
      
      act_ampm = "AM";

      if (act_hr == 0) {

         act_hr = 12;                 // change to 12 AM (midnight)

      } else {

         if (act_hr == 12) {

            act_ampm = "PM";         // change to Noon
         }
      }
      if (act_hr > 12) {

         act_hr = act_hr - 12;
         act_ampm = "PM";             // change to 12 hr clock
      }

      //
      //  Override team size if proshop pairings (just in case)
      //
      if (!pairings.equalsIgnoreCase( "Member" )) {

         size = 1;       // set size to one for proshop pairings (size is # per team)
      }

      if (req.getParameter("new") != null) {     // if 'new' request
         //
         //  Get the highest existing id from the sign up sheet and insert a new entry
         //
         id = getNewId(con, name, course, c_date, c_time);      // allocate a new entry

         if (id == 0) {

            out.println(SystemUtils.HeadTitle("Event Error"));
            out.println("<BODY><CENTER>");
            out.println("<BR><BR><H3>Event Sign Up Error</H3>");
            out.println("<BR><BR>Sorry, we were unable to allocate a new entry for this event.");
            out.println("<BR><BR>Please try again later.");
            out.println("<BR><BR>If problem persists, contact support.");
            out.println("<BR><BR>");
            out.println("<a href=\"javascript:history.back(1)\">Return</a>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }

      } else {   // not 'new' request

         if ((req.getParameter("letter") != null) || (req.getParameter("return") != null) ||
             (req.getParameter("mtypeopt") != null) || (req.getParameter("memNotice") != null)) {                                        // if user clicked on a name letter

            sid = req.getParameter("id");

         } else {

            //
            //    The name of the submit button contains the 'id' of the entry in the event sign up table
            //
            Enumeration enum1 = req.getParameterNames();     // get the parm name passed

            while (enum1.hasMoreElements()) {

               pname = (String) enum1.nextElement();             // get parm name

               if (pname.startsWith( "id" )) {

                  StringTokenizer tok = new StringTokenizer( pname, ":" );     // separate name around the colon

                  sid = tok.nextToken();                        // skip past 'id: '
                  sid = tok.nextToken();                        // skip past 'id: '
               }
            }
         }                             // end of IF letter or buddy

         id = Integer.parseInt(sid);                   // convert id from string

      }   // end of IF 'new' request

   }
   catch (Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact support (provide the following).");
      out.println("<BR><BR> id = " + id + "   sid = " + sid + "   pname = " + pname);
      out.println("<BR><BR>Exception: " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   //   Process both new and update requests (new entry has already been added)
   //
   //      id = id of entry to update
   //      name = name of event
   //      course = name of course
   //      user = username of this Proshop
   //
   //   First, set this entry in_use if not already
   //
   if ((req.getParameter("letter") != null) || (req.getParameter("return") != null) ||
       (req.getParameter("mtypeopt") != null) || (req.getParameter("memNotice") != null)) {   // if user clicked on a name letter or mtype

      player1 = req.getParameter("player1");     // get the player info from the parms passed
      player2 = req.getParameter("player2");
      player3 = req.getParameter("player3");
      player4 = req.getParameter("player4");
      player5 = req.getParameter("player5");
      p1cw = req.getParameter("p1cw");
      p2cw = req.getParameter("p2cw");
      p3cw = req.getParameter("p3cw");
      p4cw = req.getParameter("p4cw");
      p5cw = req.getParameter("p5cw");
      notes = req.getParameter("notes");
      //hides = req.getParameter("hide");

      if (req.getParameter("hide") != null) {

          hides = req.getParameter("hide");
      }
      
      //
      //  Convert hide from string to int
      //
      hide = 0;                       // init to No
      if (hides.equalsIgnoreCase( "Yes" )) {
         hide = 1;
      }

      if (req.getParameter("mtypeopt") != null) {

         mtypeOpt = req.getParameter("mtypeopt");
         session.setAttribute("mtypeOpt", mtypeOpt);   //  Save the member class options in the session for next time
      }
      if (req.getParameter("mshipopt") != null) {
         mshipOpt = req.getParameter("mshipopt");
         session.setAttribute("mshipOpt", mshipOpt);
      }

   } else {
      
      synchronized(this) {

         try {

            PreparedStatement pstmt = con.prepareStatement (
               "SELECT in_use " +
               "FROM evntsup2b WHERE name = ? AND courseName = ? AND id = ? ");

            pstmt.clearParameters();        // clear the parms
            pstmt.setString(1, name);         // put the parm in pstmt
            pstmt.setString(2, course);
            pstmt.setInt(3, id);
            rs = pstmt.executeQuery();      // execute the prepared stmt

            while (rs.next()) {

               in_use = rs.getInt("in_use");

            }
            pstmt.close();

            if (in_use != 0) {              // if event slot already in use

               out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
               out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
               out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
               out.println("<CENTER><BR><BR><H3>Event Entry Busy</H3>");
               out.println("<BR><BR>Sorry, but this entry is currently busy.<BR>");
               out.println("<BR>Please select another entry or try again later.");
               out.println("<BR><BR>");
               out.println("<a href=\"javascript:history.back(1)\">Return</a>");
               out.println("</CENTER></BODY></HTML>");
               return;
            }

         }
         catch (Exception e1) {

            dbError(out, e1);
            return;
         }

         //
         //  Entry is not in use - set it in use now
         //
         try {

            PreparedStatement pstmt1 = con.prepareStatement (
               "UPDATE evntsup2b SET in_use = 1, in_use_by = ? WHERE name = ? AND courseName = ? AND id = ?");

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, user);         // put the parm in pstmt1
            pstmt1.setString(2, name);
            pstmt1.setString(3, course);
            pstmt1.setInt(4, id);
            count2 = pstmt1.executeUpdate();      // execute the prepared stmt

            pstmt1.close();

         }
         catch (Exception e2) {

            dbError(out, e2);
            return;
         }
      }              // end of synch

      //
      //  get the existing entry and its contents
      //
      try {

         PreparedStatement pstmt3 = con.prepareStatement (
            "SELECT * FROM evntsup2b " +
            "WHERE name = ? AND courseName = ? AND id = ?");

         pstmt3.clearParameters();        // clear the parms
         pstmt3.setString(1, name);
         pstmt3.setString(2, course);
         pstmt3.setInt(3, id);
         rs = pstmt3.executeQuery();      // execute the prepared pstmt

         while (rs.next()) {

            player1 = rs.getString("player1");
            player2 = rs.getString("player2");
            player3 = rs.getString("player3");
            player4 = rs.getString("player4");
            player5 = rs.getString("player5");
            p1cw = rs.getString("p1cw");
            p2cw = rs.getString("p2cw");
            p3cw = rs.getString("p3cw");
            p4cw = rs.getString("p4cw");
            p5cw = rs.getString("p5cw");
            notes = rs.getString("notes");
            hide = rs.getInt("hideNotes");

         }
         pstmt3.close();

      }
      catch (Exception e2) {

         dbError(out, e2);
         return;
      }
        
      //
      //  if Royal Oaks Houston - always hide notes from members, but allow pro to override (do not force on returns)
      //
      if (club.equals( "royaloakscc" )) {

         hide = 1;
      }
  
      
      //
      //  Determine day of week from the event date
      //
      Calendar cal2 = new GregorianCalendar();       // get todays date

      cal2.set(Calendar.YEAR, year);                 // change to requested date
      cal2.set(Calendar.MONTH, month-1);
      cal2.set(Calendar.DAY_OF_MONTH, day);

      int day_num = cal2.get(Calendar.DAY_OF_WEEK);          // day of week (01 - 07)

      String day_name = day_table[day_num];            // get name for day
      
      if (sfb.equals( "Back" )) {      // if Event only on Back Tees
        
         fb = 1;
      }
      
      //        
      //  Check for a Member Notice message from Pro
      //
      String memNotice = verifySlot.checkMemNotice(date, time, fb, course, day_name, "event", true, con);  // use date of event and actual start time

      if (!memNotice.equals( "" )) {      // if message to display

         //
         //  Display the Pro's Message and then prompt the user to either accept or return to the tee sheet
         //
         out.println("<HTML><HEAD>");
         out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
         out.println("<Title>Member Notice For Event Signup Request</Title>");
         out.println("</HEAD>");

         out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

            out.println("<table border=\"0\" width=\"100%\" align=\"center\" valign=\"top\">");  // large table for whole page
            out.println("<tr><td valign=\"top\" align=\"center\">");
               out.println("<p>&nbsp;&nbsp;</p>");
               out.println("<p>&nbsp;&nbsp;</p>");
               out.println("<font size=\"3\">");
               out.println("<b>NOTICE FROM YOUR GOLF SHOP</b><br><br><br></font>");

            out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#f5f5dc\" cellpadding=\"3\">");
               out.println("<tr>");
               out.println("<td width=\"580\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<br>" + memNotice);
               out.println("</font></td></tr>");
               out.println("</table><br>");

               out.println("</font><font size=\"2\">");
               out.println("<br>Would you like to continue with this request?<br>");
               out.println("<br><b>Please select from the following. DO NOT use you browser's BACK button!</b><br><br>");

               out.println("<table border=\"0\" cols=\"1\" cellpadding=\"3\">");
               out.println("<tr><td align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" name=\"can\">");
               out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
               out.println("<input type=\"submit\" value=\"No - Return\" name=\"cancel\"></form>");

               out.println("</font></td>");

               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
               out.println("</font></td>");

               out.println("<td align=\"center\">");
               out.println("<font size=\"2\">");
                  out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\">");
                  out.println("<input type=\"hidden\" name=\"index\" value=\"" + index + "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hide + "\">");
                  out.println("<input type=\"hidden\" name=\"memNotice\" value=\"yes\">");
                  out.println("<input type=\"submit\" value=\"YES - Continue\"></form>");
               out.println("</font></td></tr>");
               out.println("</table>");

               out.println("</td>");
               out.println("</tr>");
            out.println("</table>");
         out.println("</font></center></body></html>");
         out.close();
         return;
      }
      
   }                // end of IF letter request

   //
   //  Ensure that there are no null player fields
   //
   if (player1 == null ) {
      player1 = "";
   }
   if (player2 == null ) {
      player2 = "";
   }
   if (player3 == null ) {
      player3 = "";
   }
   if (player4 == null ) {
      player4 = "";
   }
   if (player5 == null ) {
      player5 = "";
   }
   if (p1cw == null ) {
      p1cw = "";
   }
   if (p2cw == null ) {
      p2cw = "";
   }
   if (p3cw == null ) {
      p3cw = "";
   }
   if (p4cw == null ) {
      p4cw = "";
   }
   if (p5cw == null ) {
      p5cw = "";
   }

   //
   //   Get the 'X' parms for this event
   //
   try {

      PreparedStatement pstmtev = con.prepareStatement (
         "SELECT x FROM events2b " +
         "WHERE name = ? AND courseName = ? ");

      pstmtev.clearParameters();        // clear the parms
      pstmtev.setString(1, name);
      pstmtev.setString(2, course);
      rs = pstmtev.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         x = rs.getInt("x");
      }
      pstmtev.close();

   }
   catch (Exception ignore) {
   }

   //
   //  Build the HTML page to prompt user for names
   //
   out.println("<HTML>");
   out.println("<HEAD><link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
   out.println("<Title>Proshop Event Sign Up Page</Title>");

      //
      //*******************************************************************
      //  User clicked on a letter - submit the form for the letter
      //*******************************************************************
      //
      out.println("<script language='JavaScript'>");            // Erase name script
      out.println("<!--");
      out.println("function subletter(x) {");

//      out.println("alert(x);");
      out.println("document.playerform.letter.value = x;");         // put the letter in the parm
      out.println("playerform.submit();");        // submit the form
      out.println("}");                  // end of script function
      out.println("// -->");
      out.println("</script>");          // End of script

   //
   //*********************************************************************************
   //  Erase player name (erase button selected next to player's name)
   //
   //    Remove the player's name and shift any other names up starting at player1
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Erase name script
   out.println("<!--");

   out.println("function erasename(pos1) {");

   out.println("document.playerform[pos1].value = '';");           // clear the player field
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*********************************************************************************
   //   Move buddy script
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move buddy script
   out.println("<!--");

   out.println("function movebuddy(name, cw) {");

   if (size > 1) {
      out.println("var player1 = document.playerform.player1.value;");
      out.println("var player2 = document.playerform.player2.value;");
      if (size > 2) {
         out.println("var player3 = document.playerform.player3.value;");
      }
      if (size > 3) {
         out.println("var player4 = document.playerform.player4.value;");
      }
      if (size > 4) {
         out.println("var player5 = document.playerform.player5.value;");
      }

      if (size == 5) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3) && ( name != player4) && ( name != player5)) {");
      }
      if (size == 4) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3) && ( name != player4)) {");
      }
      if (size == 3) {
         out.println("if (( name != player1) && ( name != player2) && ( name != player3)) {");
      }
      if (size == 2) {
         out.println("if (( name != player1) && ( name != player2)) {");
      }
         out.println("if (player1 == '') {");                    // if player1 is empty
            out.println("document.playerform.player1.value = name;");
            out.println("document.playerform.p1cw.value = cw;");

         out.println("} else {");
         out.println("if (player2 == '') {");                    // if player2 is empty
            out.println("document.playerform.player2.value = name;");
            out.println("document.playerform.p2cw.value = cw;");

      if (size > 2) {
         out.println("} else {");
         out.println("if (player3 == '') {");                    // if player3 is empty
            out.println("document.playerform.player3.value = name;");
            out.println("document.playerform.p3cw.value = cw;");

         if (size > 3) {
            out.println("} else {");
            out.println("if (player4 == '') {");                    // if player4 is empty
               out.println("document.playerform.player4.value = name;");
               out.println("document.playerform.p4cw.value = cw;");

            if (size > 4) {
               out.println("} else {");

               out.println("if (player5 == '') {");                    // if player5 is empty
                  out.println("document.playerform.player5.value = name;");
                  out.println("document.playerform.p5cw.value = cw;");
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");
      }
      out.println("}");
      out.println("}");

      out.println("}");                  // end of if all players
   }
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*******************************************************************
   //  Erase text area - (Notes)      erasetext and movenotes
   //*******************************************************************
   //
   out.println("<script language='JavaScript'>");            // Erase text area script
   out.println("<!--");
   out.println("function erasetext(pos1) {");
   out.println("document.playerform[pos1].value = '';");           // clear the text field
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script

   out.println("<script language='JavaScript'>");             // Move Notes into textarea
   out.println("<!--");
   out.println("function movenotes() {");
   out.println("var oldnotes = document.playerform.oldnotes.value;");
   out.println("document.playerform.notes.value = oldnotes;");   // put notes in text area
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   //
   //*********************************************************************************
   //  Move name script
   //*********************************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move name script
   out.println("<!--");

   out.println("function movename(namewc) {");

   out.println("del = ':';");                               // deliminator is a colon
   out.println("array = namewc.split(del);");                 // split string into 2 pieces (name, wc)
   out.println("var name = array[0];");
   out.println("var wc = array[1];");
   out.println("skip = 0;");

      out.println("var player1 = document.playerform.player1.value;");
      if (size > 1) {
         out.println("var player2 = document.playerform.player2.value;");
      }
      if (size > 2) {
         out.println("var player3 = document.playerform.player3.value;");
      }
      if (size > 3) {
         out.println("var player4 = document.playerform.player4.value;");
      }
      if (size > 4) {
         out.println("var player5 = document.playerform.player5.value;");
      }

      out.println("if (( name != 'x') && ( name != 'X')) {");

      if (size == 5) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3) || ( name == player4) || ( name == player5)) {");
      }
      if (size == 4) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3) || ( name == player4)) {");
      }
      if (size == 3) {
         out.println("if (( name == player1) || ( name == player2) || ( name == player3)) {");
      }
      if (size == 2) {
         out.println("if (( name == player1) || ( name == player2)) {");
      }
      if (size == 1) {
         out.println("if ( name == player1) {");
      }
            out.println("skip = 1;");
         out.println("}");
      out.println("}");

      out.println("if (skip == 0) {");

         out.println("if (player1 == '') {");                    // if player1 is empty
            out.println("document.playerform.player1.value = name;");
            out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
               out.println("document.playerform.p1cw.value = wc;");
            out.println("}");

         if (size > 1) {
            out.println("} else {");
            out.println("if (player2 == '') {");                    // if player2 is empty
               out.println("document.playerform.player2.value = name;");
               out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                  out.println("document.playerform.p2cw.value = wc;");
               out.println("}");

            if (size > 2) {
               out.println("} else {");
               out.println("if (player3 == '') {");                    // if player3 is empty
                  out.println("document.playerform.player3.value = name;");
                  out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                     out.println("document.playerform.p3cw.value = wc;");
                  out.println("}");

               if (size > 3) {
                  out.println("} else {");
                  out.println("if (player4 == '') {");                    // if player4 is empty
                     out.println("document.playerform.player4.value = name;");
                     out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                        out.println("document.playerform.p4cw.value = wc;");
                     out.println("}");

                  if (size > 4) {
                     out.println("} else {");
                     out.println("if (player5 == '') {");                    // if player5 is empty
                        out.println("document.playerform.player5.value = name;");
                        out.println("if ((wc != null) && (wc != '')) {");                    // if player is not 'X'
                           out.println("document.playerform.p5cw.value = wc;");
                        out.println("}");
                     out.println("}");
                   }
                  out.println("}");
               }
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");

      out.println("}");                  // end of dup name chack
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");                               // End of script

   //
   //*******************************************************************
   //  Move a Guest Name or 'X' into the tee slot
   //*******************************************************************
   //
   out.println("<script language='JavaScript'>");            // Move Guest Name script
   out.println("<!--");

   out.println("function moveguest(namewc) {");

   out.println("var name = namewc;");

   out.println("var player1 = document.playerform.player1.value;");
   if (size > 1) {
      out.println("var player2 = document.playerform.player2.value;");
   }
   if (size > 2) {
      out.println("var player3 = document.playerform.player3.value;");
   }
   if (size > 3) {
      out.println("var player4 = document.playerform.player4.value;");
   }
   if (size > 4) {
      out.println("var player5 = document.playerform.player5.value;");
   }

      out.println("if (player1 == '') {");                    // if player1 is empty
         out.println("document.playerform.player1.value = name;");

      if (size > 1) {
         out.println("} else {");
         out.println("if (player2 == '') {");                    // if player2 is empty
            out.println("document.playerform.player2.value = name;");

         if (size > 2) {
            out.println("} else {");
            out.println("if (player3 == '') {");                    // if player3 is empty
               out.println("document.playerform.player3.value = name;");

            if (size > 3) {
               out.println("} else {");
               out.println("if (player4 == '') {");                    // if player4 is empty
                  out.println("document.playerform.player4.value = name;");

               if (size > 4) {
                  out.println("} else {");
                  out.println("if (player5 == '') {");                    // if player5 is empty
                     out.println("document.playerform.player5.value = name;");
                  out.println("}");
               }
               out.println("}");
            }
            out.println("}");
         }
         out.println("}");
      }
      out.println("}");

   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");                               // End of script

   //*******************************************************************

   out.println("</HEAD>");
   out.println("<body onLoad=\"movenotes()\" bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#FFFFFF\" vlink=\"#FFFFFF\" alink=\"#FF0000\">");
   out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

   out.println("<table border=\"0\" width=\"100%\" valign=\"top\">");  // large table for whole page
   out.println("<tr><td valign=\"top\">");

   out.println("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#CCCCAA\" align=\"center\" valign=\"top\">");
     out.println("<tr><td align=\"left\" width=\"300\">");
     out.println("&nbsp;&nbsp;&nbsp;<b>ForeTees</b>");
     out.println("</td>");

     out.println("<td align=\"center\">");
     out.println("<font size=\"5\">Golf Shop Event Sign Up</font>");
     out.println("</font></td>");

     out.println("<td align=\"center\" width=\"300\">");
     out.println("<font size=\"1\" color=\"#000000\">Copyright&nbsp;</font>");
     out.println("<font size=\"2\" color=\"#000000\">&#169;&nbsp;</font>");
     out.println("<font size=\"1\" color=\"#000000\">ForeTees, LLC <br> " +thisYear+ " All rights reserved.");
     out.println("</font></td>");
   out.println("</tr></table>");

   out.println("<table border=\"0\" align=\"center\">");                           // table for main page
   out.println("<tr><td align=\"center\"><br>");

      out.println("<table border=\"1\" cols=\"1\" bgcolor=\"#F5F5DC\" cellpadding=\"3\">");
         out.println("<tr>");
         out.println("<td width=\"620\" align=\"center\">");
               out.println("<font size=\"2\">");
               out.println("<b>Warning</b>:&nbsp;&nbsp;You have <b>6 minutes</b> to complete this event registration.");
                               out.println("&nbsp; If you want to return without changes, <b>do not ");
                               out.println("use your browser's BACK</b> button/option.&nbsp; Instead select the <b>Go Back</b> ");
                               out.println("option below.");
         out.println("</font></td></tr>");
      out.println("</table>");

      out.println("<table border=\"0\" cellpadding=\"5\" cellspacing=\"5\" align=\"center\">"); // table to contain 4 tables below

         out.println("<tr>");
         out.println("<td align=\"center\">");         // col for Instructions and Go Back button

            out.println("<a href=\"#\" onClick=\"window.open ('/" +rev+ "/proshop_help_evnt_instruct.htm', 'newwindow', config='Height=380, width=680, toolbar=no, menubar=no, scrollbars=auto, resizable=no, location=no directories=no, status=no')\">");
            out.println("<img src=\"/" +rev+ "/images/instructions.gif\" border=0></a><br><br><br><br><br>");

            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" name=\"can\">");
            out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("Return<br>w/o Changes:<br>");
            out.println("<input type=\"submit\" value=\"Go Back\" name=\"cancel\"></form>");
         out.println("</font></td>");

         out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" name=\"playerform\" id=\"playerform\">");

         out.println("<td align=\"center\" valign=\"top\">");

            out.println("<font size=\"2\">");
            out.println("Event:&nbsp;&nbsp;<b>" + name + "</b>");
            out.println("<br>Date:&nbsp;&nbsp;<b>" + month + "/" + day + "/" + year + "</b>&nbsp;&nbsp;");
            if (act_min < 10) {
               out.println("Time:&nbsp;&nbsp;<b>" + act_hr + ":0" + act_min + " " + act_ampm + "</b>");
            } else {
               out.println("Time:&nbsp;&nbsp;<b>" + act_hr + ":" + act_min + " " + act_ampm + "</b>");
            }
            if (!course.equals( "" )) {
                if (club.equals("congressional")) {
                    out.println("&nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + congressionalCustom.getFullCourseName(date, day, course) + "</b>");
                } else {
                    out.println("&nbsp;&nbsp;Course:&nbsp;&nbsp;<b>" + course + "</b>");
                }
            }
           out.println("<br><br></font>");

            out.println("<table border=\"1\" bgcolor=\"#F5F5DC\" align=\"center\" width=\"400\">");  // table for player selection
            out.println("<tr bgcolor=\"#336633\"><td align=\"center\">");
               out.println("<font color=\"#FFFFFF\" size=\"2\">");
               out.println("<b>Add or Remove Players</b><br>");
            out.println("</font></td></tr>");
            out.println("<tr><td align=\"center\">");
               out.println("<font size=\"2\"><br>");

               out.println("<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player1')\" style=\"cursor:hand\">");
               out.println("Player 1:&nbsp;<input type=\"text\" id=\"player1\" name=\"player1\" value=\"" + player1 + "\" size=\"26\" maxlength=\"60\">");
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p1cw\" id=\"p1cw\">");
                 if (!p1cw.equals( "" )) {
                    out.println("<option selected value=" + p1cw + ">" + p1cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p1cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select><br>");

           if (size > 1) {

               out.println("<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player2')\" style=\"cursor:hand\">");
               out.println("Player 2:&nbsp;<input type=\"text\" id=\"player2\" name=\"player2\" value=\"" + player2 + "\" size=\"26\" maxlength=\"60\">");
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p2cw\" id=\"p2cw\">");
                 if (!p2cw.equals( "" )) {
                    out.println("<option selected value=" + p2cw + ">" + p2cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p2cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select><br>");

           } else {

               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
           }
           if (size > 2) {

               out.println("<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player3')\" style=\"cursor:hand\">");
               out.println("Player 3:&nbsp;<input type=\"text\" id=\"player3\" name=\"player3\" value=\"" + player3 + "\" size=\"26\" maxlength=\"60\">");
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p3cw\" id=\"p3cw\">");
                 if (!p3cw.equals( "" )) {
                    out.println("<option selected value=" + p3cw + ">" + p3cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p3cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select><br>");

           } else {

               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
           }
           if (size > 3) {

               out.println("<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player4')\" style=\"cursor:hand\">");
               out.println("Player 4:&nbsp;<input type=\"text\" id=\"player4\" name=\"player4\" value=\"" + player4 + "\" size=\"26\" maxlength=\"60\">");
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p4cw\" id=\"p4cw\">");
                 if (!p4cw.equals( "" )) {
                    out.println("<option selected value=" + p4cw + ">" + p4cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p4cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select><br>");

           } else {

               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
           }
           if (size > 4) {

               out.println("<img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasename('player5')\" style=\"cursor:hand\">");
               out.println("Player 5:&nbsp;<input type=\"text\" id=\"player5\" name=\"player5\" value=\"" + player5 + "\" size=\"26\" maxlength=\"60\">");
                 out.println("&nbsp;&nbsp;&nbsp;<select size=\"1\" name=\"p5cw\" id=\"p5cw\">");
                 if (!p5cw.equals( "" )) {
                    out.println("<option selected value=" + p5cw + ">" + p5cw + "</option>");
                 }
                 for (i=0; i<16; i++) {        // get all c/w options
                    if (tmode[i] == 1) {       // if specified for event
                       if (!parmc.tmodea[i].equals( "" ) && !parmc.tmodea[i].equals( p5cw )) {
                          out.println("<option value=\"" +parmc.tmodea[i]+ "\">" +parmc.tmodea[i]+ "</option>");
                       }
                    }
                 }
                 out.println("</select>");
           } else {

               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
           }

               //
               //   Notes
               //
               //   Script will put any existing notes in the textarea (value= doesn't work)
               //
               out.println("<input type=\"hidden\" name=\"oldnotes\" value=\"" + notes + "\">"); // hold notes for script

               out.println("<br><img src=\"/" +rev+ "/images/erase.gif\" onClick=\"erasetext('notes')\" style=\"cursor:hand\">");
               out.println("Notes:&nbsp;<textarea name=\"notes\" value=\"\" id=\"notes\" cols=\"30\" rows=\"2\">");
               out.println("</textarea>");
               
               out.println("<br>&nbsp;&nbsp;Hide Notes from Members?:&nbsp;&nbsp; ");
               if (hide != 0) {
                   out.println("<input type=\"checkbox\" checked name=\"hide\" value=\"Yes\">");
               } else {
                   out.println("<input type=\"checkbox\" name=\"hide\" value=\"Yes\">");
               }
               out.println("</font><font size=\"1\">&nbsp;(checked = yes)</font><font size=\"2\">");
/*            
               out.println("<br>&nbsp;&nbsp;Hide Notes from Members?:&nbsp;&nbsp; ");
               out.println("<select size=\"1\" name=\"hide\">");
               if (hide != 0) {
                 out.println("<option selected value=\"Yes\">Yes</option>");
                 out.println("<option value=\"No\">No</option>");
               } else {
                 out.println("<option selected value=\"No\">No</option>");
                 out.println("<option value=\"Yes\">Yes</option>");
               }
               out.println("</select>");
*/              
               out.println("<br>Suppress email notification?:&nbsp;&nbsp; ");
               if (suppressEmails.equalsIgnoreCase( "yes" )) {
                   out.println("<input type=\"checkbox\" checked name=\"suppressEmails\" value=\"Yes\">");
               } else {
                   out.println("<input type=\"checkbox\" name=\"suppressEmails\" value=\"Yes\">");
               }
               out.println("</font><font size=\"1\">&nbsp;(checked = yes)</font><font size=\"2\">");
            
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=" + id + ">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");

               out.println("<br><br><font size=\"1\">");
               for (i=0; i<16; i++) {
                  if (tmode[i] == 1) {       // if specified for event
                     if (!parmc.tmodea[i].equals( "" )) {
                        out.println(parmc.tmodea[i]+ " = " +parmc.tmode[i]+ "&nbsp;&nbsp;");
                     }
                  }
               }
               out.println("</font><br>");
               out.println("<input type=submit value=\"Submit\" name=\"submitForm\"><br>");
               out.println("</font></td></tr>");
               out.println("</table>");
               out.println("<br><input type=submit value=\"Cancel Entry\" name=\"remove\" onclick=\"return confirm('Are you sure you want to remove ALL players from this event sign up?')\">");
         out.println("</td>");                                // end of table and column
           
         out.println("<td valign=\"top\">");


      // ********************************************************************************
      //   If we got control from user clicking on a letter in the Member List,
      //   then we must build the name list.
      // ********************************************************************************
        
      String letter = "%";         // default is 'List All'

      if (req.getParameter("letter") != null) {

         letter = req.getParameter("letter");

         if (letter.equals( "List All" )) {
            letter = "%";
         } else {
            letter = letter + "%";
         }
      }

   //
   //   Output the List of Names
   //
   alphaTable.nameList(club, letter, mshipOpt, mtypeOpt, false, parmc, out, con);


   out.println("</td>");                                      // end of this column
   out.println("<td valign=\"top\">");

   //
   //   Output the Alphabit Table for Members' Last Names
   //
   alphaTable.getTable(out, user);


   //
   //   Output the Mship and Mtype Options
   //
   alphaTable.typeOptions(club, mshipOpt, mtypeOpt, out, con);


   //
   //   Output the List of Guests
   //
   alphaTable.guestList(club, course, "", time, parm, false, out, con);


   out.println("</td>");
   out.println("</tr>");
   out.println("</form>");     // end of playerform
   out.println("</table>");      // end of large table containing 4 smaller tables

   out.println("<font size=\"2\">");
   out.println("<b>Note:</b>  If adding a guest, click on the proper guest indicator, then click in the ");
   out.println("player position immediately<br>after the guest indicator ");
   out.println("and enter a space followed by the name of the guest and his/her club name.");
   out.println("</font>");


   out.println("</font></td></tr>");
   out.println("</table>");                      // end of main page table
   //
   //  End of HTML page
   //
   out.println("</td></tr>");
   out.println("</table>");                      // end of whole page table
   out.println("</font></body></html>");

 }   // end of doPost


 // *********************************************************
 //  Get a new id and set a new entry in the Event Sign Up db table
 // *********************************************************

 private synchronized int getNewId(Connection con, String name, String course, long date, int time) {


   Statement stmtm = null;
   ResultSet rs = null;


   int month = 0;
   int day = 0;
   int year = 0;
   int hr = 0;
   int min = 0;
   int id = 0;
   int r_time = 0;
   long r_date = 0;

   try {
      //
      //   Get current date and time
      //
      Calendar cal = new GregorianCalendar();        // get current date and time
      year = cal.get(Calendar.YEAR);
      month = cal.get(Calendar.MONTH);
      day = cal.get(Calendar.DAY_OF_MONTH);
      hr = cal.get(Calendar.HOUR_OF_DAY);
      min = cal.get(Calendar.MINUTE);

      //
      //  Build the 'time' string for display
      //
      //    Adjust the time based on the club's time zone (we are Central)
      //
      r_time = (hr * 100) + min;

      r_time = SystemUtils.adjustTime(con, r_time);       // adjust for time zone

      if (r_time < 0) {                // if negative, then we went back or ahead one day

         r_time = 0 - r_time;          // convert back to positive value

         if (r_time < 100) {           // if hour is zero, then we rolled ahead 1 day

            //
            // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
            //
            cal.add(Calendar.DATE,1);                     // get next day's date

            year = cal.get(Calendar.YEAR);
            month = cal.get(Calendar.MONTH);
            day = cal.get(Calendar.DAY_OF_MONTH);

         } else {                        // we rolled back 1 day

            //
            // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
            //
            cal.add(Calendar.DATE,-1);                     // get yesterday's date

            year = cal.get(Calendar.YEAR);
            month = cal.get(Calendar.MONTH);
            day = cal.get(Calendar.DAY_OF_MONTH);
         }
      }

      hr = r_time / 100;                // get adjusted hour
      min = r_time - (hr * 100);          // get minute value

      month = month + 1;                            // month starts at zero
      r_date = (year * 10000) + (month * 100) + day;

      //
      //   get the highest existing id
      //
      PreparedStatement stmt = con.prepareStatement (
         "SELECT MAX(id) FROM evntsup2b " +
         "WHERE name = ? AND courseName = ?");

      stmt.clearParameters();        // clear the parms
      stmt.setString(1, name);
      stmt.setString(2, course);
      rs = stmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         id = rs.getInt(1);
         id++;                // set new id

      } else {                // must be first one

         id = 1;
      }
      stmt.close();

      //
      //  Create a new entry for this event
      //
      if (id != 0) {

         PreparedStatement pstmt = con.prepareStatement (
            "INSERT INTO evntsup2b " +
            "(name, courseName, player1, player2, player3, player4, player5, " +
            "username1, username2, username3, username4, username5, " +
            "p1cw, p2cw, p3cw, p4cw, p5cw, in_use, in_use_by, hndcp1, hndcp2, hndcp3, hndcp4, " +
            "hndcp5, notes, hideNotes, id, c_date, c_time, r_date, r_time, wait, " +
            "userg1, userg2, userg3, userg4, userg5, player6, player7, player8, player9, player10, " +
            "username6, username7, username8, username9, username10, p6cw, p7cw, p8cw, p9cw, p10cw, " +
            "hndcp6, hndcp7, hndcp8, hndcp9, hndcp10, userg6, userg7, userg8, userg9, userg10, hole)" +
            "VALUES (?, ?, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, " +
            "'', 0, 0, 0, 0, 0, '', 0, ?, ?, ?, ?, ?, 0, " +
            "'', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', " +
            "0, 0, 0, 0, 0, '', '', '', '', '', '')");

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, name);
         pstmt.setString(2, course);
         pstmt.setInt(3, id);
         pstmt.setLong(4, date);             // cut-off date
         pstmt.setInt(5, time);              // cut-off time
         pstmt.setLong(6, r_date);           // date registered
         pstmt.setInt(7, r_time);            // time registered

         pstmt.executeUpdate();

         pstmt.close();
      }

   }
   catch (Exception ignore) {

      id = 0;   // indicate failed
   }

   return id;
 }


 // *********************************************************
 //  Process reservation request from Proshop_evntSignUp (HTML)
 // *********************************************************

 private void verify(HttpServletRequest req, PrintWriter out, Connection con, HttpSession session, HttpServletResponse resp) {


   Statement stmt = null;
   Statement stmtN = null;
   ResultSet rs = null;
   ResultSet rs2 = null;
   ResultSet rs7 = null;


   //
   //  Get this session's username
   //
   String user = (String)session.getAttribute("user");
   String club = (String)session.getAttribute("club");

   String in_use_by = "";

   String name = "";
   String course = "";
   String sid = "";
   String player = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String g1 = "";
   String g2 = "";
   String g3 = "";
   String g4 = "";
   String g5 = "";
   String oldPlayer1 = "";
   String oldPlayer2 = "";
   String oldPlayer3 = "";
   String oldPlayer4 = "";
   String oldPlayer5 = "";
   String oldUser1 = "";
   String oldUser2 = "";
   String oldUser3 = "";
   String oldUser4 = "";
   String oldUser5 = "";
   String oldp1cw = "";
   String oldp2cw = "";
   String oldp3cw = "";
   String oldp4cw = "";
   String oldp5cw = "";
   String p1cw = "";
   String p2cw = "";
   String p3cw = "";
   String p4cw = "";
   String p5cw = "";
   String user1 = "";
   String user2 = "";
   String user3 = "";
   String user4 = "";
   String user5 = "";
   String euser = "";
   String fname1 = "";
   String lname1 = "";
   String mi1 = "";
   String fname2 = "";
   String lname2 = "";
   String mi2 = "";
   String fname3 = "";
   String lname3 = "";
   String mi3 = "";
   String fname4 = "";
   String lname4 = "";
   String mi4 = "";
   String fname5 = "";
   String lname5 = "";
   String mi5 = "";
   String act_ampm = "";
   String act_time = "";
   String wplayer1 = "";
   String wplayer2 = "";
   String wplayer3 = "";
   String wplayer4 = "";
   String wplayer5 = "";
   String wuser1 = "";
   String wuser2 = "";
   String wuser3 = "";
   String wuser4 = "";
   String wuser5 = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
   String memberName = "";

   int id = 0;
   int reject = 0;
   int count = 0;
   int in_use = 0;
   int day = 0;
   int month = 0;
   int year = 0;
   int guests = 0;
   int eguests = 0;
   int x = 0;
   int xhrs = 0;
   int act_hr = 0;
   int act_min = 0;
   int adv_time = 0;
   int adv_date = 0;
   int i = 0;
   int etype = 0;
   int hide = 0;
   int ind = 0;
   int xcount = 0;
   int sendemail = 0;
   int emailNew = 0;
   int emailMod = 0;
   int emailCan = 0;
   int members = 0;
   int teams = 0;
   int t = 0;
   int max = 0;
   int minsize = 0;
   int wait = 0;
   int checkWait = 0;
   int gi = 0;

   float hndcp1 = 99;
   float hndcp2 = 99;
   float hndcp3 = 99;
   float hndcp4 = 99;
   float hndcp5 = 99;

   //
   //  Arrays to hold member & guest names to tie guests to members
   //
   String [] gstA = new String [5];     // guests
   String [] memA = new String [5];     // members
   String [] usergA = new String [5];   // guests' associated member (username)

   boolean guestError = false;            // init error flag
   boolean error = false;                 // init error flag
   boolean hit = false;                   // init error flag
   boolean check = false;

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block


   //
   // Get all the parameters entered
   //
   course = req.getParameter("course");        //  name of course
   name = req.getParameter("name");            //  name of event
   sid = req.getParameter("id");               //  id of event entry
   player1 = req.getParameter("player1");
   player2 = req.getParameter("player2");
   player3 = req.getParameter("player3");
   player4 = req.getParameter("player4");
   player5 = req.getParameter("player5");
   p1cw = req.getParameter("p1cw");
   p2cw = req.getParameter("p2cw");
   p3cw = req.getParameter("p3cw");
   p4cw = req.getParameter("p4cw");
   p5cw = req.getParameter("p5cw");
   String notes = req.getParameter("notes");           // Notes

   String hides = "no";
   if (req.getParameter("hide") != null) {

      hides = req.getParameter("hide");
   }
   
   String suppressEmails = "no";
   if (req.getParameter("suppressEmails") != null) {

      suppressEmails = req.getParameter("suppressEmails");
   }
   
   //
   //  Convert id from string to int
   //
   try {
      id = Integer.parseInt(sid);
   }
   catch (NumberFormatException e) {
   }

   //
   //  See if user wants to hide any notes from the Members
   //
   hide = 0;      // init

   if (hides.equalsIgnoreCase( "Yes" )) {

      hide = 1;
   }

   //
   //  Get the length of Notes (max length of 254 chars)
   //
   int notesL = 0;

   if (!notes.equals( "" )) {

      notesL = notes.length();       // get length of notes
   }

   //
   //  Check C/W's for null
   //
   if (p1cw == null) {
      p1cw = "";
   }
   if (p2cw == null) {
      p2cw = "";
   }
   if (p3cw == null) {
      p3cw = "";
   }
   if (p4cw == null) {
      p4cw = "";
   }
   if (p5cw == null) {
      p5cw = "";
   }
   if (player1 == null ) {
      player1 = "";
   }
   if (player2 == null ) {
      player2 = "";
   }
   if (player3 == null ) {
      player3 = "";
   }
   if (player4 == null ) {
      player4 = "";
   }
   if (player5 == null ) {
      player5 = "";
   }

   //
   //  Check if this entry is still 'in use' and still in use by this user??
   //
   //  This is necessary because the user may have gone away while holding this slot.  If the
   //  slot timed out (system timer), the slot would be marked 'not in use' and another
   //  user could pick it up.  The original holder could be trying to use it now.
   //
   try {

      PreparedStatement pstmt = con.prepareStatement (
         "SELECT player1, player2, player3, player4, player5, username1, username2, username3, " +
         "username4, username5, p1cw, p2cw, p3cw, p4cw, p5cw, in_use, in_use_by, wait " +
         "FROM evntsup2b WHERE name = ? AND  courseName = ? AND id = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, name);         // put the parm in pstmt
      pstmt.setString(2, course);
      pstmt.setInt(3, id);
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         oldPlayer1 = rs.getString("player1");
         oldPlayer2 = rs.getString("player2");
         oldPlayer3 = rs.getString("player3");
         oldPlayer4 = rs.getString("player4");
         oldPlayer5 = rs.getString("player5");
         oldUser1 = rs.getString("username1");
         oldUser2 = rs.getString("username2");
         oldUser3 = rs.getString("username3");
         oldUser4 = rs.getString("username4");
         oldUser5 = rs.getString("username5");
         oldp1cw = rs.getString("p1cw");
         oldp2cw = rs.getString("p2cw");
         oldp3cw = rs.getString("p3cw");
         oldp4cw = rs.getString("p4cw");
         oldp5cw = rs.getString("p5cw");
         in_use = rs.getInt("in_use");
         in_use_by = rs.getString("in_use_by");
         wait = rs.getInt("wait");
      }

      pstmt.close();

      if ((in_use == 0) || (!in_use_by.equals( user ))) {    // if entry not in use or not by this user

         out.println(SystemUtils.HeadTitle("DB Record In Use Error"));
         out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
         out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<CENTER><BR><BR><H1>Reservation Timer Expired</H1>");
         out.println("<BR><BR>Sorry, but this event entry has been returned to the system.<BR>");
         out.println("<BR>The system timed out and released it.");
         out.println("<font size=\"2\"><br><br>");
         out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
         out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
         out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }
        
      //
      //   Get the parms for this event
      //
      PreparedStatement pstmtev = con.prepareStatement (
         "SELECT year, month, day, type, act_hr, act_min, max, x, xhrs, minsize FROM events2b " +
         "WHERE name = ? AND courseName = ?");

      pstmtev.clearParameters();        // clear the parms
      pstmtev.setString(1, name);
      pstmtev.setString(2, course);
      rs = pstmtev.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         year = rs.getInt("year");       // get date & time for email msgs
         month = rs.getInt("month");
         day = rs.getInt("day");
         etype = rs.getInt("type");
         act_hr = rs.getInt("act_hr");
         act_min = rs.getInt("act_min");
         minsize = rs.getInt("minsize");
         max = rs.getInt("max");
         x = rs.getInt("x");
         xhrs = rs.getInt("xhrs");
      }
      pstmtev.close();

      //
      //  Create time values for email msg below
      //
      act_ampm = " AM";

      if (act_hr == 0) {

         act_hr = 12;                 // change to 12 AM (midnight)

      } else {

         if (act_hr == 12) {

            act_ampm = " PM";         // change to Noon
         }
      }
      if (act_hr > 12) {

         act_hr = act_hr - 12;
         act_ampm = " PM";             // change to 12 hr clock
      }

      //
      //  convert time to hour and minutes for email msg
      //
      if (act_min > 9) {

         act_time = act_hr + ":" + act_min + act_ampm;

      } else {

         act_time = act_hr + ":0" + act_min + act_ampm;
      }

   }
   catch (Exception e) {

      dbError(out, e);
      return;
   }

   //
   //  If request is to 'Cancel This Res', then clear all fields for this slot
   //
   if (req.getParameter("remove") != null) {

      player1 = "";                  // set reservation fields to null
      player2 = "";
      player3 = "";
      player4 = "";
      player5 = "";
      p1cw = "";
      p2cw = "";
      p3cw = "";
      p4cw = "";
      p5cw = "";
      user1 = "";
      user2 = "";
      user3 = "";
      user4 = "";
      user5 = "";
      notes = "";
      hide = 0;

      //
      //  if this team was not on the wait list, then set an idicator so we will process the wait list below.
      //
      if (wait == 0) {
        
         checkWait = 1;
      }
      wait = 0;          // init wait in cancelled entry

      emailCan = 1;      // send email notification for Cancel Request
      sendemail = 1;

   } else {
      //
      //  Normal reservation request
      //
      //   Get the guest names specified for this club
      //
      try {
         parm.club = club;                   // set club name
         parm.course = course;               // and course name

         getClub.getParms(con, parm);        // get the club parms
        
      }
      catch (Exception ignore) {
      }

      //
      //   Remove any guest types that are null - for tests below
      //
      for (i = 0; i < parm.MAX_Guests; i++) {

         if (parm.guest[i].equals( "" )) {

            parm.guest[i] = "$@#!^&*";      // make so it won't match player field
         }
      }         // end of while loop

      //
      //  Check if any player names are guest names
      //
      gstA[0] = "";    // init guest array and indicators
      gstA[1] = "";
      gstA[2] = "";
      gstA[3] = "";
      gstA[4] = "";
      g1 = "";
      g2 = "";
      g3 = "";
      g4 = "";
      g5 = "";

      if (!player1.equals( "" )) {

         i = 0;
         loop1:
         while (i < parm.MAX_Guests) {

            if (player1.startsWith( parm.guest[i] )) {

               g1 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[0] = player1;    // save guest value
               guests++;             // increment number of guests this slot
               break loop1;
            }
            i++;
         }         // end of while loop
      }
      if (!player2.equals( "" )) {

         i = 0;
         loop2:
         while (i < parm.MAX_Guests) {

            if (player2.startsWith( parm.guest[i] )) {

               g2 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[1] = player2;    // save guest value
               guests++;             // increment number of guests this slot
               break loop2;
            }
            i++;
         }         // end of while loop
      }
      if (!player3.equals( "" )) {

         i = 0;
         loop3:
         while (i < parm.MAX_Guests) {

            if (player3.startsWith( parm.guest[i] )) {

               g3 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[2] = player3;    // save guest value
               guests++;            // increment number of guests this slot
               break loop3;
            }
            i++;
         }         // end of while loop
      }
      if (!player4.equals( "" )) {

         i = 0;
         loop4:
         while (i < parm.MAX_Guests) {

            if (player4.startsWith( parm.guest[i] )) {

               g4 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[3] = player4;    // save guest value
               guests++;            // increment number of guests this slot
               break loop4;
            }
            i++;
         }         // end of while loop
      }
      if (!player5.equals( "" )) {

         i = 0;
         loop5:
         while (i < parm.MAX_Guests) {

            if (player5.startsWith( parm.guest[i] )) {

               g5 = parm.guest[i];       // indicate player is a guest name and save name
               gstA[4] = player5;    // save guest value
               guests++;            // increment number of guests this slot
               break loop5;
            }
            i++;
         }         // end of while loop
      }

      //
      //  Make sure a C/W was specified for all players
      //
      if (((!player1.equals( "" )) && (!player1.equalsIgnoreCase( "x" )) && (p1cw.equals( "" ))) ||
          ((!player2.equals( "" )) && (!player2.equalsIgnoreCase( "x" )) && (p2cw.equals( "" ))) ||
          ((!player3.equals( "" )) && (!player3.equalsIgnoreCase( "x" )) && (p3cw.equals( "" ))) ||
          ((!player4.equals( "" )) && (!player4.equalsIgnoreCase( "x" )) && (p4cw.equals( "" ))) ||
          ((!player5.equals( "" )) && (!player5.equalsIgnoreCase( "x" )) && (p5cw.equals( "" )))) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR>Required field has not been completed or is invalid.");
         out.println("<BR><BR>You must specify a Cart or Walk option for all players.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      //  Make sure there are no duplicate names
      //
      if ((!player1.equals( "" )) && (!player1.equalsIgnoreCase( "x" )) && (g1.equals( "" ))) {

         if ((player1.equalsIgnoreCase( player2 )) || (player1.equalsIgnoreCase( player3 )) || (player1.equalsIgnoreCase( player4 )) || (player1.equalsIgnoreCase( player5 ))) {

         out.println(SystemUtils.HeadTitle("Data Entry Error"));
         out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
         out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
         out.println("<center>");
         out.println("<BR><BR><H3>Data Entry Error</H3>");
         out.println("<BR><BR><b>" + player1 + "</b> was specified more than once.");
         out.println("<BR><BR>Please correct this and try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
         }
      }

      if ((!player2.equals( "" )) && (!player2.equalsIgnoreCase( "x" )) && (g2.equals( "" ))) {

         if ((player2.equalsIgnoreCase( player3 )) || (player2.equalsIgnoreCase( player4 )) || (player2.equalsIgnoreCase( player5 ))) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player2 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if ((!player3.equals( "" )) && (!player3.equalsIgnoreCase( "x" )) && (g3.equals( "" ))) {

         if ((player3.equalsIgnoreCase( player4 )) || (player3.equalsIgnoreCase( player5 ))) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player3 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      if ((!player4.equals( "" )) && (!player4.equalsIgnoreCase( "x" )) && (g4.equals( "" ))) {

         if (player4.equalsIgnoreCase( player5 )) {

            out.println(SystemUtils.HeadTitle("Data Entry Error"));
            out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0000FF\" vlink=\"#0000FF\" alink=\"#FF0000\" OnLoad=\"window.defaultStatus='� 2001 ForeTees, LLC';\">");
            out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<center>");
            out.println("<BR><BR><H3>Data Entry Error</H3>");
            out.println("<BR><BR><b>" + player4 + "</b> was specified more than once.");
            out.println("<BR><BR>Please correct this and try again.");
            out.println("<BR><BR>");
            out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
            out.println("</CENTER></BODY></HTML>");
            return;
         }
      }

      //
      //  Parse the names to separate first, last & mi
      //  (Proshop does not verify single tokens - check for x or guest) !!!!!!!!!!!
      //
      if ((!player1.equals( "" )) && (g1.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player1 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname1 = tok.nextToken();
            lname1 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname1 = tok.nextToken();
            mi1 = tok.nextToken();
            lname1 = tok.nextToken();
         }

      }

      if ((!player2.equals( "" )) && (g2.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player2 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player2.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname2 = tok.nextToken();
            lname2 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname2 = tok.nextToken();
            mi2 = tok.nextToken();
            lname2 = tok.nextToken();
         }
      }

      if ((!player3.equals( "" )) && (g3.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player3 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player3.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname3 = tok.nextToken();
            lname3 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname3 = tok.nextToken();
            mi3 = tok.nextToken();
            lname3 = tok.nextToken();
         }
      }

      if ((!player4.equals( "" )) && (g4.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player4 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player4.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname4 = tok.nextToken();
            lname4 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname4 = tok.nextToken();
            mi4 = tok.nextToken();
            lname4 = tok.nextToken();
         }
      }

      if ((!player5.equals( "" )) && (g5.equals( "" ))) {                  // specified but not guest

         StringTokenizer tok = new StringTokenizer( player5 );     // space is the default token

         if ( tok.countTokens() > 3 ) {          // too many name fields

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if (( tok.countTokens() == 1 ) && (!player5.equalsIgnoreCase( "X"))) {    // if not X

            invData(out, player1, player2, player3, player4, player5);                        // reject
            return;
         }

         if ( tok.countTokens() == 2 ) {         // first name, last name

            fname5 = tok.nextToken();
            lname5 = tok.nextToken();
         }

         if ( tok.countTokens() == 3 ) {         // first name, mi, last name

            fname5 = tok.nextToken();
            mi5 = tok.nextToken();
            lname5 = tok.nextToken();
         }
      }

      members = 0;     // init number of members in res request

      //
      //  Get the usernames & hndcp's for players if matching name found
      //
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "SELECT username, g_hancap FROM member2b WHERE name_last = ? AND name_first = ? AND name_mi = ?");

         if ((!fname1.equals( "" )) && (!lname1.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname1);
            pstmt1.setString(2, fname1);
            pstmt1.setString(3, mi1);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user1 = rs.getString(1);
               hndcp1 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request
            }
         }

         if ((!fname2.equals( "" )) && (!lname2.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname2);
            pstmt1.setString(2, fname2);
            pstmt1.setString(3, mi2);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user2 = rs.getString(1);
               hndcp2 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request
            }
         }

         if ((!fname3.equals( "" )) && (!lname3.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname3);
            pstmt1.setString(2, fname3);
            pstmt1.setString(3, mi3);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user3 = rs.getString(1);
               hndcp3 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request
            }
         }

         if ((!fname4.equals( "" )) && (!lname4.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname4);
            pstmt1.setString(2, fname4);
            pstmt1.setString(3, mi4);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user4 = rs.getString(1);
               hndcp4 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request
            }
         }

         if ((!fname5.equals( "" )) && (!lname5.equals( "" ))) {

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, lname5);
            pstmt1.setString(2, fname5);
            pstmt1.setString(3, mi5);
            rs = pstmt1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               user5 = rs.getString(1);
               hndcp5 = rs.getFloat(2);

               members = members + 1;        // increment # of members in request
            }
         }

         pstmt1.close();

      }
      catch (Exception e1) {

         dbError(out, e1);                        // reject
         return;
      }

      //
      //  Save the members' usernames for guest association
      //
      memA[0] = user1;
      memA[1] = user2;
      memA[2] = user3;
      memA[3] = user4;
      memA[4] = user5;

      //
      // **************************************
      //  Check for Restrictions in the Event - check all members
      // **************************************
      //
      if (req.getParameter("skip1") == null) {

         try {

            String restPlayer = verifySlot.checkEventRests(user1, user2, user3, user4, user5, name, con);

            if (!restPlayer.equals( "" )) {        // if member (username) restricted from this event

               if (restPlayer.equals( user1 )) {
                  restPlayer = player1;             // get player's name
               } else {
                  if (restPlayer.equals( user2 )) {
                     restPlayer = player2;
                  } else {
                     if (restPlayer.equals( user3 )) {
                        restPlayer = player3;
                     } else {
                        if (restPlayer.equals( user4 )) {
                           restPlayer = player4;
                        } else {
                           restPlayer = player5;
                        }
                     }
                  }
               }

               out.println(SystemUtils.HeadTitle("Member Restricted - Reject"));
               out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><H3>Member Restricted For Event</H3><BR>");
               out.println("<BR><BR>Sorry, member " +restPlayer+ " is not allowed to participate in this event.");
               out.println("<BR><BR>Would you like to override the restriction and allow this event registration?");
               out.println("<BR><BR>");
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
               out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
               out.println("</form></font>");

               out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"skip1\" value=\"yes\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
               out.println("<input type=\"submit\" value=\"YES\" name=\"submitForm\"></form>");
               out.println("</CENTER></BODY></HTML>");
               return;
            }

         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }

      }   // end of skip 1

      //
      // ***************************************************************
      //  Check if any members are already scheduled for this event
      // ***************************************************************
      //
      if ((!user1.equals( "" )) && (g1.equals( "" ))) {                  // specified but not guest

         try {
            PreparedStatement pstmtu = con.prepareStatement (
               "SELECT in_use FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND id != ? AND (username1 = ? OR " +
               "username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

            pstmtu.clearParameters();        // clear the parms
            pstmtu.setString(1, name);
            pstmtu.setString(2, course);
            pstmtu.setInt(3, id);
            pstmtu.setString(4, user1);
            pstmtu.setString(5, user1);
            pstmtu.setString(6, user1);
            pstmtu.setString(7, user1);
            pstmtu.setString(8, user1);
            rs = pstmtu.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               error = true;
               player = player1;             // save player name for error msg       
            }
            pstmtu.close();
         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }
      }

      if ((!user2.equals( "" )) && (g2.equals( "" )) && (error == false)) {   // specified but not guest

         try {
            PreparedStatement pstmtu = con.prepareStatement (
               "SELECT in_use FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND id != ? AND (username1 = ? OR " +
               "username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

            pstmtu.clearParameters();        // clear the parms
            pstmtu.setString(1, name);
            pstmtu.setString(2, course);
            pstmtu.setInt(3, id);
            pstmtu.setString(4, user2);
            pstmtu.setString(5, user2);
            pstmtu.setString(6, user2);
            pstmtu.setString(7, user2);
            pstmtu.setString(8, user2);
            rs = pstmtu.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               error = true;
               player = player2;             // save player name for error msg
            }
            pstmtu.close();
         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }
      }

      if ((!user3.equals( "" )) && (g3.equals( "" )) && (error == false)) {   // specified but not guest

         try {
            PreparedStatement pstmtu = con.prepareStatement (
               "SELECT in_use FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND id != ? AND (username1 = ? OR " +
               "username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

            pstmtu.clearParameters();        // clear the parms
            pstmtu.setString(1, name);
            pstmtu.setString(2, course);
            pstmtu.setInt(3, id);
            pstmtu.setString(4, user3);
            pstmtu.setString(5, user3);
            pstmtu.setString(6, user3);
            pstmtu.setString(7, user3);
            pstmtu.setString(8, user3);
            rs = pstmtu.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               error = true;
               player = player3;             // save player name for error msg
            }
            pstmtu.close();
         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }
      }

      if ((!user4.equals( "" )) && (g4.equals( "" )) && (error == false)) {   // specified but not guest

         try {
            PreparedStatement pstmtu = con.prepareStatement (
               "SELECT in_use FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND id != ? AND (username1 = ? OR " +
               "username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

            pstmtu.clearParameters();        // clear the parms
            pstmtu.setString(1, name);
            pstmtu.setString(2, course);
            pstmtu.setInt(3, id);
            pstmtu.setString(4, user4);
            pstmtu.setString(5, user4);
            pstmtu.setString(6, user4);
            pstmtu.setString(7, user4);
            pstmtu.setString(8, user4);
            rs = pstmtu.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               error = true;
               player = player4;             // save player name for error msg
            }
            pstmtu.close();
         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }
      }

      if ((!user5.equals( "" )) && (g5.equals( "" )) && (error == false)) {   // specified but not guest

         try {
            PreparedStatement pstmtu = con.prepareStatement (
               "SELECT in_use FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND id != ? AND (username1 = ? OR " +
               "username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

            pstmtu.clearParameters();        // clear the parms
            pstmtu.setString(1, name);
            pstmtu.setString(2, course);
            pstmtu.setInt(3, id);
            pstmtu.setString(4, user5);
            pstmtu.setString(5, user5);
            pstmtu.setString(6, user5);
            pstmtu.setString(7, user5);
            pstmtu.setString(8, user5);
            rs = pstmtu.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               error = true;
               player = player5;             // save player name for error msg
            }
            pstmtu.close();
         }
         catch (Exception e1) {

            dbError(out, e1);                        // reject
            return;
         }
      }

      if (error == true) {      // if player already scheduled

         out.println(SystemUtils.HeadTitle("Member Already Scheduled - Reject"));
         out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
         out.println("<hr width=\"40%\">");
         out.println("<BR><H3>Member Already Scheduled</H3><BR>");
         out.println("<BR><BR>Sorry, " + player + " is already registered for this event.<BR>");
         out.println("Remove this player and try again.");
         out.println("<BR><BR>");
         out.println("<font size=\"2\">");
            out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
            out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
            out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
            out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
            out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
            out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
            out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
            out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
            out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
            out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
            out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
            out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
            out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
            out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
            out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
            out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
            out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
            out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</form></font>");
         out.println("</CENTER></BODY></HTML>");
         return;
      }

      //
      // **************************************
      //  Check for max # of guests exceeded (per member)
      // **************************************
      //
      if (req.getParameter("skip3") == null) { 
         
         if (guests != 0) {      // if any guests were included

            try {
               PreparedStatement pstmtg = con.prepareStatement (
                  "SELECT guests FROM events2b " +
                  "WHERE name = ? AND courseName = ? ");

               pstmtg.clearParameters();        // clear the parms
               pstmtg.setString(1, name);
               pstmtg.setString(2, course);
               rs = pstmtg.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  eguests = rs.getInt("guests");
               }
               pstmtg.close();

               // if num of guests req'd (guests) > num allowed (eguests) per member
               //
               //       to get here guests is > 0
               //       eguests is 0 - 3
               //       members is 0 - 5
               //
               guestError = false;         // init error flag

               if ((eguests == 0) || (members == 0)) {      // no guests allowed or no members

                  guestError = true;         // set error flag
               }

               if (members == 1) {

                  if (guests > eguests) {     // if 1 member and more guests than allowed

                     guestError = true;         // set error flag
                  }
               }
               if (members == 2) {

                  if (eguests == 1) {

                     if (guests > 2) {             // if 1 allowed and more than 1 each

                        guestError = true;         // set error flag
                     }
                  }
               }

               if (guestError == true) {      // if # of guests exceeded

                  out.println(SystemUtils.HeadTitle("Max Num Guests Exceeded - Reject"));
                  out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
                  out.println("<hr width=\"40%\">");
                  out.println("<BR><H3>Number of Guests Exceeded Limit</H3><BR>");
                  out.println("<BR><BR>Sorry, the maximum number of guests allowed for the<BR>");
                  out.println("event you are requesting is " + eguests + " per member.");
                  out.println("<BR>You have requested " + guests + " guests and " + members + " members.");
                  out.println("<BR><BR>Would you like to override the limit and allow this event registration?");
                  out.println("<BR><BR>");
                  out.println("<font size=\"2\">");
                  out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
                  out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
                  out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
                  out.println("</form></font>");

                  out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
                  out.println("<input type=\"hidden\" name=\"skip3\" value=\"yes\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
                  out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
                  out.println("<input type=\"submit\" value=\"YES\" name=\"submitForm\"></form>");
                  out.println("</CENTER></BODY></HTML>");
                  return;
               }

            }
            catch (Exception e5) {

               dbError(out, e5);
               return;
            }
         }      // end of if guests
      }      // end of if skip3

      //
      //  Check if proshop user requested that we skip the following test
      //
      //  If this skip is set, then we've already been through these tests.
      //
      if (req.getParameter("skip8") == null) {

         //
         //***********************************************************************************************
         //
         //    Now check the order of guests and members (guests must follow a member) - prompt to verify order
         //
         //***********************************************************************************************
         //
         if (guests != 0 && members != 0) {      // if both guests and members were included

            if (g1.equals( "" )) {               // if slot 1 is not a guest

               //
               //  Both guests and members specified - determine guest owners by order
               //
               gi = 0;
               memberName = "";
               while (gi < 5) {                   // cycle thru arrays and find guests/members

                  if (!gstA[gi].equals( "" )) {

                     usergA[gi] = memberName;       // get last players username
                  } else {
                     usergA[gi] = "";               // init field
                  }
                  if (!memA[gi].equals( "" )) {

                     memberName = memA[gi];        // get players username
                  }
                  gi++;
               }
               userg1 = usergA[0];        // max of 4 guests since 1 player must be a member to get here
               userg2 = usergA[1];
               userg3 = usergA[2];
               userg4 = usergA[3];
               userg5 = usergA[4];
            }

            if (!g1.equals( "" ) || members > 1) {     // if slot 1 is a guest OR more than 1 member

               //
               //  At least one guest and one member have been specified.
               //  Prompt user to verify the order.
               //
               out.println(SystemUtils.HeadTitle("Guests Specified - Prompt"));
               out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
               out.println("<hr width=\"40%\">");
               out.println("<BR><BR><H3>Player/Guest Association Prompt</H3><BR>");
               out.println("Guests must be specified <b>immediately after</b> the member they belong to.<br><br>");

               if (!g1.equals( "" )) {              // if slot 1 is not a guest

                  out.println("You cannot have a guest in the first player position when one or more members are also specified.");
                  out.println("<BR><BR>");
               } else {
                  out.println("Please verify that the following order is correct:");
                  out.println("<BR><BR>");
                  out.println(player1 + " <BR>");
                  out.println(player2 + " <BR>");
                  if (!player3.equals( "" )) {
                     out.println(player3 + " <BR>");
                  }
                  if (!player4.equals( "" )) {
                     out.println(player4 + " <BR>");
                  }
                  if (!player5.equals( "" )) {
                     out.println(player5 + " <BR>");
                  }
                  out.println("<BR>Would you like to process the request as is?");
               }

               //
               //  Return to _slot to change the player order
               //
               out.println("<font size=\"2\">");
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
               out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
               out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
               out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
               out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
               out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
               out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
               out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
               out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
               out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
               out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
               out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
               out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
               out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
               out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
               out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
               out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");

               if (!g1.equals( "" )) {              // if slot 1 is not a guest

                  out.println("<input type=\"submit\" value=\"Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
                  out.println("</form></font>");

               } else {
                  out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
                  out.println("</form></font>");

                  //
                  //  Return to process the players as they are
                  //
                  out.println("<font size=\"2\">");
                  out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
                  out.println("<input type=\"hidden\" name=\"skip8\" value=\"yes\">");
                  out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
                  out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
                  out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
                  out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
                  out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
                  out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
                  out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
                  out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
                  out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
                  out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
                  out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
                  out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
                  out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
                  out.println("<input type=\"hidden\" name=\"userg1\" value=\"" + userg1 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg2\" value=\"" + userg2 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg3\" value=\"" + userg3 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg4\" value=\"" + userg4 + "\">");
                  out.println("<input type=\"hidden\" name=\"userg5\" value=\"" + userg5 + "\">");
                  out.println("<input type=\"submit\" value=\"YES - Continue\" name=\"submitForm\"></form></font>");
               }
               out.println("</CENTER></BODY></HTML>");
               return;
            }

         }      // end of IF any guests specified

      } else {   // skip 8 requested
         //
         //  User has responded to the guest association prompt - process tee time request in specified order
         //
         userg1 = req.getParameter("userg1");
         userg2 = req.getParameter("userg2");
         userg3 = req.getParameter("userg3");
         userg4 = req.getParameter("userg4");
         userg5 = req.getParameter("userg5");
      }         // end of IF skip8


      //
      //  Check if proshop user requested that we skip the following test
      //
      //  If this skip is set, then we've already been through these tests.
      //
      if (req.getParameter("skip9") == null) {
          
          //
          //  Make sure this signup has enough players as specified in the event conf
          //
          int players = 0;
          if (!player1.equals( "" )) players++;
          if (!player2.equals( "" )) players++;
          if (!player3.equals( "" )) players++;
          if (!player4.equals( "" )) players++;
          if (!player5.equals( "" )) players++;

          if (players < minsize) {

              out.println(SystemUtils.HeadTitle("Max Num Guests Exceeded - Reject"));
              out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
              out.println("<hr width=\"40%\">");
              out.println("<BR><H3>Not Enough Players</H3><BR>");
              out.println("<BR><BR>The number of players (" + players + ") does not meet the required amount (" + minsize + ").");
              out.println("<BR><BR>Would you like to override this and allow the event registration?");
              out.println("<BR><BR>");
              out.println("<font size=\"2\">");
              out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
              out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
              out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
              out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
              out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
              out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
              out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
              out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
              out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
              out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
              out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
              out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
              out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
              out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
              out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
              out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
              out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
              out.println("<input type=\"submit\" value=\"No - Return\" name=\"return\" style=\"text-decoration:underline; background:#8B8970\">");
              out.println("</form></font>");

              out.println("<form action=\"/" +rev+ "/servlet/Proshop_evntSignUp\" method=\"post\" target=\"_top\">");
              out.println("<input type=\"hidden\" name=\"skip9\" value=\"yes\">");
              out.println("<input type=\"hidden\" name=\"player1\" value=\"" + player1 + "\">");
              out.println("<input type=\"hidden\" name=\"player2\" value=\"" + player2 + "\">");
              out.println("<input type=\"hidden\" name=\"player3\" value=\"" + player3 + "\">");
              out.println("<input type=\"hidden\" name=\"player4\" value=\"" + player4 + "\">");
              out.println("<input type=\"hidden\" name=\"player5\" value=\"" + player5 + "\">");
              out.println("<input type=\"hidden\" name=\"p1cw\" value=\"" + p1cw + "\">");
              out.println("<input type=\"hidden\" name=\"p2cw\" value=\"" + p2cw + "\">");
              out.println("<input type=\"hidden\" name=\"p3cw\" value=\"" + p3cw + "\">");
              out.println("<input type=\"hidden\" name=\"p4cw\" value=\"" + p4cw + "\">");
              out.println("<input type=\"hidden\" name=\"p5cw\" value=\"" + p5cw + "\">");
              out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
              out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
              out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
              out.println("<input type=\"hidden\" name=\"notes\" value=\"" + notes + "\">");
              out.println("<input type=\"hidden\" name=\"hide\" value=\"" + hides + "\">");
              out.println("<input type=\"hidden\" name=\"suppressEmails\" value=\"" + suppressEmails + "\">");
              out.println("<input type=\"submit\" value=\"YES\" name=\"submitForm\"></form>");
              out.println("</CENTER></BODY></HTML>");
              return;
          }
          
      }
      
      
      //**************************************************************
      //  Verification Complete !!!!!!!!
      //**************************************************************
      //
      //  See if entry should be on wait list
      //
      if (wait == 0) {     // if not already on wait list
        
         if (oldPlayer1.equals( "" ) && oldPlayer2.equals( "" ) && oldPlayer3.equals( "" ) &&
             oldPlayer4.equals( "" ) && oldPlayer5.equals( "" )) {      // and new entry

            try {
               //
               //   see if event is full
               //
               PreparedStatement pstmtw = con.prepareStatement (
                  "SELECT player1, player2, player3, player4, player5 FROM evntsup2b " +
                  "WHERE name = ? AND courseName = ?");

               pstmtw.clearParameters();        // clear the parms
               pstmtw.setString(1, name);
               pstmtw.setString(2, course);
               rs2 = pstmtw.executeQuery();      // execute the prepared pstmt

               while (rs2.next()) {

                  wplayer1 = rs2.getString("player1");
                  wplayer2 = rs2.getString("player2");
                  wplayer3 = rs2.getString("player3");
                  wplayer4 = rs2.getString("player4");
                  wplayer5 = rs2.getString("player5");

                  t = 0;

                  if (!wplayer1.equals( "" ) || !wplayer2.equals( "" ) || !wplayer3.equals( "" ) ||
                      !wplayer4.equals( "" ) || !wplayer5.equals( "" )) {
                     t = 1;
                  }
                  teams = teams + t;        // bump number of teams if any players
               }
               pstmtw.close();

            }
            catch (Exception ignore) {
            }
            if (teams >= max) {
              
               wait = 1;      // put on wait list
            }
         }
      }

      //
      //  process email requirements for this entry
      //
      sendemail = 0;         // init email flags
      emailNew = 0;
      emailMod = 0;
      //
      //  If players changed, then send emails
      //
      if (!player1.equals( oldPlayer1 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player2.equals( oldPlayer2 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player3.equals( oldPlayer3 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player4.equals( oldPlayer4 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      if (!player5.equals( oldPlayer5 )) {

         sendemail = 1;    // player changed - send email notification to all
      }

      //
      //   Set email type based on new or update request (cancel set above)
      //
      if ((!oldPlayer1.equals( "" )) || (!oldPlayer2.equals( "" )) || (!oldPlayer3.equals( "" )) ||
          (!oldPlayer4.equals( "" )) || (!oldPlayer5.equals( "" ))) {

         emailMod = 1;  // tee time was modified

      } else {

         emailNew = 1;  // tee time is new
      }

   }  // end of 'cancel this res' if - cancel will contain empty player fields

   //
   //  Verification complete -
   //  Update the entry in the event sign up table
   //
   try {

      PreparedStatement pstmt6 = con.prepareStatement (
         "UPDATE evntsup2b SET player1 = ?, player2 = ?, player3 = ?, player4 = ?, player5 = ?, " +
         "username1 = ?, username2 = ?, username3 = ?, username4 = ?, username5 = ?, p1cw = ?, " +
         "p2cw = ?, p3cw = ?, p4cw = ?, p5cw = ?,  in_use = 0, hndcp1 = ?, hndcp2 = ?, hndcp3 = ?, " +
         "hndcp4 = ?, hndcp5 = ?, notes = ?, hideNotes = ?, wait = ?, " +
         "userg1 = ?, userg2 = ?, userg3 = ?, userg4 = ?, userg5 = ? " +
         "WHERE name = ? AND courseName = ? AND id = ?");

      pstmt6.clearParameters();        // clear the parms
      pstmt6.setString(1, player1);
      pstmt6.setString(2, player2);
      pstmt6.setString(3, player3);
      pstmt6.setString(4, player4);
      pstmt6.setString(5, player5);
      pstmt6.setString(6, user1);
      pstmt6.setString(7, user2);
      pstmt6.setString(8, user3);
      pstmt6.setString(9, user4);
      pstmt6.setString(10, user5);
      pstmt6.setString(11, p1cw);
      pstmt6.setString(12, p2cw);
      pstmt6.setString(13, p3cw);
      pstmt6.setString(14, p4cw);
      pstmt6.setString(15, p5cw);
      pstmt6.setFloat(16, hndcp1);
      pstmt6.setFloat(17, hndcp2);
      pstmt6.setFloat(18, hndcp3);
      pstmt6.setFloat(19, hndcp4);
      pstmt6.setFloat(20, hndcp5);
      pstmt6.setString(21, notes);
      pstmt6.setInt(22, hide);
      pstmt6.setInt(23, wait);
      pstmt6.setString(24, userg1);
      pstmt6.setString(25, userg2);
      pstmt6.setString(26, userg3);
      pstmt6.setString(27, userg4);
      pstmt6.setString(28, userg5);

      pstmt6.setString(29, name);
      pstmt6.setString(30, course);
      pstmt6.setInt(31, id);
         
      count = pstmt6.executeUpdate();      // execute the prepared stmt

      pstmt6.close();

   }
   catch (Exception e6) {

      dbError(out, e6);
      return;
   }

   //
   //  Build the HTML page to confirm event registration for user
   //
   out.println("<HTML>");
   out.println("<HEAD><link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
   out.println("<Title>Proshop Event Registration Page</Title>");

   if (wait == 0 && notesL < 255) {            // if not on wait list and notes ok
      out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_jump?name=" + name + "&course=" + course + "\">");
   }
   out.println("</HEAD>");
   out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<font size=\"3\" face=\"Arial, Helvetica, Sans-serif\">");

   if (req.getParameter("remove") != null) {

      out.println("<p>&nbsp;</p><p>&nbsp;<b>Thank you!</b>&nbsp;&nbsp;The event entry has been cancelled.</p>");
   } else {

      out.println("<p>&nbsp;</p><p>&nbsp;<b>Thank you!</b>&nbsp;&nbsp;Your Event Registration has been accepted and processed.</p>");

      if (wait > 0) {            // if on wait list

         out.println("<br><br><b>Note:</b>  This team is currently on the WAIT LIST.");
      }

      if (xcount > 0 && xhrs > 0) {            // if any X's were specified

         out.println("<p>&nbsp;</p>All player positions reserved by an 'X' must be filled within " + xhrs + " hours of the tee time.");
         out.println("<br>If not, the system will automatically remove the X.<br>");
      }

      if (notesL > 254) {

      out.println("<p>&nbsp;</p><b>Notice:</b>&nbsp;&nbsp;The notes you entered exceeded 254 characters in length.  All characters beyond 254 will be truncated.</p>");
      }
   }

   out.println("<p>&nbsp;</p></font>");

      out.println("<font size=\"2\">");
      out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
      out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
      out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</form></font>");

   //
   //  End of HTML page
   //
   out.println("</center></font></body></html>");


   try {

      resp.flushBuffer();      // force the repsonse to complete

   }
   catch (Exception ignore) {
   }


   //
   //***********************************************
   //  if entry was removed then check for a wait list
   //  and move a team up if possible
   //***********************************************
   //
   if (checkWait != 0) {

      teams = 0;

      try {

         //
         //   see if event is full
         //
         PreparedStatement pstmtw = con.prepareStatement (
            "SELECT player1, player2, player3, player4, player5 FROM evntsup2b " +
            "WHERE name = ? AND courseName = ? AND wait = 0");

         pstmtw.clearParameters();        // clear the parms
         pstmtw.setString(1, name);
         pstmtw.setString(2, course);
         rs2 = pstmtw.executeQuery();      // execute the prepared pstmt

         while (rs2.next()) {

            wplayer1 = rs2.getString("player1");
            wplayer2 = rs2.getString("player2");
            wplayer3 = rs2.getString("player3");
            wplayer4 = rs2.getString("player4");
            wplayer5 = rs2.getString("player5");

            t = 0;

            if (!wplayer1.equals( "" ) || !wplayer2.equals( "" ) || !wplayer3.equals( "" ) || 
                !wplayer4.equals( "" ) || !wplayer5.equals( "" )) {
               t = 1;
            }
            teams = teams + t;        // bump number of teams if any players
         }
         pstmtw.close();

         if (teams < max) {

            long wdate = 0;
            int wtime = 0;

            //
            //   get the earliest registration date on wait list
            //
            PreparedStatement stmtw1 = con.prepareStatement (
               "SELECT MIN(r_date) FROM evntsup2b " +
               "WHERE name = ? AND courseName = ? AND wait != 0");

            stmtw1.clearParameters();        // clear the parms
            stmtw1.setString(1, name);
            stmtw1.setString(2, course);
            rs = stmtw1.executeQuery();      // execute the prepared stmt

            if (rs.next()) {

               wdate = rs.getLong(1);
            }
            stmtw1.close();

            if (wdate != 0) {

               //
               //   get the earliest time on this reg date on wait list
               //
               PreparedStatement stmtw2 = con.prepareStatement (
                  "SELECT MIN(r_time) FROM evntsup2b " +
                  "WHERE name = ? AND courseName = ? AND r_date = ? AND wait != 0");

               stmtw2.clearParameters();        // clear the parms
               stmtw2.setString(1, name);
               stmtw2.setString(2, course);
               stmtw2.setLong(3, wdate);
               rs = stmtw2.executeQuery();      // execute the prepared stmt

               if (rs.next()) {

                  wtime = rs.getInt(1);
               }
               stmtw2.close();


               if (wtime != 0) {

                  //
                  //   get the earliest time on this reg date on wait list
                  //
                  PreparedStatement stmtw4 = con.prepareStatement (
                     "SELECT username1, username2, username3, username4, username5, id " +
                     "FROM evntsup2b " +
                     "WHERE name = ? AND courseName = ? AND r_date = ? AND r_time = ? AND wait != 0 ");

                  stmtw4.clearParameters();        // clear the parms
                  stmtw4.setString(1, name);
                  stmtw4.setString(2, course);
                  stmtw4.setLong(3, wdate);
                  stmtw4.setInt(4, wtime);
                  rs = stmtw4.executeQuery();      // execute the prepared stmt

                  if (rs.next()) {

                     wuser1 = rs.getString("username1");
                     wuser2 = rs.getString("username2");
                     wuser3 = rs.getString("username3");
                     wuser4 = rs.getString("username4");
                     wuser5 = rs.getString("username5");
                     id = rs.getInt("id");
                  }
                  stmtw4.close();

                  PreparedStatement pstmtw3 = con.prepareStatement (
                     "UPDATE evntsup2b SET wait = 0 " +
                     "WHERE name = ? AND courseName = ? AND id = ?");

                  pstmtw3.clearParameters();        // clear the parms
                  pstmtw3.setString(1, name);
                  pstmtw3.setString(2, course);
                  pstmtw3.setInt(3, id);

                  count = pstmtw3.executeUpdate();      // execute the prepared stmt

                  pstmtw3.close();
               }
            }
         }
      }
      catch (Exception ignore) {
      }

   }     // end of IF checkWait

   //
   //***********************************************
   //  Send email notification if necessary
   //***********************************************
   //
   //
   //  Get this today's date and the event date
   //
   Calendar cal = new GregorianCalendar();       // get todays date
   int thisYear = cal.get(Calendar.YEAR);       
   int thisMonth = cal.get(Calendar.MONTH) +1;
   int thisDay = cal.get(Calendar.DAY_OF_MONTH);

   long today = (thisYear * 10000) + (thisMonth * 100) + thisDay;   // today's date   

   long date = (year * 10000) + (month * 100) + day;            // create event date value

   if (today > date) {
     
      sendemail = 0;        // do not send emails if event has already passed
   }
     
   //
   //  Send the email if required
   //
   if (sendemail != 0 && suppressEmails.equalsIgnoreCase( "no" )) {

      //
      //  allocate a parm block to hold the email parms
      //
      parmEmail parme = new parmEmail();          // allocate an Email parm block

      //
      //  Set the values in the email parm block
      //
      parme.type = "event";         // type = event
      parme.date = date;
      parme.time = 0;
      parme.fb = 0;
      parme.mm = month;
      parme.dd = day;
      parme.yy = year;

      parme.wuser1 = wuser1;     // set Event-only fields
      parme.wuser2 = wuser2;
      parme.wuser3 = wuser3;
      parme.wuser4 = wuser4;
      parme.wuser5 = wuser5;
      parme.name = name;
      parme.etype = etype;
      parme.act_time = act_time;
      parme.wait = wait;
      parme.checkWait = checkWait;

      parme.user = user;
      parme.emailNew = emailNew;
      parme.emailMod = emailMod;
      parme.emailCan = emailCan;

      parme.p91 = 0;     // doesn't matter for event
      parme.p92 = 0;
      parme.p93 = 0;
      parme.p94 = 0;
      parme.p95 = 0;

      parme.course = course;
      parme.day = "";

      parme.player1 = player1;
      parme.player2 = player2;
      parme.player3 = player3;
      parme.player4 = player4;
      parme.player5 = player5;

      parme.oldplayer1 = oldPlayer1;
      parme.oldplayer2 = oldPlayer2;
      parme.oldplayer3 = oldPlayer3;
      parme.oldplayer4 = oldPlayer4;
      parme.oldplayer5 = oldPlayer5;

      parme.user1 = user1;
      parme.user2 = user2;
      parme.user3 = user3;
      parme.user4 = user4;
      parme.user5 = user5;

      parme.olduser1 = oldUser1;
      parme.olduser2 = oldUser2;
      parme.olduser3 = oldUser3;
      parme.olduser4 = oldUser4;
      parme.olduser5 = oldUser5;

      parme.pcw1 = p1cw;
      parme.pcw2 = p2cw;
      parme.pcw3 = p3cw;
      parme.pcw4 = p4cw;
      parme.pcw5 = p5cw;

      parme.oldpcw1 = oldp1cw;
      parme.oldpcw2 = oldp2cw;
      parme.oldpcw3 = oldp3cw;
      parme.oldpcw4 = oldp4cw;
      parme.oldpcw5 = oldp5cw;

      //
      //  Send the email
      //
      sendEmail.sendIt(parme, con);      // in common

   }     // end of IF sendemail

 }       // end of verify


 // ************************************************************************
 //  Process cancel request (Return w/o changes) from self
 // ************************************************************************

 private void cancelReq(HttpServletRequest req, PrintWriter out, Connection con) {


   int count = 0;
   int id  = 0;

   //
   // Get all the parameters entered
   //
   String name = req.getParameter("name");           //  name of event
   String course = req.getParameter("course");        //  name of course
   String sid = req.getParameter("id");               //  id of entry in evntsup table

   //
   //  Convert the values from string to int
   //
   try {
      id = Integer.parseInt(sid);
   }
   catch (NumberFormatException e) {
      // ignore error
   }

   //
   //  Clear the 'in_use' flag for this entry
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "UPDATE evntsup2b SET in_use = 0 WHERE name = ? AND courseName = ? AND id = ?");

      pstmt1.clearParameters();        // clear the parms
      pstmt1.setString(1, name);
      pstmt1.setString(2, course);
      pstmt1.setInt(3, id);
      count = pstmt1.executeUpdate();      // execute the prepared stmt

      pstmt1.close();

   }
   catch (Exception ignore) {

   }

   //
   //  Prompt user to return to Proshop_events2
   //
   out.println("<HTML>");
   out.println("<HEAD><link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
   out.println("<Title>Proshop Event Registration Page</Title>");

   out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/servlet/Proshop_jump?name=" + name + "&course=" + course + "\">");
   out.println("</HEAD>");
   out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><BR><H3>Return/Cancel Requested</H3>");
   out.println("<BR><BR>Thank you, the event entry has been returned to the system without changes.");
   out.println("<BR><BR>");

   out.println("<font size=\"2\">");
   out.println("<form action=\"/" +rev+ "/servlet/Proshop_jump\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"name\" value=\"" + name + "\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</form></font>");

   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 //  Database Error
 // *********************************************************

 private void dbError(PrintWriter out, Exception e1) {

      out.println(SystemUtils.HeadTitle("DB Error"));
      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Unable to access the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>Exception: " + e1.getMessage());
      out.println("<BR><BR>");
      out.println("<a href=\"javascript:history.back(1)\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Invalid data received - reject request
 // *********************************************************

 private void invData(PrintWriter out, String p1, String p2, String p3, String p4, String p5) {


   if (p1.equals( "" )) {

      p1 = " ";             // use space instead of null
   }

   if (p2.equals( "" )) {

      p2 = " ";             // use space instead of null
   }

   if (p3.equals( "" )) {

      p3 = " ";             // use space instead of null
   }

   if (p4.equals( "" )) {

      p4 = " ";             // use space instead of null
   }

   if (p5.equals( "" )) {

      p5 = " ";             // use space instead of null
   }

   out.println(SystemUtils.HeadTitle("Invalid Data - Reject"));
   out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
   out.println("<hr width=\"40%\">");
   out.println("<BR><H3>Invalid Data Received</H3><BR>");
   out.println("<BR><BR>Sorry, a name you entered is not valid.<BR>");
   out.println("<BR>You entered:&nbsp;&nbsp;&nbsp;'" + p1 + "',&nbsp;&nbsp;&nbsp;'" + p2 + "',&nbsp;&nbsp;&nbsp;'" + p3 + "',&nbsp;&nbsp;&nbsp;'" + p4 + "',&nbsp;&nbsp;&nbsp;'" + p5 + "'");
   out.println("<BR><BR>");
   out.println("Please check the names and try again.");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");
   return;
 }


}
