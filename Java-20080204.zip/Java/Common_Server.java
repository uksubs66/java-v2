/***************************************************************************************
 *   Common_Server:  This class defines constants used to maintain multiple servers all
 *                   running the ForeTees application.
 *
 *
 *   created: 3/01/2006   Bob
 *
 *   last updated:       ******* keep this accurate *******
 *
 *
 ***************************************************************************************
 */

import java.io.*;


public class Common_Server {

  //
  //  Server Id values - change this for each server - MUST be unique in each server!!!!!!!!!!!!
  //
  //     This id value can be displayed and changed by Support_serverid from any server.
  //
  public static int SERVER_ID = 1;          // server #1
//  public static int SERVER_ID = 2;          // server #2
//  public static int SERVER_ID = 3;          // server #3

}
