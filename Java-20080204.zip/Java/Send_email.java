/***************************************************************************************
 *   Send_email:  This servlet allows users to create an email and pick from
 *                distribution lists or members to send it to
 *
 *
 *   created: 1/14/2004   JAG
 *
 *   last updated:
 *
 *      10/31/07  Add new call to SystemUtils.tsheetTimer(club) for send backup tee sheet to the pro
 *      10/11/07  Pine Hills - add custom trailer message in emails from Pro.
 *      10/03/07  Troon CC - Disable email tool from member side (Case #1279)
 *       9/07/07  Add password protection to email feature on pro side. (Case #1233)
 *       8/22/07  New Canaan - Block proshop users from using the email feature. (TEMP until password protection implemented)
 *       5/31/07  Added fortcollins checks to outgoing emails to remove club name from subject & message body
 *       5/10/07  Added sender information to top of message.
 *       4/06/07  Do not include members that are inactive (new inact flag in member2b).
 *      10/07/06  Changes for bounced email address flagging
 *       7/19/06  Hillcrest WI - add custom trailer message in emails from Pro.
 *       5/23/06  Unfilter special chars from the clubname for the subject line.
 *       5/18/06  Move AOL message to end (trailer) of main message.
 *       5/10/06  Minneapolis restore the eamil feature.
 *       9/29/05  For Minneapolis members, disable the eamil feature for the rest of 2005.
 *       8/29/05  For members, use canned 'From' address to prevent send failures (forging).
 *       5/20/05  For proshop, use canned 'From' address to prevent send failures (forging).
 *      10/06/04  Ver 5 - add submenu support for Members.
 *       3/08/04  RDP Remove restriction of 100 recipients for proshop user.
 *                Send email to 100 recipients at a time when more than 100 requested.
 *                This is a mail server restriction.
 *       1/25/04  RDP Add logic to extract usernames from buddy table.
 *       1/24/04  RDP Add logic to query the distribution lists (dist4 table).
 *       1/08/05  JAG Add method to process members on a particular tee sheet
 *
 ***************************************************************************************
 */

//third party imports
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import javax.mail.internet.*;
import javax.mail.*;
import javax.activation.*;


//foretees imports
import com.foretees.client.ScriptHelper;
import com.foretees.client.action.Action;
import com.foretees.client.action.ActionModel;
import com.foretees.client.action.ActionHelper;
import com.foretees.client.attribute.Attribute;
import com.foretees.client.attribute.SelectionList;
import com.foretees.client.attribute.TextBox;
import com.foretees.client.form.FormModel;
import com.foretees.client.form.FormRenderer;
import com.foretees.client.layout.Separator;
import com.foretees.client.layout.LayoutHelper;
import com.foretees.member.Member;
import com.foretees.member.MemberHelper;
import com.foretees.client.misc.LetterChooser;
import com.foretees.client.misc.NameSelector;
import com.foretees.client.table.Cell;
import com.foretees.client.table.Column;
import com.foretees.client.table.RowModel;
import com.foretees.client.table.TableModel;
import com.foretees.common.FeedBack;
import com.foretees.common.Labels;
import com.foretees.common.ProcessConstants;
import com.foretees.common.help.Help;
import com.foretees.communication.CommunicationHelper;
import com.foretees.communication.DistributionList;
import com.foretees.communication.Email;
import com.foretees.event.Event;

/**
***************************************************************************************
*
* This servlet will display and process a page to send an email to a selected set of members
*
***************************************************************************************
**/

public class Send_email extends HttpServlet {

   //********************************************************
   // Some constants for emails sent within this class
   //********************************************************
   //
   static String host = ProcessConstants.HOST;
   static String port = ProcessConstants.PORT;

   //initialize the attributes
   private static String versionId = ProcessConstants.CODEBASE;

  /**
  ***************************************************************************************
  *
  * This method will process the request to send email messages from both members and pros
  *
  ***************************************************************************************
  **/

  public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    doGet(req, resp);

  }


  public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();


    HttpSession session = null;

    //
    // This servlet can be called by both Proshop and Member users - find out which
    //
    session = req.getSession(false);  // Get user's session object (no new one)

    if (session == null) {

       out.println(SystemUtils.HeadTitle("Access Error - Redirect"));
       out.println("<BODY><CENTER>");
       out.println("<BR><H2>Access Error</H2><BR>");
       out.println("<BR><BR>Sorry, you must login before attempting to access these features.<BR>");
       out.println("<BR>This site requires the use of Cookies for security purposes.");
       out.println("<BR>We use them to verify your session and prevent unauthorized access.");
       out.println("<BR><BR>Please check your 'Privacy' settings, under 'Tools', 'Internet Options'");
       out.println("<BR>(for MS Internet Explorer).  This must be set to 'Medium High' or lower.");
       out.println("<BR><BR>");
       out.println("<BR>If you have changed or verified the setting above and still receive this message,");
       out.println("<BR>please email us at <a href=\"mailto:support@foretees.com\">support@foretees.com</a>.");
       out.println("<BR>Provide your name and the name of your club.  Thank you.");
       out.println("<BR><BR>");
       out.println("<a href=\""  + versionId +  "servlet/Logout\" target=\"_top\">Return</a>");
       out.println("</CENTER></BODY></HTML>");
       return;
    }

    //
    //  ***** get user id so we know if proshop or member
    //
    String user = (String)session.getAttribute("user");     // get username ('proshop' or member's username)
    String caller = (String)session.getAttribute("caller");     // get caller (web site?)
    String club = (String)session.getAttribute("club");   

    // see if we are here to send out a backup tee sheet
    if (req.getParameter("backup") != null && ProcessConstants.isProshopUser(user)) {
        
        SystemUtils.tsheetTimer(club, out);
        out.println(SystemUtils.HeadTitle("Send Backup Tee Sheet"));
        out.println("<BODY><CENTER>");
        out.println("<BR><H2>Send Backup Tee Sheet</H2><BR>");
        out.println("<BR><BR>We have sent todays tee sheet to you in an email.<BR>");
        out.println("<BR>Normally you should recieve the email within a few minutes, however if you");
        out.println("<BR>do not receive it within 15 minutes there may be a problem.");
        out.println("<BR>Make sure you have an email address specified and have choosen to receive ");
        out.println("<BR>backup tee sheets under System Config | Club Setup | Club Options.");
        out.println("<BR>If it ends up in your junk or spam folder you can try adding ");
        out.println("<BR>teesheets@foretees.com to your Contacts / Address Book in your email program.");
        out.println("<BR><BR>");
        out.println("<a href=\""  + versionId +  "servlet/Proshop_announce\">Home</a>");
        out.println("</CENTER></BODY></HTML>");
        return;
    }
    
    //get the database connection
    Connection con = SystemUtils.getCon(session);            // get DB connection

    //if this is a member, check to see if the user has registered an email address in the system, if not
    //they cannot use the email feature.  Let them know and give them a link the Settings
    //page to add one.

    if (!ProcessConstants.isProshopUser(user) && !ProcessConstants.isAdminUser(user))
    {
      if (!MemberHelper.hasEmailAddress(user, con, out))
      {

         String settingsUrl = "servlet/Member_services";

         out.println(SystemUtils.HeadTitleAdmin(Email.SEND_EMAIL_LIST_HEADER));
         out.println("<BODY>");
         SystemUtils.getMemberSubMenu(req, out, caller);        // required to allow submenus on this page
         out.println("<CENTER><BR><BR>To use the email feature you must first register an email address with the system.<BR>");
         out.println("<BR>Use the ");
         out.print("<a href=\""  + versionId +  settingsUrl + "\" target=\"bot\">Settings</a>");
         out.print(" page to enter your email address.</CENTER><BR><BR></BODY>");

         drawEndOfPageAfterForm(out);
         return;
           

      } else {         // member ok - check if MPLS GC and if so do not allow them to use email (temp)
              
         if (club.equals( "minneapolis" )) {
  
            out.println(SystemUtils.HeadTitleAdmin("Service Suspended Notification"));
            out.println("<BODY>");
            SystemUtils.getMemberSubMenu(req, out, caller);        // required to allow submenus on this page
            out.println("<CENTER><BR><BR>Sorry, but the email feature has been temporarily disabled.<BR>");
            out.print("</CENTER><BR><BR></BODY>");

            drawEndOfPageAfterForm(out);
            return;
            
         } else if (club.equals( "trooncc" )) {
  
            out.println(SystemUtils.HeadTitleAdmin("Service Suspended Notification"));
            out.println("<BODY>");
            SystemUtils.getMemberSubMenu(req, out, caller);        // required to allow submenus on this page
            out.println("<CENTER><BR><BR>Sorry, but the email feature is disabled for your club.<BR>");
            out.print("</CENTER><BR><BR></BODY>");

            drawEndOfPageAfterForm(out);
            return;
         }

      }
    } else {
        /*
        if (club.equals( "newcanaan" ) && user.startsWith("proshop")) {
  
            out.println(SystemUtils.HeadTitleAdmin("Service Suspended Notification"));
            out.println("<BODY>");
            SystemUtils.getProshopSubMenu(req, out, 0);
            out.println("<CENTER><BR><BR>Sorry, but the email feature has been temporarily disabled.<BR>");
            out.print("</CENTER><BR><BR></BODY>");

            drawEndOfPageAfterForm(out);
            return;
            
         } else { */
          
            String emailPass = "";
            String userPass = req.getParameter("emailPass");
            if (userPass == null) userPass = "";
            
            try {

                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT emailPass FROM club5;");
                
                if (rs.next()) emailPass = rs.getString(1);
                
                rs.close();
                stmt.close();
                
            } catch (Exception exp) {
                
                SystemUtils.buildDatabaseErrMsg("Unable to retrieve required password.", exp.toString(), out, false);
                return;
            }
            
            if (!emailPass.equals("") && !userPass.equals(emailPass)) {
                
                out.println(SystemUtils.HeadTitle("Password Required"));
                out.println("<BODY>");
                SystemUtils.getProshopSubMenu(req, out, 0);
                out.println("<CENTER><BR><BR>");
                out.println("<h3>Authentication Required</h3>");
                out.println("<p>Your club requires that you provide a password in order to access the email communication feature.</p>");
                out.println("<form method=post>");
                out.println("Password:&nbsp; <input type=password name=emailPass value=''> ");
                out.println("&nbsp; &nbsp; <input type=submit value=' Submit '>");
                out.println("</form>");
                out.print("</CENTER><BR><BR></BODY>");
                
                drawEndOfPageAfterForm(out);
                return;
                
            }
            
         //}
    }
    
    String action = req.getParameter(ActionHelper.NEXT_ACTION);
    
    if (action == null || action.equals(""))
    {
      action = (String)(req.getAttribute(ActionHelper.NEXT_ACTION));
    }

    boolean refresh = false;

    if (action == null || action.equals(""))
    {
      action = "";
      refresh = true;
    }

    if (action.equals(ActionHelper.ADD_TO_LIST))
    {
      addToList(session, req, resp, con, out);
    }
    else if (action.equals(ActionHelper.REMOVE_FROM_LIST))
    {
      removeFromList(session, req, resp, con, out);
    }
    else if (action.equals(ActionHelper.SEND))
    {
      sendEmail(session, req, resp, con, out);
    }
    else if (action.equals(ActionHelper.CANCEL))
    {
      showPage(null, session, req, resp, con, out, true);
    }
    else
    {
      showPage(null, session, req, resp, con, out, refresh);
    }

  }



  //******************************************************************************************************
  //   showPage
  //******************************************************************************************************
  //
  private void showPage(FeedBack feedback, HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out, boolean refresh)
    throws IOException
  {

    if (refresh)
    {
      session.removeAttribute(Email.EMAIL_FRM);
    }

    FormModel form = retrieveFormFromSession(session, req, res, con, out);

    if (!refresh)
    {
      form.update(req, res, out);
    }

    drawBeginningOfPageBeforeForm(feedback, out, req, session);
    FormRenderer.render(form, out);
    drawEndOfPageAfterForm(out);

  }


  //******************************************************************************************************
  //   addToList
  //******************************************************************************************************
  //
  private void addToList(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

    FormModel form = retrieveFormFromSession(session, req, res, con, out);
    FeedBack feedback = null;

    ArrayList selected_items = null;
    ArrayList selected_names = null;

    String user = (String)session.getAttribute("user");   // get username

    String search_type = (String)(req.getParameter(ActionHelper.SEARCH_TYPE));

    if (search_type.equals(ActionHelper.ADD_PARTNERS))
    {
      selected_names = getUserNamesFromPartnerList(session, req, res, con, out);

      if (selected_names == null || selected_names.size()<=0)
      {
        feedback = new FeedBack();
        feedback.setPositive(false);
        String message = ScriptHelper.escapeSpecialCharacters("You don't have any members on your partner list.");
        feedback.addMessage(message);

      }

    }
    else
    {
      String items = req.getParameter(ActionHelper.SELECTED_ITEMS_STRING);

      if (items != null && !(items.equals("")))
      {

        selected_items = ActionHelper.getSelectedNames(items);

      }

      if (search_type.equals(ActionHelper.SEARCH_LISTS))
      {
        //for each distribution list selected, need to extract the user names
        selected_names = getUserNamesFromDistributionLists(selected_items, session, req, res, con, out);

      }
      else if (search_type.equals(ActionHelper.SEARCH_EVENTS))
      {
        //for each event selected, need to extract the user names
        selected_names = getUserNamesFromEvents(selected_items, session, req, res, con, out);

      }
      else if (search_type.equals(ActionHelper.SEARCH_TEESHEET))
      {
        //for the indicated tee sheet, need to extract the user names
        selected_names = getUserNamesFromTeeSheet(session, req, res, con, out);

      }
      else //the search type was for members, user names are already determined
      {
        selected_names = selected_items;
      }

    }

    if (selected_names != null && selected_names.size()>0)
    {

      //get the table from the form and add the name in the list
      RowModel row = form.getRow(DistributionList.LIST_OF_NAMES);
      TableModel names = (TableModel)(((Cell)row.get(0)).getContent());

      for (int i=0; i<selected_names.size(); i++)
      {

        //check to see if this name is already in the list
        String name_to_add = (String)(selected_names.get(i));
        RowModel nameRow = names.getRow(name_to_add);

        boolean sizeOK = true;

        // make sure there aren't too many names (pro is unlimited)
       if (!ProcessConstants.isProshopUser(user) && !ProcessConstants.isAdminUser(user))
       {
          if (names.size() >= Email.MAX_RECIPIENTS)
          {
             sizeOK = false;
          }
        }

        if (sizeOK == true)
        {
          if (nameRow == null)
          {
            try
            {
              nameRow = new RowModel();
              nameRow.setId(name_to_add);
              String displayName = "";

              displayName = MemberHelper.getMemberDisplayName(con, name_to_add, out);   // pass username

              nameRow.add(displayName);
              ActionModel actions = new ActionModel();
              String removeUrl = "javascript:removeNameFromList('" + versionId + "servlet/Send_email', '" + ActionHelper.REMOVE_FROM_LIST + "', '" + name_to_add + "')";
              Action removeAction = new Action(ActionHelper.REMOVE, Labels.REMOVE, "Remove this member from the list.", removeUrl);

              actions.add(removeAction);
              nameRow.add(actions);
              names.addRow(nameRow);
            }
            catch (SQLException sqle)
            {
              //what to do
            }
          }
        }
        else
        {
          feedback = new FeedBack();
          feedback.setPositive(false);
          feedback.addMessage("The maximum number of recipients for an email is 100.  Some of the selected members may not have been added.");
        }
      }

      ActionModel model = names.getContextActions();
      boolean maxSizeReached = false;
      if (names.size()>=Email.MAX_RECIPIENTS)
      {
        if (!ProcessConstants.isProshopUser(user) && !ProcessConstants.isAdminUser(user))
        {
           maxSizeReached = true;
        }
      }

      for (int i=0; i<model.size(); i++)
      {
        ((Action)(model.get(i))).setSelected(maxSizeReached);

      }

    }

    showPage(feedback, session, req, res, con, out, false);
  }


  //******************************************************************************************************
  //  addTeeSheetMembersToList
  //******************************************************************************************************
  //
  private void addTeeSheetMembersToList(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
  throws IOException
  {

     buildForm(req, res, session, con, out);
     showPage(null, session, req, res, con, out, true);

  }


  //******************************************************************************************************
  //  getUserNamesFromPartnerList  
  //******************************************************************************************************
  //
  private ArrayList getUserNamesFromPartnerList(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

    String user = (String)session.getAttribute("user");   // get username
    ArrayList usernames = new ArrayList();

    try
    {
       PreparedStatement pstmt = con.prepareStatement (
                "SELECT * FROM buddy WHERE username = ?");

       pstmt.clearParameters();            // clear the parms
       pstmt.setString(1, user);           // put username in statement
       ResultSet rs = pstmt.executeQuery();          // execute the prepared stmt

       String nextBuddy = "";
       String email = "";

       if (rs.next())
       {

          for (int buddyCount = 1; buddyCount < 26; buddyCount++)
          {
             nextBuddy = rs.getString("user" +buddyCount);

             if (nextBuddy != null && !(nextBuddy.equals("")))
             {
                //check if the buddy has registered an email address
                try
                {
                  PreparedStatement stmt = con.prepareStatement (
                       "SELECT email FROM member2b WHERE username = ? AND email_bounced = 0 AND inact = 0");

                  stmt.clearParameters();                   // clear the parms
                  stmt.setString(1, nextBuddy);             // put the parm in stmt
                  ResultSet mrs = stmt.executeQuery();      // execute the prepared stmt

                  if (mrs.next())
                  {

                    email = mrs.getString("email");

                    if (email != null && !(email.equals("")))
                    {

                       usernames.add(nextBuddy);
                    }
                  }

                  stmt.close();
                }
                catch (Exception exc)
                {
                }
             }
          }        // end of FOR loop

       }  // end of IF rs.next

       pstmt.close();

    }
    catch (Exception exc)
    {
    }

    return(usernames);
  }



  //******************************************************************************************************
  //   getUserNamesFromDistributionLists  
  //******************************************************************************************************
  //
  private ArrayList getUserNamesFromDistributionLists(ArrayList selectedItems, HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

    ArrayList names = new ArrayList();

    //get the database table name based on the user
    String table_name = DistributionList.getTableName(session);    // 'dist4' or 'dist4p'

    //
    //  Get this user's distribution lists, if any, and list them by name
    //
    String user = (String)session.getAttribute("user");     // get username ('proshop' or member's username)
    int list_size = DistributionList.getMaxListSize(session) + 1;

    String [] users = new String [list_size];                     // max of 30 users per dist list (start with 1)
    String uname = "";

    if (selectedItems != null)
    {
      for (int i=0; i<selectedItems.size(); i++)
      {
        String list_name = (String)(selectedItems.get(i));

        try
        {

          PreparedStatement stmt = con.prepareStatement (
                 "SELECT * FROM " + table_name + " WHERE name = ? AND owner = ?");

          stmt.clearParameters();               // clear the parms
          stmt.setString(1, list_name);
          stmt.setString(2, user);
          ResultSet rs = stmt.executeQuery();            // execute the prepared stmt

          if (rs.next())
          {

             for (int i2 = 1; i2 < list_size; i2++) {               // check all 30 (start with 1)

                uname = "user" +i2;
                users[i2] = rs.getString(uname);

                // add each user from the distribution list
                if (!users[i2].equals( "" )) {

                   names.add(users[i2]);
                }
             }
          }
        }
        catch(Exception exc)
        {
        }
      }
    }

    return names;
  }


  //******************************************************************************************************
  //  getUserNamesFromTeeSheet
  //******************************************************************************************************
  //
  private ArrayList getUserNamesFromTeeSheet(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
  throws IOException
  {


      ArrayList selectedItems = new ArrayList();
      //get the teesheet date
      String indexStr = req.getParameter("index");
      if (indexStr == null || indexStr.equals(""))
        indexStr = "0";

      int index = (new Integer(indexStr)).intValue();

      // get the course
      String course = (String)req.getParameter("course");


      PreparedStatement pstmt2p = null;
      ResultSet rs = null;
      String email = "";

      String [] username = new String [6];

      //
      //  Get today's date and then use 'index' to locate the requested date
      //
      Calendar cal = new GregorianCalendar();       // get todays date

      cal.add(Calendar.DATE,index);                  // roll ahead 'index' days

      int year = cal.get(Calendar.YEAR);
      int month = cal.get(Calendar.MONTH) + 1;
      int day = cal.get(Calendar.DAY_OF_MONTH);

      long date = (year * 10000) + (month * 100) + day;    // create a date field of yyyymmdd


      try{
        //
        //  Get the username for each member in this date's tee sheet (username will only be present for members)
        //
        if (course.equals( "-ALL-" )) {

            pstmt2p = con.prepareStatement (
              "SELECT username1, username2, username3, username4, username5 " +
              "FROM teecurr2 WHERE date = ?");

            pstmt2p.clearParameters();        // clear the parms
            pstmt2p.setLong(1, date);

        } else {

            pstmt2p = con.prepareStatement (
              "SELECT username1, username2, username3, username4, username5 " +
              "FROM teecurr2 WHERE date = ? AND courseName = ?");

            pstmt2p.clearParameters();        // clear the parms
            pstmt2p.setLong(1, date);
            pstmt2p.setString(2, course);
        }

        rs = pstmt2p.executeQuery();      // execute the prepared stmt

        while (rs.next()) {

            for (int i = 1; i < 6; i++) {

              username[i] = rs.getString( i );
              if (!username[i].equals( "" )) {

                  if (MemberHelper.hasEmailAddress(username[i], con, out))
                    selectedItems.add(username[i]);

              }

            }

        }

        pstmt2p.close();
    }
    catch (SQLException sqle)
    {
         String club = (String)session.getAttribute("club");   // get club name
         String errorMsg = "Error adding teesheet members to the email (Send_email) from " +club+ ", Error: " +sqle.getMessage(); // build error msg
         SystemUtils.logError(errorMsg);                           // log it

    }

    return selectedItems;
  }


  //******************************************************************************************************
  //  getUserNamesFromEvents
  //******************************************************************************************************
  //
  private ArrayList getUserNamesFromEvents(ArrayList selectedItems, HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

    ArrayList names = new ArrayList();

    String user1 = "";
    String user2 = "";
    String user3 = "";
    String user4 = "";
    String user5 = "";

    if (selectedItems != null)
    {
      for (int i=0; i<selectedItems.size();i++)
      {
        String event_name = (String)(selectedItems.get(i));

        try
        {

          PreparedStatement stmt = con.prepareStatement (
                 "SELECT username1, username2, username3, username4, username5 FROM evntsup2b WHERE name = ?");

          stmt.clearParameters();               // clear the parms
          stmt.setString(1, event_name);
          ResultSet rs = stmt.executeQuery();            // execute the prepared stmt

          while (rs.next())
          {

             user1 = rs.getString(1);
             user2 = rs.getString(2);
             user3 = rs.getString(3);
             user4 = rs.getString(4);
             user5 = rs.getString(5);

             // add each member currently registered for the selected event
             if (!user1.equals( "" )) {
                if (MemberHelper.hasEmailAddress(user1, con, out))
                  names.add(user1);
             }
             if (!user2.equals( "" )) {
                if (MemberHelper.hasEmailAddress(user2, con, out))
                  names.add(user2);
             }
             if (!user3.equals( "" )) {
               if (MemberHelper.hasEmailAddress(user3, con, out))
                  names.add(user3);
             }
             if (!user4.equals( "" )) {
               if (MemberHelper.hasEmailAddress(user4, con, out))
                names.add(user4);
             }
             if (!user5.equals( "" )) {
                if (MemberHelper.hasEmailAddress(user5, con, out))
                names.add(user5);
             }

          }
        }
        catch(Exception exc)
        {
        }
      }
    }
    return names;
  }


  //******************************************************************************************************
  //  removeFromList
  //******************************************************************************************************
  //
  private void removeFromList(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

    FormModel form = retrieveFormFromSession(session, req, res, con, out);

    //the user has submitted a name to add to the list
    String name_to_remove = req.getParameter(Member.REQ_USER_NAME);

    if (name_to_remove != null && !(name_to_remove.equals("")))
    {

      //get the table from the form and add the name in the list
      RowModel row = form.getRow(DistributionList.LIST_OF_NAMES);
      TableModel names = (TableModel)(((Cell)row.get(0)).getContent());

      names.remove(name_to_remove);

      ActionModel model = names.getContextActions();
      boolean maxSizeReached = false;
      if (names.size()>=Email.MAX_RECIPIENTS)
      {
        maxSizeReached = true;
      }

      for (int i=0; i<model.size(); i++)
      {
        ((Action)(model.get(i))).setSelected(maxSizeReached);

      }
    }



    showPage(null, session, req, res, con, out, false);

  }


  //******************************************************************************************************
  //   sendEmail
  //******************************************************************************************************
  //
  private void sendEmail(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {

   Statement stmtN = null;
   ResultSet rs = null;


   String fb_message = "";
   String clubName = "";

   boolean aol = false;

   //  ***** get user id so we know if proshop or member

   String user = (String)session.getAttribute("user");     // get username ('proshop' or member's username)
   String club = (String)session.getAttribute("club");

   //
   //  Get the name of the club
   //
   try {

      stmtN = con.createStatement();

      rs = stmtN.executeQuery("SELECT clubName FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         clubName = rs.getString(1);
      }
      stmtN.close();

   }
   catch (Exception ignore) {
   }

   if (!clubName.equals( "" )) {
     
      clubName = SystemUtils.unfilter(clubName);   //  Filter out special characters - change from html format to real chars
   }


   //get the subject, message and the to list

   String subject = req.getParameter(Email.SUBJECT);
   String headerAOL = ProcessConstants.TRAILERAOL2;
   String trailer = "";
   String eaddr = "";
   String message = "";
   String memberName = SystemUtils.getFullNameFromUsername(user, con);
   
   if (user.startsWith("proshop")) {
       
       if (club.equals("fortcollins")) {
           message = "Your golf professional has sent you the following message:\n\n";
       } else {
           message = "Your golf professional at " + clubName + " has sent you the following message:\n\n";
       }
       
   } else {
        
       message = memberName + " has sent you the following message.\n\n";
   }

   message += req.getParameter(Email.MESSAGE);

   //
   //  Add the name of the club to the subject to ensure it is included (for members that belong to multiple clubs)
   //
   if (!club.equals("fortcollins")) {
       if (!clubName.equals( "" )) subject += " (" +clubName+ ")";
   }
  
   String efrom = MemberHelper.getEmailAddress(user, con, out);  // get caller's email address (pro or member)

   String replyTo = efrom;                                       // copy for ReplyTo field

   //
   //  for proshop use YourGolfShop@foretees.com as the From address to prevent 'forging' problem
   //
   if (user.startsWith( "proshop" )) {

      efrom = ProcessConstants.EFROMPRO;
        
      if (club.equals( "hillcrestwi" ) || club.equals( "pinehills" )) {        // if Hillcrest WI or Pine Hills
        
         trailer = "\n\n\n*****************************************************************************************" +
                   "\nNOTICE: This message has been sent by a golf professional at your club via the ForeTees system. " +
                   "In order to comply with new anti-spam rules, we cannot use the sender's email address in the FROM " +
                   "field. However, you may reply to the sender as their address is saved in the REPLY-TO field. " +
                   "You may also contact him/her at ";
  
      } else {
        
         trailer = ProcessConstants.TRAILERPRO;
      }
        
   } else {

      efrom = ProcessConstants.EFROMMEM;     // for members use "aMemberOfYourClub@foretees.com"
      trailer = ProcessConstants.TRAILERMEM;
   }


   //
   //  make sure there is a 'from' address for members
   //
   if (replyTo.equals( "" ) && !user.startsWith( "proshop" )) {

     FeedBack feedback = new FeedBack();
     feedback.setPositive(false);

     fb_message = "You don't have an email address.  Please go to Settings and add your email address.";
   
     feedback.addMessage(ScriptHelper.escapeSpecialCharacters(fb_message));
     showPage(feedback, session, req, res, con, out, false);
   }

   FormModel form = retrieveFormFromSession(session, req, res, con, out);

   RowModel row = form.getRow(DistributionList.LIST_OF_NAMES);
   TableModel names = (TableModel)(((Cell)row.get(0)).getContent());
   //there should be at least one person on the to list
   if (names.size() <= 0)
   {
     FeedBack feedback = new FeedBack();
     feedback.setPositive(false);
     fb_message = "You don't have anyone on the send to list.  Please add at least one member to the list.";
     feedback.addMessage(ScriptHelper.escapeSpecialCharacters(fb_message));

     showPage(feedback, session, req, res, con, out, false);
     return;
   }

   //we need to get the email address for each user from the database

   int i = 0;
   int i2 = 0;
   int i3 = 0;
   int i4 = 0;
   int count = 0;

   boolean dup = false;

   ArrayList all_email_addresses = new ArrayList(names.size());
   for (i=0; i<names.size(); i++)
   {
     ArrayList email_addresses = MemberHelper.getEmailAddresses((names.getRow(i)).getId(), con, out); // put usernames in array

     for (int j=0; j<email_addresses.size(); j++){
       if ((email_addresses.get(j)) != null && !((email_addresses.get(j)).equals("")))
       {
         all_email_addresses.add(email_addresses.get(j));    // add the email address to the list
       }
     }
   }

   if (user.startsWith( "proshop" )) {      // if email from proshop

      all_email_addresses.add( replyTo );   // add his own address so copy is sent to pro
   }

   //
   //  Remove any duplicate addresses
   //
   i = all_email_addresses.size();
     
   String [] eaddrA = new String [i];

   for (i2=0; i2<i; i2++) {          // init the email address array

      eaddrA[i2] = "";
   }

   for (i2=0; i2<i; i2++) {          // check all email address

      eaddr = String.valueOf(all_email_addresses.get(i2));      // get the email address

      if (eaddr.endsWith( "aol.com" )) {                        // if AOL address

         aol = true;
      }

      dup = false;

      //
      //  Only use this address if it is unique
      //
      if (i3 > 0) {                 // i3 is index for eaddrA array of email addresses (next location)

         eloop1:
         for (i4=0; i4<i3; i4++) {

            if (eaddr.equals( eaddrA[i4] )) {              // address already in list ?

               dup = true;
               break eloop1;
            }
         }

         if (dup == false) {

            eaddrA[i3] = eaddr;                                 // save email addr 
            i3++;
         }

      } else {

         eaddrA[i3] = eaddr;                                 // save email addr 
         i3++;
      }
   }

   //
   //  Add trailer to message
   //
   message = message + trailer;            // add trailer message (Notice.....)

   if (user.startsWith( "proshop" )) {

      message = message + replyTo;    // add pro's eamil addr to the 'unsubscribe' message
   }

   //
   //  Add AOL trailer to message if any AOL addresses were found (add as header so they see it)
   //
   if (aol == true) {

      message = message + headerAOL;      // add AOL header message (Notice AOL Users...)
   }

   //
   //send the email (send to a max of 100 recipients at a time)
   //
   //
   //  NOTICE:  ****** change this to do 1 at a time when we get our own email server !!!!!!!!!!!!!!
   //
   i = i3;               // # of email addresses to send to
   i3 = 0;

   loop1:
   while (i > 0) {       // i = number of recipients

      if (i > 99) {      // if more than 99 recipients

         count = 100;    // do 100
         i -= 100;       // adjust # of recipients

      } else {

         count = i;     // less than 100, do them all now
         i = 0;         // done
      }

      Properties properties = new Properties();
      properties.put("mail.smtp.host", host);                      // set outbound host address
      properties.put("mail.smtp.port", port);                      // set port address
      properties.put("mail.smtp.auth", "true");                    // set 'use authentication'

      Session mailSess = Session.getInstance(properties, getAuthenticator()); // get session properties

      MimeMessage email_message = new MimeMessage(mailSess);

      try {

         InternetAddress iareply[] = new InternetAddress[1];               // create replyto array
         iareply[0] = new InternetAddress(replyTo);

         email_message.setFrom(new InternetAddress(efrom));                // set 'from' addr
         email_message.setReplyTo(iareply);                                // set 'replyto' addr

         email_message.setSubject( subject );                              // set subject line
         email_message.setSentDate(new java.util.Date());                  // set date/time sent

         //  set all the 'to' addresses
         for (i2=0; i2<count; i2++)
         {
           if (user.startsWith( "proshop" )) {      // Proshop - put addresses in BCC (to hide)
             email_message.addRecipient(Message.RecipientType.BCC, new InternetAddress(eaddrA[i3]));
           } else {
             email_message.addRecipient(Message.RecipientType.TO, new InternetAddress(eaddrA[i3]));
           }
           i3++;
         }

         email_message.setText( message );       // put msg in email text area

         Transport.send(email_message);          // send it!!

      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
    //     e1.printStackTrace();
         String errorMsg = "Error sending email (Send_email) from " +club+ ", Error: " +e1.getMessage(); // build error msg
         SystemUtils.logError(errorMsg);                           // log it
      }
   }              // end of while

   //
   //  Build the HTML page
   //
   out.println(SystemUtils.HeadTitle("Email Confirmation Page"));
   out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\">");
   out.println("<font face=\"Arial, Helvetica, Sans-serif\">");

   out.println("<center><img src=\"" +versionId+ "images/foretees.gif\"><hr width=\"40%\">");
   out.println("<font size=\"3\" face=\"Arial, Helvetica, Sans-serif\">");
   out.println("<p>&nbsp;</p><p>&nbsp;<b>Thank you!</b>&nbsp;&nbsp;Your email message has been sent.</p></font>");
   out.println("<table border=0><tr><td>");
   out.println("<form method=\"get\" action=\"" +versionId+ "servlet/Send_email\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline;width:90px\">");
   out.println("</form>");
   out.println("</td><td>&nbsp;</td><td>");
   out.println("<form method=\"get\" action=\"" +versionId+ "servlet/Proshop_announce\">");
   out.println("<input type=\"submit\" value=\"Home\" style=\"text-decoration:underline;width:90px\">");
   out.println("</form></td></tr></table>");
   out.println("</center></body></html>");
   out.close();
 }


 // ************************************************************************
 //  Process getAuthenticator for email authentication
 // ************************************************************************

 private static Authenticator getAuthenticator() {

    Authenticator auth = new Authenticator() {

       public PasswordAuthentication getPasswordAuthentication() {

         return new PasswordAuthentication("support@foretees.com", "fikd18"); // credentials
       }
    };

    return auth;
 }


  /**
  ***************************************************************************************
  *
  * This method will retrieve the email form from the session if one exists or will build
  * a new one and return it.
  *
  * @param session
  * @param req
  * @param resp
  * @param con
  * @param out
  * @return the form from session or a new one.
  *
  ***************************************************************************************
  **/

  private FormModel retrieveFormFromSession(HttpSession session, HttpServletRequest req, HttpServletResponse res, Connection con, PrintWriter out)
    throws IOException
  {
    Object theForm = session.getAttribute(Email.EMAIL_FRM);

    if ( theForm != null && theForm instanceof FormModel)
    {
      return (FormModel)theForm;
    }
    else
    {
      FormModel form = buildForm(req, res, session, con, out);
      session.setAttribute(Email.EMAIL_FRM, form);
      return form;
    }
  }

  /**
  ***************************************************************************************
  *
  * This method will draw the the portion of the page that comes before the send email
  * form
  *
  * @param feedback the feedback model that contains any messages to present to the user
  *                 upon loading the page
  * @param out the printwriter to write out the html
  *
  ***************************************************************************************
  **/

  private void drawBeginningOfPageBeforeForm(FeedBack feedback, PrintWriter out, HttpServletRequest request, HttpSession session)
  {
    ActionModel pageActions = new ActionModel();
    //Action sendEmailHelp = new Action(ActionHelper.HELP, Labels.HELP);
    //sendEmailHelp.setUrl("javascript:openNewWindow('" + versionId + Help.SEND_EMAIL + "', 'SendEmailOnlineHelp', 'width=500, height=450, directories=no, location=no, menubar=no, scrollbars=yes, status=no, toolbar=no, resizable=yes')");

    //pageActions.add(sendEmailHelp);

    out.println(SystemUtils.HeadTitleAdmin(Email.SEND_EMAIL_LIST_HEADER));
    String onLoad = "";

    if (feedback != null)
    {
      onLoad = "javascript:displayFeedbackMessage('" + feedback.get(0) + "')"; //document.pgFrm." + feedback.getAffectedField() + ".focus()";
    }
    else
    {
      onLoad = "document.pgFrm." + Email.SUBJECT + ".focus()";

    }

 //   String onUnLoad = "javascript:cleanup('" + versionId + "servlet/Communication', 'cleanup', 'Your email will not be sent.')";


    LayoutHelper.drawBeginPageContentWrapper(onLoad, null, out);

    String user = (String)session.getAttribute("user");     // get username ('proshop' or member's username)
    String caller = (String)session.getAttribute("caller");     // get caller (web site?)

    if (ProcessConstants.isProshopUser(user))
    {
      String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
      int lottery = Integer.parseInt(templott);
      SystemUtils.getProshopSubMenu(request, out, lottery);
    }
    else if (ProcessConstants.isAdminUser(user))
    {
      //fix later
    }
    else
      SystemUtils.getMemberSubMenu(request, out, caller);


    //ActionHelper.drawDistListNavBar(ActionHelper.SEND_EMAIL_TO_DIST_LIST, out);
    LayoutHelper.drawBeginMainBodyContentWrapper(Email.SEND_EMAIL_LIST_HEADER, pageActions, out);

  }

  /**
  ***************************************************************************************
  *
  * This method will draw the the portion of the page that contains the email form
  *
  * @param req the request that contains information submitted by the user
  * @param resp the response object
  * @param session the session object
  * @param con the database connection
  * @param out the printwriter to write out the html
  *
  ***************************************************************************************
  **/

  private FormModel buildForm(HttpServletRequest req, HttpServletResponse resp, HttpSession session, Connection con, PrintWriter out)
  {

    //
    //  ***** get user id so we know if proshop or member
    //
    String user = (String)session.getAttribute("user");     // get username ('proshop' or member's username)

    String userPass = req.getParameter("emailPass");
    if (userPass == null) userPass = "";
            
    FormModel form = new FormModel("pgFrm", FormModel.POST, "bot");
    form.setNumColumns(3);
    form.addHiddenInput("formId", Email.EMAIL_FRM);
    form.addHiddenInput(ActionHelper.ACTION, ActionHelper.SEND_EMAIL_TO_DIST_LIST);
    form.addHiddenInput(ActionHelper.NEXT_ACTION, "");
    form.addHiddenInput(ActionHelper.SELECTED_ITEMS_STRING, "");
    form.addHiddenInput(Member.REQ_USER_NAME, "");
    form.addHiddenInput(ActionHelper.SEARCH_TYPE, "");
    form.addHiddenInput("emailPass", userPass);

    //create the action model for this form and add it to the form model
    ActionModel formActions = new ActionModel();

    String sendUrl = "javascript:sendEmail('" + versionId + "servlet/Send_email', '" + ActionHelper.SEND + "')";
    Action sendAction = new Action(ActionHelper.SEND, Labels.SEND, "Send the email.", sendUrl);

    formActions.add(sendAction);

    String cancelUrl = "javascript:cancel('" + versionId + "servlet/Send_email', '" +  ActionHelper.CANCEL + "', '" + Labels.CANCEL_WITHOUT_SENDING_EMAIL + "')";
    Action cancelAction = new Action("cancel", Labels.CANCEL, Labels.CANCEL_WITHOUT_SENDING_EMAIL, cancelUrl);
    formActions.add(cancelAction);

    form.setActions(formActions);

    //Add the help steps for the form
    ArrayList helpSteps = new ArrayList(3);
    helpSteps.add(Email.SUBJECT_HELP);
    helpSteps.add(Email.MESSAGE_HELP);

    if (ProcessConstants.isProshopUser(user))
    {
      helpSteps.add(Email.TO_HELP_PROSHOP);
    }
    else
    {
      helpSteps.add(Email.TO_HELP);
    }

    helpSteps.add(Email.SEND_HELP);

    if (ProcessConstants.isProshopUser(user))
    {
      helpSteps.add(Email.NOTE_PROSHOP);
    }
    else
    {
      helpSteps.add(Email.NOTE);
    }

    form.setHelpSteps(helpSteps);

    Attribute subject = new Attribute(Email.SUBJECT, Email.SUBJECT_LABEL, "", Attribute.EDIT);
    subject.setMaxLength("200");
    subject.setSize("70");
    //subject.setHelpText(Email.SUBJECT_HELP);

    RowModel subject_row = new RowModel();
    subject_row.setId(Email.SUBJECT);
    subject_row.add(subject, "frm", 3);

    form.addRow(subject_row);

    TextBox message = new TextBox(Email.MESSAGE, Email.MESSAGE_LABEL, "", Attribute.EDIT);
    message.setMaxLength("50");
    message.setSize("5");
    //message.setHelpText(Email.MESSAGE_HELP);

    RowModel message_row = new RowModel();
    message_row.setId(Email.MESSAGE);
    message_row.add(message, "frm", 3);

    form.addRow(message_row);
    form.addSeparator(new Separator());

    RowModel list_row = new RowModel();
    list_row.setId(DistributionList.LIST_OF_NAMES);

    TableModel names = new TableModel(Email.RECIPIENTS_LABEL);
    names.setEditLabel(Email.TO_LABEL);
    names.setMode(Attribute.EDIT);
    //names.setHelpText(Email.TO_HELP);

    names.addColumn(new Column("name", "Member"));
    names.addColumn(new Column("actions", ActionHelper.ACTIONS_LABEL));

    list_row.add(names);

    ActionModel toActions = new ActionModel();

    String searchMembersUrl = "javascript:openNewWindow('" + versionId + Member.SEARCH_WINDOW_URL + "', '" + Member.SEARCH_WINDOW_NAME + "', '" + Member.SEARCH_WINDOW_PARAMS + "')";
    Action searchMembersAction = new Action(ActionHelper.SEARCH_MEMBERS , Labels.SEARCH_MEMBERS, "Search for members to add", searchMembersUrl);
    toActions.add(searchMembersAction);

    String searchListsUrl = "javascript:openNewWindow('" + versionId + DistributionList.SEARCH_WINDOW_URL + "', '" + DistributionList.SEARCH_WINDOW_NAME + "', '" + DistributionList.SEARCH_WINDOW_PARAMS + "')";
    Action searchListsAction = new Action(ActionHelper.SEARCH_LISTS, Labels.SEARCH_DIST_LISTS, "Search for distribution lists to add", searchListsUrl);

    toActions.add(searchListsAction);

    //
    //  for Proshop only
    //
    if (user.startsWith( "proshop" )) {

       //
       //  for Proshop only
       //
       String searchEventsUrl = "javascript:openNewWindow('" + versionId + Event.SEARCH_WINDOW_URL + "', '" + Event.SEARCH_WINDOW_NAME + "', '" + Event.SEARCH_WINDOW_PARAMS + "')";
       Action searchEventsAction = new Action(ActionHelper.SEARCH_EVENTS , Labels.SEARCH_EVENTS, "Search for events to add participants to this email", searchEventsUrl);
       toActions.add(searchEventsAction);

    } else {
       //
       //  for Members only
       //
       String addPartnersUrl = "javascript:execute('" + versionId + "servlet/Send_email', '" + ActionHelper.ADD_TO_LIST + "', '" + ActionHelper.ADD_PARTNERS + "')";
       Action addPartnersAction = new Action(ActionHelper.ADD_PARTNERS , Labels.ADD_PARTNERS, "Add partners to the email", addPartnersUrl);
       toActions.add(addPartnersAction);
    }

    names.setContextActions(toActions);

    form.addRow(list_row);

    return form;
  }

  /**
  ***************************************************************************************
  *
  * This method will draw the the portion of the page that comes after the add list
  * form
  *
  * @param out the printwriter to write out the html
  *
  ***************************************************************************************
  **/

  private void drawEndOfPageAfterForm(PrintWriter out)
  {
    LayoutHelper.drawEndMainBodyContentWrapper(out);
    // LayoutHelper.drawFooter(out);
    LayoutHelper.drawEndPageContentWrapper(out);
    out.flush();
  }

}
