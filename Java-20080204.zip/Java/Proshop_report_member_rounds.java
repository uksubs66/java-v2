/***************************************************************************************
 *   Proshop_diary: This servlet will ouput the member rounds report
 *
 *
 *   Called by:     called by main menu options
 *
 *
 *   Created:       3/10/2005 by Paul
 *
 *
 *   Last Updated:  
 *
 *             1/05/07 RDP  Add an option for last year.                  
 *            10/26/05 RDP  Add an option to display counts for the current year.
 *                  
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import java.lang.Math;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

// foretees imports
import com.foretees.common.parmCourse;
import com.foretees.common.parmClub;
import com.foretees.common.getParms;
import com.foretees.common.parmPOS;
import com.foretees.common.getClub;
import com.foretees.client.action.ActionHelper;


public class Proshop_report_member_rounds extends HttpServlet {

    String rev = SystemUtils.REVLEVEL;                              // Software Revision Level (Version)
    
    DateFormat df_full = DateFormat.getDateInstance(DateFormat.MEDIUM);
    
 //*****************************************************
 // Process the a get method on this page as a post call
 //*****************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

    doPost(req, resp);                                              // call doPost processing

 } // end of doGet routine
 
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {
    
    resp.setHeader("Pragma","no-cache");                            // for HTTP 1.0
    resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
    resp.setDateHeader("Expires",0);                                // prevents caching at the proxy server
    resp.setContentType("text/html");                               
    
    PrintWriter out = resp.getWriter();                             // normal output stream
    
    String excel = (req.getParameter("excel") != null) ? req.getParameter("excel")  : "";
    
    // handle excel output
    try{
        if (excel.equals("yes")) {                // if user requested Excel Spreadsheet Format
            resp.setContentType("application/vnd.ms-excel");    // response in Excel Format
        }
    }
    catch (Exception exc) {
    }
    
    HttpSession session = SystemUtils.verifyPro(req, out);          // check for intruder
    if (session == null) { return; }
    
    Connection con = SystemUtils.getCon(session);                   // get DB connection
    if (con == null) {
        displayDatabaseErrMsg("Can not establish connection.", "", out);
        return;
    }
    
    String templott = (String)session.getAttribute("lottery");      // get lottery support indicator
    int lottery = Integer.parseInt(templott);
       
    String period = (req.getParameter("period") != null) ? req.getParameter("period")  : "";
      
    // strict enforce either value, default to this month
    if (!period.equals("last") && !period.equals("year") && !period.equals("lstyr")) {
    
       period = "this";
    }

    // 
    //  First time here - display warning message to inform user that this report can take several minutes!!!!
    //
    if (req.getParameter("continue") == null) {

       displayWarning(period, out);              // display warning message
       return;                                   // exit and wait for continue
    }


    //
    //  Declare our local variables
    //
    Statement stmt1 = null;
    PreparedStatement pstmtc1 = null;
    ResultSet rs1 = null;
    Statement stmt2 = null;
    PreparedStatement pstmtc2 = null;
    ResultSet rs2 = null;
    
    GregorianCalendar cal = new GregorianCalendar();            // get todays date
    
    int month = 0;  // will hold last month value
    int year = 0;   // will hold current year
    int i = 0;      // generic counter
    
    String username = "";
    String name_last = "";
    String name_first = "";
    String name_mi = "";
    String m_ship = "";
    String m_type = "";
    String mem_num = "";
    String sql;
        
    // set the calendar to last month if needed
    if (period.equals("last")) cal.add(cal.MONTH, -1);
    
    // populate our date part variables for use in the sql statement
    month = cal.get(cal.MONTH) + 1;
    year = cal.get(cal.YEAR);
    
    // set the year to last year if needed
    if (period.equals("lstyr")) year--;

    
    // 1  SELECT m.username, m.name_last, m.name_first, m.name_mi, m.m_ship, m.m_type, m.memNum FROM member2b m ORDER BY m.name_last, m.name_first, m.name_mi
    // 2  SELECT count(mm) AS total FROM teepast2 WHERE mm = 3 AND yy = 2005 AND ((username1 = 1900 AND show1 = 1) OR (username2 = 1900 AND show2 = 1) OR (username3 = 1900 AND show3 = 1) OR (username4 = 1900 AND show4 = 1))
    
    // start page output     
    startPageOutput(out);
    SystemUtils.getProshopSubMenu(req, out, lottery);               // required to allow submenus on this page
    
    SimpleDateFormat tmpA = new SimpleDateFormat("MMMM yyyy");
    
    // output report title
    out.println("<center><font face=\"Arial, Helvetica, Sans-serif\"><center><b>Member Rounds Report For ");
      
    if (period.equals("year") || period.equals("lstyr")) {     // if for whole year

       out.println(year);

    } else {

       out.println(tmpA.format(cal.getTime()));
    }

    out.println("</b></font></center>");
    
    if (!excel.equals("yes")) {                // if not Excel Spreadsheet Format

       out.println("<br><table border=\"0\" align=\"center\">");
       out.println("<tr><td>");
       out.println("<input type=\"button\" value=\"Print\" onclick=\"window.print();\" style=\"text-decoration:underline; background:#8B8970\">&nbsp; &nbsp;");
       out.println("</td>");
       out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_report_member_rounds\" target=\"_blank\">");
       out.println("<input type=\"hidden\" name=\"excel\" value=\"yes\">");
       out.println("<input type=\"hidden\" name=\"period\" value=\"" + period + "\">");
       out.println("<input type=\"hidden\" name=\"continue\" value=\"yes\">");
       out.println("<td>");
       out.println("<input type=\"submit\" value=\"Excel\" style=\"text-decoration:underline; background:#8B8970\">&nbsp; &nbsp;");
       out.println("</td>");
       out.println("</form>");
       out.println("<td>");
       out.println("<input type=\"button\" value=\"Exit\" onclick=\"document.location.href='/" +rev+ "/servlet/Proshop_announce'\" style=\"text-decoration:underline; background:#8B8970\">");
       out.println("</td></tr></table><br>");

    }
    
    // start table output
    out.println("<table align=\"center\" cellpadding=\"3\" bgcolor=\"#F5F5DC\" style=\"border: 1px solid black\">");
    out.println("<tr bgcolor=\"#336633\" style=\"font-family:verdana;color:white;font-size:.9em\">" +
                "<td><b>Member Name&nbsp;&nbsp;&nbsp;&nbsp;</b></td>" +
                "<td><b>Membership Type&nbsp;&nbsp;&nbsp;&nbsp;</b></td>" +
                "<td><b>Member Type&nbsp;&nbsp;&nbsp;&nbsp;</b></td>" +
                "<td><b>Member Number&nbsp;&nbsp;</b></td>" +
                "<td><b>Rounds&nbsp;&nbsp;</b></td></tr>");
    
    int alt_row = 0;
        
    try {
        sql = "SELECT username, name_last, name_first, name_mi, m_ship, m_type, memNum FROM member2b ORDER BY name_last, name_first, name_mi";
        stmt1 = con.createStatement();
        rs1 = stmt1.executeQuery(sql);
        
        while (rs1.next()) {
            
            username = rs1.getString("username");

            if (period.equals("year") || period.equals("lstyr")) {            // if for whole year

               sql = "SELECT COUNT(mm) FROM teepast2 WHERE yy = ? AND " +
                    "((username1 = ? AND show1 = 1) OR (username2 = ? AND show2 = 1) OR " +
                    "(username3 = ? AND show3 = 1) OR (username4 = ? AND show4 = 1) OR " +
                    "(username5 = ? AND show5 = 1))";

            } else {

               sql = "SELECT COUNT(mm) FROM teepast2 WHERE mm = ? AND yy = ? AND " +
                    "((username1 = ? AND show1 = 1) OR (username2 = ? AND show2 = 1) OR " +
                    "(username3 = ? AND show3 = 1) OR (username4 = ? AND show4 = 1) OR " +
                    "(username5 = ? AND show5 = 1))";
            }

            pstmtc2 = con.prepareStatement(sql);
            pstmtc2.clearParameters();
              
            if (period.equals("year") || period.equals("lstyr")) {            // if for whole year

               pstmtc2.setInt(1, year);
               pstmtc2.setString(2, username);
               pstmtc2.setString(3, username);
               pstmtc2.setString(4, username);
               pstmtc2.setString(5, username);
               pstmtc2.setString(6, username);

            } else {

               pstmtc2.setInt(1, month);
               pstmtc2.setInt(2, year);
               pstmtc2.setString(3, username);
               pstmtc2.setString(4, username);
               pstmtc2.setString(5, username);
               pstmtc2.setString(6, username);
               pstmtc2.setString(7, username);
            }

            rs2 = pstmtc2.executeQuery();      // execute the prepared stmt

            while (rs2.next()) {

                i = rs2.getInt(1);

                if (i != 0) {
                    
                    name_last = rs1.getString("name_last");
                    name_first = rs1.getString("name_first");
                    name_mi = rs1.getString("name_mi");
                    m_ship = rs1.getString("m_ship");
                    m_type = rs1.getString("m_type");
                    mem_num = rs1.getString("memNum");
                    alt_row = (alt_row == 0) ? 1 : 0;
                    out.println("<tr" + ((alt_row == 0) ? " bgcolor=\"#FDFDEF\"" : "") + " style=\"font-family:arial;color:black;font-size:.8em\">");
                    out.println("<td nowrap>" + name_last + ", " + name_first + " " + name_mi + "</td>");
                    out.println("<td>" + m_ship + "</td><td>" + m_type + "</td><td align=\"center\">" + mem_num + "</td><td align=\"center\">" + i + "</td>");
                    out.println("</tr>");
                    
                } // end if tee times where found block

            } // end nested rs2 loop (tee times)

            pstmtc2.close();
               
        } // end main rs1 loop (members)
        
        stmt1.close();
    }
    catch (Exception e) {
        displayDatabaseErrMsg("Error loading member information for report.", e.getMessage(), out);
        return;
        
    }
    
    out.println("</table><br><br>");
    
    endPageOutput(out);
    
 } // end of doPost routine
 

//
//  Start of Page
//
 private void startPageOutput(PrintWriter out) {
    out.println(SystemUtils.HeadTitle("Diary Reports"));
    //out.println("<html><head><title>Diary Reports</title></head><body bgcolor=white>");
 }
 

//
//  End of Page
//
 private void endPageOutput(PrintWriter out) {
    out.println("</body></html>");
 }
 

//
//   Error Message
//
 private void displayDatabaseErrMsg(String pMessage, String pException, PrintWriter out) {

    out.println(SystemUtils.HeadTitle("Database Error"));
    out.println("<BODY><CENTER>");
    out.println("<BR><BR><H2>Database Access Error</H2>");
    out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
    out.println("<BR>Please try again later.");
    out.println("<BR><br>Fatal Error: " + pMessage);
    out.println("<BR><br>Exception: " + pException);
    out.println("<BR><BR>If problem persists, contact customer support.");
    out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
    out.println("</CENTER></BODY></HTML>");
 }


//
//   Warning Message
//
 private void displayWarning(String period, PrintWriter out) {

    out.println(SystemUtils.HeadTitle("Report Warning"));
    out.println("<BODY><CENTER>");
    out.println("<BR><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
    out.println("<hr width=\"40%\">");
    out.println("<BR><H2>WARNING</H2>");
    out.println("<BR><BR>This report may take several minutes to complete.");
    out.println("<BR>Please be patient.");
    out.println("<BR><BR>Contact ForeTees Support if you receive a timeout error message.");
    out.println("<BR><BR>");
    out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_report_member_rounds\">");
    out.println("<input type=\"hidden\" name=\"period\" value=\"" +period+ "\">");
    out.println("<input type=\"hidden\" name=\"continue\" value=\"yes\">");
    out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
    out.println("</input></form>");
    out.println("<BR><BR>");
    out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_announce\">");
    out.println("<input type=\"submit\" value=\"Cancel\" style=\"text-decoration:underline; background:#8B8970\">");
    out.println("</input></form>");
    out.println("</CENTER></BODY></HTML>");
 }

} // end servlet public class
