/***************************************************************************************
 *   Member_teelist:  This servlet will search teecurr for this member and display
 *                    a list of current tee times.  Also, search evntsup for any
 *                    events and lreqs for any lottery requests.
 *
 *
 *   called by:  member_main.htm
 *
 *   created: 1/10/2002   Bob P.
 *
 *   last updated:
 *
 *        7/14/07   Desert Highlands - display 12 months of calendars.
 *        6/20/07   Get all lesson times for the day but filter any with num=0 (subsequent times).
 *        5/22/07   Remove custom days to view tee sheets.
 *        5/09/07   DaysAdv array no longer stored in session block - Using call to SystemUtils.daysInAdv
 *        4/12/07   The CC - custom, show all events, including guest only (case #1103).
 *        2/14/07   Mission Viejo - custom, only allow 10 days in advance for members to view tee sheets.
 *       02/05/07   Fix verbiage for TLT system.
 *       01/24/07   Changes for Interlachen Spa.
 *       01/05/07   Changes for TLT system - display notifications on calanders / redirect to MemberTLT_sheet instead
 *       10/18/06   Westchester - allow access to tee times 90 days in adv.
 *        7/11/06   If tee time is during a shotgun event, do not allow link and show as shotgun time.
 *        7/20/05   Forest Highlands - custom, only allow 5 days in advance for members to view tee sheets.
 *        1/24/05   Ver 5 - change club2 to club5.
 *        1/10/05   RDP Add check for member restriction with ALL member types specified.
 *       11/18/04   Ver 5 - Change to a calendar format.
 *       10/06/04   Ver 5 - add sub-menu support.
 *        2/25/04   RDP Check for Unaccompanied Guest tee times tied to the member.
 *        1/13/04   JAG Modified to match new color scheme
 *        7/18/03   Enhancements for Version 3 of the software.
 *                  Add lottery processing.
 *        2/24/03   Add event sign up processing.
 *        9/18/02   Enhancements for Version 2 of the software.
 *
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.DaysAdv;
import com.foretees.common.getRests;
import com.foretees.common.parmClub;
import com.foretees.common.getClub;
import com.foretees.common.verifySlot;


public class Member_teelist extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
     
         doGet(req, resp);
 }
 
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   //
   //  Prevent caching so sessions are not mangled
   //
   resp.setHeader("Pragma","no-cache");               // for HTTP 1.0
   resp.setHeader("Cache-Control","no-store, no-cache, must-revalidate");    // for HTTP 1.1
   resp.setDateHeader("Expires",0);                   // prevents caching at the proxy server

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   PreparedStatement pstmt1 = null;
   Statement stmt = null;
   ResultSet rs = null;
   ResultSet rs2 = null;
   ResultSet rsev = null;

   HttpSession session = SystemUtils.verifyMem(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY bgcolor=\"#ccccaa\"><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your club manager.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   String omit = "";
   String ampm = "";
   String player1 = "";
   String sfb = "";
   String submit = "";
   String monthName = "";
   String name = "";
   String course = "";
   String zone = "";
   String lname = "";
   String lgname = "";
   String ename = "";
   String dayname = "";
   String rest = "";
   String rest5 = "";
   String p5 = "";
   String stime = "";
   String stime2 = "";
   String ltype = "";
   String url = "";

   long date = 0;
   long edate = 0;
   long sdate = 0;
   long ldate = 0;
   long lottid = 0;
   long temp = 0;

   int mm = 0;
   int dd = 0;
   int yy = 0;
   int month = 0;
   int months = 0;
   int day = 0;
   int numDays = 0;
   int today = 0;
   int day_num = 0;
   int year = 0;
   int hr = 0;
   int min = 0;
   int time = 0;
   int ptime = 0;
   int ctime = 0;
   int index = 0;
   int i = 0;
   int i2 = 0;
   int max = 30;    // default
   int col = 0;
   int multi = 0;
   int lottery = 0;
   int lstate = 0;
   int sdays = 0;
   int sdtime = 0;
   int edays = 0;
   int edtime = 0;
   int pdays = 0;
   int pdtime = 0;
   int slots = 0;
   int advance_days = 0;
   int fives = 0;
   int fivesomes = 0;
   int signUp = 0;
   int fb = 0;
   int proid = 0;
   int etype = 0;

   int tmp_tlt = (Integer)session.getAttribute("tlt");
   boolean IS_TLT = (tmp_tlt == 1) ? true : false;
    
   String user = (String)session.getAttribute("user");      // get username
   String club = (String)session.getAttribute("club");      // get club name
   String caller = (String)session.getAttribute("caller");
   String mship = (String)session.getAttribute("mship");             // get member's mship type
   String mtype = (String)session.getAttribute("mtype");             // get member's mtype
   //DaysAdv daysArray = (DaysAdv)session.getAttribute("daysArray");   // get array object for 'days in adv' from Login
   
   // Setup the daysArray
   DaysAdv daysArray = new DaysAdv();          // allocate an array object for 'days in adv'
   daysArray = SystemUtils.daysInAdv(daysArray, club, mship, mtype, user, con);
   
   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   boolean events = false;
   boolean didone = false;
   boolean allRest = false;

   String [] mm_table = { "inv", "January", "February", "March", "April", "May", "June", "July", "August",
                          "September", "October", "November", "December" };

   String [] day_table = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

   //
   //  Num of days in each month
   //
   int [] numDays_table = { 0, 31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   //
   //  Num of days in Feb indexed by year starting with 2000 - 2040
   //
   int [] feb_table = { 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29,  +
                            28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29, 28, 28, 28, 29 };

   //
   //  Arrays to hold the event indicators - one entry per day (is there one of the events on this day)
   //
   int [] eventA = new int [32];          //  events (32 entries so we can index by day #)
   int [] teetimeA = new int [32];        //  tee times
   int [] lessonA = new int [32];         //  lesson times
   int [] lessongrpA = new int [32];      //  lesson group times
   int [] lotteryA = new int [32];        //  lotteries


   try {

      //
      // Get the days in advance and time for advance from the club db
      //
      getClub.getParms(con, parm);        // get the club parms

      //
      //  use the member's mship type to determine which 'days in advance' parms to use
      //
      verifySlot.getDaysInAdv(con, parm, mship);        // get the days in adv data for this member

      max = parm.memviewdays +1;        // days this member can view tee sheets
        
   }
   catch (Exception exc) {
   }


   //
   //   Get options for this club
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT multi, lottery, adv_zone FROM club5 WHERE clubName != ''");

      if (rs.next()) {

         multi = rs.getInt(1);
         lottery = rs.getInt(2);
         zone = rs.getString(3);
      }
      stmt.close();

   }
   catch (Exception exc) {

      out.println(SystemUtils.HeadTitle("Member My Tee Times - Error"));
      out.println("<body bgcolor=\"#ccccaa\" text=\"#000000\">");
      out.println("<CENTER><BR>");
      out.println("<BR><BR><H3>Database Access Error</H3>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Error:" + exc.getMessage());
      out.println("<BR><BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact your golf shop (provide this information).");
      out.println("<br><br><a href=\"/" +rev+ "/servlet/Member_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   //  get today's date
   //
   Calendar cal = new GregorianCalendar();       // get todays date

   int cal_hourDay = cal.get(Calendar.HOUR_OF_DAY);     // get current time
   int cal_min = cal.get(Calendar.MINUTE);

   //
   //    Adjust the time based on the club's time zone (we are Central)
   //
   ctime = (cal_hourDay * 100) + cal_min;        // get time in hhmm format

   ctime = SystemUtils.adjustTime(con, ctime);   // adjust the time

   if (ctime < 0) {                // if negative, then we went back or ahead one day

      ctime = 0 - ctime;           // convert back to positive value

      if (ctime < 100) {           // if hour is zero, then we rolled ahead 1 day

         //
         // roll cal ahead 1 day (its now just after midnight, the next day Eastern Time)
         //
         cal.add(Calendar.DATE,1);                     // get next day's date

      } else {                        // we rolled back 1 day

         //
         // roll cal back 1 day (its now just before midnight, yesterday Pacific or Mountain Time)
         //
         cal.add(Calendar.DATE,-1);                     // get yesterday's date
      }
   }

   cal_hourDay = ctime / 100;                      // get adjusted hour
   cal_min = ctime - (cal_hourDay * 100);          // get minute value

   yy = cal.get(Calendar.YEAR);
   mm = cal.get(Calendar.MONTH);
   dd = cal.get(Calendar.DAY_OF_MONTH);
   day_num = cal.get(Calendar.DAY_OF_WEEK);        // day of week (01 - 07)

   mm = mm + 1;                                    // month starts at zero

   year = yy;
   month = mm;
   day = dd;
   yy = 0;
   mm = 0;
   dd = 0;

   today = day;                                  // save today's number
     

   //
   //   build the HTML page for the display
   //
   out.println(SystemUtils.HeadTitle2("Member My " + ((IS_TLT) ? "Activities" : "Tee Times")));
   //
   //*******************************************************************
   //  Scripts to complete and submit the forms
   //*******************************************************************
   //
    out.println("<script type=\"text/javascript\">");
    out.println("function editNotify(pId, pTime) {");
    out.println(" var f = document.forms['frmEditNotify'];");
    out.println(" f.notifyId.value = pId;");
    out.println(" f.stime.value = pTime;");
    out.println(" f.submit();");
    out.println("}");
    out.println("</script>");

    out.println("<form method=post action=/" + rev + "/servlet/MemberTLT_slot name=frmEditNotify id=frmEditNotify target=_top>");
    out.println("<input type=hidden name=notifyId value=\"\">");
    out.println("<input type=hidden name=stime value=\"\">");  
    out.println("<input type=hidden name=index value=\"999\">");  
    out.println("</form>");
      
   out.println("<script language='JavaScript'>");            // Tee Time Script
   out.println("<!--");
   out.println("function exeTtimeForm(date, day, p5, course, fb, stime) {");
      //     out.println("alert(date);");
      out.println("document.forms['teeTime'].date.value = date;");
      out.println("document.forms['teeTime'].day.value = day;");
      out.println("document.forms['teeTime'].p5.value = p5;");
      out.println("document.forms['teeTime'].course.value = course;");
      out.println("document.forms['teeTime'].fb.value = fb;");
      out.println("document.forms['teeTime'].stime.value = stime;");
      out.println("document.forms['teeTime'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");            // Lottery State 2
   out.println("<!--");
   out.println("function exeLott2Form(date, day, p5, course, fb, stime, lname, lottid, slots, lstate) {");
      out.println("document.forms['lott2'].date.value = date;");
      out.println("document.forms['lott2'].day.value = day;");
      out.println("document.forms['lott2'].p5.value = p5;");
      out.println("document.forms['lott2'].course.value = course;");
      out.println("document.forms['lott2'].fb.value = fb;");
      out.println("document.forms['lott2'].stime.value = stime;");
      out.println("document.forms['lott2'].lname.value = lname;");
      out.println("document.forms['lott2'].lottid.value = lottid;");
      out.println("document.forms['lott2'].slots.value = slots;");
      out.println("document.forms['lott2'].lstate.value = lstate;");
      out.println("document.forms['lott2'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");                    // Lottery State 5
   out.println("<!--");
   out.println("function exeLott5Form(date, day, p5, course, fb, stime, lname, lottid, lstate) {");
      out.println("document.forms['lott5'].date.value = date;");
      out.println("document.forms['lott5'].day.value = day;");
      out.println("document.forms['lott5'].p5.value = p5;");
      out.println("document.forms['lott5'].course.value = course;");
      out.println("document.forms['lott5'].fb.value = fb;");
      out.println("document.forms['lott5'].stime.value = stime;");
      out.println("document.forms['lott5'].lname.value = lname;");
      out.println("document.forms['lott5'].lottid.value = lottid;");
      out.println("document.forms['lott5'].lstate.value = lstate;");
      out.println("document.forms['lott5'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");                     // Events
   out.println("<!--");
   out.println("function exeEventForm(name, course) {");
      out.println("document.forms['eventForm'].course.value = course;");
      out.println("document.forms['eventForm'].name.value = name;");
      out.println("document.forms['eventForm'].index.value = '999';");
      out.println("document.forms['eventForm'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");                     // Non-Signup Events
   out.println("<!--");
   out.println("function exeEventForm2(name) {");
      out.println("document.forms['eventForm2'].event.value = name;");
      out.println("document.forms['eventForm2'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");                     // Lesson Times
   out.println("<!--");
   out.println("function exeLtimeForm(proid, calDate, date, time, day, ltype) {");
      out.println("document.forms['LtimeForm'].proid.value = proid;");
      out.println("document.forms['LtimeForm'].calDate.value = calDate;");
      out.println("document.forms['LtimeForm'].date.value = date;");
      out.println("document.forms['LtimeForm'].time.value = time;");
      out.println("document.forms['LtimeForm'].day.value = day;");
      out.println("document.forms['LtimeForm'].ltype.value = ltype;");
      out.println("document.forms['LtimeForm'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("<script language='JavaScript'>");                     // Lesson Groups
   out.println("<!--");
   out.println("function exeLgroupForm(proid, date, lgname) {");
      out.println("document.forms['LgroupForm'].proid.value = proid;");
      out.println("document.forms['LgroupForm'].date.value = date;");
      out.println("document.forms['LgroupForm'].lgname.value = lgname;");
      out.println("document.forms['LgroupForm'].submit();");        // submit the form
   out.println("}");                  // end of script function
   out.println("// -->");
   out.println("</script>");          // End of script


   out.println("</head>");
   out.println("<body bgcolor=\"#CCCCAA\" text=\"#000000\" link=\"#336633\" vlink=\"#336633\" >");
   SystemUtils.getMemberSubMenu(req, out, caller);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\" valign=\"top\">");   // table for main page
   out.println("<tr><td align=\"center\">");

   out.println("<font size=\"3\">");
   out.println("<b>Your Current " + ((IS_TLT) ? "Notifications" : "Tee Times") + " and Other Activities</b></font>");
   out.println("<font size=\"2\"><br><br>");
     out.println("<table border=\"0\" align=\"center\" valign=\"top\" width=\"510\" bgcolor=\"#F5F5DC\">"); // legend
     out.println("<tr bgcolor=\"#336633\"><td align=\"center\" colspan=\"3\">");
     out.println("<font color=\"#FFFFFF\" size=\"2\">");
     out.println("<b>Legend</b>");
     out.println("</font></td></tr>");
       
     out.println("<tr>");

     if (club.equals( "interlachenspa" )) {

        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"goldenrod\">");
        out.println("Your Scheduled Spa Services");
        out.println("</font></td>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"black\">");
        out.println("Other Events");
        out.println("</font></td>");
          
     } else {  
       
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"blue\">");
        out.println("Your Scheduled Events");
        out.println("</font></td>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"red\">");
        out.println("Events You May Join");
        out.println("</font></td>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"black\">");
        out.println("Other Events");
        out.println("</font></td>");
        out.println("</tr>");

        out.println("<tr>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"green\">");
        out.println("Your " + ((IS_TLT) ? "Submitted Notifications" : "Scheduled Tee Times"));
        out.println("</font></td>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"goldenrod\">");
        out.println("Your Scheduled Lessons");
        out.println("</font></td>");
        out.println("<td width=\"170\" align=\"center\"><font size=\"1\" color=\"brown\">");
        if (lottery > 0) {
           if (club.equals( "oldoaks" )) {
              out.println("Your Tee Time Requests");
           } else {
              out.println("Your Lottery Requests");
           }
        } else {
           out.println("&nbsp;");
        }
        out.println("</font></td>");
        out.println("</tr>");

        out.println("<tr><td align=\"center\" colspan=\"3\">");
        out.println("<font color=\"#336633\" size=\"1\">");
        out.println("If the day number is underlined, you may click it to access that day's tee sheet.");
        out.println("</font></td>");
     }
     out.println("</tr></table>");

   out.println("<font size=\"1\"><br>");
   out.println("<form method=\"link\" action=\"javascript:self.print()\">");
   out.println("Click image to print this page. &nbsp;&nbsp;");
   out.println("<input type=\"image\" src=\"/" +rev+ "/images/print_sm.gif\" alt=\"Print\">");
   out.println(" &nbsp;&nbsp;<b>Hint:</b> Print in landscape mode.");
   out.println("</form></font>");


   //
   //  Display 3 tables - 1 for each of the next 3 months
   //
   months = 3;                                      // default = 3 months
     
   if (club.equals( "deserthighlands" )) {
  
      months = 12;                               // they want 12 months
   }

   for (i2 = 0; i2 < months; i2++) {                 // do each month

      monthName = mm_table[month];                  // month name

      numDays = numDays_table[month];               // number of days in month

      if (numDays == 0) {                           // if Feb

         int leapYear = year - 2000;
         numDays = feb_table[leapYear];             // get days in Feb
      }

      //
      //  Adjust values to start at the beginning of the month
      //
      cal.set(Calendar.YEAR, year);                 // set year in case it changed below
      cal.set(Calendar.MONTH, month-1);             // set the current month value
      cal.set(Calendar.DAY_OF_MONTH, 1);            // start with the 1st
      day_num = cal.get(Calendar.DAY_OF_WEEK);      // day of week (01 - 07)
      day = 1;
      col = 0;

      //
      //  init the indicator arrays to start new month
      //
      for (i = 0; i < 32; i++) {   
         eventA[i] = 0;
         teetimeA[i] = 0;
         lessonA[i] = 0;
         lotteryA[i] = 0;
      }

      //
      //  Locate all the Events for this member & month and set the array indicators for each day
      //
      sdate = (year * 10000) + (month * 100) + 0;       // start of the month (for searches)
      edate = (year * 10000) + (month * 100) + 32;      // end of the month

      try {
         //
         // search for this user's tee times for this month
         //
         pstmt1 = con.prepareStatement (
            "SELECT dd " +
            "FROM teecurr2 " +
            "WHERE (username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? " +
            "OR username5 = ? OR userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?) " +
            "AND (date > ? AND date < ?) " +
            "ORDER BY date");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setString(1, user);
         pstmt1.setString(2, user);
         pstmt1.setString(3, user);
         pstmt1.setString(4, user);
         pstmt1.setString(5, user);
         pstmt1.setString(6, user);
         pstmt1.setString(7, user);
         pstmt1.setString(8, user);
         pstmt1.setString(9, user);
         pstmt1.setString(10, user);
         pstmt1.setLong(11, sdate);
         pstmt1.setLong(12, edate);
         rs = pstmt1.executeQuery();      // execute the prepared stmt

         while (rs.next()) {

            dd = rs.getInt(1);
              
            teetimeA[dd] = 1;       // set indicator for this day (tee time exists)
         }
         pstmt1.close();

      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         String errorMsg = "Member_teelist: Error getting tee times for " +club+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
         SystemUtils.logError(errorMsg);                           // log it
      }

      //
      //  Check for any lottery requests, if supported
      //
      if (lottery > 0) {

         try {
            pstmt1 = con.prepareStatement (
               "SELECT dd " +
               "FROM lreqs3 " +
               "WHERE (user1 LIKE ? OR user2 LIKE ? OR user3 LIKE ? OR user4 LIKE ? OR user5 LIKE ? OR " +
               "user6 LIKE ? OR user7 LIKE ? OR user8 LIKE ? OR user9 LIKE ? OR user10 LIKE ? OR " +
               "user11 LIKE ? OR user12 LIKE ? OR user13 LIKE ? OR user14 LIKE ? OR user15 LIKE ? OR " +
               "user16 LIKE ? OR user17 LIKE ? OR user18 LIKE ? OR user19 LIKE ? OR user20 LIKE ? OR " +
               "user21 LIKE ? OR user22 LIKE ? OR user23 LIKE ? OR user24 LIKE ? OR user25 LIKE ?) " +
               "AND (date > ? AND date < ?) " +
               "ORDER BY date");

            pstmt1.clearParameters();        // clear the parms
            pstmt1.setString(1, user);
            pstmt1.setString(2, user);
            pstmt1.setString(3, user);
            pstmt1.setString(4, user);
            pstmt1.setString(5, user);
            pstmt1.setString(6, user);
            pstmt1.setString(7, user);
            pstmt1.setString(8, user);
            pstmt1.setString(9, user);
            pstmt1.setString(10, user);
            pstmt1.setString(11, user);
            pstmt1.setString(12, user);
            pstmt1.setString(13, user);
            pstmt1.setString(14, user);
            pstmt1.setString(15, user);
            pstmt1.setString(16, user);
            pstmt1.setString(17, user);
            pstmt1.setString(18, user);
            pstmt1.setString(19, user);
            pstmt1.setString(20, user);
            pstmt1.setString(21, user);
            pstmt1.setString(22, user);
            pstmt1.setString(23, user);
            pstmt1.setString(24, user);
            pstmt1.setString(25, user);
            pstmt1.setLong(26, sdate);
            pstmt1.setLong(27, edate);
            rs = pstmt1.executeQuery();     

            while (rs.next()) {

               dd = rs.getInt(1);

               lotteryA[dd] = 1;       // set indicator for this day (lottery req exists)
            }
            pstmt1.close();

         }
         catch (Exception e1) {
            //
            //  save error message in /" +rev+ "/error.txt
            //
            String errorMsg = "Member_teelist: Error getting lottery reqs for " +club+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
            SystemUtils.logError(errorMsg);                           // log it
         }
      }         // end of IF lottery

      //
      //  Get all lesson times for this user this month 
      //
      try {
       
         pstmt1 = con.prepareStatement (
            "SELECT date " +
            "FROM lessonbook5 " +
            "WHERE date > ? AND date < ? AND memid = ? " +
            "ORDER BY date");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setLong(1, sdate);
         pstmt1.setLong(2, edate);
         pstmt1.setString(3, user);
         rs = pstmt1.executeQuery();

         while (rs.next()) {

            ldate = rs.getLong(1);

            ldate = ldate - ((ldate / 100) * 100);     // get day
            dd = (int)ldate;

            lessonA[dd] = 1;       // set indicator for this day (lesson time exists)

         }
         pstmt1.close();

         pstmt1 = con.prepareStatement (
            "SELECT date " +
            "FROM lgrpsignup5 " +
            "WHERE date > ? AND date < ? AND memid = ? " +
            "ORDER BY date");

         pstmt1.clearParameters();        // clear the parms
         pstmt1.setLong(1, sdate);
         pstmt1.setLong(2, edate);
         pstmt1.setString(3, user);
         rs = pstmt1.executeQuery();

         while (rs.next()) {

            ldate = rs.getLong(1);

            ldate = ldate - ((ldate / 100) * 100);     // get day
            dd = (int)ldate;

            lessongrpA[dd] = 1;       // set indicator for this day (lesson time exists)
         }
         pstmt1.close();

      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         String errorMsg = "Member_teelist: Error getting lesson times for " +club+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
         SystemUtils.logError(errorMsg);                           // log it
      }

      //
      //  Get all events for this month
      //
      try {

         if (club.equals( "tcclub" )) {
           
            pstmt1 = con.prepareStatement (
               "SELECT day " +
               "FROM events2b WHERE date > ? AND date < ?");

         } else {

            pstmt1 = con.prepareStatement (
               "SELECT day " +
               "FROM events2b WHERE date > ? AND date < ? AND gstOnly = 0");
         }

         pstmt1.setLong(1, sdate);
         pstmt1.setLong(2, edate);
         rs = pstmt1.executeQuery();

         while (rs.next()) {

            dd = rs.getInt(1);

            eventA[dd] = 1;       // set indicator for this day (event exists)
         }
         pstmt1.close();

      }
      catch (Exception e1) {
         //
         //  save error message in /" +rev+ "/error.txt
         //
         String errorMsg = "Member_teelist: Error getting events for " +club+ ", Error: " +e1.getMessage(); // build error msg
         SystemUtils.logError(errorMsg);                           // log it
      }
        
      //
      //  table for the month
      //
      out.println("<table border=\"1\" width=\"770\" bgcolor=\"#F5F5DC\">");
      out.println("<tr><td colspan=\"7\" align=\"center\" bgcolor=\"#336633\">");
         out.println("<font color=\"#FFFFFF\" size=\"2\"><b>" + monthName + "&nbsp;&nbsp;" + year + "</b></font>");
      out.println("</td></tr><tr>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Sunday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Monday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Tuesday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Wednesday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Thursday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Friday</b></font></td>");
         out.println("<td width=\"110\" align=\"center\"><font size=\"1\"><b>Saturday</b></font></td>");
      out.println("</tr>");
      out.println("<tr>");        // first row of days

      for (i = 1; i < day_num; i++) {    // skip to the first day
         out.println("<td>&nbsp;<br><br></td>");
         col++;
      }

      while (day < today) {
         out.println("<td align=\"left\" valign=\"top\"><font size=\"1\">" + day + "</font>");  // put in day of month
         out.println("<br><br></td>");  // put in day of month
         col++;
         day++;

         if (col == 7) {
            col = 0;                             // start new week
            out.println("</tr>");
         }
      }

      //
      // start with today, or 1st day of month, and go to end of month
      //
      while (day <= numDays) {

         if (col == 0) {      // if new row

            out.println("<tr>");
         }

         out.println("<td align=\"left\" valign=\"top\"><font size=\"1\">");   // day of month

         if (max > 0) {            // if member can view tee sheet for this date

            //
            //  Add link to Member_sheet (do not specify a course, it will default to 1st one)
            //
            out.println("<a href=\"/" +rev+ "/servlet/Member" + ((IS_TLT) ? "TLT" : "") + "_sheet?index=" +index+ "\">");
            out.println(day+ "</a>");

            index++;              // next day
            max--;

         } else {

            out.println(day);         // just put in day of month
         }
         out.println("<br>");

         //
         //  create a date field for queries
         //
         date = (year * 10000) + (month * 100) + day;      // create a date field of yyyymmdd
         String mysql_date = year + "-" + SystemUtils.ensureDoubleDigit(month) + "-" + SystemUtils.ensureDoubleDigit(day);
         didone = false;        // init 'did one' flag


     if (IS_TLT) {

  
        // check to see if there are any notifications for this day

        try {

           pstmt1 = con.prepareStatement (
                "SELECT n.notification_id, DATE_FORMAT(n.req_datetime, '%l:%i %p') AS pretty_time " +
                "FROM notifications n, notifications_players np " +
                "WHERE n.notification_id = np.notification_id " +
                   "AND np.username = ? " +
                   "AND DATE(n.req_datetime) = ? ");

           pstmt1.clearParameters();        // clear the parms
           pstmt1.setString(1, user);
           pstmt1.setString(2, mysql_date);
           rs = pstmt1.executeQuery();

           while (rs.next()) {
               
               out.println("" +
                   "<a href=\"javascript:editNotify(" + rs.getInt("notification_id") + ", '" + rs.getString("pretty_time") + "')\">" +
                   "<font color=darkGreen>Golf at " + rs.getString("pretty_time") + "</font></a>");
           }
           
        } catch (Exception exp) {
            
        }
             
     } else {
             
         //*******************************************************************************
         //  Check for any tee times for this day
         //*******************************************************************************
         //
         if (teetimeA[day] == 1) {        // if any tee times exist for this day

            try {

               pstmt1 = con.prepareStatement (
                  "SELECT day, hr, min, time, event, event_type, fb, " +
                  "courseName, rest5 " +
                  "FROM teecurr2 WHERE (username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? " +
                  "OR username5 = ? OR userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?) " +
                  "AND date = ? ORDER BY time");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setString(1, user);
               pstmt1.setString(2, user);
               pstmt1.setString(3, user);
               pstmt1.setString(4, user);
               pstmt1.setString(5, user);
               pstmt1.setString(6, user);
               pstmt1.setString(7, user);
               pstmt1.setString(8, user);
               pstmt1.setString(9, user);
               pstmt1.setString(10, user);
               pstmt1.setLong(11, date);
               rs = pstmt1.executeQuery();      // execute the prepared stmt

               while (rs.next()) {

                  dayname = rs.getString(1);
                  hr = rs.getInt(2);
                  min = rs.getInt(3);
                  time = rs.getInt(4);
                  ename = rs.getString(5);
                  etype = rs.getInt(6);
                  fb = rs.getInt(7);
                  course = rs.getString(8);
                  rest5 = rs.getString(9);

                  //
                  //  Check if a member restriction has been set up to block ALL mem types or mship types for this date & time
                  //
                  allRest = getRests.checkRests(date, time, fb, course, dayname, con);

                  ampm = " AM";
                  if (hr == 12) {
                     ampm = " PM";
                  }
                  if (hr > 12) {
                     ampm = " PM";
                     hr = hr - 12;    // convert to conventional time
                  }

                  if (min < 10) {
                     stime2 = hr+ ":0" +min;    // create a value for display on calendar
                  } else {
                     stime2 = hr+ ":" +min;
                  }

                  stime = stime2 + ampm;        // create a value for time parm

                  p5 = "No";                   // default = no 5-somes

                  //
                  //  check if 5-somes allowed on this course
                  //
                  PreparedStatement pstmt3 = con.prepareStatement (
                     "SELECT fives FROM clubparm2 WHERE courseName = ?");

                  pstmt3.clearParameters();        // clear the parms
                  pstmt3.setString(1, course);
                  rs2 = pstmt3.executeQuery();      // execute the prepared pstmt3

                  if (rs2.next()) {

                     fives = rs2.getInt(1);

                     if ((fives != 0 ) && (rest5.equals( "" ))) {   // if 5-somes and not restricted

                        p5 = "Yes";
                     }
                  }
                  pstmt3.close();

                  //
                  // Check for a shotgun event during this time
                  //
                  if (!ename.equals( "" ) && etype == 1) {  // tee time during a shotgun event

                     try {

                        //
                        //   Get the parms for this event
                        //
                        PreparedStatement pstmtev = con.prepareStatement (
                              "SELECT act_hr, act_min FROM events2b " +
                              "WHERE name = ?");

                        pstmtev.clearParameters();        // clear the parms
                        pstmtev.setString(1, ename);
                        rsev = pstmtev.executeQuery();      // execute the prepared stmt

                        if (rsev.next()) {

                           hr = rsev.getInt("act_hr");
                           min = rsev.getInt("act_min");
                        }
                        pstmtev.close();

                        //
                        //  Create time value for email msg
                        //
                        ampm = " AM";

                        if (hr == 0) {

                           hr = 12;                 // change to 12 AM (midnight)

                        } else {

                           if (hr == 12) {

                              ampm = " PM";         // change to Noon
                           }
                        }
                        if (hr > 12) {

                           hr = hr - 12;
                           ampm = " PM";             // change to 12 hr clock
                        }

                        //
                        //  convert time to hour and minutes for email msg
                        //
                        if (min > 9) {

                           stime2 = hr + ":" + min + ampm;

                        } else {

                           stime2 = hr + ":0" + min + ampm;
                        }

                     }
                     catch (Exception e) {
                     }

                     out.println("Shotgun Start at " +stime2+ "<br>");

                  } else {

                     if (allRest == false) {                // if mem can edit tee time

                        //
                        //  Display the tee time as a clickable link (see form & js above)
                        //
                        //     refer to 'web utilities/foretees2.css' for style info
                        //
                        out.println("<a href=\"javascript: exeTtimeForm('" +date+ "','" +dayname+ "','" +p5+ "','" +course+ "','" +fb+ "','" +stime+ "')\" class=mteetime>");
                        out.println("Tee Time at " +stime2+ "</a><br>");

                     } else {

                        out.println("Tee Time at " +stime2+ "<br>");
                     }
                  }

                  didone = true;        // set 'did one' flag

               }                    // end of WHILE
               pstmt1.close();

            }
            catch (Exception e1) {
               String errorMsg = "Member_teelist: Error getting tee times for " +club+ ", Day=" +day+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
               SystemUtils.logError(errorMsg);                           // log it
            }
         }                       // end of IF tee times
   
     } // end if tlt

         //*******************************************************************************
         //  Check for any lotteries for this day (all will be zero if not supported)
         //*******************************************************************************
         //
         if (lotteryA[day] == 1) {        // if any lotteries  exist for this day

            try {

               pstmt1 = con.prepareStatement (
                  "SELECT name, mm, dd, yy, day, hr, min, time, " +
                  "fb, courseName, id " +
                  "FROM lreqs3 " +
                  "WHERE (user1 LIKE ? OR user2 LIKE ? OR user3 LIKE ? OR user4 LIKE ? OR user5 LIKE ? OR " +
                  "user6 LIKE ? OR user7 LIKE ? OR user8 LIKE ? OR user9 LIKE ? OR user10 LIKE ? OR " +
                  "user11 LIKE ? OR user12 LIKE ? OR user13 LIKE ? OR user14 LIKE ? OR user15 LIKE ? OR " +
                  "user16 LIKE ? OR user17 LIKE ? OR user18 LIKE ? OR user19 LIKE ? OR user20 LIKE ? OR " +
                  "user21 LIKE ? OR user22 LIKE ? OR user23 LIKE ? OR user24 LIKE ? OR user25 LIKE ?) " +
                  "AND date = ? ORDER BY time");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setString(1, user);
               pstmt1.setString(2, user);
               pstmt1.setString(3, user);
               pstmt1.setString(4, user);
               pstmt1.setString(5, user);
               pstmt1.setString(6, user);
               pstmt1.setString(7, user);
               pstmt1.setString(8, user);
               pstmt1.setString(9, user);
               pstmt1.setString(10, user);
               pstmt1.setString(11, user);
               pstmt1.setString(12, user);
               pstmt1.setString(13, user);
               pstmt1.setString(14, user);
               pstmt1.setString(15, user);
               pstmt1.setString(16, user);
               pstmt1.setString(17, user);
               pstmt1.setString(18, user);
               pstmt1.setString(19, user);
               pstmt1.setString(20, user);
               pstmt1.setString(21, user);
               pstmt1.setString(22, user);
               pstmt1.setString(23, user);
               pstmt1.setString(24, user);
               pstmt1.setString(25, user);
               pstmt1.setLong(26, date);
               rs = pstmt1.executeQuery();      // execute the prepared stmt

               while (rs.next()) {

                  lname = rs.getString(1);
                  mm = rs.getInt(2);
                  dd = rs.getInt(3);
                  yy = rs.getInt(4);
                  dayname = rs.getString(5);
                  hr = rs.getInt(6);
                  min = rs.getInt(7);
                  time = rs.getInt(8);
                  fb = rs.getInt(9);
                  course = rs.getString(10);
                  lottid = rs.getLong(11);

                  ampm = " AM";
                  if (hr == 12) {
                     ampm = " PM";
                  }
                  if (hr > 12) {
                     ampm = " PM";
                     hr = hr - 12;    // convert to conventional time
                  }

                  if (min < 10) {
                     stime2 = hr+ ":0" +min;    // create a value for display on calendar
                  } else {
                     stime2 = hr+ ":" +min;
                  }

                  stime = stime2 + ampm;        // create a value for time parm

                  //
                  //  Check if 5-somes supported for this course
                  //
                  fives = 0;        // init

                  PreparedStatement pstmtc = con.prepareStatement (
                     "SELECT fives " +
                     "FROM clubparm2 WHERE first_hr != 0 AND courseName = ?");

                  pstmtc.clearParameters();        // clear the parms
                  pstmtc.setString(1, course);
                  rs2 = pstmtc.executeQuery();      // execute the prepared stmt

                  if (rs2.next()) {

                     fives = rs2.getInt(1);          // 5-somes
                  }
                  pstmtc.close();

                  //
                  //  check if 5-somes restricted for this time
                  //
                  rest = "";     // no rest5

                  if (fives != 0) {

                     PreparedStatement pstmtr = con.prepareStatement (
                        "SELECT rest5 " +
                        "FROM teecurr2 WHERE date = ? AND time =? AND fb = ? AND courseName = ?");

                     pstmtr.clearParameters();        // clear the parms
                     pstmtr.setLong(1, date);
                     pstmtr.setInt(2, time);
                     pstmtr.setInt(3, fb);
                     pstmtr.setString(4, course);
                     rs2 = pstmtr.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        rest = rs2.getString(1);
                     }
                     pstmtr.close();
                  }

                  p5 = "No";                   // default = no 5-somes

                  if (fives != 0 && rest.equals( "" )) {     // if 5-somes are supported & not restricted

                     p5 = "Yes";                   // 5-somes ok
                  }

                  //
                  //  get the slots value and determine the current state for this lottery
                  //
                  PreparedStatement pstmt7d = con.prepareStatement (
                     "SELECT sdays, sdtime, edays, edtime, pdays, ptime, slots " +
                     "FROM lottery3 WHERE name = ?");

                  pstmt7d.clearParameters();          // clear the parms
                  pstmt7d.setString(1, lname);

                  rs2 = pstmt7d.executeQuery();      // find all matching lotteries, if any

                  if (rs2.next()) {

                     sdays = rs2.getInt(1);         // days in advance to start taking requests
                     sdtime = rs2.getInt(2);
                     edays = rs2.getInt(3);         // ...stop taking reqs
                     edtime = rs2.getInt(4);
                     pdays = rs2.getInt(5);         // ....to process reqs
                     ptime = rs2.getInt(6);
                     slots = rs2.getInt(7);

                  }                  // end of while
                  pstmt7d.close();

                  //
                  //    Determine which state we are in (before req's, during req's, before process, after process)
                  //
                  //  Get the current time
                  //
                  Calendar cal3 = new GregorianCalendar();    // get the current time of the day

                  if (zone.equals( "Eastern" )) {         // Eastern Time = +1 hr

                     cal3.add(Calendar.HOUR_OF_DAY,1);         // roll ahead 1 hour (rest should adjust)
                  }

                  if (zone.equals( "Mountain" )) {        // Mountain Time = -1 hr

                     cal3.add(Calendar.HOUR_OF_DAY,-1);        // roll back 1 hour (rest should adjust)
                  }

                  if (zone.equals( "Pacific" )) {         // Pacific Time = -2 hrs

                     cal3.add(Calendar.HOUR_OF_DAY,-2);        // roll back 2 hours (rest should adjust)
                  }

                  int cal_hour = cal3.get(Calendar.HOUR_OF_DAY);  // 00 - 23 (military time - adjusted for time zone)
                  cal_min = cal3.get(Calendar.MINUTE);
                  int curr_time = cal_hour * 100;
                  curr_time = curr_time + cal_min;                // create military time

                  //
                  //  determine the number of days in advance of the req'd tee time we currently are
                  //
                  int cal_yy = cal3.get(Calendar.YEAR);
                  int cal_mm = cal3.get(Calendar.MONTH);
                  int cal_dd = cal3.get(Calendar.DAY_OF_MONTH);

                  cal_mm++;                            // month starts at zero
                  advance_days = 0;

                  while (cal_mm != mm || cal_dd != dd || cal_yy != yy) {

                     cal3.add(Calendar.DATE,1);                // roll ahead 1 day until a match found

                     cal_yy = cal3.get(Calendar.YEAR);
                     cal_mm = cal3.get(Calendar.MONTH);
                     cal_dd = cal3.get(Calendar.DAY_OF_MONTH);

                     cal_mm++;                            // month starts at zero
                     advance_days++;
                  }

                  //
                  //  now check the day and time values
                  //
                  if (advance_days > sdays) {       // if we haven't reached the start day yet

                     lstate = 1;                    // before time to take requests

                  } else {

                     if (advance_days == sdays) {   // if this is the start day

                        if (curr_time >= sdtime) {   // have we reached the start time?

                           lstate = 2;              // after start time, before stop time to take requests

                        } else {

                           lstate = 1;              // before time to take requests
                        }
                     } else {                        // we are past the start day

                        lstate = 2;                 // after start time, before stop time to take requests
                     }

                     if (advance_days == edays) {   // if this is the stop day

                        if (curr_time >= edtime) {   // have we reached the stop time?

                           lstate = 3;              // after start time, before stop time to take requests
                        }
                     }

                     if (advance_days < edays) {   // if we are past the stop day

                        lstate = 3;                // after start time, before stop time to take requests
                     }
                  }

                  if (lstate == 3) {                // if we are now in state 3, check for state 4

                     if (advance_days == pdays) {   // if this is the process day

                        if (curr_time >= ptime) {    // have we reached the process time?

                           lstate = 4;              // after process time
                        }
                     }

                     if (advance_days < pdays) {   // if we are past the process day

                        lstate = 4;                // after process time
                     }
                  }

                  if (lstate == 4) {                // if we are now in state 4, check for state 5

                     PreparedStatement pstmt12 = con.prepareStatement (
                            "SELECT mm FROM lreqs3 " +
                            "WHERE name = ? AND date = ? AND courseName = ? AND state = 2");

                     pstmt12.clearParameters();        // clear the parms
                     pstmt12.setString(1, lname);
                     pstmt12.setLong(2, date);
                     pstmt12.setString(3, course);
                     rs2 = pstmt12.executeQuery();

                     if (!rs2.next()) {             // if none waiting approval

                        lstate = 5;                // state 5 - after process & approval time
                     }
                     pstmt12.close();
                  }

                  //
                  //  Form depends on the state
                  //
                  if (lstate == 2) {       // if still ok to process lottery requests

                     //
                     //  Display the lottery time as a clickable link (see form & js above)
                     //
                     out.println("<a href=\"javascript: exeLott2Form('" +date+ "','" +dayname+ "','" +p5+ "','" +course+ "','" +fb+ "','" +stime+ "','" +lname+ "','" +lottid+ "','" +slots+ "','" +lstate+ "')\" class=mlottery>");
                     if (club.equals( "oldoaks" )) {
                        out.println("T Time Req at " +stime2+ "</a><br>");
                     } else {
                        out.println("Lottery Req at " +stime2+ "</a><br>");
                     }

                  } else {

                     if (lstate == 5) {       // if lottery has already been processed

                        //
                        //  Display the lottery time as a clickable link (see form & js above)
                        //
                        out.println("<a href=\"javascript: exeLott5Form('" +date+ "','" +dayname+ "','" +p5+ "','" +course+ "','" +fb+ "','" +stime+ "','" +lname+ "','" +lottid+ "','" +lstate+ "')\" class=mlottery>");
                        if (club.equals( "oldoaks" )) {
                           out.println("T Time Req at " +stime2+ "</a><br>");
                        } else {
                           out.println("Lottery Req at " +stime2+ "</a><br>");
                        }

                     } else {

                        out.println("<div style=\"text-decoration:underline; color:brown\">");
                        if (club.equals( "oldoaks" )) {
                           out.println("T Time Req at " +stime2+ "</div>");
                        } else {
                           out.println("Lottery Req at " +stime2+ "</div>");
                        }
                     }
                  }

                  didone = true;        // set 'did one' flag

               }                    // end of WHILE
               pstmt1.close();

            }
            catch (Exception e1) {
               String errorMsg = "Member_teelist: Error getting tee times for " +club+ ", Day=" +day+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
               SystemUtils.logError(errorMsg);                           // log it
            }
         }    // end of IF lotteries


         //**********************************************************
         //  Check for any lessons for this day
         //**********************************************************
         //
         if (lessonA[day] == 1) {        // if any lessons  exist for this day

            try {

               pstmt1 = con.prepareStatement (
                  "SELECT proid, time, ltype " +
                  "FROM lessonbook5 " +
                  "WHERE memid = ? AND date = ? AND num > 0 ORDER BY time");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setString(1, user);
               pstmt1.setLong(2, date);
               rs = pstmt1.executeQuery();      // execute the prepared stmt

//               if (rs.next()) {             // just get the first one as each lesson can have multiple entries
               while (rs.next()) {            // get all lesson times that have a num greater than zero (not a subsequent time)

                  proid = rs.getInt(1);
                  time = rs.getInt(2);
                  ltype = rs.getString(3);

                  hr = time / 100;
                  min = time - (hr * 100);

                  if (hr > 12) {
                     hr = hr - 12;    // convert to conventional time
                  }

                  if (min < 10) {
                     stime2 = hr+ ":0" +min;    // create a value for display on calendar
                  } else {
                     stime2 = hr+ ":" +min;
                  }

                  dayname = day_table[col];                           // get the name of this day

                  String calDate = month+ "/" +day+ "/" + year;       // set parm for form

                  //
                  //  Display the lesson time as a clickable link (see form & js above)
                  //
                  //     refer to 'web utilities/foretees2.css' for style info
                  //
                  out.println("<a href=\"javascript: exeLtimeForm('" +proid+ "','" +calDate+ "','" +date+ "','" +time+ "','" +dayname+ "','" +ltype+ "')\" class=mlesson>");
                  if (club.equals( "interlachenspa" )) {
                     out.println("Spa Reservation at " +stime2+ "</a><br>");
                  } else {
                     out.println("Lesson at " +stime2+ "</a><br>");
                  }

                  didone = true;        // set 'did one' flag

               }                    // end of WHILE
               pstmt1.close();

            }
            catch (Exception e1) {
               String errorMsg = "Member_teelist: Error getting lesson times for " +club+ ", Day=" +day+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
               SystemUtils.logError(errorMsg);                           // log it
            }
         }    // end of IF lessons


         //**********************************************************
         //  Check for any lessongrps for this day
         //**********************************************************
         //
         if (lessongrpA[day] == 1) {        // if any lessongrps  exist for this day

            try {

               pstmt1 = con.prepareStatement (
                  "SELECT proid, lname " +
                  "FROM lgrpsignup5 " +
                  "WHERE memid = ? AND date = ?");

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setString(1, user);
               pstmt1.setLong(2, date);
               rs = pstmt1.executeQuery();      // execute the prepared stmt

               while (rs.next()) {

                  proid = rs.getInt(1);
                  lgname = rs.getString(2);

                  //
                  //  Get the start time for this group lesson
                  //
                  PreparedStatement pstmt7d = con.prepareStatement (
                     "SELECT stime " +
                     "FROM lessongrp5 WHERE proid = ? AND lname = ?");

                  pstmt7d.clearParameters();          // clear the parms
                  pstmt7d.setInt(1, proid);
                  pstmt7d.setString(2, lgname);

                  rs2 = pstmt7d.executeQuery();      // find all matching lotteries, if any

                  if (rs2.next()) {

                     time = rs2.getInt(1);

                     hr = time / 100;
                     min = time - (hr * 100);

                     if (hr > 12) {
                        hr = hr - 12;    // convert to conventional time
                     }

                     if (min < 10) {
                        stime2 = hr+ ":0" +min;    // create a value for display on calendar
                     } else {
                        stime2 = hr+ ":" +min;
                     }

                  }                  // end of IF
                  pstmt7d.close();

                  //
                  //  Display the lesson time as a clickable link (see form & js above)
                  //
                  //     refer to 'web utilities/foretees2.css' for style info
                  //
                  out.println("<a href=\"javascript: exeLgroupForm('" +proid+ "','" +date+ "','" +lgname+ "')\" class=mlesson>");
                  out.println("Group Lesson at " +stime2+ "</a><br>");

                  didone = true;        // set 'did one' flag

               }                    // end of WHILE
               pstmt1.close();

            }
            catch (Exception e1) {
               String errorMsg = "Member_teelist: Error getting group lesson times for " +club+ ", Day=" +day+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
               SystemUtils.logError(errorMsg);                           // log it
            }

         }    // end of IF lessongrps


         //**********************************************************
         //  Check for any events for this day
         //**********************************************************
         //
         if (eventA[day] == 1) {        // if any events  exist for this day

            try {

               if (club.equals( "tcclub" )) {
                 
                  pstmt1 = con.prepareStatement (
                     "SELECT name, coursename, signup " +
                     "FROM events2b WHERE date = ?");

               } else {

                  pstmt1 = con.prepareStatement (
                     "SELECT name, coursename, signup " +
                     "FROM events2b WHERE date = ? AND gstOnly = 0");
               }

               pstmt1.clearParameters();        // clear the parms
               pstmt1.setLong(1, date);
               rs = pstmt1.executeQuery();      // execute the prepared stmt

               while (rs.next()) {

                  ename = rs.getString(1);
                  course = rs.getString(2);
                  signUp = rs.getInt(3);

                  //
                  //  Check if this member is signed up
                  //
                  boolean signedup = false;

                  if (signUp != 0) {           // if members can signup

                     PreparedStatement pstmte = con.prepareStatement (
                        "SELECT player1 " +
                        "FROM evntsup2b WHERE name = ? AND courseName = ? " +
                        "AND (username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? " +
                        "OR username5 = ?)");

                     pstmte.clearParameters();        // clear the parms
                     pstmte.setString(1, ename);
                     pstmte.setString(2, course);
                     pstmte.setString(3, user);
                     pstmte.setString(4, user);
                     pstmte.setString(5, user);
                     pstmte.setString(6, user);
                     pstmte.setString(7, user);
                     rs2 = pstmte.executeQuery();      // execute the prepared stmt

                     if (rs2.next()) {

                        signedup = true;              // set member signed up
                     }
                     pstmte.close();

                     //
                     //  display a link to the signup
                     //
                     if (signedup == true) {     // if member already registered

                        //
                        //  Display the event name as a clickable link (see form & js above)
                        //
                        out.println("<a href=\"javascript: exeEventForm('" +ename+ "','" +course+ "')\" class=meventblue>");
                        out.println(ename+ "</a><br>");

                     } else {     // not registered yet

                        out.println("<a href=\"javascript: exeEventForm('" +ename+ "','" +course+ "')\" class=meventred>");
                        out.println(ename+ "</a><br>");
                     }

                  } else {     // no sign up available

                     //
                     //  Go to Member_sheet to display the event info
                     //
                     out.println("<a href=\"javascript: exeEventForm2('" +ename+ "')\" class=meventblack>");
                     out.println(ename+ "</a><br>");

                  }       // end of IF signup

               }          // end of WHILE events
               pstmt1.close();

            }
            catch (Exception e1) {
               String errorMsg = "Member_teelist: Error processing events for " +club+ ", Day=" +day+ ", User: " +user+ ", Error: " +e1.getMessage(); // build error msg
               SystemUtils.logError(errorMsg);                           // log it
            }

         }    // end of IF events


         //
         //**********************************************************
         //  End of display for this day - get next day
         //**********************************************************
         //
         if (didone == true) {          // if we added something to the day
            out.println("</td>");       // end of column (day)
         } else {
            out.println("<br><br><br></td>");
         }
         col++;
         day++;

         if (col == 7) {
            col = 0;                             // start new week
            out.println("</tr>");
         }
      }

      if (col != 0) {      // if not at the start

         while (col != 0 && col < 7) {      // finish off this row if not at the end

            out.println("<td>&nbsp;</td>");
            col++;
         }
         out.println("</tr>");
      }

      //
      // end of calendar row
      //
      out.println("</table>");
      out.println("<br>");
        
      today = 1;       // ready for next month
      month++;
        
      if (month > 12) {     // if end of year
         year++;         
         month = 1;
      }
   }

   out.println("</font></td>");
   out.println("</tr>");
   out.println("</table>");                   // end of table for main page

   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Member_announce\">");
   out.println("<input type=\"submit\" value=\"Home\" style=\"text-decoration:underline;\">");
   out.println("</input></form></font>");

   //
   //  Build forms for submitting requests in calendars
   //
   out.println("<form name=\"teeTime\" action=\"/" +rev+ "/servlet/Member_slot\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"date\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"day\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"p5\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"fb\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"stime\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"index\" value=\"999\">");  // indicate from here
   out.println("</form>");

   //
   //  Lottery Forms
   //
   out.println("<form name=\"lott2\" action=\"/" +rev+ "/servlet/Member_lott\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"date\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"day\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lname\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lottid\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"slots\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lstate\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"p5\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"fb\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"stime\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"index\" value=999>");  // indicate from teelist
   out.println("</form>");

   out.println("<form name=\"lott5\" action=\"/" +rev+ "/servlet/Member_slot\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"date\" value=>");
   out.println("<input type=\"hidden\" name=\"day\" value=>");
   out.println("<input type=\"hidden\" name=\"course\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lname\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lottid\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lstate\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"p5\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"fb\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"stime\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"index\" value=999>");  // indicate from teelist
   out.println("</form>");

   //
   //  Event Form
   //
   out.println("<form name=\"eventForm\" action=\"/" +rev+ "/servlet/Member_events2\" method=\"post\" target=\"bot\">");
   out.println("<input type=\"hidden\" name=\"name\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"index\" value=\"\">");  // indicate from teelist
   out.println("</form>");

   //
   //  Event Form for Non_Sign-up Events
   //
   out.println("<form name=\"eventForm2\" action=\"/" +rev+ "/servlet/Member_sheet\" method=\"post\" target=\"_blank\">");
   out.println("<input type=\"hidden\" name=\"event\" value=\"\">");
   out.println("</form>");

   //
   //  Lesson Time Form
   //
   out.println("<form name=\"LtimeForm\" action=\"/" +rev+ "/servlet/Member_lesson\" method=\"post\" target=\"_top\">");
   out.println("<input type=\"hidden\" name=\"proid\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"calDate\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"date\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"time\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"day\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"ltype\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"reqtime\" value=\"yes\">");       // indicate a request
   out.println("<input type=\"hidden\" name=\"index\" value=999>");             // indicate from teelist
   out.println("</form>");

   //
   //  Lesson Group Form
   //
   out.println("<form name=\"LgroupForm\" action=\"/" +rev+ "/servlet/Member_lesson\" method=\"post\" target=\"bot\">");
   out.println("<input type=\"hidden\" name=\"proid\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"date\" value=\"\">");
   out.println("<input type=\"hidden\" name=\"lgname\" value=\"\">");       // name of group lesson
   out.println("<input type=\"hidden\" name=\"groupLesson\" value=\"yes\">");
   out.println("<input type=\"hidden\" name=\"index\" value=999>");             // indicate from teelist
   out.println("</form>");

   //
   //  End of HTML page
   //
   out.println("</center></font></body></html>");
   out.close();

 }   // end of doGet

}
