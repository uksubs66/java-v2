/***************************************************************************************
 *   Support_assistant: This servlet will provide assistance to members when they
 *                      trouble logging in to the ForeTees site
 *
 *
 *   called by: 
 *
 *   created: 1/06/2008   Paul S..
 *
 *   last updated:      ******* keep this accurate *******
 *
 *              
 *
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;



public class Support_assistant extends HttpServlet {


 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)
 
 
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {


   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();
   
   if (req.getParameter("cookie") != null) {
       doCookieTest(req, out);
       return;
   }
   
   out.println("<h3>Troubleshoot Menu</h3>");
   out.println("<a href='?cookie'>Cookie Test</a><br>");
   out.println("<a href='?exit'>Exit & Return to Login Page</a><br>");
   
 }
 
 
 private static void doCookieTest(HttpServletRequest req, PrintWriter out) {

     if (req.getParameter("step2") == null) {
     
         // do step 1
         HttpSession session = req.getSession(true);   // Create a new session object
         session.setAttribute("count", 1);             // testing variable

         out.println("We've placed a cookie on your computer.<br>");
         out.println("<a href='?cookie&step2'>Click here to continue.</a>");
         
     } else {
         
         // do step2
         HttpSession session = null;
         session = req.getSession(false);  // Get user's session object (no new one)

         if (session == null) {
             
             out.println("Your computer is not excepting the cookie.");
             
         } else {
             
             out.println("Your computer has excepted the cookie.  You should have no problems logging into ForeTees.");
             out.println("<a href=''>Return</a>;")
         }
         
     }
 }
 
 
} // end of servlet class