/***************************************************************************************
 *   MemberHelper:  This utility class contains methods to get information for gathering
 *                 information necessary to create and edit members
 *
 *
 *   created: 10/03/2003   jag
 *
 *
 *   last updated:
 *
 *             9/03/08  Fix related to 9/02/08 update, Check/Uncheck All button fixed
 *             9/02/08  Commented out TS_CTRL_EMAIL limited access proshop restriction
 *             8/19/08  Added addTeeSheetOptionsToForm() method to add checkboxes for each proshop tee sheet option
 *             8/11/08  SYSCONFIG access types added to addLimitedAccessTypesToForm() and NUM_LIMITED_ACCESS_TYPES raised from 27 to 33
 *             8/08/08  Updated javascript in addLimitedAccessTypesToForm() method.
 *             7/14/08  Do not include excluded members (billable = 0) in email lists.
 *             7/14/08  Added addLimitedAccessTypesToForm() method to add Checkboxes for each proshop limited access feature
 *             5/16/08  Do not include inactive members in email lists.
 *             4/24/08  Update ArrayList to use String instead of raw types
 *             3/15/07  Add hdcp club & association numbers
 *            10/06/06  pts modified email retrieving query to only return if _bounced flags are 0
 *             9/02/05  rdp verify the email addresses before adding to list
 *             1/24/05  rdp changed cub db table from club2 to club5 for ver 5
 *             1/11/05  jag added method to get all email addresses for a particular user
 *             1/20/04  jag added method to query database for member names
 *
 *
 *
 ***************************************************************************************
 */

package com.foretees.member;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.http.*;


import com.foretees.client.attribute.Checkbox;
import com.foretees.client.attribute.SelectionList;
import com.foretees.client.action.ActionHelper;
import com.foretees.client.ScriptHelper;
import com.foretees.client.form.FormModel;
import com.foretees.client.layout.LayoutModel;
import com.foretees.member.Member;
import com.foretees.client.table.RowModel;
import com.foretees.common.parmCourse;
import com.foretees.common.getParms;
import com.foretees.common.FeedBack;


/**
 ***************************************************************************************
 *
 *  This helper class contains methods for commonly used functions related to
 *  creating and editing members.
 *
 ***************************************************************************************
 **/

public class MemberHelper {

  public static final int NUM_MEMBER_TYPES = 24;
  public static final int NUM_MEMBERSHIPS = 24;
  public static final int NUM_HOTEL_GUEST_TYPES = 36;
  public static final int NUM_GUEST_TYPES = 36;
  public static final int NUM_MEMBER_SUB_TYPES = 8;      // for Hazeltine Natl - Custom
  public static final int NUM_LIMITED_ACCESS_TYPES = 32;    // used for limited access proshop users
  public static final int NUM_TEE_SHEET_OPTIONS = 3;        // used for limited access proshop users


  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the  hdcp club numbers for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/
  
  public static SelectionList getHdcpClubNums(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] clubNums = new String [20];

    if (type == null || type.equals("")) type = member.HDCP_CLUB_NUM;

    SelectionList sl = new SelectionList(type, member.HDCP_CLUB_NUM_LABEL, true);
    boolean isSelected = false;

    ResultSet rs = stmtc.executeQuery("SELECT * FROM hdcp_club_num");

    sl.addOption("", "0", isSelected);
    
    while (rs.next()) {

          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( rs.getString("hdcp_club_num_id") )) isSelected = true;
          sl.addOption(rs.getString("club_num"), rs.getString("hdcp_club_num_id"), isSelected);
        
    }

    stmtc.close();

    return sl;

  }
  
  
  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the hdcp club association numbers for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/
  
  public static SelectionList getHdcpAssocNums(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] assocNums = new String [20];

    if (type == null || type.equals("")) type = member.HDCP_ASSOC_NUM;

    SelectionList sl = new SelectionList(type, member.HDCP_ASSOC_NUM_LABEL, true);
    boolean isSelected = false;

    ResultSet rs = stmtc.executeQuery("SELECT * FROM hdcp_assoc_num");

    sl.addOption("", "0", isSelected);
          
    while (rs.next()) {

          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( rs.getString("hdcp_assoc_num_id") )) isSelected = true;
          sl.addOption(rs.getString("assoc_num"), rs.getString("hdcp_assoc_num_id"), isSelected);
        
    }

    stmtc.close();

    return sl;

  }
  
  
  public static SelectionList getGenderTypes(String selected, String type) {
        
    Member member = new Member();
    
    if (selected == null) selected = "";
    if (type == null || type.equals("")) type = member.GENDER;
    
    SelectionList sl = new SelectionList(type, member.GENDER_LABEL, true);
    
    sl.addOption("", "0", selected.equals(""));
    sl.addOption("M", "M", selected.equals("M"));
    sl.addOption("F", "F", selected.equals("F"));
    
    return sl;
    
  }
  
  
  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the member types for the club
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberTypes(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");

    Member member = new Member();
    String [] memType = new String [NUM_MEMBER_TYPES];     // member types

    if (type == null || type.equals("")) type = member.MEM_TYPE;

    SelectionList sl = new SelectionList(type, member.MEM_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    ResultSet rs = stmtc.executeQuery("SELECT mem1, mem2, mem3, mem4, mem5, mem6, mem7, mem8, " +
                                      "mem9, mem10, mem11, mem12, mem13, mem14, mem15, mem16, " +
                                      "mem17, mem18, mem19, mem20, mem21, mem22, mem23, mem24 " +
                              "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      for (int i=0; i<NUM_MEMBER_TYPES; i++) {
        memType[i] = rs.getString(i+1);
        if (memType[i] != null && !(memType[i].equals("")))
        {
          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( memType[i] )) isSelected = true;
          sl.addOption(memType[i], memType[i], isSelected);
        }
      }
    }

    stmtc.close();

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the member sub-types for Hazeltine Natl
  *
  * @param sl the selection list that contains the member types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberSubTypes(Connection con, String selected, String type) throws SQLException {


    if (selected == null) selected = "";

    Member member = new Member();
    String [] memSubType = new String [NUM_MEMBER_SUB_TYPES];     // member sub-types

    if (type == null || type.equals("")) type = member.MEM_SUB_TYPE;

    SelectionList sl = new SelectionList(type, member.MEM_SUB_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    memSubType[0] = "";

       isSelected = false;
       sl.addOption(memSubType[0], memSubType[0], isSelected);

    memSubType[1] = "After Hours";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[1] )) isSelected = true;
       sl.addOption(memSubType[1], memSubType[1], isSelected);

    memSubType[2] = "18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[2] )) isSelected = true;
       sl.addOption(memSubType[2], memSubType[2], isSelected);

    memSubType[3] = "9 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[3] )) isSelected = true;
       sl.addOption(memSubType[3], memSubType[3], isSelected);

    memSubType[4] = "AH-18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[4] )) isSelected = true;
       sl.addOption(memSubType[4], memSubType[4], isSelected);

    memSubType[5] = "AH-9 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[5] )) isSelected = true;
       sl.addOption(memSubType[5], memSubType[5], isSelected);

    memSubType[6] = "AH-9/18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[6] )) isSelected = true;
       sl.addOption(memSubType[6], memSubType[6], isSelected);

    memSubType[7] = "9/18 Holer";

       isSelected = false;
       if (!selected.equals( "" ) && selected.equals( memSubType[7] )) isSelected = true;
       sl.addOption(memSubType[7], memSubType[7], isSelected);

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list of all the membership types for the club
  *
  * @param sl the selection list that contains the membership types
  *
  ***************************************************************************************
  **/

  public static SelectionList getMemberShips(Connection con, String selected, String type) throws SQLException {

    Statement stmtc = con.createStatement();        // create a statement

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();
    String [] memship = new String [NUM_MEMBERSHIPS];     // member types

    if (type == null || type.equals("")) type = member.MEMSHIP_TYPE;

    SelectionList sl = new SelectionList(type, member.MEMSHIP_TYPE_LABEL, true);
    boolean isSelected = false;

    //
    //  Get the Member Types and save them in a Selection List
    //
    ResultSet rs = stmtc.executeQuery("SELECT " +
                              "mship1, mship2, mship3, mship4, mship5, mship6, mship7, mship8, " +
                                      "mship9, mship10, mship11, mship12, mship13, mship14, mship15, mship16, " +
                                      "mship17, mship18, mship19, mship20, mship21, mship22, mship23, mship24 " +
                              "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      for (int i=0; i<NUM_MEMBERSHIPS; i++) {
        memship[i] = rs.getString(i+1);
        if (memship[i] != null && !(memship[i].equals("")))
        {
          isSelected = false;
          if (!selected.equals( "" ) && selected.equals( memship[i] )) isSelected = true;
          sl.addOption(memship[i], memship[i], isSelected);
        }
      }
    }

    stmtc.close();

    return sl;

  }

  /**
  ***************************************************************************************
  *
  * This method will return a selection list that contains all the transportation options
  * available for the club
  *
  * @param con the database connection to use to query for the member types and membership types
  * @param selected the string containing the selected transportation option
  *
  ***************************************************************************************
  **/

  public static SelectionList getWalkCartOptions(Connection con, String selected) throws Exception
  {

    if (selected == null) selected = "";
    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();

    //
    //  parm block to hold the course parameters
    //
    parmCourse parmc = new parmCourse();          // allocate a parm block

    //
    //  Get the walk/cart options available for this club
    //
    getParms.getCourseTrans(con, parmc);



    SelectionList walkCart = new SelectionList(member.WALK_CART, member.WALK_CART_LABEL, false);
    boolean isSelected = false;

    for (int i=0; i<16; i++) {        // get all c/w options (tmodea = acronym, tmode = full name)

       if (!parmc.tmodea[i].equals( "" )) {

          isSelected = selected.equals( parmc.tmodea[i] );
          walkCart.addOption(parmc.tmode[i], parmc.tmodea[i], isSelected);
       }
    }

    return walkCart;
  }


  /**
  ***************************************************************************************
  *
  * This method will return a selection list that contains all the guest types available
  * for the club
  *
  * @param con the database connection to use to query for the member types and membership types
  * @param selected the string array containing all the values selected for this hotel user
  ***************************************************************************************
  **/

  public static RowModel getGuestTypes(Connection con, String[] selected) throws SQLException
  {

    if (con == null) throw new SQLException("Invalid connection");
    Member member = new Member();

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

    // Get Guest Types from the club db
    guestTypes = getGuestTypesFromDB(con);

    RowModel guests = new RowModel();
    guests.setId("guestRow");

    if (guestTypes.length > 0) {

      boolean isSelected = false;

      for (int i=0; i<NUM_GUEST_TYPES; i++)
      {
        String type = guestTypes[i];
        if (type != null && !(type.equals("")))
        {
          isSelected = isSelectedGuestType(selected, type);

          Checkbox cb = new Checkbox((Member.GUEST_TYPE_REQ + (i+1)), type, type, isSelected);
          guests.add(cb, "frm");
        }
      }

    }
    return guests;
  }


  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the selected values
  * @param theValue the value to test if selected
  ***************************************************************************************
  **/

  private static boolean isSelectedGuestType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the selected values
  * @param theValue the value to test if selected
  ***************************************************************************************
  **/

  private static boolean isSelectedMemType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method true or false whether the value specified is one that is selected
  *
  * @param selected the string array containing the selected values
  * @param theValue the value to scan the string array with
  ***************************************************************************************
  **/

  private static boolean isSelectedMShipType(String[] selected, String theValue)
  {
    boolean isSelected = false;

    if (selected != null && !(selected.equals("")))
    {

      for (int i=0; i<selected.length; i++)
      {
        if ((selected[i]).equals(theValue))
        {
          isSelected = true;
        }

      }
    }

    return isSelected;
  }

  /**
  ***************************************************************************************
  *
  * This method will take all of the selected guest types and set them as values in the
  * sql statement (for Hotel Users)
  *
  * @param req the http request object reference 
  * @param stmt reference to the stmt object that is being manipulated by this method
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static void setGuestTypesInStatement(HttpServletRequest req,  PreparedStatement stmt, PrintWriter out) throws SQLException
  {

    int colEntryStart = 13;      // first guest type column in table

    for (int i=0; i<NUM_HOTEL_GUEST_TYPES; i++)
    {

        String type = req.getParameter(Member.GUEST_TYPE_REQ + (i + 1));

        if (type != null && !(type.equals("")))
        {
          stmt.setString(i+colEntryStart, type);
        }
        else
        {
          stmt.setString(i+colEntryStart, "");
        }

    }

  }

  /**
  ***************************************************************************************
  *
  * This method will get all the guest types for a given club
  *
  * @param con the database connection
  *
  ***************************************************************************************
  **/

  private static String[] getGuestTypesFromDB (Connection con) throws SQLException
  {

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

   // Get Guest Types from the club db
    Statement stmtc = con.createStatement();        // create a statement
    ResultSet rs = stmtc.executeQuery("SELECT guest1, guest2, guest3, guest4, guest5, guest6, guest7, guest8, " +
                            "guest9, guest10, guest11, guest12, guest13, guest14, guest15, guest16, guest17, " +
                            "guest18, guest19, guest20, guest21, guest22, guest23, guest24, guest25, guest26, " +
                            "guest27, guest28, guest29, guest30, guest31, guest32, guest33, guest34, guest35, " +
                            "guest36 " +
                            "FROM club5 WHERE clubName != ''");

    if (rs.next()) {

      guestTypes[0] = rs.getString(1);
      guestTypes[1] = rs.getString(2);
      guestTypes[2] = rs.getString(3);
      guestTypes[3] = rs.getString(4);
      guestTypes[4] = rs.getString(5);
      guestTypes[5] = rs.getString(6);
      guestTypes[6] = rs.getString(7);
      guestTypes[7] = rs.getString(8);
      guestTypes[8] = rs.getString(9);
      guestTypes[9] = rs.getString(10);
      guestTypes[10] = rs.getString(11);
      guestTypes[11] = rs.getString(12);
      guestTypes[12] = rs.getString(13);
      guestTypes[13] = rs.getString(14);
      guestTypes[14] = rs.getString(15);
      guestTypes[15] = rs.getString(16);
      guestTypes[16] = rs.getString(17);
      guestTypes[17] = rs.getString(18);
      guestTypes[18] = rs.getString(19);
      guestTypes[19] = rs.getString(20);
      guestTypes[20] = rs.getString(21);
      guestTypes[21] = rs.getString(22);
      guestTypes[22] = rs.getString(23);
      guestTypes[23] = rs.getString(24);
      guestTypes[24] = rs.getString(25);
      guestTypes[25] = rs.getString(26);
      guestTypes[26] = rs.getString(27);
      guestTypes[27] = rs.getString(28);
      guestTypes[28] = rs.getString(29);
      guestTypes[29] = rs.getString(30);
      guestTypes[30] = rs.getString(31);
      guestTypes[31] = rs.getString(32);
      guestTypes[32] = rs.getString(33);
      guestTypes[33] = rs.getString(34);
      guestTypes[34] = rs.getString(35);
      guestTypes[35] = rs.getString(36);
    }

    stmtc.close();

    return guestTypes;
  }
  
  /**
  ***************************************************************************************
  *
  * This method will add the guest types to the form provided
  *
  * @param con the database connection
  * @param selected the string array containing the guest types currently selected
  * @param form the form to be updated
  *
  ***************************************************************************************
  **/

  public static void addGuestTypesToForm(Connection con, String[] selected, FormModel form) throws SQLException
  {

    String [] guestTypes = new String [NUM_GUEST_TYPES];     // guest types

    if (con == null) throw new SQLException("Invalid connection");

    // Get Guest Types from the club db
    guestTypes = getGuestTypesFromDB(con);

    RowModel guests1 = new RowModel();
    RowModel guests2 = new RowModel();
    RowModel guests3 = new RowModel();
    RowModel guests4 = new RowModel();
    RowModel guests5 = new RowModel();
    RowModel guests6 = new RowModel();
    guests1.setId("guestRow1");
    guests2.setId("guestRow2");
    guests3.setId("guestRow3");
    guests4.setId("guestRow4");
    guests5.setId("guestRow5");
    guests6.setId("guestRow6");

    LayoutModel layout = new LayoutModel();
    layout.setId("guestTypes");
    layout.setNumColumns(form.getNumColumns());


    if (guestTypes.length > 0) {

      boolean isSelected = false;

      for (int i=0; i<NUM_GUEST_TYPES; i++)
      {
        String type = guestTypes[i];
        if (type != null && !(type.equals("")))
        {
          isSelected = isSelectedGuestType(selected, type);

          Checkbox cb = new Checkbox((Member.GUEST_TYPE_REQ + (i+1)), type, type, isSelected);

          if (i < NUM_GUEST_TYPES - 30) {

            guests1.add(cb, "frm");

          } else {

            if (i < NUM_GUEST_TYPES - 24) {

              guests2.add(cb, "frm");

            } else {

              if (i < NUM_GUEST_TYPES - 18) {

                guests3.add(cb, "frm");

              } else {

                if (i < NUM_GUEST_TYPES - 12) {

                  guests4.add(cb, "frm");

                } else {

                  if (i < NUM_GUEST_TYPES - 6) {

                    guests5.add(cb, "frm");

                  } else {

                    guests6.add(cb, "frm");
                  }
                }
              }
            }
          }
        }   // end of IF type
      }     // end of FOR loop

    }      // end of IF length > 0

    layout.addRow(guests1);

    if (guests2.size() > 0)
    {
      layout.addRow(guests2);
    }
    if (guests3.size() > 0)
    {
      layout.addRow(guests3);
    }
    if (guests4.size() > 0)
    {
      layout.addRow(guests4);
    }
    if (guests5.size() > 0)
    {
      layout.addRow(guests5);
    }
    if (guests6.size() > 0)
    {
      layout.addRow(guests6);
    }

    form.addRow(layout);


  }  // end of addGuestTypesToForm

    /**
  ***************************************************************************************
  *
  * This method will add the limited access types to the form provided
  *
  * @param form the form to be updated
  *
  ***************************************************************************************
  **/

  public static void addLimitedAccessTypesToForm(FormModel form, ResultSet rs, PrintWriter out, boolean newUser) {
      
      boolean isSelected = true;
      boolean isProshop = true;
      
      try {
          out.println("<script type=\"text/javascript\">");
          out.println("<!--");
          out.println("function toggleFeatureAccess() {");
          out.println("  var ltdBool = new Boolean();");
          out.println("  ltdBool = !(document.forms['pgFrm'].ltd1.checked);");
          out.println("  var i = 1;");
          out.println("  for(i=1;i<=" + MemberHelper.NUM_LIMITED_ACCESS_TYPES + ";i++) {");
          out.println("    eval(\"document.forms['pgFrm'].ltd\" + i + \".checked = ltdBool;\")");
          out.println("  }");
          out.println("}");
          out.println("// -->");
          out.println("</script>");
          
          //Construct rows for Limited Access Type checkboxes
          RowModel ltdAccessHeaderRow = new RowModel();
          ltdAccessHeaderRow.setId("ltdAccessHeaderRow");
          String ltdAccessHeader = "Feature Access:";
          ltdAccessHeaderRow.add(ltdAccessHeader, "frm");
          form.addRow(ltdAccessHeaderRow);
              
          RowModel cb1 = new RowModel();
          cb1.setId("SYSCONFIG_CLUBCONFIG");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_CLUBCONFIG"); }
          Checkbox SYSCONFIG_CLUBCONFIG = new Checkbox("ltd1", "System Configuration - Club Configuration", "SYSCONFIG_CLUBCONFIG", isSelected, isProshop);
          cb1.add(SYSCONFIG_CLUBCONFIG, "frm");
          form.addRow(cb1);
              
          RowModel cb2 = new RowModel();
          cb2.setId("SYSCONFIG_TEESHEETS");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_TEESHEETS"); }
          Checkbox SYSCONFIG_TEESHEETS = new Checkbox("ltd2", "System Configuration - Tee Sheets", "SYSCONFIG_TEESHEETS", isSelected, isProshop);
          cb2.add(SYSCONFIG_TEESHEETS, "frm");
          form.addRow(cb2);
              
          RowModel cb3 = new RowModel();
          cb3.setId("SYSCONFIG_EVENT");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_EVENT"); }
          Checkbox SYSCONFIG_EVENT = new Checkbox("ltd3", "System Configuration - Event", "SYSCONFIG_EVENT", isSelected, isProshop);
          cb3.add(SYSCONFIG_EVENT, "frm");
          form.addRow(cb3);
              
          RowModel cb4 = new RowModel();
          cb4.setId("SYSCONFIG_LOTTERY");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_LOTTERY"); }
          Checkbox SYSCONFIG_LOTTERY = new Checkbox("ltd4", "System Configuration - Lottery", "SYSCONFIG_LOTTERY", isSelected, isProshop);
          cb4.add(SYSCONFIG_LOTTERY, "frm");
          form.addRow(cb4);
              
          RowModel cb5 = new RowModel();
          cb5.setId("SYSCONFIG_WAITLIST");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_WAITLIST"); }
          Checkbox SYSCONFIG_WAITLIST = new Checkbox("ltd5", "System Configuration - Waitlist", "SYSCONFIG_WAITLIST", isSelected, isProshop);
          cb5.add(SYSCONFIG_WAITLIST, "frm");
          form.addRow(cb5);
              
          RowModel cb6 = new RowModel();
          cb6.setId("SYSCONFIG_RESTRICTIONS");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_RESTRICTIONS"); }
          Checkbox SYSCONFIG_RESTRICTIONS = new Checkbox("ltd6", "System Configuration - Restrictions", "SYSCONFIG_RESTRICTIONS", isSelected, isProshop);
          cb6.add(SYSCONFIG_RESTRICTIONS, "frm");
          form.addRow(cb6);
              
          RowModel cb7 = new RowModel();
          cb7.setId("SYSCONFIG_MEMBERNOTICES");
          if (!newUser) { isSelected = rs.getBoolean("SYSCONFIG_MEMBERNOTICES"); }
          Checkbox SYSCONFIG_MEMBERNOTICES = new Checkbox("ltd7", "System Configuration - Member Notices", "SYSCONFIG_MEMBERNOTICES", isSelected, isProshop);
          cb7.add(SYSCONFIG_MEMBERNOTICES, "frm");
          form.addRow(cb7);

          RowModel cb8 = new RowModel();
          cb8.setId("TOOLS_ANNOUNCE");
          if (!newUser) { isSelected = rs.getBoolean("TOOLS_ANNOUNCE"); }
          Checkbox TOOLS_ANNOUNCE = new Checkbox("ltd8", "Tools - Announcement Page Changes", "TOOLS_ANNOUNCE", isSelected, isProshop);
          cb8.add(TOOLS_ANNOUNCE, "frm");
          form.addRow(cb8);

          RowModel cb9 = new RowModel();
          cb9.setId("TOOLS_EMAIL");
          if (!newUser) { isSelected = rs.getBoolean("TOOLS_EMAIL"); }
          Checkbox TOOLS_EMAIL = new Checkbox("ltd9", "Tools - Send Emails", "TOOLS_EMAIL", isSelected, isProshop);
          cb9.add(TOOLS_EMAIL, "frm");
          form.addRow(cb9);

          RowModel cb10 = new RowModel();
          cb10.setId("TOOLS_SEARCHTS");
          if (!newUser) { isSelected = rs.getBoolean("TOOLS_SEARCHTS"); }
          Checkbox TOOLS_SEARCHTS = new Checkbox("ltd10", "Tools - Search Member Tee Times", "TOOLS_SEARCHTS", isSelected, isProshop);
          cb10.add(TOOLS_SEARCHTS, "frm");
          form.addRow(cb10);

          RowModel cb11 = new RowModel();
          cb11.setId("TOOLS_HDCP");
          if (!newUser) { isSelected = rs.getBoolean("TOOLS_HDCP"); }
          Checkbox TOOLS_HDCP = new Checkbox("ltd11", "Tools - Post and View Handicap Information", "TOOLS_HDCP", isSelected, isProshop);
          cb11.add(TOOLS_HDCP, "frm");
          form.addRow(cb11);

          RowModel cb12 = new RowModel();
          cb12.setId("REPORTS");
          if (!newUser) { isSelected = rs.getBoolean("REPORTS"); }
          Checkbox REPORTS = new Checkbox("ltd12", "Reports", "REPORTS", isSelected, isProshop);
          cb12.add(REPORTS, "frm");
          form.addRow(cb12);

          RowModel cb13 = new RowModel();
          cb13.setId("LOTT_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("LOTT_UPDATE"); }
          Checkbox LOTT_UPDATE = new Checkbox("ltd13", "Lottery - Add/Change Lottery Requests", "LOTT_UPDATE", isSelected, isProshop);
          cb13.add(LOTT_UPDATE, "frm");
          form.addRow(cb13);

          RowModel cb14 = new RowModel();
          cb14.setId("LOTT_APPROVE");
          if (!newUser) { isSelected = rs.getBoolean("LOTT_APPROVE"); }
          Checkbox LOTT_APPROVE = new Checkbox("ltd14", "Lottery - Approve Lotteries", "LOTT_APPROVE", isSelected, isProshop);
          cb14.add(LOTT_APPROVE, "frm");
          form.addRow(cb14);

          RowModel cb15 = new RowModel();
          cb15.setId("LESS_CONFIG");
          if (!newUser) { isSelected = rs.getBoolean("LESS_CONFIG"); }
          Checkbox LESS_CONFIG = new Checkbox("ltd15", "Lessons - Configuration of Lesson Books, etc.", "LESS_CONFIG", isSelected, isProshop);
          cb15.add(LESS_CONFIG, "frm");
          form.addRow(cb15);

          RowModel cb16 = new RowModel();
          cb16.setId("LESS_VIEW");
          if (!newUser) { isSelected = rs.getBoolean("LESS_VIEW"); }
          Checkbox LESS_VIEW = new Checkbox("ltd16", "Lessons - View Lesson Books", "LESS_VIEW", isSelected, isProshop);
          cb16.add(LESS_VIEW, "frm");
          form.addRow(cb16);

          RowModel cb17 = new RowModel();
          cb17.setId("LESS_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("LESS_UPDATE"); }
          Checkbox LESS_UPDATE = new Checkbox("ltd17", "Lessons - Add/Change Member Lessons", "LESS_UPDATE", isSelected, isProshop);
          cb17.add(LESS_UPDATE, "frm");
          form.addRow(cb17);

          RowModel cb18 = new RowModel();
          cb18.setId("EVNTSUP_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("EVNTSUP_UPDATE"); }
          Checkbox EVNTSUP_UPDATE = new Checkbox("ltd18", "Event Setup - Add/Change Event Registrations", "EVNTSUP_UPDATE", isSelected, isProshop);
          cb18.add(EVNTSUP_UPDATE, "frm");
          form.addRow(cb18);

          RowModel cb19 = new RowModel();
          cb19.setId("EVNTSUP_VIEW");
          if (!newUser) { isSelected = rs.getBoolean("EVNTSUP_VIEW"); }
          Checkbox EVNTSUP_VIEW = new Checkbox("ltd19", "Event Setup - View Event Registrations", "EVNTSUP_VIEW", isSelected, isProshop);
          cb19.add(EVNTSUP_VIEW, "frm");
          form.addRow(cb19);

          RowModel cb20 = new RowModel();
          cb20.setId("EVNTSUP_MANAGE");
          if (!newUser) { isSelected = rs.getBoolean("EVNTSUP_MANAGE"); }
          Checkbox EVNTSUP_MANAGE = new Checkbox("ltd20", "Event Setup - Manage Event Registrations", "EVNTSUP_MANAGE", isSelected, isProshop);
          cb20.add(EVNTSUP_MANAGE, "frm");
          form.addRow(cb20);

          RowModel cb21 = new RowModel();
          cb21.setId("WAITLIST_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("WAITLIST_UPDATE"); }
          Checkbox WAITLIST_UPDATE = new Checkbox("ltd21", "Wait List - Add/Change Wait List Signups", "WAITLIST_UPDATE", isSelected, isProshop);
          cb21.add(WAITLIST_UPDATE, "frm");
          form.addRow(cb21);

          RowModel cb22 = new RowModel();
          cb22.setId("WAITLIST_VIEW");
          if (!newUser) { isSelected = rs.getBoolean("WAITLIST_VIEW"); }
          Checkbox WAITLIST_VIEW = new Checkbox("ltd22", "Wait List - View Wait List Signups", "WAITLIST_VIEW", isSelected, isProshop);
          cb22.add(WAITLIST_VIEW, "frm");
          form.addRow(cb22);

          RowModel cb23 = new RowModel();
          cb23.setId("WAITLIST_MANAGE");
          if (!newUser) { isSelected = rs.getBoolean("WAITLIST_MANAGE"); }
          Checkbox WAITLIST_MANAGE = new Checkbox("ltd23", "Wait List - Manage Wait List Signups", "WAITLIST_MANAGE", isSelected, isProshop);
          cb23.add(WAITLIST_MANAGE, "frm");
          form.addRow(cb23);

          RowModel cb24 = new RowModel();
          cb24.setId("TS_VIEW");
          if (!newUser) { isSelected = rs.getBoolean("TS_VIEW"); }
          Checkbox TS_VIEW = new Checkbox("ltd24", "Tee Sheets - View Tee Sheets", "TS_VIEW", isSelected, isProshop);
          cb24.add(TS_VIEW, "frm");
          form.addRow(cb24);

          RowModel cb25 = new RowModel();
          cb25.setId("TS_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("TS_UPDATE"); }
          Checkbox TS_UPDATE = new Checkbox("ltd25", "Tee Sheets - Add/Change Tee Times", "TS_UPDATE", isSelected, isProshop);
          cb25.add(TS_UPDATE, "frm");
          form.addRow(cb25);

          RowModel cb26 = new RowModel();
          cb26.setId("TS_CHECKIN");
          if (!newUser) { isSelected = rs.getBoolean("TS_CHECKIN"); }
          Checkbox TS_CHECKIN = new Checkbox("ltd26", "Tee Sheets - Check Players In or Out", "TS_CHECKIN", isSelected, isProshop);
          cb26.add(TS_CHECKIN, "frm");
          form.addRow(cb26);

          RowModel cb27 = new RowModel();
          cb27.setId("TS_PRINT");
          if (!newUser) { isSelected = rs.getBoolean("TS_PRINT"); }
          Checkbox TS_PRINT = new Checkbox("ltd27", "Tee Sheets - Print Tee Sheets", "TS_PRINT", isSelected, isProshop);
          cb27.add(TS_PRINT, "frm");
          form.addRow(cb27);

          RowModel cb28 = new RowModel();
          cb28.setId("TS_POS");
          if (!newUser) { isSelected = rs.getBoolean("TS_POS"); }
          Checkbox TS_POS = new Checkbox("ltd28", "Tee Sheets - Send POS Charges", "TS_POS", isSelected, isProshop);
          cb28.add(TS_POS, "frm");
          form.addRow(cb28);

          RowModel cb29 = new RowModel();
          cb29.setId("TS_CTRL_FROST");
          if (!newUser) { isSelected = rs.getBoolean("TS_CTRL_FROST"); }
          Checkbox TS_CTRL_FROST = new Checkbox("ltd29", "Tee Sheets - Control Panel - Frost Delay", "TS_CTRL_FROST", isSelected, isProshop);
          cb29.add(TS_CTRL_FROST, "frm");
          form.addRow(cb29);

          RowModel cb30 = new RowModel();
          cb30.setId("TS_CTRL_TSEDIT");
          if (!newUser) { isSelected = rs.getBoolean("TS_CTRL_TSEDIT"); }
          Checkbox TS_CTRL_TSEDIT = new Checkbox("ltd30", "Tee Sheets - Control Panel - Edit Tee Sheets", "TS_CTRL_TSEDIT", isSelected, isProshop);
          cb30.add(TS_CTRL_TSEDIT, "frm");
          form.addRow(cb30);
          
          /* // removed for now
          RowModel cb31 = new RowModel();
          cb31.setId("TS_CTRL_EMAIL");
          if (!newUser) { isSelected = rs.getBoolean("TS_CTRL_EMAIL"); }
          Checkbox TS_CTRL_EMAIL = new Checkbox("ltd31", "Tee Sheets - Control Panel - Send Emails", "TS_CTRL_EMAIL", isSelected, isProshop);
          cb31.add(TS_CTRL_EMAIL, "frm");
          form.addRow(cb31);
          */

          RowModel cb31 = new RowModel();
          cb31.setId("TS_PACE_VIEW");
          if (!newUser) { isSelected = rs.getBoolean("TS_PACE_VIEW"); }
          Checkbox TS_PACE_VIEW = new Checkbox("ltd31", "Tee Sheets - Pace of Play - View PoP Information", "TS_PACE_VIEW", isSelected, isProshop);
          cb31.add(TS_PACE_VIEW, "frm");
          form.addRow(cb31);

          RowModel cb32 = new RowModel();
          cb32.setId("TS_PACE_UPDATE");
          if (!newUser) { isSelected = rs.getBoolean("TS_PACE_UPDATE"); }
          Checkbox TS_PACE_UPDATE = new Checkbox("ltd32", "Tee Sheets - Pace of Play - Update PoP Entries", "TS_PACE_UPDATE", isSelected, isProshop);
          cb32.add(TS_PACE_UPDATE, "frm");
          form.addRow(cb32);
          
          //add button to check/uncheck all checkboxes at once
          RowModel selectAllRow2 = new RowModel();
          selectAllRow2.setId("selectAllRow");
          String selectAllButton2 = "&nbsp<table class=\"pgMnu\"><tbody><tr><td><table class=\"btn\"><tbody><tr><td><a class=\"btnHref\" href=\"javascript:toggleFeatureAccess()\">Check/Uncheck All</a></td></tr></tbody></table></td></tr></tbody></table>";
          selectAllRow2.add(selectAllButton2, "frm");
          form.addRow(selectAllRow2);
          
      } catch (Exception exc) {
          
      }
  }
  
  
  /**
  ***************************************************************************************
  *
  * This method will add the tee sheet options to the form provided
  *
  * @param form the form to be updated
  *
  ***************************************************************************************
  **/

  public static void addTeeSheetOptionsToForm(FormModel form, ResultSet rs, PrintWriter out, boolean newUser) {
      
      boolean isSelected = false;
      boolean isProshop = true;
      
      try {
          //Add checkboxes for Tee Sheet options
          RowModel tsOptsHeaderRow = new RowModel();
          tsOptsHeaderRow.setId("ltdAccessHeaderRow");
          String tsOptsHeader = "Tee Sheet Options (will display after player names on tee sheets):";
          tsOptsHeaderRow.add(tsOptsHeader, "frm");
          form.addRow(tsOptsHeaderRow);

          RowModel tsOpts1 = new RowModel();
          tsOpts1.setId("TEESHEET_OPTIONS1");
          if (!newUser) { isSelected = rs.getBoolean("display_hdcp"); }
          Checkbox tsOptsCb1 = new Checkbox("tsOptsCb1", "Handicap", "display_hdcp", isSelected, isProshop);
          tsOpts1.add(tsOptsCb1, "frm");
          form.addRow(tsOpts1);

          RowModel tsOpts2 = new RowModel();
          tsOpts2.setId("TEESHEET_OPTIONS2");
          if (!newUser) { isSelected = rs.getBoolean("display_mnum"); }
          Checkbox tsOptsCb2 = new Checkbox("tsOptsCb2", "Member Number", "display_mnum", isSelected, isProshop);
          tsOpts2.add(tsOptsCb2, "frm");
          form.addRow(tsOpts2);

          RowModel tsOpts3 = new RowModel();
          tsOpts3.setId("TEESHEET_OPTIONS3");
          if (!newUser) { isSelected = rs.getBoolean("display_bag"); }
          Checkbox tsOptsCb3 = new Checkbox("tsOptsCb3", "Bag Number", "display_bag", isSelected, isProshop);
          tsOpts3.add(tsOptsCb3, "frm");
          form.addRow(tsOpts3);
          
      } catch (Exception exc) {
          
      }
  }
  
  /**
  ***************************************************************************************
  *
  * This method will retrieve members from the member database based on the letter provided.
  * if the letter passed in is null or empty, all members will be returned.
  *
  * @param con the database connection
  * @param theLetter the letter to use for the query
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static SelectionList queryMembersWithEmailAddresses(Connection con, String theLetter, PrintWriter out) throws SQLException
  {

    String letter = theLetter;

    if (letter.equalsIgnoreCase( ActionHelper.VIEW_ALL )) {

      letter = "%";        // all names
    } else {

       letter = letter + "%";
    }

    PreparedStatement stmt = null;
    SelectionList names = new SelectionList("listOfNames", "Name List", false);


    try {                            // Get all columns from member table for names requested

      stmt = con.prepareStatement (
               "SELECT * FROM member2b WHERE name_last LIKE ? AND (email NOT LIKE ? OR email2 NOT LIKE ?) AND inact = 0 AND billable = 1 ORDER BY name_last, name_first, name_mi");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, letter);            // put the parm in stmt
      stmt.setString(2, "");
      stmt.setString(3, "");
      ResultSet rs = stmt.executeQuery();            // execute the prepared stmt


      while(rs.next()) {


        String lastname = rs.getString("name_last");
        String firstname = rs.getString("name_first");
        String middleinitial = rs.getString("name_mi");

        //escape special characters in the username
        String username = rs.getString("username");
        String escName = ScriptHelper.escapeSpecialCharacters(username);

        String displayName = lastname + ", " + firstname + " " + middleinitial;

        names.addOption(displayName, username, false);
      }
    }
    catch (SQLException exc) {

        throw exc;
    }
    finally{
       stmt.close();
    }

    return names;

  }

  /**
  ***************************************************************************************
  *
  * This method will return the display name for the specified user.
  *
  * @param con the database connection
  * @param theUserName the username for the query
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static String getMemberDisplayName(Connection con, String theUserName, PrintWriter out) throws SQLException
  {

    PreparedStatement stmt = null;
    String displayName = "";

    try {                            // Get all columns from member table for names requested

      stmt = con.prepareStatement (
               "SELECT name_last, name_first, name_mi FROM member2b WHERE username = ?");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, theUserName);
      ResultSet rs = stmt.executeQuery();            // execute the prepared stmt

      while(rs.next()) {


        String lastname = rs.getString("name_last");
        String firstname = rs.getString("name_first");
        String middleinitial = rs.getString("name_mi");

        displayName = lastname + ", " + firstname + " " + middleinitial;

      }
    }
    catch (SQLException exc) {

        throw exc;
    }
    finally{
       stmt.close();
    }

    return displayName;

  }

  /**
  ***************************************************************************************
  *
  * This method will return true if the specified user has an email address.
  *
  * @param username the username for the query
  * @param con the database connection reference
  * @param out the PrintWriter object reference
  *
  ***************************************************************************************
  **/

  public static boolean hasEmailAddress(String username, Connection con, PrintWriter out)
  {
      boolean hasEmailAddress = false;
      try
      {
            //"SELECT email, email2 FROM member2b WHERE username = ?"
        PreparedStatement stmt = con.prepareStatement (
            "SELECT (" +
                "SELECT email FROM member2b WHERE username = ? AND email_bounced = 0 AND inact = 0 AND billable = 1" +
            ") AS email1, (" +
                "SELECT email2 FROM member2b WHERE username = ? AND email2_bounced = 0 AND inact = 0 AND billable = 1" +
            ") AS email2");

        stmt.clearParameters();
        stmt.setString(1, username);
        stmt.setString(2, username);
        ResultSet mrs = stmt.executeQuery();

        if (mrs.next())
        {

          String email1 = mrs.getString("email1");
          String email2 = mrs.getString("email2");

          if ( (email1 != null && !(email1.equals(""))) || (email2 != null && !(email2.equals(""))) ) {

             hasEmailAddress = true;
          }
        }

        stmt.close();
      }
      catch (Exception exc)
      {
      }

      return hasEmailAddress;
  }

  /**
  ***************************************************************************************
  *
  * This method will return one email address for the given user.  IF the email one has a value
  * it will return that one.  If it doesn't have a value but the email2 does, it will return that value
  *
  * @param con the database connection
  * @param theUserName the username for the query
  *
  ***************************************************************************************
  **/

  public static String getEmailAddress(String username, Connection con, PrintWriter out)
  {
    ArrayList <String> emailAddresses = getEmailAddresses (username, con, out);
    String email = "";
    int count = 0;
    while (count < emailAddresses.size() && email.equals(""))
    {
      email = (String)emailAddresses.get(count);
      count++;
    }

    return email;
  }

  /**
  ***************************************************************************************
  *
  * This method will return the email addresses for the given user.
  *
  * @param con the database connection
  * @param theUserName the username for the query
  *
  ***************************************************************************************
  **/

  public static ArrayList<String> getEmailAddresses(String username, Connection con, PrintWriter out)
  {
    PreparedStatement stmt = null;
    ResultSet mrs = null;
    ArrayList <String> email = new ArrayList<String>();

    Member member = new Member();

    String emailAddress = "";


    try
    {
      if (username.startsWith( "proshop" )) {            // if proshop user

         stmt = con.prepareStatement (
              "SELECT email FROM club5 WHERE clubName != ''");

         stmt.clearParameters();                   // clear the parms
         mrs = stmt.executeQuery();      // execute the prepared stmt

         if (mrs.next())
         {
           email.add(mrs.getString("email"));
         }

         stmt.close();

      } else {

              //"SELECT email, email2 FROM member2b WHERE username = ?"
         stmt = con.prepareStatement (
                 "SELECT (" +
                    "SELECT email FROM member2b WHERE username = ? AND email_bounced = 0 AND inact = 0 AND billable = 1" +
                 ") AS email1, (" +
                    "SELECT email2 FROM member2b WHERE username = ? AND email2_bounced = 0 AND inact = 0 AND billable = 1" +
                 ") AS email2");

         stmt.clearParameters();                   // clear the parms
         stmt.setString(1, username);             // put the parm in stmt
         stmt.setString(2, username);             // put the parm in stmt
         mrs = stmt.executeQuery();      // execute the prepared stmt

         if (mrs.next())
         {
           
           emailAddress = mrs.getString("email1");     // get email address

           if (!emailAddress.equals( "" ) && emailAddress != null) {     // if present
             
              FeedBack feedback = (member.isEmailValid(emailAddress));   // verify the address

              if (feedback.isPositive()) {          // if valid

                 email.add(emailAddress);           // add it
              }
           }

           emailAddress = mrs.getString("email2");     // get email address #2

           if (!emailAddress.equals( "" ) && emailAddress != null) {     // if present

              FeedBack feedback = (member.isEmailValid(emailAddress));   // verify the address

              if (feedback.isPositive()) {          // if valid

                 email.add(emailAddress);           // add it
              }
           }

         } // end if rs

         stmt.close();
      }
    }
    catch (Exception exc)
    {
    }

    return email;
  }


}
