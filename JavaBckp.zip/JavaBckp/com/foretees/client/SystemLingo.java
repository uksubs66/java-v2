/***************************************************************************************
 *   SystemLingo:  This class represents the different words to be used by the various
 *                 ForeTees systems.
 *
 *
 *   created: 9/23/2006   PTS
 *
 *
 *   revisions:       
 *
 *           
 *
 ***************************************************************************************
 */

package com.foretees.client;


public class SystemLingo {

    
   // declare public variables that we'll access for various words   
   public String TEXT_tee_time = "";
   public String TEXT_tee_times = ""; 
   public String TEXT_Tee_Time = "";
   public String TEXT_Tee_Times = "";
     
   public String TEXT_reservation = "";  
   public String TEXT_Reservation = "";
   public String TEXT_reservations = "";  
   public String TEXT_Reservations = "";
   
      
   public void setLingo(boolean pTLT) {
       
       if (pTLT) {
   
           TEXT_tee_time = "notification";
           TEXT_Tee_Time = "Notification";
           TEXT_tee_times = "notifications";
           TEXT_Tee_Times = "Notifications";
           TEXT_reservation = "notification";
           TEXT_Reservation = "Notification";
           TEXT_reservations = "notifications";
           TEXT_Reservations = "Notifications";
       
       } else {
           
           TEXT_tee_time = "tee time";
           TEXT_Tee_Time = "Tee Time";
           TEXT_tee_times = "tee times";
           TEXT_Tee_Times = "Tee Times";
           TEXT_reservation = "reservation";
           TEXT_Reservation = "Reservation";
           TEXT_reservations = "reservations";
           TEXT_Reservations = "Reservations";
       
       }
   }

}