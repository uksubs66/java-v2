/***************************************************************************************
 *   parmPOS:  This class will define a paramter block object to be used for POS Parms.
 *
 *
 *   called by:  several
 *
 *   created: 12/08/2003   Bob P.
 *
 *   last updated:
 *
 *       7/17/08  Add pos_paynow and fields for making history entry.
 *       9/30/06  Add salestax for IBS.
 *
 ***************************************************************************************
 */

package com.foretees.common;


public class parmPOS {

   public boolean error = false;
     
   public int MAX_Guests = Labels.MAX_GUESTS;         // IN Labels
   public int MAX_Mems = Labels.MAX_MEMS;
   public int MAX_Mships = Labels.MAX_MSHIPS;
   public int MAX_Tmodes = Labels.MAX_TMODES;

   public String posType = "";                 // System type (Jonus, Pro-ShopKeeper, etc.)
   public String sdate = "";
   public String poslist = "";
   public String player = "";
   public String user = "";
   public String pcw = "";
   public String posid = "";
   public String courseid = "";
   public String course = "";
   public String club = "";
   public String day = "";                   // name of day
     
   //
   //  Event Charge Codes
   //
   public String mempos = "";
   public String gstpos = "";
     

   public int count = 0;
   public int p9 = 0;
   public int time = 0;
   public int pos_paynow = 0;

   public long date = 0;

   public double salestax = 0;

   //
   //  Jonas - unique fields
   //
   public String stime = "";
   public String memNum = "";      // posid from member2b
   public String item = "";        // item name
   
   //
   //   Fields for history table entry (pos_hist table)
   //
   public int hist_fb = 0;
   public String hist_posid = "";
   public String hist_player = "";
   public String hist_item_num = "";
   public String hist_item_name = "";
   public String hist_price = "";
   

   //
   //  arrays
   //
   public String [] gtype = new String [Labels.MAX_GUESTS];    // guest types
   public String [] gpos = new String [Labels.MAX_GUESTS];     // guest type codes (18 holes)
   public String [] g9pos = new String [Labels.MAX_GUESTS];    // guest type codes (9 holes)

   public String [] gstI = new String [Labels.MAX_GUESTS];     // Item Group # for guest type
   public String [] gst9I = new String [Labels.MAX_GUESTS];    // Item Group # for guest type (9 holes)

   public String [] tmode = new String [Labels.MAX_TMODES];    // Modes of trans description
   public String [] tmodea = new String [Labels.MAX_TMODES];   // Modes of trans acronyms
   public String [] tpos = new String [Labels.MAX_TMODES];     // Modes of trans codes (18 holes)
   public String [] t9pos = new String [Labels.MAX_TMODES];    // modes of trans codes (9 holes)
   public String [] tposc = new String [Labels.MAX_TMODES];    // Modes of trans cost (18 holes)
   public String [] t9posc = new String [Labels.MAX_TMODES];   // modes of trans cost (9 holes)

   public String [] mship = new String [Labels.MAX_MSHIPS];     // mship types
   public String [] mpos = new String [Labels.MAX_MSHIPS];      // mship type class codes (Pro-ShopKeeper)
   public String [] mposc = new String [Labels.MAX_MSHIPS];     // mship type charge codes (Jonas)
   public String [] m9posc = new String [Labels.MAX_MSHIPS];    // mship type charge codes (Jonas)

   public String [] mshipI = new String [Labels.MAX_MSHIPS];    // Item Group # for mship type
   public String [] mship9I = new String [Labels.MAX_MSHIPS];   // Item Group # for mship type (9 holes)

}  // end of class
