/***************************************************************************************
 *   verifyCustom:  This servlet will provide some Custom tee time request processing methods.
 *
 *       called by:  Proshop_slot
 *                   Proshop_slotm
 *                   Proshop_lott
 *                   Member_slot
 *                   Member_slotm
 *                   Member_lott
 *
 *
 *   created:  6/09/2006   Bob P.
 *
 *
 *   last updated:
 *
 *     10/21/08  Jonathans Landing - add checkJLGCmships to process Membership restrictions (case 1329). 
 *     10/20/08  Palm Valley CC - add checkPVCCmships to process Membership restrictions (case 1242). 
 *     10/15/08  Tualatin - add checkTualatinJr to process Junior restrictions (case 1473). 
 *     10/15/08  Add checkCustoms1 method to provide a common method to check for individual customs.  This can be called by both
 *               Member and Proshop servlets (slot and slotm) to process custom restrictions, etc. 
 *     10/10/08  Add checkPattersonGuests for Patterson Club (case 1470).
 *      9/17/08  Remove Wednesday conditional in checkPGCwalkupeckPGCwalkup
 *      8/25/08  Add checkPGCwalkup for Portland GC to check for Walk-Up Only times (case 1527).
 *      8/13/08  Update checkTCCguests to NOT include Tournament guests for guest counts.
 *      6/26/08  Add checkBaltusrolGuestQuota for Baltusrol (case 1455).
 *      6/11/08  Add checkBelleMeadeFems for Belle Meade female restriction on Sundays (case 1496).
 *      6/07/08  Add getLCGender for Los Coyotes (case 1482).
 *      6/06/08  Add checkRivercrest and checkRivercrestDay method for custom 3-some times.
 *      5/16/08  Move checkInUseMN to verifySlot as this is now standard code.
 *      5/16/08  Tamarack - add removeHist method to delete a lottery request history entry when member removed from tee time (case 1479).
 *      5/05/08  Beverly GC - add beverlyGuests for custom guest quota (case 1449).
 *      5/04/08  Minikahda - change number of guests per hour between Mem Day and Labor Day (case 1027).
 *      5/03/08  Sonnenalp - change some guest rates (case 1461).
 *      4/15/08  Wellesley - change the mship checks in wellesleyGuests (add Limited).
 *      4/10/08  Added checkDorsetFC for 2-some check for Case# 1440
 *      4/10/08  Added checkMayfieldSR for 2-some check for Case# 1424
 *      4/10/08  TheCC (Brookline) - updated checkTheCC to include new 2-some times Case# 1436
 *      3/27/08  Sonnenalp addGuestRates - change the date range for the high season.
 *      3/14/08  Los Coyotes - add checkLCSpouses to check if spouses together more than 3 days in advance (case 1397).
 *      1/24/08  Oakmont - add checkOakmontGuestQuota to check max number of guest times per member (case #1364).
 *     11/26/07  Eagle Creek - Add checkEagleCreekSocial method for Case #1284
 *     10/12/07  checkInUseMn - check if user is restricted from tee times before using as alternative tee time.
 *      9/25/07  Add checkMediterraSports for checking Sports membership quotas (fixed 10/3/07)
 *      8/29/07  Update checkTCCguests to NOT include event times for guest counts.
 *      8/21/07  Update checkTheCC to include 2-some times for 9/04 - 10/31.
 *      7/23/07  Update checkTheCC to include 8:00 for 2-some time.
 *      7/17/07  Add checkWilmington - check for special mship subtypes so they can be marked on pro tee sheet (case #1204).
 *      6/29/07  Add checkMerrill - check for special mships so they can be marked on pro tee sheet (case #1183).
 *      6/21/07  Add checkNewCan for New Canaan - check for 2-some time.
 *      5/29/07  Add addGuestRates for Sonnenalp - add guest rate info to tee time for all guests for tee sheet (case #1070).
 *      4/25/07  Add checkMiniGuestTimes for Minikahda CC - check for 2 guest times per hour (case #1027).
 *      4/24/07  Add checkGreenwich for Greenwich CC - check for 2-some time.
 *      4/12/07  Add checkTCCguests for The CC (Brookline) - check guest quotas (case #1087).
 *      4/04/07  Add checkTheCC for The CC (Brookline) - check for 2-some time.
 *      3/29/07  Add checkInUseMn for CC of Jackson - if one time of a multi request is busy,
 *                  check for other available times (case 1074).
 *      2/15/07  Add checkAwbreyDependents method to check for Juniors w/o and adult.
 *      2/09/07  Add checkWilmingtonGuests for Wilmington.
 *     12/20/06  Add checkElNiguelDependents for El Niguel.
 *     11/28/06  Add checkInUseMc for Long Cove - if one time of a multi request is busy, skip it
 *                    and return the others.
 *     11/17/06  Riverside - add custom guest restriction (no more than 12 on Sunday mornings).
 *      9/05/06  Wellesley - verify the parms before processing to prevent exception.
 *      7/26/06  Bearpath - add custom restriction to check member types.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.internet.*;
import javax.mail.*;
import javax.activation.*;


public class verifyCustom {

   private static String rev = ProcessConstants.REV;

   //
   //  Holidays for custom codes that may require them
   //
   //   Must change them in ProcessConstants...
   //     also, refer to SystemUtils !!!!!!!!!
   //
   private static long Hdate1 = ProcessConstants.memDay;     // Memorial Day
   private static long Hdate2 = ProcessConstants.july4;      // 4th of July - Monday
   private static long Hdate2b = ProcessConstants.july4b;    // 4th of July - other
   private static long Hdate3 = ProcessConstants.laborDay;   // Labor Day
   private static long Hdate7 = ProcessConstants.tgDay;      // Thanksgiving Day
   private static long Hdate8 = ProcessConstants.colDay;     // Columbus Day
     
   private static long Hdate4 = ProcessConstants.Hdate4;     // October 1st
   private static long Hdate5 = ProcessConstants.Hdate5;     // Junior Fridays Start (start on Thurs.)
   private static long Hdate6 = ProcessConstants.Hdate6;     // Junior Fridays End  (end on Sat.)
     
     
 
/**
 //************************************************************************
 //
 //  checkCustoms1 
 //
 //      This method provides a common mechanism to process individual custom 
 //      restrictions, etc. Each Member and Proshop verify method can call this one
 //      method to chack ALL custom restrictions that do not involve Guests.
 //      This is called early in the verification process.
 //
 //      This method will process each custom based on the club.  A String is
 //      returned to indicate if it hit on an error condition.  The string will
 //      contain the specific error message for the response. 
 //
 //      Any other pertinent information is returned in slotParms.
 //
 //************************************************************************
 **/

 public static String checkCustoms1(parmSlot slotParms, Connection con) {

   String returnMsg = "";
   
   boolean error = false;
   
    
   //
   //  Process according to the club
   //
   if (slotParms.club.equals("tualatincc")) {     // TUALATIN CC
      
      //
      //  Tualatin - Check for any Juniors without an Adult
      //
      error = checkTualatinJr(slotParms, con);
      
      if (error == true) {         // if we hit an error
         
         returnMsg = "<BR><BR><H3>Juniors Not Allowed Without An Adult</H3>" +
                     "<BR>Sorry, but there must be at least one adult member in the group" +
                     "<BR>when one or more juniors are included between 11:00 AM and 2:00 PM." +
                     "<BR><BR>Please include an adult in the group, or try another time of the day.";
      } 
   }        // end of IF Tualatin
   
    
   if (slotParms.club.equals("palmvalley-cc")) {     // PALM VALLEY CC
      
      //
      //  Palm Valley CC - Check for Membership Quotas
      //
      error = checkPVCCmships(slotParms, con);
      
      if (error == true) {         // if we hit an error
         
         returnMsg = "<BR><BR><H3>Quota Exceeded for Membership</H3>" +
                     "<BR>Sorry, but " +slotParms.player+ " has already played (or scheduled to play) the maximum allowed rounds for the season." +
                     "<BR><BR>Please remove this player or return to the tee sheet.";
      } 
   }        // end of IF Palm Valley CC
   
    
   if (slotParms.club.equals("jonathanslanding")) {     // JONATHANS LANDING GC
      
      //
      //  Jonathans Landing - Check for Membership Quotas
      //
      error = checkJLGCmships(slotParms, con);
      
      if (error == true) {         // if we hit an error
         
         returnMsg = "<BR><BR><H3>Quota Exceeded for Membership</H3>" +
                     "<BR>Sorry, but " +slotParms.player+ " (and family) have already played, or are scheduled to play, the maximum allowed rounds for the season." +
                     "<BR><BR>Please remove the player(s) or return to the tee sheet.";
      } 
   }        // end of IF Palm Valley CC
   
    
   return(returnMsg); 
 }
 
 
 
/**
 //************************************************************************
 //
 //  wellesleyGuests - special Guest processing for Wellesley CC.
 //
 //     At this point we know there is more than one guest
 //     in this tee time and it is Wellesley.
 //
 //     Restrictions:
 //
 //       Social, & 'Child (under age 15)' mship types can never have guests.      
 //
 //       'Junior B (ages 15-24)', Non-Resident mship types cannot have guests on     
 //       Sat, Sun and Holidays (Mem Day, July 4th, Labor Day).
 //
 //       Wait List A, Limited, & Wait List mship types cannot have guests on
 //       Wed, Fri, Sat, Sun and Holidays (Mem Day, July 4th, Labor Day).
 //
 //       'Junior B (ages 15-24)' mship type cannot have guests from
 //       May 1 thru June 30.
 //
 //       Non-Resident mship type can have up to 3 guest rounds per year 
 //       where the year runs May 1 to April 30.
 //
 //
 //************************************************************************
 **/

 public static int wellesleyGuests(parmSlot slotParms, Connection con) {


   PreparedStatement pstmt = null;
   PreparedStatement pstmt1 = null;
   ResultSet rs = null;

   boolean check = true;

   int error = 0;              // error code for return

   int time = 0;
   int fb = 0;
   int gtimes = 0;         // number of guest times
   int holiday = 0;

   long memDay = Hdate1;       // Memorial Day     !!!!!!!!!! Must keep current !!!!!!!!!!!!!!!!!!
   long july4th = Hdate2;      // 4th of July
   long laborDay = Hdate3;     // Labor Day
     
   long sdate = 0;
   long edate = 0;

   String day = slotParms.day;
   String g1 = "";
   String g2 = "";
   String g3 = "";
   String g4 = "";
   String g5 = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";
   String course = "";
   String errorMsg = "";
   String errorParm = "";

   //
   //  break down date of tee time
   //
   long yy = slotParms.date / 10000;                             // get year
   long mm = (slotParms.date - (yy * 10000)) / 100;              // get month
   long dd = (slotParms.date - (yy * 10000)) - (mm * 100);       // get day

   int omonth = (int)mm;
   int oday = (int)dd;
   int oyear = (int)yy;

   int shortDate = (omonth * 100) + oday;
   int i = 0;

   String [] usergA = new String [5];       // array to hold the members' usernames
   String [] userA = new String [5];        // array to hold the usernames
   String [] playerA = new String [5];      // array to hold the player's names
   String [] mshipA = new String [5];       // array to hold the players' membership types

   playerA[0] = slotParms.player1;
   playerA[1] = slotParms.player2;
   playerA[2] = slotParms.player3;
   playerA[3] = slotParms.player4;
   playerA[4] = slotParms.player5;

   userA[0] = slotParms.user1;
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;
   userA[4] = slotParms.user5;

   usergA[0] = slotParms.userg1;                  // copy userg values into array
   usergA[1] = slotParms.userg2;
   usergA[2] = slotParms.userg3;
   usergA[3] = slotParms.userg4;
   usergA[4] = slotParms.userg5;

   mshipA[0] = slotParms.mship1;
   mshipA[1] = slotParms.mship2;
   mshipA[2] = slotParms.mship3;
   mshipA[3] = slotParms.mship4;
   mshipA[4] = slotParms.mship5;

   //
   //  First, verify the parms
   //
   for (i = 0; i < 5; i++) {

      if (playerA[i] == null) {   // if null parm
     
         errorParm = "player" +(i+1);
         playerA[i] = "";
      }
   }
     
   for (i = 0; i < 5; i++) {

      if (userA[i] == null) {   // if null parm

         errorParm = "user" +(i+1);
         userA[i] = "";
      }
   }

   for (i = 0; i < 5; i++) {

      if (usergA[i] == null) {   // if null parm

         errorParm = "userg" +(i+1);
         usergA[i] = "";
      }
   }

   for (i = 0; i < 5; i++) {

      if (mshipA[i] == null) {   // if null parm

         errorParm = "mship" +(i+1);
         mshipA[i] = "";
      }
   }

   if (!errorParm.equals( "" )) {   // if null parm

      errorMsg = "Error checking for Wellesley guests - verifyCustom.wellesleyGuests: null parm received - " +errorParm;
      verifySlot.logError(errorMsg);        // log the error message
   }

   try {

      holiday = 0;      // default no holiday

      if (slotParms.date == memDay || slotParms.date == july4th || slotParms.date == laborDay) {

         holiday = 1;
      }

      //
      //  Check each player
      //
      for (i = 0; i < 5; i++) {

         if (error == 0) {              // if error not already hit
  
            //
            //  First check for any Limited, Social or Child mship types - no guests allowed
            //
            if (mshipA[i].equals( "Social" ) || mshipA[i].startsWith( "Child" )) {

               //
               //  if this user has any guests in this request
               //
               if (usergA[0].equals( userA[i] ) || usergA[1].equals( userA[i] ) || usergA[2].equals( userA[i] ) ||  
                   usergA[3].equals( userA[i] ) || usergA[4].equals( userA[i] )) {

                  error = 1;                           // indicate error
                  slotParms.player = playerA[i];       // save player name for error message 
               }
            }

            //
            //  Now check for Junior B and Non-Resident mship types - no guests on W/E's or Holidays
            //
            if ((mshipA[i].startsWith( "Junior B" ) || mshipA[i].equals( "Non-Resident" )) && 
                (day.equals( "Saturday" ) || day.equals( "Sunday" ) || holiday == 1)) {

               //
               //  if this user has any guests in this request
               //
               if (usergA[0].equals( userA[i] ) || usergA[1].equals( userA[i] ) || usergA[2].equals( userA[i] ) ||
                   usergA[3].equals( userA[i] ) || usergA[4].equals( userA[i] )) {

                  error = 2;                           // indicate error
                  slotParms.player = playerA[i];       // save player name for error message
               }
            }

            //
            //  Now check for Wait List mship types - no guests on Wed, Fri, W/E's or Holidays
            //
            if ((mshipA[i].equals( "Limited" ) || mshipA[i].startsWith( "Wait List" )) && (day.equals( "Wednesday" ) || day.equals( "Friday" ) ||
                day.equals( "Saturday" ) || day.equals( "Sunday" ) || holiday == 1)) {

               //
               //  if this user has any guests in this request
               //
               if (usergA[0].equals( userA[i] ) || usergA[1].equals( userA[i] ) || usergA[2].equals( userA[i] ) ||
                   usergA[3].equals( userA[i] ) || usergA[4].equals( userA[i] )) {

                  error = 3;                           // indicate error
                  slotParms.player = playerA[i];       // save player name for error message
               }
            }

            //
            //  Now check for Junior B mship types - no guests between 5/01 and 6/30
            //
            if (mshipA[i].startsWith( "Junior B" ) && shortDate > 500 && shortDate < 631) {

               //
               //  if this user has any guests in this request
               //
               if (usergA[0].equals( userA[i] ) || usergA[1].equals( userA[i] ) || usergA[2].equals( userA[i] ) ||
                   usergA[3].equals( userA[i] ) || usergA[4].equals( userA[i] )) {

                  error = 4;                           // indicate error
                  slotParms.player = playerA[i];       // save player name for error message
               }
            }

            //
            //  Finally check for Non-Resident mship types - no more than 3 guest times per year (year starts 5/01)
            //
            if (mshipA[i].equals( "Non-Resident" )) {

               //
               //  and this user has a guest in this request
               //
               if (usergA[0].equals( userA[i] ) || usergA[1].equals( userA[i] ) || usergA[2].equals( userA[i] ) ||
                   usergA[3].equals( userA[i] ) || usergA[4].equals( userA[i] )) {

                  //
                  //  Determine date range to query
                  //
                  if (shortDate < 501) {          // if tee time date is earlier than may 1st

                     edate = (yy * 10000) + 431;        // end date = yyyy0431

                     yy--;                              // back up one year

                     sdate = (yy * 10000) + 500;        // start date = yyyy0500 (previous year)

                  } else {

                     sdate = (yy * 10000) + 500;        // start date = yyyy0500 

                     yy++;                              // next year

                     edate = (yy * 10000) + 431;        // end date = yyyy0431 (next year)
                  }

                  gtimes = 0;                          // # of guest times

                  //
                  //   Check teecurr and teepast for other guest times for this member
                  //
                  pstmt = con.prepareStatement (
                     "SELECT time " +
                     "FROM teepast2 " +
                     "WHERE date < ? AND date > ? AND date != ? AND time != ? AND " +
                     "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                  pstmt.clearParameters();       
                  pstmt.setLong(1, edate);
                  pstmt.setLong(2, sdate);
                  pstmt.setLong(3, slotParms.date);        // not this tee time
                  pstmt.setInt(4, slotParms.time);
                  pstmt1.setString(5, userA[i]);
                  pstmt1.setString(6, userA[i]);
                  pstmt1.setString(7, userA[i]);
                  pstmt1.setString(8, userA[i]);
                  pstmt1.setString(9, userA[i]);
                  rs = pstmt.executeQuery();     

                  while (rs.next()) {

                     gtimes++;     // bump # of guests
               
                  }      // end of WHILE

                  pstmt.close();

                  pstmt = con.prepareStatement (
                     "SELECT time " +
                     "FROM teecurr2 " +
                     "WHERE date < ? AND date > ? AND date != ? AND time != ? AND " +
                     "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                  pstmt.clearParameters();
                  pstmt.setLong(1, edate);
                  pstmt.setLong(2, sdate);
                  pstmt.setLong(3, slotParms.date);        // not this tee time
                  pstmt.setInt(4, slotParms.time);
                  pstmt1.setString(5, userA[i]);
                  pstmt1.setString(6, userA[i]);
                  pstmt1.setString(7, userA[i]);
                  pstmt1.setString(8, userA[i]);
                  pstmt1.setString(9, userA[i]);
                  rs = pstmt.executeQuery();

                  while (rs.next()) {

                     gtimes++;     // bump # of guests

                  }      // end of WHILE

                  pstmt.close();


                  if (gtimes > 2) {                    // if 3 tee times already on this date

                     error = 5;                           // indicate error
                     slotParms.player = playerA[i];       // save player name for error message
                  }
               }
            }

         }
      }              // end of FOR loop (do each player)
        
   }
   catch (Exception e) {

      errorMsg = "Error checking for Wellesley guests - verifyCustom.wellesleyGuests " + e.getMessage();
      verifySlot.logError(errorMsg);        // log the error message
   }

   return(error);
 }


/**
 //************************************************************************
 //
 //  checkBearpathMems - special processing for Bearpath CC.
 //
 //
 //      If a 'CD plus' mtype is included, they must be accompanied by
 //      a Primary or Spouse mtype on weekdays between 11 AM and 3 PM, 
 //      and on weekends before noon.
 //
 //
 //************************************************************************
 **/

 public static boolean checkBearpathMems(parmSlot slotParms) {


   boolean error = false;
   boolean check = false;

   String cdplus = "CD plus"; 
     
   long memDay = Hdate1;       // Memorial Day     !!!!!!!!!! Must keep current !!!!!!!!!!!!!!!!!!
   long july4th = Hdate2;      // 4th of July
   long laborDay = Hdate3;     // Labor Day


   //
   //  Check time of day based on day of week
   //
   if (slotParms.day.equals( "Saturday" ) || slotParms.day.equals( "Sunday" ) || slotParms.date == memDay ||
       slotParms.date == july4th || slotParms.date == laborDay) {          // if weekend or holiday

      if (slotParms.time < 1200) {         // if before Noon
        
         check = true;                     // check this request
      }

   } else {     // weekday
    
      if (slotParms.time < 1500 && slotParms.time > 1100) {  // if between 11 AM and 3 PM

         check = true;                     // check this request
      }
   }

   if (check == true) {

      //
      //  Check each player for CD plus mtype
      //
      if (slotParms.mtype1.equals( cdplus ) || slotParms.mtype2.equals( cdplus ) || slotParms.mtype3.equals( cdplus ) ||
          slotParms.mtype4.equals( cdplus ) || slotParms.mtype5.equals( cdplus )) {

         error = true;        // default to error

         //
         //  now check for any Primary members or Spouse members
         //
         if (slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype1.startsWith( "Spouse" ) ||
             slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Spouse" ) ||
             slotParms.mtype3.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Spouse" ) ||
             slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype4.startsWith( "Spouse" ) ||
             slotParms.mtype5.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Spouse" )) {

            error = false;        // ok
         }
      }
   }

   return(error);
 }


/**
 //************************************************************************
 //
 //  Riverside G&CC - Check for more than 12 guests total on Sunday Mornings.
 //
 //    Called by:  Member_slot & Proshop_slot
 //
 //    Check teecurr for the number of guests requested before noon.
 //
 //************************************************************************
 **/

 public static boolean checkRSguests(parmSlot slotParms, Connection con) {

   ResultSet rs = null;


   boolean error = false;

   String omit = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";

   int guests = slotParms.guests;    // # of guests in this request

   //
   //  Count all guests already scheduled before noon today (exclude this time)
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "SELECT " +
         "userg1, userg2, userg3, userg4, userg5 " +
         "FROM teecurr2 " +
         "WHERE date = ? AND time < 1200 AND time != ? AND " +
         "(userg1 != ? OR userg2 != ? OR userg3 != ? OR userg4 != ? OR userg5 != ?)");

      pstmt1.clearParameters();        // clear the parms and check player 1
      pstmt1.setLong(1, slotParms.date);
      pstmt1.setInt(2, slotParms.time);
      pstmt1.setString(3, omit);
      pstmt1.setString(4, omit);
      pstmt1.setString(5, omit);
      pstmt1.setString(6, omit);
      pstmt1.setString(7, omit);
      rs = pstmt1.executeQuery();      // execute the prepared stmt

      while (rs.next()) {

         userg1 = rs.getString("userg1");
         userg2 = rs.getString("userg2");
         userg3 = rs.getString("userg3");
         userg4 = rs.getString("userg4");
         userg5 = rs.getString("userg5");

         //
         //  Count the number of guests already scheduled
         //
         if (!userg1.equals( "" )) {

            guests++;
         }
         if (!userg2.equals( "" )) {

            guests++;
         }
         if (!userg3.equals( "" )) {

            guests++;
         }
         if (!userg4.equals( "" )) {

            guests++;
         }
         if (!userg5.equals( "" )) {

            guests++;
         }
      }   // end of WHILE

      pstmt1.close();

      //
      //  If more then 12 guests scheduled (counting this request), then set error
      //
      if (guests > 12) {

         error = true;
      }

   }
   catch (Exception e) {

      String errorMsg = "Error checking for Riverside Guests - verifyCustom.checkRSguests: ";
      errorMsg = errorMsg + e.getMessage();
      logError(errorMsg);        // log the error message
   }

   return(error);
 }                   // end of checkRSguests
/**
 //************************************************************************
 //
 //  The Patterson Club - Check for more than 12 guests total between 7-9:30am on Weekends & Holidays.
 //
 //    Called by:  Member_slot & Proshop_slot
 //
 //    Check teecurr for the number of guests requested between 7-9:30am.
 //
 //************************************************************************
 **/

 public static boolean checkPattersonGuests(parmSlot slotParms, Connection con) {

   ResultSet rs = null;


   boolean error = false;

   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";

   int guests = slotParms.guests;    // # of guests in this request

   //
   //  Count all guests already scheduled before noon today (exclude this time)
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "SELECT " +
         "userg1, userg2, userg3, userg4, userg5, time, fb " +
         "FROM teecurr2 " +
         "WHERE date = ? AND time > 659 AND time < 931 AND " +
         "(userg1 != '' OR userg2 != '' OR userg3 != '' OR userg4 != '' OR userg5 != '')");

      pstmt1.clearParameters();        // clear the parms and check player 1
      pstmt1.setLong(1, slotParms.date);
      rs = pstmt1.executeQuery();      // execute the prepared stmt

      while (rs.next()) {
          
         if (rs.getInt("time") != slotParms.time || rs.getInt("fb") != slotParms.fb) {
             
             userg1 = rs.getString("userg1");
             userg2 = rs.getString("userg2");
             userg3 = rs.getString("userg3");
             userg4 = rs.getString("userg4");
             userg5 = rs.getString("userg5");

             //
             //  Count the number of guests already scheduled
             //
             if (!userg1.equals( "" )) {

                guests++;
             }
             if (!userg2.equals( "" )) {

                guests++;
             }
             if (!userg3.equals( "" )) {

                guests++;
             }
             if (!userg4.equals( "" )) {

                guests++;
             }
             if (!userg5.equals( "" )) {

                guests++;
             }
         }
      }   // end of WHILE

      pstmt1.close();

      //
      //  If more then 12 guests scheduled (counting this request), then set error
      //
      if (guests > 12) {

         error = true;
      }

   }
   catch (Exception e) {

      String errorMsg = "Error checking for Patterson Club Guests - verifyCustom.checkPattersonGuests: ";
      errorMsg = errorMsg + e.getMessage();
      logError(errorMsg);        // log the error message
   }

   return(error);
 }                   // end of checkPattersonGuests

/**
 //************************************************************************
 //
 //  Minikahda CC - Check for 2 guest times per hour.
 //
 //    Called by:  Member_slot (new requests only)
 //
 //    Check teecurr for the number of guest times already scheduled.
 //
 //************************************************************************
 **/

 public static boolean checkMiniGuestTimes(parmSlot slotParms, Connection con) {

   ResultSet rs = null;


   boolean error = false;

   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String user1 = "";
   String user2 = "";
   String user3 = "";
   String user4 = "";
     
   int hour = 0;
   int count = 0;
   int memcount = 0;
     
   long date = slotParms.date;          

   hour = slotParms.time / 100;            // isolate the hour


   //
   //  Count all guest times already scheduled this hour (do not count this one)
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "SELECT player1, player2, player3, player4, username1, username2, username3, username4 " +
         "FROM teecurr2 " +
         "WHERE date = ? AND hr = ? AND time != ? AND player1 != ''");

      pstmt1.clearParameters();       
      pstmt1.setLong(1, slotParms.date);
      pstmt1.setInt(2, hour);
      pstmt1.setInt(3, slotParms.time);            // not this time
      rs = pstmt1.executeQuery();     

      while (rs.next()) {

         player1 = rs.getString("player1");
         player2 = rs.getString("player2");
         player3 = rs.getString("player3");
         player4 = rs.getString("player4");
         user1 = rs.getString("username1");
         user2 = rs.getString("username2");
         user3 = rs.getString("username3");
         user4 = rs.getString("username4");

         if (!player1.equals( "" ) && !player2.equals( "" ) && !player3.equals( "" ) && !player4.equals( "" )) {       // if 4 players

            memcount = 0;
              
            if (!user1.equals( "" )) {         // 4 players - see how many are members
              
               memcount++;
            }
            if (!user2.equals( "" )) {

               memcount++;
            }
            if (!user3.equals( "" )) {

               memcount++;
            }
            if (!user4.equals( "" )) {

               memcount++;
            }
  
            if (memcount == 1) {         // if 1 member & 3 guests
  
               count++;                 // count # of guest times
            }
         }
      }

      pstmt1.close();

      //
      //  If 2 guest times already scheduled, then set error
      //
      if (hour < 8) {          // if before 8:00 AM

         if (count > 0) {      // only one time allowed

            error = true;
         }
           
      } else {
        
         if ((hour > 10 && hour < 14) && (date >= Hdate1 && date <= Hdate3)) {  // if between 11 and 1, and between Memorial Day and Labor Day
            
            if (count > 0) {      // only 1 times allowed

               error = true;
            }
            
         } else {
            
            if (count > 1) {      // only 2 times allowed

               error = true;
            }
         }
      }

   }
   catch (Exception e) {

      String errorMsg = "Error checking for Minikahda Guests - verifyCustom.checkMiniGuestTimes: ";
      errorMsg = errorMsg + e.getMessage();
      logError(errorMsg);        // log the error message
   }

   return(error);
 }                   // end of checkMiniGuestTimes



/**
 //************************************************************************
 //
 //  Wilmington CC - Check for more than 12 guests total during specified days/times.
 //
 //    Called by:  Member_slot(m) & Proshop_slot(m)
 //
 //    Check teecurr for the number of guests already scheduled.
 //
 //************************************************************************
 **/

 public static boolean checkWilmingtonGuests(parmSlot slotParms, Connection con) {

   ResultSet rs = null;


   boolean error = false;
   boolean check = false;

   String day = slotParms.day;

   int stime = 0;
   int etime = 0;
   int time = slotParms.time;

   long date = slotParms.date;
   long shortDate = date - ((date / 10000) * 10000);       // get mmdd (i.e.  20060512 - 20060000)


   //
   //  Determine time range based on the date
   //
   //       If Tue - Fri, not 7/04, and between 8:00 - 11:30 AM
   //
   if ((day.equals( "Tuesday" ) || day.equals( "Wednesday" ) || day.equals( "Thursday" ) || day.equals( "Friday" )) && 
        date != Hdate2b && time > 759 && time < 1131) { 

      check = true;         // check for max guests
        
      stime = 759;          // time range to check
      etime = 1131;
        
   } else {

      //
      //   OR   If Tue - Sun, or Memorial Day, or Labor Day, and between 1:30 - 7:00 PM
      //
      if ((!day.equals( "Monday" ) || date == Hdate1 || date == Hdate3) &&
           time > 1329 && time < 1901) {

         check = true;         // check for max guests

         stime = 1329;          // time range to check
         etime = 1901;
      }
   }

   if (check == true) {          // check for guests?
     
      error = checkWilDB(slotParms, stime, etime, con);         // go check for too many guests
   }

   return(error);
 }                   // end of checkWilmingtonGuests


 //
 private static boolean checkWilDB(parmSlot slotParms, int stime, int etime, Connection con) {

   ResultSet rs = null;


   boolean error = false;
     
   String omit = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
     
   int guests = slotParms.guests;    // # of guests in this request
  

   //
   //  Count all guests already scheduled before noon today (exclude this time)
   //
   try {

      PreparedStatement pstmt1 = con.prepareStatement (
         "SELECT " +
         "userg1, userg2, userg3, userg4, userg5 " +
         "FROM teecurr2 " +
         "WHERE date = ? AND time > ? AND time < ? AND time != ? AND " +
         "(userg1 != ? OR userg2 != ? OR userg3 != ? OR userg4 != ? OR userg5 != ?)");

      pstmt1.clearParameters();        // clear the parms and check player 1
      pstmt1.setLong(1, slotParms.date);
      pstmt1.setInt(2, stime);
      pstmt1.setInt(3, etime);
      pstmt1.setInt(4, slotParms.time);
      pstmt1.setString(5, omit);
      pstmt1.setString(6, omit);
      pstmt1.setString(7, omit);
      pstmt1.setString(8, omit);
      pstmt1.setString(9, omit);
      rs = pstmt1.executeQuery();      // execute the prepared stmt

      while (rs.next()) {

         userg1 = rs.getString("userg1");
         userg2 = rs.getString("userg2");
         userg3 = rs.getString("userg3");
         userg4 = rs.getString("userg4");
         userg5 = rs.getString("userg5");

         //
         //  Count the number of guests already scheduled
         //
         if (!userg1.equals( "" )) {

            guests++;
         }
         if (!userg2.equals( "" )) {

            guests++;
         }
         if (!userg3.equals( "" )) {

            guests++;
         }
         if (!userg4.equals( "" )) {

            guests++;
         }
         if (!userg5.equals( "" )) {

            guests++;
         }
      }   // end of WHILE

      pstmt1.close();

      //
      //  If more then 12 guests scheduled (counting this request), then set error
      //
      if (guests > 12) {

         error = true;
      }

   }
   catch (Exception e) {

      String errorMsg = "Error checking for Wilmington Guests - verifyCustom.checkWilDB: ";
      errorMsg = errorMsg + e.getMessage();
      logError(errorMsg);        // log the error message
   }

   return(error);
 }                   // end of checkWilDB



/**
 //************************************************************************
 //
 //  Beverly GC - Check for more than 21 guests total during specified days/times.
 //
 //    Called by:  Member_slot(m)
 //
 //    Check teecurr for the number of guests already scheduled.
 //
 //************************************************************************
 **/

 public static boolean beverlyGuests(parmSlot slotParms, Connection con) {

   ResultSet rs = null;


   boolean error = false;
   boolean check = false;

   String day = slotParms.day;
   String omit = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";

   int stime = 1200;
   int etime = 1700;
   int time = slotParms.time;
   int guests = slotParms.guests;    // # of guests in this request

   long date = slotParms.date;
   long shortDate = date - ((date / 10000) * 10000);       // get mmdd (i.e.  20060512 - 20060000 = 512)


   //
   //   Only check if Wed or Fri, between Noon and 5:00 PM and between 4/15 and 11/15
   //
   if ((day.equals( "Wednesday" ) || day.equals( "Friday" )) && (time > 1200 && time < 1700) &&
        (shortDate > 414 && shortDate < 1116)) { 

      //
      //  Count all guests already scheduled between noon and 5 PM today (exclude this time)
      //
      try {

         PreparedStatement pstmt1 = con.prepareStatement (
            "SELECT " +
            "userg1, userg2, userg3, userg4, userg5 " +
            "FROM teecurr2 " +
            "WHERE date = ? AND time > ? AND time < ? AND time != ? AND " +
            "(userg1 != ? OR userg2 != ? OR userg3 != ? OR userg4 != ? OR userg5 != ?)");

         pstmt1.clearParameters();        // clear the parms and check player 1
         pstmt1.setLong(1, date);
         pstmt1.setInt(2, stime);
         pstmt1.setInt(3, etime);
         pstmt1.setInt(4, time);
         pstmt1.setString(5, omit);
         pstmt1.setString(6, omit);
         pstmt1.setString(7, omit);
         pstmt1.setString(8, omit);
         pstmt1.setString(9, omit);
         rs = pstmt1.executeQuery();      // execute the prepared stmt

         while (rs.next()) {

            userg1 = rs.getString("userg1");
            userg2 = rs.getString("userg2");
            userg3 = rs.getString("userg3");
            userg4 = rs.getString("userg4");
            userg5 = rs.getString("userg5");

            //
            //  Count the number of guests already scheduled
            //
            if (!userg1.equals( "" )) {

               guests++;
            }
            if (!userg2.equals( "" )) {

               guests++;
            }
            if (!userg3.equals( "" )) {

               guests++;
            }
            if (!userg4.equals( "" )) {

               guests++;
            }
            if (!userg5.equals( "" )) {

               guests++;
            }
         }   // end of WHILE

         pstmt1.close();

         //
         //  If more then 21 guests scheduled (counting this request), then set error
         //
         if (guests > 21) {

            error = true;
         }

      }
      catch (Exception e) {

         logError("Error checking for Beverly Guests - verifyCustom.beverlyGuests: " + e.getMessage());        // log the error message
      }
   }

   return(error);
 }                   // end of beverlyGuests



 // *********************************************************
 //  El Niguel CC - check for Juniors w/o an adult
 //
 //    Dependents = mtypes of 'Junior Male' and 'Junior Female'
 //
 //    Restrictions:  Sunday 7 - 11 AM on Back Tee (already known)
 //
 // *********************************************************

 public static boolean checkElNiguelDependents(parmSlot slotParms) {


   boolean error = false;


   //
   //  Check for any dependents
   //
   if (slotParms.mtype1.startsWith( "Junior" ) || slotParms.mtype2.startsWith( "Junior" ) || slotParms.mtype3.startsWith( "Junior" ) ||
       slotParms.mtype4.startsWith( "Junior" ) || slotParms.mtype5.startsWith( "Junior" )) {

      //
      //  Make sure at least 1 adult
      //
      if (!slotParms.mtype1.startsWith( "Adult" ) &&
          !slotParms.mtype2.startsWith( "Adult" ) &&
          !slotParms.mtype3.startsWith( "Adult" ) &&
          !slotParms.mtype4.startsWith( "Adult" ) &&
          !slotParms.mtype5.startsWith( "Adult" )) {       // if no adults

         error = true;           // no adult - error
      }
   }

   return(error);
 }



 // *********************************************************
 //  Belle Meade CC - check for Females w/o a Male
 //
 //    Restrictions:  Sunday 8 - 12:50 (already known)
 //
 // *********************************************************

 public static boolean checkBelleMeadeFems(parmSlot slotParms) {


   boolean error = false;


   //
   //  Check for any Primary Females
   //
   if (slotParms.mtype1.endsWith( "Female" ) || slotParms.mtype2.endsWith( "Female" ) || slotParms.mtype3.endsWith( "Female" ) ||
       slotParms.mtype4.endsWith( "Female" ) || slotParms.mtype5.endsWith( "Female" )) {

      //
      //  Make sure at least 1 Male
      //
      if (!slotParms.mtype1.equals( "Primary Male" ) &&
          !slotParms.mtype2.equals( "Primary Male" ) &&
          !slotParms.mtype3.equals( "Primary Male" ) &&
          !slotParms.mtype4.equals( "Primary Male" ) &&
          !slotParms.mtype5.equals( "Primary Male" )) {       // if no Males

         error = true;           // no adult - error
      }
   }

   return(error);
 }



 // *********************************************************
 //  Los Coyotes CC - check for Spouses w/o Primary
 //
 //    Restrictions:  more than 3 days in advance (checked before here)
 //
 //         If a Secondary member in group with at least one Primary member,
 //         the Secondary's spouse must be included.
 //
 // *********************************************************

 public static boolean checkLCSpouses(parmSlot slotParms) {


   boolean error = false;

   //  check if any Secondary members in group
   if (slotParms.mtype1.startsWith( "Secondary" ) || slotParms.mtype2.startsWith( "Secondary" ) || slotParms.mtype3.startsWith( "Secondary" ) ||
       slotParms.mtype4.startsWith( "Secondary" ) || slotParms.mtype5.startsWith( "Secondary" )) {

      //
      //  If any Primary members in group, they must be of the same family
      //
      if (slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Primary" ) ||
          slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Primary" )) {

         //
         //  We have at least 1 of each - see if they are same family
         //
         error = false;    

         if (slotParms.mtype1.startsWith("Secondary")) {

            error = true;
            
            if (slotParms.mNum1.equals(slotParms.mNum2) || slotParms.mNum1.equals(slotParms.mNum3) || 
                slotParms.mNum1.equals(slotParms.mNum4) || slotParms.mNum1.equals(slotParms.mNum5)) {
               
               error = false;         
            }
         }
               
         if (slotParms.mtype2.startsWith("Secondary") && error == false) {

            error = true;
            
            if (slotParms.mNum2.equals(slotParms.mNum1) || slotParms.mNum2.equals(slotParms.mNum3) || 
                slotParms.mNum2.equals(slotParms.mNum4) || slotParms.mNum2.equals(slotParms.mNum5)) {
               
               error = false;         
            }
         }
               
         if (slotParms.mtype3.startsWith("Secondary") && error == false) {

            error = true;
            
            if (slotParms.mNum3.equals(slotParms.mNum1) || slotParms.mNum3.equals(slotParms.mNum2) || 
                slotParms.mNum3.equals(slotParms.mNum4) || slotParms.mNum3.equals(slotParms.mNum5)) {
               
               error = false;         
            }
         }
               
         if (slotParms.mtype4.startsWith("Secondary") && error == false) {

            error = true;
            
            if (slotParms.mNum4.equals(slotParms.mNum1) || slotParms.mNum4.equals(slotParms.mNum2) || 
                slotParms.mNum4.equals(slotParms.mNum3) || slotParms.mNum4.equals(slotParms.mNum5)) {
               
               error = false;         
            }
         }
               
         if (slotParms.mtype5.startsWith("Secondary") && error == false) {

            error = true;
            
            if (slotParms.mNum5.equals(slotParms.mNum1) || slotParms.mNum5.equals(slotParms.mNum2) || 
                slotParms.mNum5.equals(slotParms.mNum3) || slotParms.mNum5.equals(slotParms.mNum4)) {
               
               error = false;         
            }
         }  
      }
   }

   return(error);
 }


 // *********************************************************
 //  Awbrey Glen - check for Juniors w/o an adult
 //
 //    Dependents = mtypes of 'Junior Male' and 'Junior Female'
 //                 or 'Junior xx 12 and over' (xx = Male or Female)
 //
 //    Restrictions:  all day, every day for Juniors
 //                   before Noon, every day for Juniors 12 and over
 //
 // *********************************************************

 public static boolean checkAwbreyDependents(parmSlot slotParms) {


   boolean error = false;


   //
   //  Check for any dependents
   //
   if (slotParms.mtype1.equals( "Junior Male" ) || slotParms.mtype2.equals( "Junior Male" ) || slotParms.mtype3.equals( "Junior Male" ) ||
       slotParms.mtype4.equals( "Junior Male" ) || slotParms.mtype5.equals( "Junior Male" ) ||
       slotParms.mtype1.equals( "Junior Female" ) || slotParms.mtype2.equals( "Junior Female" ) || slotParms.mtype3.equals( "Junior Female" ) ||
       slotParms.mtype4.equals( "Junior Female" ) || slotParms.mtype5.equals( "Junior Female" )) {

      //
      //  Make sure at least 1 adult
      //
      if (!slotParms.mtype1.startsWith( "Adult" ) &&
          !slotParms.mtype2.startsWith( "Adult" ) &&
          !slotParms.mtype3.startsWith( "Adult" ) &&
          !slotParms.mtype4.startsWith( "Adult" ) &&
          !slotParms.mtype5.startsWith( "Adult" )) {       // if no adults

         error = true;           // no adult - error
      }
        
   } else {

      if (slotParms.mtype1.endsWith( "over" ) || slotParms.mtype2.endsWith( "over" ) || slotParms.mtype3.endsWith( "over" ) ||
          slotParms.mtype4.endsWith( "over" ) || slotParms.mtype5.endsWith( "over" )) {

         if (slotParms.time < 1200) {       // if before Noon
        
            //
            //  Make sure at least 1 adult
            //
            if (!slotParms.mtype1.startsWith( "Adult" ) &&
                !slotParms.mtype2.startsWith( "Adult" ) &&
                !slotParms.mtype3.startsWith( "Adult" ) &&
                !slotParms.mtype4.startsWith( "Adult" ) &&
                !slotParms.mtype5.startsWith( "Adult" )) {       // if no adults

               error = true;           // no adult - error
            }
         }
      }
   }

   return(error);
 }


 // *********************************************************
 //  Tualatin - check for Juniors w/o an adult
 //
 //    Dependents = mtypes of 'Junior 17 Male' and 'Junior 17 Female'
 //                 or 'Junior 18-23 Male' and 'Junior 18-23 Female' 
 //
 //    Restrictions:  T-W-F-S-Sun 11:00 - 2:00
 //                 
 //
 // *********************************************************

 public static boolean checkTualatinJr(parmSlot slotParms, Connection con) {


   boolean error = false;

   
   //
   //  If Tues, Wed, Fri, Sat, or Sun, AND between 11:00 and 2:00 - check for unaccompanied Juniors
   //
   if (!slotParms.day.equals( "Monday" ) && !slotParms.day.equals( "Thursday" ) && slotParms.time > 1059 && slotParms.time < 1401) {

      //
      //  Check for any dependents
      //
      if (slotParms.mtype1.startsWith( "Junior" )) {

         error = true;           // init to error
         
         //
         //  Make sure at least 1 adult
         //
         if (slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Spouse" ) ||
             slotParms.mtype3.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Spouse" ) ||
             slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype4.startsWith( "Spouse" ) ||
             slotParms.mtype5.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Spouse" )) {       // if adults

            error = false;           // there is an adult - NO error
         }
      }

      if (slotParms.mtype2.startsWith( "Junior" ) && error == false) {

         error = true;           // init to error
         
         //
         //  Make sure at least 1 adult
         //
         if (slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype1.startsWith( "Spouse" ) ||
             slotParms.mtype3.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Spouse" ) ||
             slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype4.startsWith( "Spouse" ) ||
             slotParms.mtype5.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Spouse" )) {       // if adults

            error = false;           // there is an adult - NO error
         }
      }

      if (slotParms.mtype3.startsWith( "Junior" ) && error == false) {

         error = true;           // init to error
         
         //
         //  Make sure at least 1 adult
         //
         if (slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype1.startsWith( "Spouse" ) ||
             slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Spouse" ) ||
             slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype4.startsWith( "Spouse" ) ||
             slotParms.mtype5.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Spouse" )) {       // if adults

            error = false;           // there is an adult - NO error
         }
      }

      if (slotParms.mtype4.startsWith( "Junior" ) && error == false) {

         error = true;           // init to error
         
         //
         //  Make sure at least 1 adult
         //
         if (slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype1.startsWith( "Spouse" ) ||
             slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Spouse" ) ||
             slotParms.mtype3.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Spouse" ) ||
             slotParms.mtype5.startsWith( "Primary" ) || slotParms.mtype5.startsWith( "Spouse" )) {       // if adults

            error = false;           // there is an adult - NO error
         }
      }

      if (slotParms.mtype5.startsWith( "Junior" ) && error == false) {

         error = true;           // init to error
         
         //
         //  Make sure at least 1 adult
         //
         if (slotParms.mtype2.startsWith( "Primary" ) || slotParms.mtype2.startsWith( "Spouse" ) ||
             slotParms.mtype3.startsWith( "Primary" ) || slotParms.mtype3.startsWith( "Spouse" ) ||
             slotParms.mtype4.startsWith( "Primary" ) || slotParms.mtype4.startsWith( "Spouse" ) ||
             slotParms.mtype1.startsWith( "Primary" ) || slotParms.mtype1.startsWith( "Spouse" )) {       // if adults

            error = false;           // there is an adult - NO error
         }
      }
   }

   return(error);
 }


 // *************************************************************************************
 //  New Cannan - Custom Processing (check for 2-some only time)
 // *************************************************************************************

 public static boolean checkNewCan(long date, int time, String day_name) {


   boolean status = false;

   //
   //   2-some ONLY times from 7:00 AM to 7:25 AM on Weekends and holidays
   //
   if (date == Hdate1 || date == Hdate2b || date == Hdate3 || day_name.equals( "Saturday" ) || day_name.equals( "Sunday" )) {

      if (time > 659 && time < 726) {         // if tee time is between 7:00 and 7:25 AM

         status = true;                        // 2-some only time
      }
   }

   return(status);         // true = 2-somes only time
 }     
         
         
 // *************************************************************************************
 //  Dorset Field Cbub - Custom Processing (check for 2-some only time)
 // *************************************************************************************

 public static boolean checkDorsetFC(long date, int time, String day_name) {


   boolean status = false;

   long year = date / 10000;
   long month = (date - (year * 10000)) / 100;
   long day = date - ((year * 10000) + (month * 100));
   long mmdd = (month * 100) + day;                        // create mmdd value
   
   //
   //   2-some ONLY times from 7:40AM to 7:59AM on Mon, Tues, Wed, Fri from May 27 thru Aug 30
   //
   if ( (mmdd >= 527 && mmdd <= 830) && 
        (day_name.equals( "Monday" ) || day_name.equals( "Tuesday" ) || 
         day_name.equals( "Wednesday" ) || day_name.equals( "Friday" )) ) {

      if (time >= 740 && time <= 759) {         // if tee time is between 7:40 and 7:59 AM

         status = true;                        // 2-some only time
      }
   }

   return(status);         // true = 2-somes only time
 }


 // *************************************************************************************
 //  Mayfield Sand Ridge - Custom Processing (check for 2-some only time)
 // *************************************************************************************

 public static boolean checkMayfieldSR(long date, int time, String day_name) {


   boolean status = false;

   long year = date / 10000;
   long month = (date - (year * 10000)) / 100;
   long day = date - ((year * 10000) + (month * 100));
   long mmdd = (month * 100) + day;                        // create mmdd value
   
   //
   //   2-some ONLY times from 7:00 AM to 7:25 AM on Weekdays and holidays from May 24 thru Sept 1
   //
   if ( ((mmdd > 523 && mmdd < 902) || (date == Hdate1 || date == Hdate2b || date == Hdate3)) && 
        (day_name.equals( "Saturday" ) || day_name.equals( "Sunday" )) ) {

      if (time > 659 && time < 726) {         // if tee time is between 7:00 and 7:25 AM

         status = true;                        // 2-some only time
      }
   }

   return(status);         // true = 2-somes only time
 }
 
 
 // *************************************************************************************
 //  The CC - Custom Processing (check date and time of day for 2-some only time)
 // *************************************************************************************

 public static boolean checkTheCC(long date, int time, String day_name) {


   boolean status = false;

   //
   //  Determine date values - month, day, year
   //
   long year = date / 10000;
   long month = (date - (year * 10000)) / 100;
   long day = date - ((year * 10000) + (month * 100));
   long mmdd = (month * 100) + day;                        // create mmdd value

   //
   //      ************* See also SystemUtils ********************
   //
   //   2-some ONLY times from 7:30 AM to 8:00 AM for the following dates:
   //
   //      Every Tues, Wed & Thurs from 4/01 - 8/31
   //
   //      Every Tues, Wed & Thurs from 9/04 - 10/31
   //
   //
   if (mmdd > 400 && mmdd < 832 && (day_name.equals( "Tuesday" ) || day_name.equals( "Wednesday" ) || day_name.equals( "Thursday" ))) {

      if ( (time > 729 && time < 801) || (time > 1629 && time < 1701) ) {         // if tee time is between 7:30 and 8:00 AM OR 4:30-5PM

         status = true;                        // 2-some only time
      }
   }

   if (mmdd > 903 && mmdd < 1032 && (day_name.equals( "Tuesday" ) || day_name.equals( "Wednesday" ) || day_name.equals( "Thursday" ))) {

      if (time > 744 && time < 816) {         // if tee time is between 7:45 and 8:15 AM

         status = true;                        // 2-some only time
      }
   }

   return(status);         // true = 2-somes only time
 }


 // *************************************************************************************
 //  Greenwich CC - Custom Processing (check date and time of day for 2-some only time)
 // *************************************************************************************

 public static boolean checkGreenwich(long date, int time) {


   boolean status = false;

   //
   //  Determine date values - month, day, year
   //
   long year = date / 10000;
   long month = (date - (year * 10000)) / 100;
   long day = date - ((year * 10000) + (month * 100));
   long shortDate = (month * 100) + day;                        // create mmdd value

   //
   //      ************* See also SystemUtils ********************
   //
   //   2-some ONLY times from 7:00 AM to 7:48 AM for the specified dates.
   //
   //
   if (shortDate == 526 || shortDate == 527 || shortDate == 528 || shortDate == 602 || shortDate == 603 ||
       shortDate == 609 || shortDate == 610 || shortDate == 616 || shortDate == 617 || shortDate == 623 ||
       shortDate == 624 || shortDate == 701 || shortDate == 707 || shortDate == 708 || shortDate == 721 ||
       shortDate == 804 || shortDate == 811 || shortDate == 812 || shortDate == 818 || shortDate == 819 ||
       shortDate == 826) {

      if (time > 659 && time < 749) {         // if tee time is between 7:00 and 7:48 AM

         status = true;                        // 2-some only time
      }
   }

   return(status);         // true = 2-somes only time
 }


/**
 //************************************************************************
 //
 //  The CC - special Guest processing.
 //
 //     At this point we know there is more than one guest
 //     in this tee time, it is The CC, it is in season, and on a restricted course.
 //
 //     Restrictions:
 //
 //       Members (per family) can have up to 6 guests per month
 //       and 18 per season, where the season is April 1 to Oct 31.
 //       Event rounds are NOT counted.
 //
 //************************************************************************
 **/

 public static boolean checkTCCguests(parmSlot slotParms, Connection con) {


   PreparedStatement pstmt = null;
   PreparedStatement pstmt1 = null;
   ResultSet rs = null;
   ResultSet rs2 = null;

   boolean error = false;

   int time = 0;
   int ttime = 0;
   int fb = 0;
   int countm = 0;         // number of guests for month
   int counts = 0;         // number of guests for season

   String user = "";
   String mNum = "";
   String userg1 = "";
   String userg2 = "";
   String userg3 = "";
   String userg4 = "";
   String userg5 = "";
   String errorMsg = "";
   String player1 = "";
   String player2 = "";
   String player3 = "";
   String player4 = "";
   String player5 = "";

   //
   //  break down date of tee time
   //
   long yy = slotParms.date / 10000;                             // get year
   long mm = (slotParms.date - (yy * 10000)) / 100;              // get month
   long dd = (slotParms.date - (yy * 10000)) - (mm * 100);       // get day

   long sdate = (yy * 10000) + 400;       // yyyy0400
   long edate = (yy * 10000) + 1032;      // yyyy1032
   long tdate = 0;

   int imm = (int)mm;
   int iyy = (int)yy;
   int i = 0;


   String [] usergA = new String [5];       // array to hold the members' usernames
   String [] userA = new String [5];        // array to hold the usernames
   String [] playerA = new String [5];      // array to hold the player's names
   String [] mnumA = new String [5];       // array to hold the players' membership types

   playerA[0] = slotParms.player1;
   playerA[1] = slotParms.player2;
   playerA[2] = slotParms.player3;
   playerA[3] = slotParms.player4;
   playerA[4] = slotParms.player5;

   userA[0] = slotParms.user1;
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;
   userA[4] = slotParms.user5;

   usergA[0] = slotParms.userg1;                  // copy userg values into array
   usergA[1] = slotParms.userg2;
   usergA[2] = slotParms.userg3;
   usergA[3] = slotParms.userg4;
   usergA[4] = slotParms.userg5;

   mnumA[0] = slotParms.mNum1;
   mnumA[1] = slotParms.mNum2;
   mnumA[2] = slotParms.mNum3;
   mnumA[3] = slotParms.mNum4;
   mnumA[4] = slotParms.mNum5;


   //
   //  Remove any duplicate family members - only check one user for the family
   //
   if (!mnumA[0].equals( "" )) {        // if mnum exists
     
      if (mnumA[1].equals( mnumA[0] )) {        // if mnum is the same

         mnumA[1] = "";
         userA[1] = "";
      }
      if (mnumA[2].equals( mnumA[0] )) {        // if mnum is the same

         mnumA[2] = "";
         userA[2] = "";
      }
      if (mnumA[3].equals( mnumA[0] )) {        // if mnum is the same

         mnumA[3] = "";
         userA[3] = "";
      }
      if (mnumA[4].equals( mnumA[0] )) {        // if mnum is the same

         mnumA[4] = "";
         userA[4] = "";
      }
   }
     
   if (!mnumA[1].equals( "" )) {        // if mnum exists

      if (mnumA[2].equals( mnumA[1] )) {        // if mnum is the same

         mnumA[2] = "";
         userA[2] = "";
      }
      if (mnumA[3].equals( mnumA[1] )) {        // if mnum is the same

         mnumA[3] = "";
         userA[3] = "";
      }
      if (mnumA[4].equals( mnumA[1] )) {        // if mnum is the same

         mnumA[4] = "";
         userA[4] = "";
      }
   }

   if (!mnumA[2].equals( "" )) {        // if mnum exists

      if (mnumA[3].equals( mnumA[2] )) {        // if mnum is the same

         mnumA[3] = "";
         userA[3] = "";
      }
      if (mnumA[4].equals( mnumA[2] )) {        // if mnum is the same

         mnumA[4] = "";
         userA[4] = "";
      }
   }

   if (!mnumA[3].equals( "" )) {        // if mnum exists

      if (mnumA[4].equals( mnumA[3] )) {        // if mnum is the same

         mnumA[4] = "";
         userA[4] = "";
      }
   }

  
   try {

      //
      //  Check each player
      //
      loop1:
      for (i = 0; i < 5; i++) {

         if (!userA[i].equals( "" )) {       // if member

            countm = 0;
            counts = 0;
              
            //
            //  count # of guests for this user in this tee time
            //
            if (usergA[0].equals( userA[i] ) && !playerA[0].startsWith("Tournament")) {

               countm++;           // count # of guests
               counts++;       
            }
            if (usergA[1].equals( userA[i] ) && !playerA[1].startsWith("Tournament")) {

               countm++;           // count # of guests
               counts++;
            }
            if (usergA[2].equals( userA[i] ) && !playerA[2].startsWith("Tournament")) {

               countm++;           // count # of guests
               counts++;
            }
            if (usergA[3].equals( userA[i] ) && !playerA[3].startsWith("Tournament")) {

               countm++;           // count # of guests
               counts++;
            }
            if (usergA[4].equals( userA[i] ) && !playerA[4].startsWith("Tournament")) {

               countm++;           // count # of guests
               counts++;
            }
              
            if (countm > 0) {
              
               //  get this user's mNum
                 
               mNum = mnumA[i];

               if (!mNum.equals( "" )) {     // if there is one specified

                  //
                  //  get all users with matching mNum
                  //
                  PreparedStatement pstmt4 = con.prepareStatement (
                     "SELECT username FROM member2b WHERE memNum = ?");

                  pstmt4.clearParameters();        // clear the parms
                  pstmt4.setString(1, mNum);
                  rs2 = pstmt4.executeQuery();      // execute the prepared stmt

                  while (rs2.next()) {

                     user = rs2.getString(1);       // get the username

                     //
                     //   Check teecurr and teepast for other guest times for this member for the season
                     //
                     pstmt = con.prepareStatement (
                        "SELECT player1, player2, player3, player4, player5, userg1, userg2, userg3, userg4, userg5 " +
                        "FROM teepast2 " +
                        "WHERE date < ? AND date > ? AND event = '' AND " +
                        "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                     pstmt.clearParameters();
                     pstmt.setLong(1, edate);
                     pstmt.setLong(2, sdate);
                     pstmt.setString(3, user);
                     pstmt.setString(4, user);
                     pstmt.setString(5, user);
                     pstmt.setString(6, user);
                     pstmt.setString(7, user);
                     rs = pstmt.executeQuery();

                     while (rs.next()) {

                        player1 = rs.getString(1);     
                        player2 = rs.getString(2);     
                        player3 = rs.getString(3);     
                        player4 = rs.getString(4);     
                        player5 = rs.getString(5);     
                        userg1 = rs.getString(6);     
                        userg2 = rs.getString(7);
                        userg3 = rs.getString(8);
                        userg4 = rs.getString(9);
                        userg5 = rs.getString(10);
                          
                        if (userg1.equals( user ) && !player1.startsWith("Tournament")) {
                          
                           counts++;     // bump # of guests
                        }
                        if (userg2.equals( user ) && !player2.startsWith("Tournament")) {

                           counts++;     // bump # of guests
                        }
                        if (userg3.equals( user ) && !player3.startsWith("Tournament")) {

                           counts++;     // bump # of guests
                        }
                        if (userg4.equals( user ) && !player4.startsWith("Tournament")) {

                           counts++;     // bump # of guests
                        }
                        if (userg5.equals( user ) && !player5.startsWith("Tournament")) {

                           counts++;     // bump # of guests
                        }
                     }      // end of WHILE

                     pstmt.close();

                     pstmt = con.prepareStatement (
                        "SELECT date, time, player1, player2, player3, player4, player5, userg1, userg2, userg3, userg4, userg5 " +
                        "FROM teecurr2 " +
                        "WHERE date < ? AND date > ? AND event = '' AND " +
                        "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                     pstmt.clearParameters();
                     pstmt.setLong(1, edate);
                     pstmt.setLong(2, sdate);
                     pstmt.setString(3, user);
                     pstmt.setString(4, user);
                     pstmt.setString(5, user);
                     pstmt.setString(6, user);
                     pstmt.setString(7, user);
                     rs = pstmt.executeQuery();

                     while (rs.next()) {

                        tdate = rs.getLong(1);
                        ttime = rs.getInt(2);
                        player1 = rs.getString(3);     
                        player2 = rs.getString(4);     
                        player3 = rs.getString(5);     
                        player4 = rs.getString(6);     
                        player5 = rs.getString(7);     
                        userg1 = rs.getString(8);
                        userg2 = rs.getString(9);
                        userg3 = rs.getString(10);
                        userg4 = rs.getString(11);
                        userg5 = rs.getString(12);

                        if (tdate != slotParms.date || ttime != slotParms.time) {   // if not this tee time
                          
                           if (userg1.equals( user ) && !player1.startsWith("Tournament")) {

                              counts++;     // bump # of guests
                           }
                           if (userg2.equals( user ) && !player2.startsWith("Tournament")) {

                              counts++;     // bump # of guests
                           }
                           if (userg3.equals( user ) && !player3.startsWith("Tournament")) {

                              counts++;     // bump # of guests
                           }
                           if (userg4.equals( user ) && !player4.startsWith("Tournament")) {

                              counts++;     // bump # of guests
                           }
                           if (userg5.equals( user ) && !player5.startsWith("Tournament")) {

                              counts++;     // bump # of guests
                           }
                        }
                     }      // end of WHILE

                     pstmt.close();

                     //
                     //   Check teecurr and teepast for other guest times for this member for the month
                     //
                     pstmt = con.prepareStatement (
                        "SELECT player1, player2, player3, player4, player5, userg1, userg2, userg3, userg4, userg5 " +
                        "FROM teepast2 " +
                        "WHERE mm = ? AND yy = ? AND event = '' AND " +
                        "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                     pstmt.clearParameters();
                     pstmt.setInt(1, imm);
                     pstmt.setInt(2, iyy);
                     pstmt.setString(3, user);
                     pstmt.setString(4, user);
                     pstmt.setString(5, user);
                     pstmt.setString(6, user);
                     pstmt.setString(7, user);
                     rs = pstmt.executeQuery();

                     while (rs.next()) {

                        player1 = rs.getString(1);     
                        player2 = rs.getString(2);     
                        player3 = rs.getString(3);     
                        player4 = rs.getString(4);     
                        player5 = rs.getString(5);     
                        userg1 = rs.getString(6);
                        userg2 = rs.getString(7);
                        userg3 = rs.getString(8);
                        userg4 = rs.getString(9);
                        userg5 = rs.getString(10);

                        if (userg1.equals( user ) && !player1.startsWith("Tournament")) {

                           countm++;     // bump # of guests
                        }
                        if (userg2.equals( user ) && !player2.startsWith("Tournament")) {

                           countm++;     // bump # of guests
                        }
                        if (userg3.equals( user ) && !player3.startsWith("Tournament")) {

                           countm++;     // bump # of guests
                        }
                        if (userg4.equals( user ) && !player4.startsWith("Tournament")) {

                           countm++;     // bump # of guests
                        }
                        if (userg5.equals( user ) && !player5.startsWith("Tournament")) {

                           countm++;     // bump # of guests
                        }
                     }      // end of WHILE

                     pstmt.close();

                     pstmt = con.prepareStatement (
                        "SELECT date, time, player1, player2, player3, player4, player5, userg1, userg2, userg3, userg4, userg5 " +
                        "FROM teecurr2 " +
                        "WHERE mm = ? AND yy = ? AND event = '' AND " +
                        "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ? OR userg5 = ?)");

                     pstmt.clearParameters();
                     pstmt.setInt(1, imm);
                     pstmt.setInt(2, iyy);
                     pstmt.setString(3, user);
                     pstmt.setString(4, user);
                     pstmt.setString(5, user);
                     pstmt.setString(6, user);
                     pstmt.setString(7, user);
                     rs = pstmt.executeQuery();

                     while (rs.next()) {

                        tdate = rs.getLong(1);
                        ttime = rs.getInt(2);
                        player1 = rs.getString(3);     
                        player2 = rs.getString(4);     
                        player3 = rs.getString(5);     
                        player4 = rs.getString(6);     
                        player5 = rs.getString(7);     
                        userg1 = rs.getString(8);
                        userg2 = rs.getString(9);
                        userg3 = rs.getString(10);
                        userg4 = rs.getString(11);
                        userg5 = rs.getString(12);

                        if (tdate != slotParms.date || ttime != slotParms.time) {   // if not this tee time

                           if (userg1.equals( user ) && !player1.startsWith("Tournament")) {

                              countm++;     // bump # of guests
                           }
                           if (userg2.equals( user ) && !player2.startsWith("Tournament")) {

                              countm++;     // bump # of guests
                           }
                           if (userg3.equals( user ) && !player3.startsWith("Tournament")) {

                              countm++;     // bump # of guests
                           }
                           if (userg4.equals( user ) && !player4.startsWith("Tournament")) {

                              countm++;     // bump # of guests
                           }
                           if (userg5.equals( user ) && !player5.startsWith("Tournament")) {

                              countm++;     // bump # of guests
                           }
                        }
                     }      // end of WHILE

                     pstmt.close();

                  }
                  pstmt4.close();

                  if (counts > 18 || countm > 6) {          // if either count puts user over the limit

                     error = true;                          // indicate error
                     slotParms.player = playerA[i];         // save player name for error message
                     break loop1;
                  }
                    
               }
            }
         }
      }              // end of FOR loop (do each player)

   }
   catch (Exception e) {

      errorMsg = "Error checking for The CC guests - verifyCustom.checkTCCguests " + e.getMessage();
      verifySlot.logError(errorMsg);        // log the error message
   }


   return(error);
 }


 // *********************************************************
 //
 //  Merrill Hills - check mships for display on pro tee sheet
 //
 // *********************************************************

 public static void checkMerrill(parmSlot slotParms) {


   slotParms.custom_disp1 = "";
   slotParms.custom_disp2 = "";
   slotParms.custom_disp3 = "";
   slotParms.custom_disp4 = "";
   slotParms.custom_disp5 = "";

   if (slotParms.mship1.equals( "Athletic" )) {

      slotParms.custom_disp1 = " *";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship2.equals( "Athletic" )) {

      slotParms.custom_disp2 = " *";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship3.equals( "Athletic" )) {

      slotParms.custom_disp3 = " *";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship4.equals( "Athletic" )) {

      slotParms.custom_disp4 = " *";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship5.equals( "Athletic" )) {

      slotParms.custom_disp5 = " *";          // to be added to player name in Proshop_sheet
   }

   if (slotParms.mship1.equals( "Century Club" )) {

      slotParms.custom_disp1 = " $";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship2.equals( "Century Club" )) {

      slotParms.custom_disp2 = " $";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship3.equals( "Century Club" )) {

      slotParms.custom_disp3 = " $";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship4.equals( "Century Club" )) {

      slotParms.custom_disp4 = " $";          // to be added to player name in Proshop_sheet
   }
   if (slotParms.mship5.equals( "Century Club" )) {

      slotParms.custom_disp5 = " $";          // to be added to player name in Proshop_sheet
   }

 }

 // *********************************************************
 //
 //  Merrill Hills - check mships for display on pro tee sheet (for _slotm)
 //
 // *********************************************************

 public static void checkMerrillm(parmSlotm parm) {


   parm.custom_disp1 = "";
   parm.custom_disp2 = "";
   parm.custom_disp3 = "";
   parm.custom_disp4 = "";
   parm.custom_disp5 = "";
   parm.custom_disp6 = "";
   parm.custom_disp7 = "";
   parm.custom_disp8 = "";
   parm.custom_disp9 = "";
   parm.custom_disp10 = "";
   parm.custom_disp11 = "";
   parm.custom_disp12 = "";
   parm.custom_disp13 = "";
   parm.custom_disp14 = "";
   parm.custom_disp15 = "";
   parm.custom_disp16 = "";
   parm.custom_disp17 = "";
   parm.custom_disp18 = "";
   parm.custom_disp19 = "";
   parm.custom_disp20 = "";
   parm.custom_disp21 = "";
   parm.custom_disp22 = "";
   parm.custom_disp23 = "";
   parm.custom_disp24 = "";
   parm.custom_disp25 = "";


   if (parm.mship1.equals( "Athletic" )) {

      parm.custom_disp1 = " *";          
   }
   if (parm.mship2.equals( "Athletic" )) {

      parm.custom_disp2 = " *";          
   }
   if (parm.mship3.equals( "Athletic" )) {

      parm.custom_disp3 = " *";          
   }
   if (parm.mship4.equals( "Athletic" )) {

      parm.custom_disp4 = " *";          
   }
   if (parm.mship5.equals( "Athletic" )) {

      parm.custom_disp5 = " *";          
   }
   if (parm.mship6.equals( "Athletic" )) {

      parm.custom_disp6 = " *";
   }
   if (parm.mship7.equals( "Athletic" )) {

      parm.custom_disp7 = " *";
   }
   if (parm.mship8.equals( "Athletic" )) {

      parm.custom_disp8 = " *";
   }
   if (parm.mship9.equals( "Athletic" )) {

      parm.custom_disp9 = " *";
   }
   if (parm.mship10.equals( "Athletic" )) {

      parm.custom_disp10 = " *";
   }
   if (parm.mship11.equals( "Athletic" )) {

      parm.custom_disp11 = " *";
   }
   if (parm.mship12.equals( "Athletic" )) {

      parm.custom_disp12 = " *";
   }
   if (parm.mship13.equals( "Athletic" )) {

      parm.custom_disp13 = " *";
   }
   if (parm.mship14.equals( "Athletic" )) {

      parm.custom_disp14 = " *";
   }
   if (parm.mship15.equals( "Athletic" )) {

      parm.custom_disp15 = " *";
   }
   if (parm.mship16.equals( "Athletic" )) {

      parm.custom_disp16 = " *";
   }
   if (parm.mship17.equals( "Athletic" )) {

      parm.custom_disp17 = " *";
   }
   if (parm.mship18.equals( "Athletic" )) {

      parm.custom_disp18 = " *";
   }
   if (parm.mship19.equals( "Athletic" )) {

      parm.custom_disp19 = " *";
   }
   if (parm.mship20.equals( "Athletic" )) {

      parm.custom_disp20 = " *";
   }
   if (parm.mship21.equals( "Athletic" )) {

      parm.custom_disp21 = " *";
   }
   if (parm.mship22.equals( "Athletic" )) {

      parm.custom_disp22 = " *";
   }
   if (parm.mship23.equals( "Athletic" )) {

      parm.custom_disp23 = " *";
   }
   if (parm.mship24.equals( "Athletic" )) {

      parm.custom_disp24 = " *";
   }
   if (parm.mship25.equals( "Athletic" )) {

      parm.custom_disp25 = " *";
   }

   if (parm.mship1.equals( "Century Club" )) {

      parm.custom_disp1 = " $";
   }
   if (parm.mship2.equals( "Century Club" )) {

      parm.custom_disp2 = " $";
   }
   if (parm.mship3.equals( "Century Club" )) {

      parm.custom_disp3 = " $";
   }
   if (parm.mship4.equals( "Century Club" )) {

      parm.custom_disp4 = " $";
   }
   if (parm.mship5.equals( "Century Club" )) {

      parm.custom_disp5 = " $";
   }
   if (parm.mship6.equals( "Century Club" )) {

      parm.custom_disp6 = " $";
   }
   if (parm.mship7.equals( "Century Club" )) {

      parm.custom_disp7 = " $";
   }
   if (parm.mship8.equals( "Century Club" )) {

      parm.custom_disp8 = " $";
   }
   if (parm.mship9.equals( "Century Club" )) {

      parm.custom_disp9 = " $";
   }
   if (parm.mship10.equals( "Century Club" )) {

      parm.custom_disp10 = " $";
   }
   if (parm.mship11.equals( "Century Club" )) {

      parm.custom_disp11 = " $";
   }
   if (parm.mship12.equals( "Century Club" )) {

      parm.custom_disp12 = " $";
   }
   if (parm.mship13.equals( "Century Club" )) {

      parm.custom_disp13 = " $";
   }
   if (parm.mship14.equals( "Century Club" )) {

      parm.custom_disp14 = " $";
   }
   if (parm.mship15.equals( "Century Club" )) {

      parm.custom_disp15 = " $";
   }
   if (parm.mship16.equals( "Century Club" )) {

      parm.custom_disp16 = " $";
   }
   if (parm.mship17.equals( "Century Club" )) {

      parm.custom_disp17 = " $";
   }
   if (parm.mship18.equals( "Century Club" )) {

      parm.custom_disp18 = " $";
   }
   if (parm.mship19.equals( "Century Club" )) {

      parm.custom_disp19 = " $";
   }
   if (parm.mship20.equals( "Century Club" )) {

      parm.custom_disp20 = " $";
   }
   if (parm.mship21.equals( "Century Club" )) {

      parm.custom_disp21 = " $";
   }
   if (parm.mship22.equals( "Century Club" )) {

      parm.custom_disp22 = " $";
   }
   if (parm.mship23.equals( "Century Club" )) {

      parm.custom_disp23 = " $";
   }
   if (parm.mship24.equals( "Century Club" )) {

      parm.custom_disp24 = " $";
   }
   if (parm.mship25.equals( "Century Club" )) {

      parm.custom_disp25 = " $";
   }

 }


 // *********************************************************
 //
 //  Wilmington - check mship subtypes for display on pro tee sheet (for _slotm)
 //
 // *********************************************************

 public static void checkWilmington(parmSlotm parm) {


   parm.custom_disp1 = "";
   parm.custom_disp2 = "";
   parm.custom_disp3 = "";
   parm.custom_disp4 = "";
   parm.custom_disp5 = "";
   parm.custom_disp6 = "";
   parm.custom_disp7 = "";
   parm.custom_disp8 = "";
   parm.custom_disp9 = "";
   parm.custom_disp10 = "";
   parm.custom_disp11 = "";
   parm.custom_disp12 = "";
   parm.custom_disp13 = "";
   parm.custom_disp14 = "";
   parm.custom_disp15 = "";
   parm.custom_disp16 = "";
   parm.custom_disp17 = "";
   parm.custom_disp18 = "";
   parm.custom_disp19 = "";
   parm.custom_disp20 = "";
   parm.custom_disp21 = "";
   parm.custom_disp22 = "";
   parm.custom_disp23 = "";
   parm.custom_disp24 = "";
   parm.custom_disp25 = "";


   if (!parm.mstype1.equals( "" )) {

      parm.custom_disp1 = parm.mstype1;
   }
   if (!parm.mstype2.equals( "" )) {

      parm.custom_disp2 = parm.mstype2;
   }
   if (!parm.mstype3.equals( "" )) {

      parm.custom_disp3 = parm.mstype3;
   }
   if (!parm.mstype4.equals( "" )) {

      parm.custom_disp4 = parm.mstype4;
   }
   if (!parm.mstype5.equals( "" )) {

      parm.custom_disp5 = parm.mstype5;
   }
   if (!parm.mstype6.equals( "" )) {

      parm.custom_disp6 = parm.mstype6;
   }
   if (!parm.mstype7.equals( "" )) {

      parm.custom_disp7 = parm.mstype7;
   }
   if (!parm.mstype8.equals( "" )) {

      parm.custom_disp8 = parm.mstype8;
   }
   if (!parm.mstype9.equals( "" )) {

      parm.custom_disp9 = parm.mstype9;
   }
   if (!parm.mstype10.equals( "" )) {

      parm.custom_disp10 = parm.mstype10;
   }
   if (!parm.mstype11.equals( "" )) {

      parm.custom_disp11 = parm.mstype11;
   }
   if (!parm.mstype12.equals( "" )) {

      parm.custom_disp12 = parm.mstype12;
   }
   if (!parm.mstype13.equals( "" )) {

      parm.custom_disp13 = parm.mstype13;
   }
   if (!parm.mstype14.equals( "" )) {

      parm.custom_disp14 = parm.mstype14;
   }
   if (!parm.mstype15.equals( "" )) {

      parm.custom_disp15 = parm.mstype15;
   }
   if (!parm.mstype16.equals( "" )) {

      parm.custom_disp16 = parm.mstype16;
   }
   if (!parm.mstype17.equals( "" )) {

      parm.custom_disp17 = parm.mstype17;
   }
   if (!parm.mstype18.equals( "" )) {

      parm.custom_disp18 = parm.mstype18;
   }
   if (!parm.mstype19.equals( "" )) {

      parm.custom_disp19 = parm.mstype19;
   }
   if (!parm.mstype20.equals( "" )) {

      parm.custom_disp20 = parm.mstype20;
   }
   if (!parm.mstype21.equals( "" )) {

      parm.custom_disp21 = parm.mstype21;
   }
   if (!parm.mstype22.equals( "" )) {

      parm.custom_disp22 = parm.mstype22;
   }
   if (!parm.mstype23.equals( "" )) {

      parm.custom_disp23 = parm.mstype23;
   }
   if (!parm.mstype24.equals( "" )) {

      parm.custom_disp24 = parm.mstype24;
   }
   if (!parm.mstype25.equals( "" )) {

      parm.custom_disp25 = parm.mstype25;
   }

 }



 // *********************************************************
 //
 //  Sonnenalp - get guest rates for each guest type and add to tee time for display on tee sheet
 //
 // *********************************************************

 public static void addGuestRates(parmSlot slotParms) {

   long date = slotParms.date;
   int time = slotParms.time;
   int p91 = slotParms.p91;
   int p92 = slotParms.p92;
   int p93 = slotParms.p93;
   int p94 = slotParms.p94;
   int p95 = slotParms.p95;


   //
   //  Check for any guests
   //
   if (!slotParms.g1.equals( "" )) {

      slotParms.custom_disp1 = getGuestRate(date, time, p91, slotParms.g1);        // get the guest fee for this guest type
   }

   if (!slotParms.g2.equals( "" )) {

      slotParms.custom_disp2 = getGuestRate(date, time, p92, slotParms.g2);        // get the guest fee for this guest type
   }

   if (!slotParms.g3.equals( "" )) {

      slotParms.custom_disp3 = getGuestRate(date, time, p93, slotParms.g3);        // get the guest fee for this guest type
   }

   if (!slotParms.g4.equals( "" )) {

      slotParms.custom_disp4 = getGuestRate(date, time, p94, slotParms.g4);        // get the guest fee for this guest type
   }

   if (!slotParms.g5.equals( "" )) {

      slotParms.custom_disp5 = getGuestRate(date, time, p95, slotParms.g5);        // get the guest fee for this guest type
   }

 }

 // *********************************************************
 //
 //  Sonnenalp - get guest rates for each guest type and add to tee time for display on tee sheet (multiple tee time requests)
 //
 //       NOTE:  Sonnenalp does NOT allow 5-somes!!
 //
 // *********************************************************

 public static void addGuestRatesM(parmSlotm parm) {

   long date = parm.date;
   int time1 = parm.time1;
   int time2 = parm.time2;
   int time3 = parm.time3;
   int time4 = parm.time4;
   int time5 = parm.time5;
   int time = time1;
     
   String g1 = parm.g[0];         // get the guest types
   String g2 = parm.g[1];
   String g3 = parm.g[2];
   String g4 = parm.g[3];
   String g5 = parm.g[4];
   String g6 = parm.g[5];
   String g7 = parm.g[6];
   String g8 = parm.g[7];
   String g9 = parm.g[8];
   String g10 = parm.g[9];
   String g11 = parm.g[10];
   String g12 = parm.g[11];
   String g13 = parm.g[12];
   String g14 = parm.g[13];
   String g15 = parm.g[14];
   String g16 = parm.g[15];
   String g17 = parm.g[16];
   String g18 = parm.g[17];
   String g19 = parm.g[18];
   String g20 = parm.g[19];


   //
   //  Check for any guests
   //
   if (!g1.equals( "" )) {

      parm.custom_disp1 = getGuestRate(date, time, parm.p91, g1);        // get the guest fee for this guest type
   }

   if (!g2.equals( "" )) {

      parm.custom_disp2 = getGuestRate(date, time, parm.p92, g2);
   }

   if (!g3.equals( "" )) {

      parm.custom_disp3 = getGuestRate(date, time, parm.p93, g3);
   }

   if (!g4.equals( "" )) {

      parm.custom_disp4 = getGuestRate(date, time, parm.p94, g4);
   }

   time = time2; 

   if (!g5.equals( "" )) {

      parm.custom_disp5 = getGuestRate(date, time, parm.p95, g5);
   }

   if (!g6.equals( "" )) {

      parm.custom_disp6 = getGuestRate(date, time, parm.p96, g6);
   }

   if (!g7.equals( "" )) {

      parm.custom_disp7 = getGuestRate(date, time, parm.p97, g7);
   }

   if (!g8.equals( "" )) {

      parm.custom_disp8 = getGuestRate(date, time, parm.p98, g8);
   }

   time = time3;

   if (!g9.equals( "" )) {

      parm.custom_disp9 = getGuestRate(date, time, parm.p99, g9);
   }

   if (!g10.equals( "" )) {

      parm.custom_disp10 = getGuestRate(date, time, parm.p910, g10);
   }

   if (!g11.equals( "" )) {

      parm.custom_disp11 = getGuestRate(date, time, parm.p911, g11);        // get the guest fee for this guest type
   }

   if (!g12.equals( "" )) {

      parm.custom_disp12 = getGuestRate(date, time, parm.p912, g12);
   }

   time = time4;

   if (!g13.equals( "" )) {

      parm.custom_disp13 = getGuestRate(date, time, parm.p913, g13);
   }

   if (!g14.equals( "" )) {

      parm.custom_disp14 = getGuestRate(date, time, parm.p914, g14);
   }

   if (!g15.equals( "" )) {

      parm.custom_disp15 = getGuestRate(date, time, parm.p915, g15);
   }

   if (!g16.equals( "" )) {

      parm.custom_disp16 = getGuestRate(date, time, parm.p916, g16);
   }

   time = time5;

   if (!g17.equals( "" )) {

      parm.custom_disp17 = getGuestRate(date, time, parm.p917, g17);
   }

   if (!g18.equals( "" )) {

      parm.custom_disp18 = getGuestRate(date, time, parm.p918, g18);
   }

   if (!g19.equals( "" )) {

      parm.custom_disp19 = getGuestRate(date, time, parm.p919, g19);
   }

   if (!g20.equals( "" )) {

      parm.custom_disp20 = getGuestRate(date, time, parm.p920, g20);
   }

 }

 // *********************************************************
 //  Sonnenalp - get guest rate for specified guest type
 // *********************************************************

 public static String getGuestRate(long date, int time, int p9, String gtype) {


   String cost = "";

   long sdate = date - ((date / 10000) * 10000);       // get mmdd (short date)
     
   int morning = 1330;                //  end of morning times
   int twilight = 1529;                // start of twilight


   //
   //  Sonnenalp Guests - determine fee based on time of year and time of day
   //
   //    Low Season  = 4/01 - 6/14 and 9/16 - 10/28
   //    High Season = 6/15 - 9/15
   //
   //    Morning = open up to 1:20 (inclusive)
   //    Mid Day = 1:30 - 3:20 (inclusive)
   //    Twilight = after 3:29
   //
   if (gtype.equals( "Hotel" )) {            // if guest type = Hotel

      if (sdate > 614 && sdate < 916) {       // if High Season

         if (time > twilight) {             // if twilight

            cost = "50.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "25.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "125.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "62.50";
               }

            } else {         // Mid Day (1:30 - 3:20)

               cost = "100.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "50.00";
               }
            }
         }

      } else {    // Low Season

         if (time > twilight) {             // if twilight

            cost = "35.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "17.50";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "85.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "42.50";
               }

            } else {         // Mid Day (1:30 - 3:20)

               cost = "60.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "30.00";
               }
            }
         }
      }
   }     // end of Hotel Guest

   //
   //  Escorted Guest
   //
   if (gtype.equals( "Escorted Guest" )) {            // if guest type = Escorted Guest

      if (sdate > 614 && sdate < 916) {       // if High Season

         if (time > twilight) {             // if twilight

            cost = "50.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "25.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "100.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "50.00";
               }

            } else {         // Mid Day (1:30 - 3:20)

               cost = "75.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "37.50";
               }
            }
         }

      } else {    // Low Season

         if (time > twilight) {             // if twilight

            cost = "25.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "12.50";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "75.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "37.50";
               }

            } else {         // Mid Day (1:30 - 3:20)

               cost = "50.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "25.00";
               }
            }
         }
      }
   }     // end of Escorted Guest

   //
   //  Unescorted Guest
   //
   if (gtype.equals( "Unescorted Guest" )) {            // if guest type = Unescorted Guest

      if (sdate > 614 && sdate < 916) {       // if High Season

         if (time > twilight) {             // if twilight

            cost = "50.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "25.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "125.00";          // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "100.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "50.00";
               }
            }
         }

      } else {    // Low Season

         if (time > twilight) {             // if twilight

            cost = "35.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "17.50";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "85.00";        // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "60.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "30.00";
               }
            }
         }
      }
   }     // end of Unescorted Guest

   //
   //  Public Guest
   //
   if (gtype.equals( "Public" )) {            // if guest type = Public Guest

      if (sdate > 614 && sdate < 916) {       // if High Season

         if (time > twilight) {             // if twilight

            cost = "100.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "50.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "200.00";          // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "150.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "75.00";
               }
            }
         }

      } else {    // Low Season

         if (time > twilight) {             // if twilight

            cost = "75.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "37.50";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "125.00";        // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "100.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "50.00";
               }
            }
         }
      }
   }     // end of Public Guest

   //
   //  Property Owner Guest
   //
   if (gtype.equals( "Property Owner" )) {            // if guest type = Property Owner Guest

      if (sdate > 614 && sdate < 916) {       // if High Season

         if (time > twilight) {             // if twilight

            cost = "100.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "50.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "200.00";          // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "125.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "62.50";
               }
            }
         }

      } else {    // Low Season

         if (time > twilight) {             // if twilight

            cost = "50.00";

            if (p9 == 1) {             // if 9 hole round

               cost = "25.00";
            }

         } else {        // NOT twilight

            if (time < morning) {             // if normal time (before 1:30)

               cost = "125.00";        // no 9 hole fee

            } else {         // Mid Day (1:30 - 3:20)

               cost = "75.00";

               if (p9 == 1) {             // if 9 hole round

                  cost = "37.50";
               }
            }
         }
      }
   }     // end of Property Owner Guest


   if (!cost.equals( "" )) {     // if cost identified

      cost = "$" +cost;          // prefix with a dollar sign
   }
     
   return(cost);
 }



 public static boolean checkMediterraSports(parmSlot slotParms, Connection con) {
     

    boolean error = false;

    //
    //  break down date of tee time
    //
    int yy = (int)slotParms.date / 10000;       // get year
    int sdate = (yy * 10000) + 1001;            // yyyy1001
    int edate = ((yy + 1) * 10000) + 430;       // yyyy0430

    //
    //  Only check quota if tee time is within the Golf Year
    //
    if (slotParms.date > sdate && slotParms.date < edate) {   
       
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int i = 0;
        int show1 = 0;
        int show2 = 0;
        int show3 = 0;
        int show4 = 0;
        int show5 = 0;
        int time = 0;
        int fb = 0;
        int count_req = 0;
        int count = 0;                               // number of guests for date range
        int max = 4;                                 // max of rounds

        String user = "";
        String mNum = "";
        String player1 = "";
        String player2 = "";
        String player3 = "";
        String player4 = "";
        String player5 = "";
        String errorMsg = "";

        String [] userA = new String [5];            // array to hold the usernames
        String [] playerA = new String [5];          // array to hold the player's names
        String [] mnumA = new String [5];            // array to hold the players' member numbers
        String [] mshipA = new String [5];           // array to hold the players' membership types

        playerA[0] = slotParms.player1;
        playerA[1] = slotParms.player2;
        playerA[2] = slotParms.player3;
        playerA[3] = slotParms.player4;
        playerA[4] = slotParms.player5;

        userA[0] = slotParms.user1;
        userA[1] = slotParms.user2;
        userA[2] = slotParms.user3;
        userA[3] = slotParms.user4;
        userA[4] = slotParms.user5;

        mnumA[0] = slotParms.mNum1;
        mnumA[1] = slotParms.mNum2;
        mnumA[2] = slotParms.mNum3;
        mnumA[3] = slotParms.mNum4;
        mnumA[4] = slotParms.mNum5;

        mshipA[0] = slotParms.mship1;
        mshipA[1] = slotParms.mship2;
        mshipA[2] = slotParms.mship3;
        mshipA[3] = slotParms.mship4;
        mshipA[4] = slotParms.mship5;


        try {

            //
            //  Check each player
            //
            loop1:
            for (i = 0; i < 5; i++) {

                if (mshipA[i].equals("Sports")) {       // if it's a sports member

                    slotParms.player = playerA[i];      // save the player name we are currently checking

                    //
                    //   Check teepast2
                    //
                    pstmt = con.prepareStatement (
                       "SELECT mNum1, mNum2, mNum3, mNum4, mNum5, show1, show2, show3, show4, show5 " +
                       "FROM teepast2 " +
                       "WHERE " +
                            "date <= ? AND date >= ? AND (" +
                            "(mNum1 = ? AND show1 = 1) OR " +
                            "(mNum2 = ? AND show2 = 1) OR " +
                            "(mNum3 = ? AND show3 = 1) OR " +
                            "(mNum4 = ? AND show4 = 1) OR " +
                            "(mNum5 = ? AND show5 = 1))");

                    pstmt.setInt(1, sdate);
                    pstmt.setInt(2, edate);
                    pstmt.setString(3, mnumA[i]);
                    pstmt.setString(4, mnumA[i]);
                    pstmt.setString(5, mnumA[i]);
                    pstmt.setString(6, mnumA[i]);
                    pstmt.setString(7, mnumA[i]);
                    rs = pstmt.executeQuery();      // execute the prepared stmt

                    while (rs.next()) {

                        if (rs.getString("mNum1").equals(mnumA[i]) && rs.getInt("show1") == 1) count++;
                        if (rs.getString("mNum2").equals(mnumA[i]) && rs.getInt("show2") == 1) count++;
                        if (rs.getString("mNum3").equals(mnumA[i]) && rs.getInt("show3") == 1) count++;
                        if (rs.getString("mNum4").equals(mnumA[i]) && rs.getInt("show4") == 1) count++;
                        if (rs.getString("mNum5").equals(mnumA[i]) && rs.getInt("show5") == 1) count++;

                        if (count > max) {                         // if either count puts user over the limit

                            error = true;                          // indicate error
                            //slotParms.player = mnumA[i];           // save member number for error message
                            break loop1;
                        }

                    } // end while of all matching mNum's

                    rs.close();
                    pstmt.close();
                

                    //
                    //   Check teecurr2
                    //
                    pstmt = con.prepareStatement (
                       "SELECT mNum1, mNum2, mNum3, mNum4, mNum5, show1, show2, show3, show4, show5 " +
                       "FROM teecurr2 " +
                       "WHERE " +
                            "date <= ? AND date >= ? AND (" +
                            "(mNum1 = ? AND show1 = 1) OR " +
                            "(mNum2 = ? AND show2 = 1) OR " +
                            "(mNum3 = ? AND show3 = 1) OR " +
                            "(mNum4 = ? AND show4 = 1) OR " +
                            "(mNum5 = ? AND show5 = 1))");

                    pstmt.setInt(1, sdate);
                    pstmt.setInt(2, edate);
                    pstmt.setString(3, mnumA[i]);
                    pstmt.setString(4, mnumA[i]);
                    pstmt.setString(5, mnumA[i]);
                    pstmt.setString(6, mnumA[i]);
                    pstmt.setString(7, mnumA[i]);
                    rs = pstmt.executeQuery();      // execute the prepared stmt

                    while (rs.next()) {

                        if (rs.getString("mNum1").equals(mnumA[i]) && rs.getInt("show1") == 1) count++;
                        if (rs.getString("mNum2").equals(mnumA[i]) && rs.getInt("show2") == 1) count++;
                        if (rs.getString("mNum3").equals(mnumA[i]) && rs.getInt("show3") == 1) count++;
                        if (rs.getString("mNum4").equals(mnumA[i]) && rs.getInt("show4") == 1) count++;
                        if (rs.getString("mNum5").equals(mnumA[i]) && rs.getInt("show5") == 1) count++;

                        if (count > max) {                         // if either count puts user over the limit

                            error = true;                          // indicate error
                            //slotParms.player = mnumA[i];           // save member number for error message
                            break loop1;
                        }

                    } // end while of all matching mNum's

                    rs.close();
                    pstmt.close();

                    // if they are about to book their final allowed tee time then send email to pro
                    if (count == 3) {

                        sendEmail.sendMediterraEmail(slotParms.player, mnumA[i]);
                    }

                }   // end if sports mship

            }  // end of FOR loop (do each player)

            //slotParms.rnds = count;     // return the count of rounds to determin if we need to send email to pro

        }
        catch (Exception e) {

            errorMsg = "Error checking for Mediterra guests - verifyCustom.checkMediterraSports: " + e.getMessage();
            verifySlot.logError(errorMsg);        // log the error message
        }
        
    } // end if date in season

    if (!error) slotParms.player = "";
    
    return(error);
   
 }  // end checkMediterraSports
 
 
 public static boolean checkEagleCreekSocial(parmSlot slotParms, Connection con) {
     

    boolean error = false;

    //
    //  break down date of tee time
    //
    int yy = (int)slotParms.date / 10000;       // get year
    int sdate = (yy * 10000) + 1101;            // yyyy1101
    int edate = ((yy + 1) * 10000) + 430;       // yyyy0430

    //
    //  Only check quota if tee time is within the Golf Year
    //
    if (slotParms.date > sdate && slotParms.date < edate) {   
       
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int i = 0;
        int show1 = 0;
        int show2 = 0;
        int show3 = 0;
        int show4 = 0;
        int show5 = 0;
        int time = 0;
        int fb = 0;
        int count_req = 0;
        int count = 0;                               // number of guests for date range
        int max = 6;                                 // max of rounds

        String user = "";
        String player1 = "";
        String player2 = "";
        String player3 = "";
        String player4 = "";
        String player5 = "";
        String errorMsg = "";

        String [] userA = new String [5];            // array to hold the usernames
        String [] playerA = new String [5];          // array to hold the player's names
        String [] mshipA = new String [5];          // array to hold the players' membership types

        playerA[0] = slotParms.player1;
        playerA[1] = slotParms.player2;
        playerA[2] = slotParms.player3;
        playerA[3] = slotParms.player4;
        playerA[4] = slotParms.player5;

        userA[0] = slotParms.user1;
        userA[1] = slotParms.user2;
        userA[2] = slotParms.user3;
        userA[3] = slotParms.user4;
        userA[4] = slotParms.user5;

        mshipA[0] = slotParms.mship1;
        mshipA[1] = slotParms.mship2;
        mshipA[2] = slotParms.mship3;
        mshipA[3] = slotParms.mship4;
        mshipA[4] = slotParms.mship5;


        try {

            //
            //  Check each player
            //
            loop1:
            for (i = 0; i < 5; i++) {

                if (mshipA[i].equals("Social")) {          // if it's a social member

                    slotParms.player = playerA[i];       // save the player name we are currently checking

                    //
                    //   Check teepast2
                    //
                    pstmt = con.prepareStatement (
                       "SELECT COUNT(*) " +
                       "FROM teepast2 " +
                       "WHERE " +
                            "date <= ? AND date >= ? AND (" +
                            "(username1 = ? AND show1 = 1) OR " +
                            "(username2 = ? AND show2 = 1) OR " +
                            "(username3 = ? AND show3 = 1) OR " +
                            "(username4 = ? AND show4 = 1) OR " +
                            "(username5 = ? AND show5 = 1))");

                    pstmt.setInt(1, sdate);
                    pstmt.setInt(2, edate);
                    pstmt.setString(3, userA[i]);
                    pstmt.setString(4, userA[i]);
                    pstmt.setString(5, userA[i]);
                    pstmt.setString(6, userA[i]);
                    pstmt.setString(7, userA[i]);
                    rs = pstmt.executeQuery();      // execute the prepared stmt

                    if (rs.next()) count = count + rs.getInt(1);

                    if (count > max) {                        // if either count puts user over the limit

                        error = true;                          // indicate error
                        break loop1;
                    }

                    rs.close();
                    pstmt.close();
                

                    //
                    //   Check teecurr2
                    //
                    pstmt = con.prepareStatement (
                       "SELECT COUNT(*) " +
                       "FROM teecurr2 " +
                       "WHERE " +
                            "date <= ? AND date >= ? AND (" +
                            "(username1 = ? AND show1 = 1) OR " +
                            "(username2 = ? AND show2 = 1) OR " +
                            "(username3 = ? AND show3 = 1) OR " +
                            "(username4 = ? AND show4 = 1) OR " +
                            "(username5 = ? AND show5 = 1))");

                    pstmt.setInt(1, sdate);
                    pstmt.setInt(2, edate);
                    pstmt.setString(3, userA[i]);
                    pstmt.setString(4, userA[i]);
                    pstmt.setString(5, userA[i]);
                    pstmt.setString(6, userA[i]);
                    pstmt.setString(7, userA[i]);
                    rs = pstmt.executeQuery();      // execute the prepared stmt

                    if (rs.next()) count = count + rs.getInt(1);

                    if (count > max) {                         // if either count puts user over the limit

                        error = true;                          // indicate error
                        break loop1;
                    }

                    rs.close();
                    pstmt.close();

                }   // end if social mship

            }  // end of FOR loop (do each player)

        }
        catch (Exception e) {

            errorMsg = "Error checking for Eagle Creek guests - verifyCustom.checkEagleCreekSocial: " + e.getMessage();
            verifySlot.logError(errorMsg);        // log the error message
        }
        
    } // end if date in season

    if (!error) slotParms.player = "";
    
    return(error);
   
 }  // end checkEagleCreekSocial
 
 
/**
 //************************************************************************
 //
 //  checkPVCCmships - checks certain membership types for max rounds per season.
 //
 //************************************************************************
 **/

 public static boolean checkPVCCmships(parmSlot slotParms, Connection con) {


   Statement stmt = null;
   ResultSet rs = null;

   int count = 0;
   int i = 0;
   int max = 4;               // max of 4 rounds per season
   
   long sdate = 1020;         // season is defined as 10/20 thru 5/31
   long edate = 531;

   String mship = "";         // Membership type to check
   String user = "";
   
   String [] mshipA = new String [5];
   String [] userA = new String [5];
  
   mshipA[0] = slotParms.mship1;
   mshipA[1] = slotParms.mship2;
   mshipA[2] = slotParms.mship3;
   mshipA[3] = slotParms.mship4;
   mshipA[4] = slotParms.mship5;
   userA[0] = slotParms.user1;
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;
   userA[4] = slotParms.user5;

   boolean error = false;
   
   
   long year = slotParms.date / 10000;                       // break down the tee time date
   long month = (slotParms.date - (year * 10000)) / 100;
   long day = slotParms.date - ((year * 10000) + (month * 100));
   long mmdd = (month * 100) + day;                        // create mmdd value

   
   //
   //  Create the start date and end date for queries.
   //  The season is from 10/20 to 5/31, so we must determine which years to use.
   //
   if (mmdd > edate && mmdd < sdate) {         // if out of season
      
      sdate = 0;
      edate = 0;       // out of season - skip checks
      
   } else {
      
      if (month > 9) {         // if fall of the year

         sdate = sdate + (year * 10000);          // start date is 10/20/yyyy (this year)
         edate = edate + ((year + 1) * 10000);    // end date is 5/31/yyyy (next year)

      } else {

         if (month < 6) {         // if start of the year

            sdate = sdate + ((year - 1) * 10000);    // start date is 10/20/yyyy (last year)
            edate = edate + (year * 10000);          // end date is 5/31/yyyy (this year)       
         }
      }
   }

   //
   //  Count the existing tee times if in season and at least one of the members is one of the following mship types:
   //
   //       Proprietary
   //       Spa
   //       Single Spa
   //       Tennis/Spa
   //       Tennis Only
   //       Homeowner
   //
   if (sdate > 0  &&
       (mshipA[0].equals("Proprietary") || mshipA[0].equals("Spa") || mshipA[0].equals("Single Spa") || mshipA[0].equals("Tennis/Spa") || mshipA[0].equals("Tennis Only") || mshipA[0].equals("Homeowner") ||
        mshipA[1].equals("Proprietary") || mshipA[1].equals("Spa") || mshipA[1].equals("Single Spa") || mshipA[1].equals("Tennis/Spa") || mshipA[1].equals("Tennis Only") || mshipA[1].equals("Homeowner") ||
        mshipA[2].equals("Proprietary") || mshipA[2].equals("Spa") || mshipA[2].equals("Single Spa") || mshipA[2].equals("Tennis/Spa") || mshipA[2].equals("Tennis Only") || mshipA[2].equals("Homeowner") ||
        mshipA[3].equals("Proprietary") || mshipA[3].equals("Spa") || mshipA[3].equals("Single Spa") || mshipA[3].equals("Tennis/Spa") || mshipA[3].equals("Tennis Only") || mshipA[3].equals("Homeowner") ||
        mshipA[4].equals("Proprietary") || mshipA[4].equals("Spa") || mshipA[4].equals("Single Spa") || mshipA[4].equals("Tennis/Spa") || mshipA[4].equals("Tennis Only") || mshipA[4].equals("Homeowner"))) {
       
      try {

         //
         // statements for queries
         //
         PreparedStatement pstmt2m = con.prepareStatement (
            "SELECT COUNT(*) " +
            "FROM teecurr2 WHERE date >= ? AND date <= ? AND date != ? AND " +
                       "(username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");

         PreparedStatement pstmt3m = con.prepareStatement (
            "SELECT COUNT(*) " +
            "FROM teepast2 WHERE date >= ? AND date <= ? AND date != ? AND " +
                       "(username1 = ? OR username2 = ? OR username3 = ? OR username4 = ? OR username5 = ?)");


         //
         //  Check each player
         //
         i = 0;
         while (i < 5 && error == false) {
            
            if (mshipA[i].equals("Proprietary") || mshipA[i].equals("Spa") || mshipA[i].equals("Single Spa") || mshipA[i].equals("Tennis/Spa") || mshipA[i].equals("Tennis Only") || mshipA[i].equals("Homeowner")) {

               count = 0;
               
               //
               //  Count the rounds for this member (excluding the day of this tee time)
               //
               pstmt2m.clearParameters();                 
               pstmt2m.setLong(1, sdate);
               pstmt2m.setLong(2, edate);
               pstmt2m.setLong(3, slotParms.date);
               pstmt2m.setString(4, userA[i]);
               pstmt2m.setString(5, userA[i]);
               pstmt2m.setString(6, userA[i]);
               pstmt2m.setString(7, userA[i]);
               pstmt2m.setString(8, userA[i]);
               rs = pstmt2m.executeQuery();

               if (rs.next()) {

                  count = rs.getInt(1);                // get count of tee times from teecurr
               }

               pstmt3m.clearParameters();                    
               pstmt3m.setLong(1, sdate);
               pstmt3m.setLong(2, edate);
               pstmt3m.setLong(3, slotParms.date);
               pstmt3m.setString(4, userA[i]);
               pstmt3m.setString(5, userA[i]);
               pstmt3m.setString(6, userA[i]);
               pstmt3m.setString(7, userA[i]);
               pstmt3m.setString(8, userA[i]);
               rs = pstmt3m.executeQuery();

               if (rs.next()) {

                  count += rs.getInt(1);                // add number of tee times from teepast
               }


               if (count >= max)  {               // if limit already reached

                  error = true;                   // reject this member
                  slotParms.mship = mship;
                  slotParms.player = slotParms.player1;
               }
            }        // end of IF player is mship to check
            
            i++;     // do next player
                    
         }          // end of WHILE player

         pstmt2m.close();
         pstmt3m.close();

      }
      catch (SQLException e1) {

         logError("SQL Error Checking Max Rounds - verifySlot.checkPVCCmships " + e1.getMessage());        // log the error message
      }

      catch (Exception e) {

         logError("Exception Checking Max Rounds - verifySlot.checkPVCCmships " + e.getMessage());        // log the error message
      }
   
   }       // end of if date in season

   return(error);
 }                  // end of checkPVCCmahips



/**
 //************************************************************************
 //
 //  checkJLGCmships - checks certain membership types for max rounds per month during the season.
 //
 //************************************************************************
 **/

 public static boolean checkJLGCmships(parmSlot slotParms, Connection con) {


   Statement stmt = null;
   ResultSet rs = null;


   boolean error = false;
   
   int count = 0;
   int i = 0;
   int i2 = 0;
   int max = 8;               // max rounds per season
   
   long sdate = 1101;         // season is defined as 11/01 thru 4/30
   long edate = 430;

   String mship = "";         // Membership type to check
   String user = "";
   String mNum1 = "";
   String mNum2 = "";
   String mNum3 = "";
   String mNum4 = "";
   String mNum5 = "";
   
   String [] mshipA = new String [5];
   String [] mnumA = new String [5];
  
   mshipA[0] = slotParms.mship1;
   mshipA[1] = slotParms.mship2;
   mshipA[2] = slotParms.mship3;
   mshipA[3] = slotParms.mship4;
   mshipA[4] = slotParms.mship5;
   mnumA[0] = slotParms.mNum1;
   mnumA[1] = slotParms.mNum2;
   mnumA[2] = slotParms.mNum3;
   mnumA[3] = slotParms.mNum4;
   mnumA[4] = slotParms.mNum5;


   //
   //  Remove any duplicate family members - only check one user for the family
   //
   if (!mnumA[0].equals( "" )) {        // if mnum exists
     
      if (mnumA[1].equals( mnumA[0] )) {        // if mnum is the same

         mshipA[1] = "";
      }
      if (mnumA[2].equals( mnumA[0] )) {        // if mnum is the same

         mshipA[2] = "";
      }
      if (mnumA[3].equals( mnumA[0] )) {        // if mnum is the same

         mshipA[3] = "";
      }
      if (mnumA[4].equals( mnumA[0] )) {        // if mnum is the same

         mshipA[4] = "";
      }
   }
     
   if (!mnumA[1].equals( "" )) {        // if mnum exists

      if (mnumA[2].equals( mnumA[1] )) {        // if mnum is the same

         mshipA[2] = "";
      }
      if (mnumA[3].equals( mnumA[1] )) {        // if mnum is the same

         mshipA[3] = "";
      }
      if (mnumA[4].equals( mnumA[1] )) {        // if mnum is the same

         mshipA[4] = "";
      }
   }

   if (!mnumA[2].equals( "" )) {        // if mnum exists

      if (mnumA[3].equals( mnumA[2] )) {        // if mnum is the same

         mshipA[3] = "";
      }
      if (mnumA[4].equals( mnumA[2] )) {        // if mnum is the same

         mshipA[4] = "";
      }
   }

   if (!mnumA[3].equals( "" )) {        // if mnum exists

      if (mnumA[4].equals( mnumA[3] )) {        // if mnum is the same

         mshipA[4] = "";
      }
   }

  
   
   long year = slotParms.date / 10000;                       // break down the tee time date
   long month = (slotParms.date - (year * 10000)) / 100;
   long day = slotParms.date - ((year * 10000) + (month * 100));
   long mmdd = (month * 100) + day;                        // create mmdd value

   
   //
   //  Create the start date and end date for queries.
   //  The season is from 11/01 to 4/30, so we must determine which years to use.
   //
   if (mmdd > edate && mmdd < sdate) {         // if out of season
      
      sdate = 0;
      edate = 0;       // out of season - skip checks
      
   } else {
      
      sdate = (year * 10000) + (month * 100) + 01;         // mm/01/yyyy -  we will check for max rounds per month
      edate = (year * 10000) + (month * 100) + 31;         // mm/31/yyyy
   }

   //
   //  Count the existing tee times if in season and at least one of the members is one of the following mship types:
   //
   //       Renter Sports
   //       Sports
   //
   if (sdate > 0  &&
       (mshipA[0].equals("Renter Sports") || mshipA[0].equals("Sports") ||
        mshipA[1].equals("Renter Sports") || mshipA[1].equals("Sports") || 
        mshipA[2].equals("Renter Sports") || mshipA[2].equals("Sports") || 
        mshipA[3].equals("Renter Sports") || mshipA[3].equals("Sports") || 
        mshipA[4].equals("Renter Sports") || mshipA[4].equals("Sports"))) {
       
      try {

         //
         // statements for queries
         //
         PreparedStatement pstmt2m = con.prepareStatement (
            "SELECT mNum1, mNum2, mNum3, mNum4, mNum5 " +
            "FROM teecurr2 WHERE date >= ? AND date <= ? AND (date != ? AND courseName != ?) AND " +
                       "(mNum1 = ? OR mNum2 = ? OR mNum3 = ? OR mNum4 = ? OR mNum5 = ?)");

         PreparedStatement pstmt3m = con.prepareStatement (
            "SELECT mNum1, mNum2, mNum3, mNum4, mNum5 " +
            "FROM teepast2 WHERE date >= ? AND date <= ? AND (date != ? AND courseName != ?) AND " +
                       "(mNum1 = ? OR mNum2 = ? OR mNum3 = ? OR mNum4 = ? OR mNum5 = ?)");


         //
         //  Check each player/family
         //
         i = 0;
         while (i < 5 && error == false) {
            
            if (mshipA[i].equals("Renter Sports") || mshipA[i].equals("Sports")) {
               
               count = 1;         // count this member
               
               //
               //  Count number of family members in this tee time
               //
               i2 = i + 1;        // next player
                  
               while (i2 < 5) {
               
                  if (mnumA[i].equals(mnumA[i2])) {
                     
                     count++;              // add family member
                  }
                  i2++;
               }

               //
               //  Count the rounds for this member (excluding the day of this tee time)
               //
               pstmt2m.clearParameters();                  
               pstmt2m.setLong(1, sdate);
               pstmt2m.setLong(2, edate);
               pstmt2m.setLong(3, slotParms.date);      // make sure not this date
               pstmt2m.setString(4, slotParms.course);      // and course
               pstmt2m.setString(5, mnumA[i]);
               pstmt2m.setString(6, mnumA[i]);
               pstmt2m.setString(7, mnumA[i]);
               pstmt2m.setString(8, mnumA[i]);
               pstmt2m.setString(9, mnumA[i]);
               rs = pstmt2m.executeQuery();

               while (rs.next()) {

                   mNum1 = rs.getString("mNum1");
                   mNum2 = rs.getString("mNum2");
                   mNum3 = rs.getString("mNum3");
                   mNum4 = rs.getString("mNum4");
                   mNum5 = rs.getString("mNum5");
                 
                  if (mnumA[i].equals(mNum1)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum2)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum3)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum4)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum5)) {
                     count++;              // add family member
                  }
               }

               pstmt3m.clearParameters();                    
               pstmt3m.setLong(1, sdate);
               pstmt3m.setLong(2, edate);
               pstmt3m.setLong(3, slotParms.date);
               pstmt2m.setString(4, slotParms.course);      // and course
               pstmt3m.setString(5, mnumA[i]);
               pstmt3m.setString(6, mnumA[i]);
               pstmt3m.setString(7, mnumA[i]);
               pstmt3m.setString(8, mnumA[i]);
               pstmt3m.setString(9, mnumA[i]);
               rs = pstmt3m.executeQuery();

               while (rs.next()) {

                   mNum1 = rs.getString("mNum1");
                   mNum2 = rs.getString("mNum2");
                   mNum3 = rs.getString("mNum3");
                   mNum4 = rs.getString("mNum4");
                   mNum5 = rs.getString("mNum5");
                 
                  if (mnumA[i].equals(mNum1)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum2)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum3)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum4)) {
                     count++;              // add family member
                  }
                  if (mnumA[i].equals(mNum5)) {
                     count++;              // add family member
                  }                  
               }


               if (count > max)  {                // if this time would put the family over the max

                  error = true;                   // reject this member
                  slotParms.mship = mship;
                  slotParms.player = slotParms.player1;
               }
            }        // end of IF player is mship to check
            
            i++;     // do next player
                    
         }          // end of WHILE player

         pstmt2m.close();
         pstmt3m.close();

      }
      catch (SQLException e1) {

         logError("SQL Error Checking Max Rounds - verifySlot.checkJLGCmships " + e1.getMessage());        // log the error message
      }

      catch (Exception e) {

         logError("Exception Checking Max Rounds - verifySlot.checkJLGCmships " + e.getMessage());        // log the error message
      }
   
   }       // end of if date in season

   return(error);
 }                  // end of checkJLGCmahips



/**
 //************************************************************************
 //
 //  checkOakmontGuestQuota - special Guest processing for Oakmont CC.
 //
 //     At this point we know this is Oakmont, there is more than one guest
 //     in this tee time and it is Feb, Mar or Apr.
 //
 //     Restrictions:
 //
 //         Members can book guest times in advance (all year), however they   
 //         can only book up to 10 per month during Feb, Mar and Apr.  The guest times
 //         can be for any time of the season, we only check when the time was booked. 
 //         Therefore, we must track when the tee time was actually created.
 //
 //      Note:  5-somes not allowed at Oakmont
 //
 //      **** See also Proshop_slotm.checkOakGuestQuota ************************
 //
 //************************************************************************
 **/

 public static boolean checkOakmontGuestQuota(parmSlot slotParms, int month, Connection con) {


   PreparedStatement pstmt = null;
   ResultSet rs = null;

   boolean error = false;

   String errorMsg = "";
   
   int i = 0;
   int i2 = 0;
   int count = 0;
   int max = 9;                             // max is 10 advance guest times per month - use > 9 for compare

   String [] usergA = new String [4];       // array to hold the members' usernames
   String [] userA = new String [4];        // array to hold the usernames
   String [] playerA = new String [4];      // array to hold the player names

   userA[0] = slotParms.user1;              // get values from this request
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;

   usergA[0] = slotParms.userg1;                
   usergA[1] = slotParms.userg2;
   usergA[2] = slotParms.userg3;
   usergA[3] = slotParms.userg4;

   playerA[0] = slotParms.player1;                
   playerA[1] = slotParms.player2;                
   playerA[2] = slotParms.player3;                
   playerA[3] = slotParms.player4;                


   try {

      //
      //  Check each player for member followed by guest
      //
      for (i = 0; i < 3; i++) {             // check first 3 players (no 5-somes at Oakmont, if 4th not guest then doesn't matter)
         
         i2 = i + 1;

         if (error == false) {              // if error not already hit
  
            if (!userA[i].equals( "" ) && userA[i].equals( usergA[i2] )) {       // if player followed by his/her guest
               
               count = 0;
        
               //
               //   Check teecurr for other guest times for this member that were scheduled during this month
               //
               pstmt = con.prepareStatement (
                  "SELECT COUNT(*) " +
                  "FROM teecurr2 " +
                  "WHERE custom_int = ? AND " +
                  "(userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ?)");

               pstmt.clearParameters();
               pstmt.setInt(1, month);
               pstmt.setString(2, userA[i]);
               pstmt.setString(3, userA[i]);
               pstmt.setString(4, userA[i]);
               pstmt.setString(5, userA[i]);
               rs = pstmt.executeQuery();

               if (rs.next()) {

                  count = rs.getInt("COUNT(*)");
               }    

               pstmt.close();


               if (count > max) {                         // if 10 advance guest times already created this month

                  error = true;                           // indicate error
                  slotParms.player = playerA[i];          // save player name for error message
               }           
            }
         }
      }              // end of FOR loop (do each player)
        
   }
   catch (Exception e) {

      errorMsg = "Error checking for Oakmont guests - verifyCustom.checkOakmontGuestQuota " + e.getMessage();
      logError(errorMsg);        // log the error message
   }
   
   return(error);
 }


/**
 //************************************************************************
 //
 //  checkBaltusrolGuestQuota - special Guest processing for Baltusrol GC.
 //
 //     At this point we know this is baltusrol and there is more than one guest
 //     in this tee time.
 //
 //     Restrictions:
 //
 //         Members can have up to 3 guest times scheduled in advance.  
 //
 //      Note:  5-somes not allowed at Baltusrol
 //
 //      **** See also Proshop_slotm.checkBaltGuestQuota ************************
 //
 //************************************************************************
 **/

 public static boolean checkBaltusrolGuestQuota(parmSlot slotParms, Connection con) {


   PreparedStatement pstmt = null;
   ResultSet rs = null;

   boolean error = false;

   String errorMsg = "";
   
   int i = 0;
   int i2 = 0;
   int count = 0;
   int max = 2;                             // max is 3 advance guest times (use 2 to allow for this one) 

   String [] usergA = new String [4];       // array to hold the members' usernames
   String [] userA = new String [4];        // array to hold the usernames
   String [] playerA = new String [4];      // array to hold the player names

   userA[0] = slotParms.user1;              // get values from this request
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;

   usergA[0] = slotParms.userg1;                
   usergA[1] = slotParms.userg2;
   usergA[2] = slotParms.userg3;
   usergA[3] = slotParms.userg4;

   playerA[0] = slotParms.player1;                
   playerA[1] = slotParms.player2;                
   playerA[2] = slotParms.player3;                
   playerA[3] = slotParms.player4;                


   try {

      //
      //  Check each player for member followed by guest
      //
      for (i = 0; i < 3; i++) {             // check first 3 players (no 5-somes, if 4th not guest then doesn't matter)
         
         i2 = i + 1;

         if (error == false) {              // if error not already hit
  
            if (!userA[i].equals( "" ) && userA[i].equals( usergA[i2] )) {       // if player followed by his/her guest
               
               count = 0;
        
               //
               //   Check teecurr for other guest times for this member that are scheduled 
               //
               pstmt = con.prepareStatement (
                  "SELECT COUNT(*) " +
                  "FROM teecurr2 " +
                  "WHERE teecurr_id != ? AND (userg1 = ? OR userg2 = ? OR userg3 = ? OR userg4 = ?)");

               pstmt.clearParameters();
               pstmt.setInt(1, slotParms.teecurr_id);    // do not include this one!
               pstmt.setString(2, userA[i]);
               pstmt.setString(3, userA[i]);
               pstmt.setString(4, userA[i]);
               pstmt.setString(5, userA[i]);
               rs = pstmt.executeQuery();

               if (rs.next()) {

                  count = rs.getInt("COUNT(*)");
               }    

               pstmt.close();


               if (count > max) {                         // if 3 advance guest times already exist for this member

                  error = true;                           // indicate error
                  slotParms.player = playerA[i];          // save player name for error message
               }           
            }
         }
      }              // end of FOR loop (do each player)
        
   }
   catch (Exception e) {

      errorMsg = "Error checking for Baltusrol guests - verifyCustom.checkBaltusrolGuestQuota " + e.getMessage();
      logError(errorMsg);        // log the error message
   }
   
   return(error);
 }


 // *********************************************************
 //  Rivercrest - Custom Processing (check date and time of day for 3-some only time)
 // *********************************************************

 public static boolean checkRivercrest(long date, int time, String name) {


   boolean status = false;

   long shortDate = date - ((date / 10000) * 10000);       // get mmdd (i.e.  20060512 - 20060000 = 512)

   //
   //     Special 3-some times (for women) on Thurs between mid April and mid Sept
   //
   //
   if (name.equals( "Thursday" ) && shortDate > 403 && shortDate < 919) {      

      if (date != 20080626 && date != 20080717 && date != 20080828 && date != 20080904 && date != 20080911) {   // skip event days in 2008

         if (time > 829 && time < 1031) {  // if 8:30 - 10:30

            status = true;                        // 3-some only time
         }
      }
   }

   return(status);         // true = 3-somes only time
 }


 // *********************************************************
 //  Rivercrest - Custom Processing (check date for 3-some only times)
 // *********************************************************

 public static boolean checkRivercrestDay(long date, String name) {


   boolean status = false;

   long shortDate = date - ((date / 10000) * 10000);     

   //
   //     Special 3-some days (for women) on Thurs between mid April and mid Sept - do not allow consecutive tee times before or during their times
   //
   //
   if (name.equals( "Thursday" ) && shortDate > 403 && shortDate < 919) {      

      if (date != 20080626 && date != 20080717 && date != 20080828 && date != 20080904 && date != 20080911) {   // skip event days in 2008

         status = true;                        // 3-some only day
      }
   }

   return(status);         // true = 3-somes only day
 }


 // *********************************************************
 //  Portland GC - Custom Processing (check tee time for Walk-Up only time)
 // *********************************************************

 public static boolean checkPGCwalkup(long date, int time, String day) {


   boolean status = false;

   long shortDate = date - ((date / 10000) * 10000);   
   
   int stime = 0;
   int etime = 0;
   int min = 0;
   

   
   //  
   //   get minute value of tee time
   //
   min = time/100;                // get hour vallue
   min = time - (min * 100);      // get minute value

   //
   //    Check if tee time is for Walk-Ups Only
   //
   if (day.equals( "Friday" )) {      

      stime = 930;          // 9:30 AM
      etime = 1930;         // to 7:30 PM
      
   } else {
      
      stime = 630;          // 6:30 AM
      etime = 1930;         // to 7:30 PM      
   }

   //
   //  Check times within the range for Walk-Up Only
   //
   if (time >= stime && time <= etime) {
      
      if (day.equals("Tuesday") && shortDate > 331 && shortDate < 1101 && time > 759 && time < 1001) {  // exception for Ladies Day
         
         status = false;
         
      } else {
         
         //
         //  Tee Times = 700, 707, 715, 722, 730, 737, 745, 752, 800, etc.  -  every other is a walk up
         //
         if (min == 7 || min == 22 || min == 37 || min == 52) {    

            status = true;      // indicate walk-up time
         }
      }
   }
   
   return(status);         // true = Walk-Up Only time
 }


 // ******************************************************************************
 //  Los Coyotes - Get a member's Gender and appeand to the Member Number
 // ******************************************************************************

 public static String getLCGender(String user, String mnum, Connection con) {


   ResultSet rs = null;

   String mtype = "";
   String gender = "";


   try {

      if (!user.equals( "" )) {

         PreparedStatement pstmte1 = con.prepareStatement (
                  "SELECT m_type FROM member2b WHERE username = ?");

         pstmte1.clearParameters();        // clear the parms
         pstmte1.setString(1, user);
         rs = pstmte1.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            mtype = rs.getString(1);         // user's member type
         }

         pstmte1.close();                  // close the stmt
           
         //
         //  Add Primary/Secondary/Junior and gender to mnum
         //
         if (mtype.startsWith( "Primary" )) {
           
            mnum = mnum + " P";            // Primary
              
         } else {
           
            if (mtype.startsWith( "Secondary" )) {

               mnum = mnum + " S";            // Secondary

            } else {

               mnum = mnum + " J";            // Junior
            }
         }
           
         if (mtype.endsWith( "Female" ) || mtype.endsWith( "Ladies" )) {
           
            mnum = mnum + "F";            // Female
              
         } else {
           
            mnum = mnum + "M";            // Male
         }
           
      }

   }
   catch (Exception ignore) {
   }

   return(mnum);

 }                   // end of getLCGender


/**
 //************************************************************************
 //
 //   removeHist (Tamarack) - remove lottery history if member deleted  
 //                           from tee time.
 //
 //
 //   called by:  Member_slot & Proshop_slot
 //
 //************************************************************************
 **/

 public static void removeHist(parmSlot slotParms, Connection con) {


   PreparedStatement stmt = null;

   int i = 0;

   String [] userA = new String [5];           // array to hold the usernames
   String [] olduserA = new String [5];        // array to hold the old usernames

   userA[0] = slotParms.user1;                 // get the new users
   userA[1] = slotParms.user2;
   userA[2] = slotParms.user3;
   userA[3] = slotParms.user4;
   userA[4] = slotParms.user4;

   olduserA[0] = slotParms.oldUser1;           // get the old users
   olduserA[1] = slotParms.oldUser2;
   olduserA[2] = slotParms.oldUser3;
   olduserA[3] = slotParms.oldUser4;
   olduserA[4] = slotParms.oldUser4;


   try {

      for (i = 0; i < 5; i++) {          // check each player    
         
         // check if member no longer part of tee time
         
         if (!olduserA[i].equals( "" ) && !olduserA[i].equals( userA[0] ) && !olduserA[i].equals( userA[1] ) && 
             !olduserA[i].equals( userA[2] ) && !olduserA[i].equals( userA[3] ) && !olduserA[i].equals( userA[4] )) {       
               
            //
            //  A member has been removed from the tee time - remove any lottery history (weights) for this member
            //                                                on this date (assuming the lottery history was for this time).
            //
            stmt = con.prepareStatement (
                     "Delete FROM lassigns5 WHERE username = ? AND date = ?");

            stmt.clearParameters();             
            stmt.setString(1, olduserA[i]);             
            stmt.setLong(2, slotParms.date);
            stmt.executeUpdate();        

            stmt.close();
         }
      }              // end of FOR loop (do each player)
        
   }
   catch (Exception e) {

      logError("Error in verifyCustom.removeHist " + e.getMessage());        // log the error message
   }
   
 }


 //************************************************************************
 //
 //  logError - logs system error messages to a text file
 //
 //************************************************************************

 public static void logError(String msg) {


   Connection con = null;
   String club = rev;                       // get db name to use for 'clubs' table

   //
   //   Get current month
   //
   Calendar cal = new GregorianCalendar();                      // get todays date
   int year = cal.get(Calendar.YEAR);
   int month = cal.get(Calendar.MONTH) +1;
   int daynum = cal.get(Calendar.DAY_OF_MONTH);

   long date = (year * 10000) + (month * 100) + daynum;         // date value for today

   String sdate = String.valueOf(new java.util.Date());         // get date and time string

   try {

      con = Connect.getCon(club);                       // get a connection to Vx db

      if (con != null) {                         // if we got one

         Statement stmt = con.createStatement();        // create a statement
/*
         stmt.executeUpdate("CREATE TABLE IF NOT EXISTS errorlog(" +
                            "date bigint, sdate varchar(36), msg text, " +
                            "index ind1 (date))");

         stmt.close();
*/
         //
         //  Save the session message in the db table
         //
         PreparedStatement pstmt = con.prepareStatement (
              "INSERT INTO errorlog (id, err_timestamp, date, sdate, msg) " +
              "VALUES (null,now(),?,?,?)");

         pstmt.clearParameters();
         pstmt.setLong(1, date);
         pstmt.setString(2, sdate);
         pstmt.setString(3, msg);
         pstmt.executeUpdate();

         pstmt.close();

         con.close();
      }

   }
   catch (Exception ignore) {
   }

 }  // end of logError


}  // end of verifyCustom class

