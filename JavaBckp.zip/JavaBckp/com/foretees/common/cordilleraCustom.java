/**************************************************************************************************************
 *   cordilleraCustom:  This will provide the common methods for processing custom requests for Cordillera CC.
 *
 *       called by:  Hotel_sheet
 *                   Member_sheet
 *
 *
 *   created:  2/01/2006   Bob P.
 *
 *
 *   last updated:
 *
 *             6/26/08 Change 7/24 from 2-4-1 to 1-4-2 for an event.
 *             5/03/08 Custom times for 6/17.
 *             3/04/08 Adjust times for 2008.
 *             1/25/07 Corrected times for .
 *             1/09/07 Adjusted times for  per Penti's request.
 *             2/28/06 Adjusted times on 6/25 and 7/28 per Penti's request.
 *
 **************************************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class cordilleraCustom {


/**
 // *********************************************************
 //  Check for custom hotel guest restrictions for Cordillera
 // *********************************************************
 **/

 public static boolean checkCordillera(long date, int time, String course, String caller) {



   boolean allow = true;        // default return status to 'ok'
   boolean hit = false;

   int stime = 1059;      // earliest time to check
   int etime = 1451;      // latest time to check

   int stime1 = 1059;     // 11:00 - 2:50    (time range 1)    TIMES AVAILABLE FOR MEMBERS!!!!
   int etime1 = 1451;

   int stime2 = 1429;     // 2:30 - 2:50     (time range 2)
   int etime2 = 1451;

   int stime3 = 1329;     // 1:30 - 2:50     (time range 3)
   int etime3 = 1451;

   int stime4 = 1329;     // 1:30 - 1:50     (time range 4)
   int etime4 = 1351;

   int stime5 = 1059;     // 11:00 - 2:10    (time range 5)
   int etime5 = 1411;

   int stime6 = 1329;     // 1:30 - 1:40     (time range 6)
   int etime6 = 1341;

   int stime7 = 1409;     // 2:10 - 2:50     (time range 7)
   int etime7 = 1451;

   int mstime = 1200;     // 12:00 - 1:30    (Member Times - ok for members, not for hotel guests)
   int metime = 1329;

   //
   //  Patterns (a, b, c)  where:
   //
   //        course:   Mountain        Valley         Summit
   //                  --------        ------         ------
   //
   //    time range:      a              b              c
   //
   //
   //  Process:  If the requested tee time is between 11:00 and 3:00, then check for the
   //            above listed restricted times based on the course and date.  If a match is
   //            found, then allow or disallow the request based on the user (hotel or member).
   //            These times are restricted for hotel guests and the other times in this time
   //            frame are ok.  These times are ok for members, but the other times in this time
   //            frame are restricted for members.           
   //
   //         1.  Only check times between 11:00 AM and 3:00 PM each day (and never on the Short Course).
   //         2.  Check if time is a Member Only Time (based on course, dates and times in spreadsheet).
   //         3.  If time is a Member Only Time, then do not allow Hotel Guests
   //         4.  If time is NOT a Member Only Time and it is between 12:00 & 2:50 PM, then DO NOT allow members.
   //
   //****************************************************************************************************************
   //  NOTE:  The blacked out times in the spreadsheet are 'For Members Only'.  The other times are 'Lodge Times'!!!
   //         hit = true is set if the time falls in the blacked out range.
   //****************************************************************************************************************
   //
   //
   //********************************************************************************************************************
   //

   //
   //   Create mmdd date
   //
   date = date - ((date / 10000) * 10000);                   // get mmdd (i.e.  20060512 - 20060000 = 512)

   //
   //  Only check if the tee time is between 11:00 and 3:00 and in this year's date range (change anually!!!!!)
   //
   if (date > 417 && date < 1029 && time > stime && time < etime && !course.equals( "Short" )) {   

      //
      //  Check if requested tee time is restricted for hotel guests - based on date, time and course
      //
      if (date == 1027 || date == 1028) {

         //
         //     Pattern = 1-1-1
         //
         if (course.equals( "Mountain" ) || course.equals( "Valley" ) || course.equals( "Summit" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }
         }
      }

      if (date == 717) {

         //
         //     Pattern = 1-1-2
         //
         if (course.equals( "Mountain" ) || course.equals( "Valley" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Summit" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if ((date > 417 && date < 523) || date == 719 ||
          (date > 1012 && date < 1027)) {  

         //
         //     Pattern = 1-2-1
         //
         if (course.equals( "Mountain" ) || course.equals( "Summit" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 915 || date == 917 || date == 919) {

         //
         //     Pattern = 1-2-3
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime3 && time < etime3) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 829) {

         //
         //     Pattern = 1-2-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 828 || date == 907 || date == 916 || date == 918) { 

         //
         //     Pattern = 1-3-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 608 || date == 609 || date == 611 || date == 615 || date == 619 ||
          date == 625 || date == 629 || date == 629 || date == 702 || date == 706 ||
          date == 709 || date == 710 || date == 713 || date == 716 || date == 720 ||
          date == 723 || date == 724 || date == 727 || date == 730 || date == 731 || date == 803 ||
          date == 806 || date == 808 || date == 810 || date == 813 || date == 817 ||
          date == 821 || date == 824 || date == 827 || date == 903 || date == 914 ||
          date == 924 || date == 928) {

         //
         //     Pattern = 1-4-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime4 && time < etime4) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
                    
            } else {

               if (course.equals( "Summit" )) {

                  if ((time > stime2 && time < etime2)) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 613) {

         //
         //     Pattern = 1-5-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime1 && time < etime1) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime5 && time < etime5) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 718) {            

         //
         //     Pattern = 2-1-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) || course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }

      if (date == 816 || date == 818 || date == 823 || date == 908 || date == 910 ||
          date == 912) {

         //
         //     Pattern = 2-1-3
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime3 && time < etime3) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 606 || date == 616 || date == 620 || date == 623 || date == 626 || 
          date == 627 || date == 630 || date == 704 || date == 707 ||
          date == 711 || date == 714 || date == 721 || date == 725 || date == 728 ||
          date == 804 || date == 811 || date == 820 || date == 831 ||
          date == 825 || date == 901 || date == 905 || date == 922 || date == 926) {

         //
         //     Pattern = 2-1-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                                // indicate we hit a restricted time
            }
                 
         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                                // indicate we hit a restricted time
               }

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                                // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      /*
      if (date == ) {

         //
         //     Pattern = 2-2-1
         //
         if (course.equals( "Mountain" ) || course.equals( "Valley" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }
       */
      

      if (date == 523 || date == 525 || date == 527 || 
          date == 529 || date == 531 || date == 601 || date == 603 ||
          date == 822 || date == 930 || date == 1001 || date == 1003 || date == 1005 ||
          date == 1007 || date == 1009 || date == 1011) {

         //
         //     Pattern = 2-3-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime3 && time < etime3) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 906 || date == 920 || date == 927) {

         //
         //     Pattern = 2-4-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime2 && time < etime2) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime4 && time < etime4) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 909 || date == 911) {

         //
         //     Pattern = 3-1-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      
      /*
      if (date == ) {    

         //
         //     Pattern = 3-1-3
         //
         if (course.equals( "Mountain" ) || course.equals( "Summit" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }
       */
      

      if (date == 524 || date == 526 || date == 528 || date == 530 || date == 602 || date == 604 || date == 809 ||
          date == 929 || date == 1002 || date == 1004 || date == 1006 || date == 1008 || date == 1010 || date == 1012) {

         //
         //     Pattern = 3-2-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime3 && time < etime3) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      /*
      if (date == ) {

         //
         //     Pattern = 4-1-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" ) || course.equals( "Summit" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }
            }
         }
      }
       */
      

      if (date == 801 || date == 807 || date == 815) {   

         //
         //     Pattern = 4-1-2
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime2 && time < etime2) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 605 || date == 607 || date == 610 || date == 614 ||
          date == 618 || date == 621 || date == 622 || date == 624 || date == 628 ||
          date == 701 || date == 703 || date == 705 || date == 708 || date == 712 ||
          date == 715 || date == 722 || date == 726 || date == 802 || date == 805 ||
          date == 812 || date == 814 || date == 819 || date == 826 || date == 830 ||
          date == 902 || date == 904 || date == 913 || date == 921 || date == 923 || date == 925) {

         //
         //     Pattern = 4-2-1
         //
         if (course.equals( "Mountain" )) {

            if (time > stime4 && time < etime4) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime1 && time < etime1) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 617) {          // custom for this one!!

         //
         //     Pattern = custom
         //
         if (course.equals( "Mountain" )) {

            if (time > 1329 && time < 1421) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime2 && time < etime2) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if ((time > stime2 && time < etime2) || (time > 1059 && time < 1351)) {   // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }

      if (date == 612) {

         //
         //     Pattern = 5-1-4
         //
         if (course.equals( "Mountain" )) {

            if (time > stime5 && time < etime5) {         // if restricted time

               hit = true;                             // indicate we hit a restricted time
            }

         } else {

            if (course.equals( "Valley" )) {

               if (time > stime1 && time < etime1) {         // if restricted time

                  hit = true;                             // indicate we hit a restricted time
               }

            } else {

               if (course.equals( "Summit" )) {

                  if (time > stime4 && time < etime4) {         // if restricted time

                     hit = true;                             // indicate we hit a restricted time
                  }
               }
            }
         }
      }


      //
      //  Now process the request according to the caller; hotel or member
      //
      //      Member:  if we hit on a time, then member is ok, else they might be restricted
      //
      //      Hotel:   if we hit on a time, then hotel guests are restricted, else they are ok
      //
      allow = true;                // default to ok
        
      if (caller.equals( "hotel" )) {
        
         if (hit == true) {        // if this is a 'Member Only' time
           
            allow = false;         // hotel guests are restricted
         }
           
      } else {                    // member
        
         if (hit == false) {                           // if NOT a 'Member Only' time

            if (time < mstime || time > metime) {      // if a 'Lodge Time' (noon - 2:50)
              
               allow = false;                          // members are restricted
            }
         }
      }

   }           // end of IF within time frame (11:00 - 3:00)

   return(allow);

 }  // end of checkCordillera

}  // end of cordilleraCustom class

