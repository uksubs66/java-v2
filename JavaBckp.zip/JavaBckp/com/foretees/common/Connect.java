/***************************************************************************************
 *   Connect:  This servlet will connect to the Vx database for error logs.
 *
 *       called by:  verifySlot
 *
 *
 *   created:  3/07/2006   Bob P.
 *
 *
 *   last updated:
 *
 *        8/15/08  Change from synchronized to not.
 *
 ***************************************************************************************
 */


package com.foretees.common;

import java.io.*;
import java.util.*;
import java.sql.*;


public class Connect {

   private static String rev = ProcessConstants.REV;


/**
 //************************************************************************
 //
 //  Get the connection     -    see also SystemUtils !!!!!!!!!!!!!!!!!
 //
 //************************************************************************
 **/

// public synchronized static Connection getCon(String club) {
 public static Connection getCon(String club) {

   String user = "bobp";
   String password = "rdp0805";

   //
   // ***********************************************************************
   //
   //  Change this url based on which server it is. !!!!!!!!!!!!!!!!!!!!!!!
   //
   //      see also verifySlot !!!!!!!!!!!!!
   //
   // ***********************************************************************
   //
   String url = "jdbc:mysql://localhost/" + club;        // use this on the DB Server and Local PC
   //String url = "jdbc:mysql://192.168.0.48/" + club;           // use this on the development cluster/workstation

   //String url = "jdbc:mysql://10.0.0.10/" + club;           // PRIVATE INTERFACE TO DB
   //String url = "jdbc:mysql://216.243.184.85/" + club;    // PUBLIC INTERFACE TO DB


   Connection con = null;

   try {

      // Load the JDBC Driver

      // The newinstance() call is a work around for some Java implementations.

      //Class.forName("org.gjt.mm.mysql.Driver").newInstance();
      Class.forName("com.mysql.jdbc.Driver").newInstance();

      // Connect to the DB.........

      con = DriverManager.getConnection(url, user, password);

   }
   catch (Exception e1) {
   }

   return(con);
 }

}  // end of Connect class

