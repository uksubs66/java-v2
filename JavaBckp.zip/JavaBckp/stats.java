/***************************************************************************************
 *   Class file:    stats
 *
 *
 *   Called by:     called directly
 *
 *
 *   Created:       4/17/08 by Brad
 *
 *
 *   Last Updated:  4/17/08
 *
 *                  
 *                  
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import java.net.*;
import java.text.*;


public class stats extends HttpServlet {

    String rev = SystemUtils.REVLEVEL; 
 
    
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        GregorianCalendar cal = new GregorianCalendar();
        DateFormat df_date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
        String display_date = df_date.format(cal.getTime());
        
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<html>");
        out.println("<head>");
        out.println(" <meta http-equiv=\"refresh\" content=\"120\">");
        out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">");
        out.println(" <meta http-equiv=\"Content-Language\" content=\"en-us\">");
        out.println("<title>Application Statistics</title>");
        out.println("</head>");
        out.println("<body bgcolor=white>");
        out.println("<font size=4><u>Application Statistics</u></font><br/>");

        out.println("<font size=2>Node " + Common_Server.SERVER_ID + " reporting<br/>" + display_date + "</font></p>");
        
        
        // Display Master Database Stats
        out.println("<font size=4><u>Master Database Statistics</u></font><br/>");
        displayMasterDBStats(out);
        out.println("<br/><br/>");
        
        // Display Slave Database Stats
        out.println("<font size=4><u>Slave Database Statistics</u></font><br/>");
        displaySlaveDBStats(out);
        out.println("<br/><br/>");
        
        // Display Login Stats
        out.println("<font size=4><u>Login Statistics</u></font><br/>");
        displayLoginStats(req, out);
        out.println("<br/><br/>");
        
        // Display Bounced Count
        out.println("<font size=4><u>Emails</u></font><br/>");
        displayBouncedCount(req, out);
        out.println("<br/><br/>");
                
        out.println("</body></html>");
        out.close();
    }   // end of doGet method
       
    
    private void displayMasterDBStats(PrintWriter out){
        
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        int max_connections = 0;
        int threads_connected = 0;
        int questions = 0;
        int uptime = 0;
        long bytes_in = 0;
        double bytes_out = 0;
        String size_in = "MB";
        String size_out = "MB";
        
        String err = "";
        
        try{
            con = dbConn.Connect(rev);
            stmt = con.createStatement();
            

            rs = stmt.executeQuery("show status like 'Max_used_connections'");      // Max_connections
            err = "max_connections";
            if (rs.next()) max_connections = rs.getInt(2);
            
            rs = stmt.executeQuery("show status like 'Threads_connected'");         // Threads_connected
            err = "threads_connected";
            if (rs.next()) threads_connected = rs.getInt(2);

            rs = stmt.executeQuery("show status like 'Questions'");                 // Questions
            err = "questions";
            if (rs.next()) questions = rs.getInt(2);

            rs = stmt.executeQuery("show status like 'Uptime'");                    // Uptime
            err = "uptime";
            if (rs.next()) uptime = rs.getInt(2);

            rs = stmt.executeQuery("show status like 'Bytes_received'");            // Bytes_received
            err = "bytes_in";
            if (rs.next()) bytes_in = rs.getLong(2);

            rs = stmt.executeQuery("show status like 'Bytes_sent'");                // Bytes_sent
            err = "bytes_out";
            if (rs.next()) bytes_out = rs.getDouble(2);
            
            con.close();
        }
        catch(Exception exc){
            out.println("<BR><BR>Master Database Error!");
            out.println("<BR>Exception: "+ err + " : " + exc.getMessage());
            return;
        }
        
        double qpers = (questions / uptime);
        
        bytes_in = bytes_in / 1024 / 1024;                // convert bytes_in to MB
        bytes_out = bytes_out / 1024 / 1024;               // convert bytes_out to MB
        
        // if larger than 1000 MB, convert to GB
        if (bytes_in > 1024){
            bytes_in /= 1024;
            size_in = "GB";
        }
        if (bytes_out > 1024){
            bytes_out /= 1024;
            size_out = "GB";
        }
        
        // print results to screen
        out.println("<font size=2>");
        out.println("Con: " + threads_connected + "/" + max_connections + "<br>");
        out.println("Qsec: " + qpers + "<br>");
        out.println("Data: " + (int)bytes_in + size_in + "/" + (int)bytes_out + size_out);
        out.println("</font>");
    }   // end of displayMasterDBStats method
    
    private void displaySlaveDBStats(PrintWriter out){
        
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String slave_IOstate = "";
        String slave_IOrunning = "";
        String slave_SQLrunning = "";
        int lastErrno = 0;
        String lastErr = "";
        int secsBehind = 0;
        
        String err = "";
        
        try{
            con = dbConn_slave.Connect(rev);
            stmt = con.createStatement();
            
            rs = stmt.executeQuery("show slave status"); 
            if (rs.next()){
                slave_IOstate = rs.getString("Slave_IO_State");
                err = "slave_IOstate";
                slave_IOrunning = rs.getString("Slave_IO_Running");
                err = "slave_IOrunning";
                slave_SQLrunning = rs.getString("Slave_SQL_Running");
                err = "slave_SQLrunning";
                lastErrno = rs.getInt("Last_Errno");
                err = "lastErrno";
                lastErr = rs.getString("Last_Error");
                err = "lastErr";
                secsBehind = rs.getInt("Seconds_Behind_Master");
                err = "secsBehind";
            }
        }
        catch(Exception exc){
            out.println("<BR><BR>Slave Database Error!");
            out.println("<BR>Exception: "+ err + " : " + exc.getMessage());
            return;            
        }
        
        out.println("<font size=2>");
        out.println("IO state: " + slave_IOstate + "<br/>");
        out.println("IO running? " + slave_IOrunning + "<br/>");
        out.println("SQL running? " + slave_SQLrunning + "<br/>");
        if (lastErrno != 0 && !lastErr.equals(""))
            out.println("Last Error: " + lastErr + "<br/>");
        out.println("Seconds behind master: " + secsBehind);
        out.println("</font>");
        
    }   // end displaySlaveDBStatus method
    
    private void displayLoginStats(HttpServletRequest req, PrintWriter out) {

        Connection con = null;          
        Statement stmt = null;
        ResultSet rs = null;

        NumberFormat nf;
        nf = NumberFormat.getNumberInstance();

        int today = 0;
        int today_pro = 0;
        int today_mem = 0;
        int today_memL = 0;
        int today_memR = 0;
        double this_month = 0;
        double this_month_ly = 0;
        double last_month = 0;
        double this_year = 0;
        double last_year = 0;
        double last_year_todate = 0;
        double increase = 0;
        double increase_todate = 0;

        try {
            con = dbConn.Connect(rev);
            stmt = con.createStatement();

            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND (user_type_id = 3 OR user_type_id = 4)");
            if (rs.next()) today_pro = rs.getInt(1);

            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND user_type_id = 1");
            if (rs.next()) today_memL = rs.getInt(1);

            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE entry_date = now() AND user_type_id = 2");
            if (rs.next()) today_memR = rs.getInt(1);

            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(now()) AND YEAR(entry_date) = YEAR(now())");
            if (rs.next()) this_month = rs.getInt(1);
            
            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_Date) = MONTH(now()) AND YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 YEAR)) AND DAYOFYEAR(entry_date) <= DAYOFYEAR(now())");
            if (rs.next()) this_month_ly = rs.getInt(1);

            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE MONTH(entry_date) = MONTH(DATE_ADD(now(), INTERVAL -1 MONTH)) AND YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 MONTH))");
            if (rs.next()) last_month = rs.getInt(1);
            
            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE YEAR(entry_date) = YEAR(now())");
            if (rs.next()) this_year = rs.getInt(1);
            
            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 YEAR))");
            if (rs.next()) last_year = rs.getInt(1);
            
            rs = stmt.executeQuery("SELECT sum(login_count) AS today FROM login_stats WHERE DAYOFYEAR(entry_date) <= DAYOFYEAR(now()) AND YEAR(entry_date) = YEAR(DATE_ADD(now(), INTERVAL -1 YEAR))");
            if (rs.next()) last_year_todate = rs.getInt(1);
                        
            rs.close();
            con.close();
        }
        catch (Exception exc) {
            out.println("<p>Database Error!");
            out.println("<br>Exception: "+ exc.getMessage() + "</p>");
            return;
        }

        today_mem = today_memR + today_memL;
        today = today_pro + today_mem;
        DecimalFormat df = new DecimalFormat("#.##");
        increase = ((this_month - this_month_ly) / this_month_ly) * 100;
        increase_todate = ((this_year - last_year_todate) / last_year_todate) * 100;

        
        out.println("<font size=2>");
        out.println("Today: " + nf.format(today) + " (" + nf.format(today_pro) + "P / " + nf.format(today_memL) + "L / " + nf.format(today_memR) + "R)<br/>");
        //if (req.getParameter("logins").equals("1")) return; // if logins=1 then just show todays logins
        out.println("This Month: " + nf.format(this_month) + "<br/>");
        out.println("Last Month: " + nf.format(last_month) + "<br/>");  
        out.println("Increase From LY (Cur Month): " + df.format(increase) + "%<br/>");
        out.println("This Year: " + nf.format(this_year) + "<br/>");
        out.println("Last Year (Total): " + nf.format(last_year) + "<br/>");
        out.println("Last Year (To Cur): " + nf.format(last_year_todate) + "<br/>");
        out.println("Increase From LY (To Cur): " + df.format(increase_todate) + "%<br/>");
        
        out.println("</font>");
    }  // end displayLoginStats method
    
    private void displayBouncedCount(HttpServletRequest req, PrintWriter out) {
        
        Connection con = null;           
        Statement stmt = null;
        ResultSet rs = null;

        int bounced = 0;
        
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://216.243.184.88/xmail_bounces", "xmail_filters", "xmfilmail");
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT COUNT(*) FROM bounced;");
            if (rs.next())
                bounced = rs.getInt(1);

            con.close();
        }
        catch(Exception exc){
            out.println("<BR><BR>Database Error!");
            out.println("<BR>Exception: Bounced - " + exc.getMessage());
            return;
        }
        
        out.println("<font size=2>Bounced Emails: " + bounced + "</font>");
    }   // end displayBouncedCount method
        
}   // end of stats2 class