/***************************************************************************************
 *   Support_getProEmails: Displays a list of emails for all active clubs
 *
 ***************************************************************************************
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;


public class Support_getProEmails extends HttpServlet {
    
    
 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)
 
 String SEPARATOR = ",";

    public void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();



        out.println("<HTML><HEAD><TITLE>Get Pro Emails</TITLE></HEAD><CENTER><BR>");

        out.println("<H3>Pro Email Addresses</H3>");
        out.println("<P>Below are email addresses found for the pro's at all active clubs.  Each box contains up to 100 email addresses.</P><BR>");
        
        getEmails(out);                                 // print emails on page in groups of 100
        
        out.println("<BR><BR> <A HREF=\"/v5/support_main.htm\">Return</A><BR><BR>");        
        out.println("</CENTER></BODY></HTML>");

        out.close();
    }
    
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
        
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String action = "";
        if (req.getParameter("todo") != null) action = req.getParameter("todo");

        if (action.equals("refresh")) {
            getEmails(out);
            return;
        }
        
    }
    
    
    private void getEmails(PrintWriter out){

        Connection con1 = null;
        Connection con2 = null;
        Statement stmt1 = null;
        Statement stmt2 = null;
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        String club = "";
        String email = "";
        int count = 0;
        
        try {
            
            con1 = dbConn.Connect(rev);
            stmt1 = con1.createStatement();
            rs1 = stmt1.executeQuery("SELECT clubname FROM clubs WHERE inactive='0'");
            
            out.println("<TEXTAREA ROWS='4' COLS='60'>");
            
            while(rs1.next()) {
                
                club = rs1.getString(1);                // get a club name
                
                try{
                    
                    con2 = dbConn.Connect(club);            // get a connection to this club's db
                    stmt2 = con2.createStatement();         // create a statement

                    rs2 = stmt2.executeQuery("SELECT email FROM club5 WHERE email <> '';"); 
                    if (rs2.next()) {
                        
                        email = rs2.getString(1);           // get the club email
                        email = email.trim();
                        
                        if (count >= 100){                  // if count >= 100, insert linebreaks and reset count
                            out.println("</TEXTAREA><BR/><BR/><TEXTAREA ROWS='4' COLS='60'>");
                            count = 0;
                        }
                        
                        if (!email.equals("")) out.print(email + SEPARATOR + " ");            // print out the email with trailing semicolon
                        count++;
                        
                    }
                } 
                catch(Exception exc1){
                    //out.println("Error processing request 1;" + exc1.getMessage());
                }
            }
            out.println("</TEXTAREA>");
//            stmt2.close();
//            con2.close();
        }
        catch (Exception exc){
            out.println("Error processing request;" + exc.getMessage());
        }
        //stmt1.close();
        //con1.close();
    } 
}
