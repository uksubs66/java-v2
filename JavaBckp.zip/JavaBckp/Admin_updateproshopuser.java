/***************************************************************************************
*   Admin_updateproshopuser:  This servlet will process the the request to update a proshop
*                             users information
*
*   created: 11/22/2003  JAG (Reworked for Proshop Users - 7/01/2008 BSK)
*
*   last updated:
*
 *  9/02/08  Commented out TS_CTRL_EMAIL limited access proshop restriction
*   8/19/08  Added Limited Access Proshop User tee sheet display options (hdcp, mnum, bag)
*   8/11/08  Adjusted updateMem to account for additional SYSCONFIG limited access types in SQL stmt
*   7/14/08  Updated/Modified to update proshop user information in the database when called by Admin_editproshopuser
*   4/24/08  Update Connection object to use SystemUtils.getCon()
*   3/10/05  Changed to validate the days in advance.
*
*
***************************************************************************************
*/


//third party imports
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

//foretees imports
import com.foretees.client.action.ActionHelper;
import com.foretees.client.form.FormModel;
import com.foretees.common.FeedBack;
import com.foretees.common.ProcessConstants;
import com.foretees.member.Member;
import com.foretees.member.MemberHelper;

/**
***************************************************************************************
*
* This servlet will process the form data for editing information about an
* existing proshop user
*
***************************************************************************************
**/

public class Admin_updateproshopuser extends HttpServlet {

  //initialize the attributes
  private static String versionId = ProcessConstants.CODEBASE;

  /**
  ***************************************************************************************
  *
  * This method will forward the request and response onto the the post method
  *
  ***************************************************************************************
  **/

  public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    doPost(req, resp);

  }

  /**
  ***************************************************************************************
  *
  * This method will process the request to update a proshop users information
  *
  ***************************************************************************************
  **/

  public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();

   //check for intruder
    HttpSession session = SystemUtils.verifyAdmin(req, out);       // check for intruder

    if (session == null) {

      return;
    }

    // Process request according to the next action

    String nextAction = (String)(req.getAttribute(ActionHelper.NEXT_ACTION));
    String redirectURL = "";

    if (nextAction == null || nextAction.equals("")){
      nextAction = req.getParameter(ActionHelper.NEXT_ACTION);
    }

    if (nextAction.equals(ActionHelper.CLEANUP) || nextAction.equals(ActionHelper.CANCEL))
    {
      //user left the page with out hitting a button or hit the cancel button
      redirectURL = cleanup(req, resp, session, out);
    }
    else if (nextAction.equals(ActionHelper.DELETE)) {
      //remove the record from the database and return them to the page they came from
      removeMem(req, out, session);
      redirectURL = cleanup(req, resp, session, out);
    } else {

      boolean updateSuccessful = updateMem(req, resp, out, session);

      if (updateSuccessful){


        if (nextAction.equals(ActionHelper.UPDATE_AND_RETURN))
        {
          String username = req.getParameter(Member.REQ_USER_NAME);
          session.removeAttribute(Member.PROSHOP_USER_FEEDBACK);
          redirectURL = versionId + "servlet/Admin_editproshopuser?username=" + username;
        }
        else
        {
          redirectURL = cleanup(req, resp, session, out);
        }
      }
      else
      {
        String username = req.getParameter(Member.REQ_USER_NAME);
        redirectURL = versionId + "servlet/Admin_editproshopuser?username=" + username;
      }

    }

    resp.sendRedirect(redirectURL);

  }   // end of doPost

  /**
  ***************************************************************************************
  *
  * This method will remove a member record from the member table in the database
  *
  ***************************************************************************************
  **/

  private void removeMem(HttpServletRequest req, PrintWriter out, HttpSession sess) {


    String p_user = "";

    String club = (String)sess.getAttribute("club");

    Connection con = SystemUtils.getCon(sess);            // get DB connection

    if (con == null) {

      out.println(SystemUtils.HeadTitleAdmin("DB Connection Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"" +versionId+ "servlet/Admin_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
    }

    // Get the parameters entered, original username (from hidden field)
    p_user = req.getParameter(Member.REQ_USER_NAME);

    // Delete the member from the member table
    int count = 0;
    try {

      PreparedStatement stmt = con.prepareStatement (
               "DELETE FROM login2 WHERE username = ?");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, p_user);            // put the parm in stmt
      count = stmt.executeUpdate();     // execute the prepared stmt

      stmt.close();

    }
    catch (Exception exc) {

      dbError(out);
      return;
    }

    if (count == 0) {

      noMem(out);    // member does not exist - inform the user and return
      return;
    }
  }  // done with delete function

  /**
  ***************************************************************************************
  *
  * This method will update a member record in the member table in the database
  *
  ***************************************************************************************
  **/

  private boolean updateMem(HttpServletRequest req, HttpServletResponse resp, PrintWriter out, HttpSession session) {

    String club = (String)session.getAttribute("club");

    Connection con = SystemUtils.getCon(session);            // get DB connection

    if (con == null) {

      out.println(SystemUtils.HeadTitleAdmin("DB Connection Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"" +versionId+ "servlet/Admin_announce\">Return</a>");
      out.println("</CENTER></BODY></HTML>");
      return false;
    }

    FormModel editProshopUserForm = null;
    Member member = new Member();

    Object theForm = session.getAttribute(Member.EDIT_PROSHOP_USER_FRM);

    if (theForm != null && theForm instanceof FormModel)
    {
      editProshopUserForm = (FormModel)theForm;
    }
    else
    {
      try
      {
        //editProshopUserForm = new FormModel();
        //session.setAttribute(Member.EDIT_PROSHOP_USER_FRM, editProshopUserForm);
        //editProshopUserForm.update(req, resp, out);
      }
      catch (Exception e)
      {
        return false;
      }
    }

    FeedBack feedback = new FeedBack();

    // Get all the parameters entered and validate them

    //  first name
    String fname = req.getParameter(member.FIRST_NAME);
    if (!fname.equals("")) {
        feedback = (member.isFirstNameValid(member.FIRST_NAME, req));
        if (!feedback.isPositive())
        {
         //the first name has invalid data, update the form and return with error message
         updateFormAndReturnUser(editProshopUserForm, feedback, req, resp, session, out);
         return false;
        }
    }

    //  last name
    String lname = req.getParameter(member.LAST_NAME);
    if (!lname.equals("")) {
        feedback = (member.isLastNameValid(member.LAST_NAME, req));
        if (!feedback.isPositive())
        {
         //the last name has invalid data, update the form and return with error message
         updateFormAndReturnUser(editProshopUserForm, feedback, req, resp, session, out);
         return false;
        }
    }

    //  mid initial
    String mname = req.getParameter(member.MIDDLE_INITIAL);

    //  username
    String user = req.getParameter("username");
    
    //  inact
    int inact = 0;
    if (req.getParameter("inactive") != null) {
        inact = 1;
    }
    
    // create and populate int array containing tee sheet option selections
    int[] tsOpts = new int[MemberHelper.NUM_TEE_SHEET_OPTIONS];
    for (int i=0; i<MemberHelper.NUM_TEE_SHEET_OPTIONS; i++) {
        if (req.getParameter("tsOptsCb" + String.valueOf(i+1)) != null) {
            tsOpts[i] = 1;
        } else {
            tsOpts[i] = 0;
        }
    }
     
    // create and populate int array containing limited access features selections
    int[] ltdAccess = new int[MemberHelper.NUM_LIMITED_ACCESS_TYPES];
    for (int i=0; i<MemberHelper.NUM_LIMITED_ACCESS_TYPES; i++) {
        if (req.getParameter("ltd" + String.valueOf(i+1)) != null) {
            ltdAccess[i] = 1;
        } else {
            ltdAccess[i] = 0;
        }
    }

    //  Update the member in the member table
    //
    int count = 0;
    try {

      PreparedStatement stmt = con.prepareStatement (
      "UPDATE login2 SET inact = ?, name_last = ?, name_first = ?, name_mi = ?, message = '', " +
              "display_hdcp = ?, display_mnum = ?, display_bag = ?, " +
              "SYSCONFIG_CLUBCONFIG = ?, SYSCONFIG_TEESHEETS = ?, SYSCONFIG_EVENT = ?, SYSCONFIG_LOTTERY = ?, SYSCONFIG_WAITLIST = ?, " +
              "SYSCONFIG_RESTRICTIONS = ?, SYSCONFIG_MEMBERNOTICES = ?, TOOLS_ANNOUNCE = ?, TOOLS_EMAIL = ?, TOOLS_SEARCHTS = ?, " +
              "TOOLS_HDCP = ?, REPORTS = ?, LOTT_UPDATE = ?, LOTT_APPROVE = ?, LESS_CONFIG = ?, " +
              "LESS_VIEW = ?, LESS_UPDATE = ?, EVNTSUP_UPDATE = ?, EVNTSUP_VIEW = ?, EVNTSUP_MANAGE = ?, " +
              "WAITLIST_UPDATE = ?, WAITLIST_VIEW = ?, WAITLIST_MANAGE = ?, TS_VIEW = ?, TS_UPDATE = ?, " +
              "TS_CHECKIN = ?, TS_PRINT = ?, TS_POS = ?, TS_CTRL_FROST = ?, TS_CTRL_TSEDIT = ?, " +
              "TS_PACE_VIEW = ?, TS_PACE_UPDATE = ? " +
      "WHERE username = ?");

      stmt.clearParameters();               // clear the parms
      stmt.setInt(1, inact);
      stmt.setString(2, lname);
      stmt.setString(3, fname);
      stmt.setString(4, mname);
      
      int offsetVal = 5;    //start at this value
      for (int i=0; i<MemberHelper.NUM_TEE_SHEET_OPTIONS; i++) {
          stmt.setInt(i + offsetVal, tsOpts[i]);
      }
      
      int offsetVal2 = offsetVal + MemberHelper.NUM_TEE_SHEET_OPTIONS;
      for (int i=0; i<MemberHelper.NUM_LIMITED_ACCESS_TYPES; i++) {
          stmt.setInt(i + offsetVal2, ltdAccess[i]);
      }
      
      stmt.setString(offsetVal2 + MemberHelper.NUM_LIMITED_ACCESS_TYPES, user);
      
      count = stmt.executeUpdate();     // execute the prepared stmt

      stmt.close();

    }
    catch (Exception exc) {
      exc.printStackTrace();
      dbError(out);
      return false;
    }

    editProshopUserForm.update(req, resp, out);
    session.setAttribute(Member.EDIT_PROSHOP_USER_FRM, editProshopUserForm);

    return true;
  }

  
  /**
  ***************************************************************************************
  *
  * This method will print an error message when there is a database error
  *
  ***************************************************************************************
  **/

  private void dbError(PrintWriter out) {

    out.println(SystemUtils.HeadTitleAdmin("Database Error"));
    out.println("<BODY><CENTER>");
    out.println("<BR><BR><H3>Database Access Error</H3>");
    out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
    out.println("<BR>Please try again later.");
    out.println("<BR><BR>If problem persists, contact customer support.");
    out.println("<BR><BR>");
    out.println("<a href=\"javascript:history.back(1)\">Return</a>");
    out.println("</CENTER></BODY></HTML>");

  }

  /**
  ***************************************************************************************
  *
  * This method will print an error message when the user does not exist in the database
  *
  ***************************************************************************************
  **/

  private void noMem(PrintWriter out)
  {

    out.println(SystemUtils.HeadTitleAdmin("Input Error - Redirect"));
    out.println("<BODY><CENTER>");
    out.println("<p>&nbsp;</p>");
    out.println("<BR><H3>Input Error</H3><BR>");
    out.println("<BR><BR>Sorry, the member you specified does exist in the database.<BR>");
    out.println("<BR>Please check your data and try again.<BR>");
    out.println("<BR><BR>");
    out.println("<a href=\"javascript:history.back(1)\">Return</a>");
    out.println("</CENTER></BODY></HTML>");

  }

  /**
  ***************************************************************************************
  *
  * This method update the form model with the data from the request and adds the form and
  * the feedback into the session
  *
  ***************************************************************************************
  **/

  private void updateFormAndReturnUser(FormModel editProshopUserForm, FeedBack feedback, HttpServletRequest req,HttpServletResponse resp, HttpSession session, PrintWriter out)
  {
    if (editProshopUserForm != null)
    {
      editProshopUserForm.update(req, resp, out);
      session.setAttribute(Member.EDIT_PROSHOP_USER_FRM, editProshopUserForm);
      session.setAttribute(Member.PROSHOP_USER_FEEDBACK, feedback);

     }
  }

  /**
  ***************************************************************************************
  *
  * This method remove the form model and the feedback from the session and return
  * the redirect url
  *
  ***************************************************************************************
  **/

  private String cleanup(HttpServletRequest req,HttpServletResponse resp, HttpSession session, PrintWriter out)
  {
    session.removeAttribute(Member.EDIT_PROSHOP_USER_FRM);
    session.removeAttribute(Member.PROSHOP_USER_FEEDBACK);
    return (versionId + "servlet/Admin_proshopusers");
  }


}
