/***************************************************************************************     
 *   Proshop_editgrest:  This servlet will process the 'Edit Guest Restriction' request from
 *                      the Proshop's Edit Guest Restrictions page.
 *
 *
 *   called by:  Proshop_grest (via doPost in HTML built by Proshop_grest)
 *
 *   created: 1/02/2002   Bob P.
 *
 *   last updated:
 *
 *       11/06/08   Delete all corresponding suspensions when deleting a guest restriction
 *        8/12/08   Added limited access proshop users checks
 *        3/01/04   Add option to specify Number of Guests per Member or Tee Time.
 *       11/22/03   Enhancements for Version 3 - add color option for hotels.
 *        7/18/03   Enhancements for Version 3 of the software.
 *        1/08/03   Enhancements for Version 2 of the software.
 *                  Add support for multiple courses, F/B option and multiple guest types.
 *
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

public class Proshop_editgrest extends HttpServlet {

                                 
 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 //****************************************************************
 // Process the form request from Proshop_editgrest page.
 //****************************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();


   HttpSession session = SystemUtils.verifyPro(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   //
   // Process request according to which 'submit' button was selected
   //
   //      Update - update the record - prompt user for conf
   //      Remove - delete the record - prompt user for conf
   //      Yes (value = update) - process the update confirmation
   //      Delete (value = remove) - process the delete confirmation
   //
   if (req.getParameter("Update") != null) {

      updateConf(req, out, session);

   } else {

      if (req.getParameter("Remove") != null) {

         removeConf(req, out);

      } else {

         if (req.getParameter("Delete") != null) {

            removeGrest(req, out, session);

         } else {

            if (req.getParameter("Yes") != null) {

               updateGrest(req, out, session);

            }
         }
      }
   }
 }   // end of doPost


   //*************************************************
   //  updateConf - Request a confirmation from user
   //*************************************************

 private void updateConf(HttpServletRequest req, PrintWriter out, HttpSession sess) {


   ResultSet rs = null;
   Connection con = SystemUtils.getCon(sess);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   // Check Feature Access Rights for current proshop user
   if (!SystemUtils.verifyProAccess(req, "SYSCONFIG_RESTRICTIONS", con, out)) {
       SystemUtils.restrictProshop("SYSCONFIG_RESTRICTIONS", out);
   }
     
   //
   // Get the other parameters entered
   //
   String name = req.getParameter("rest_name");
   String oldName = req.getParameter("oldName");
   String smonth = req.getParameter("smonth");        
   String sday = req.getParameter("sday");      
   String syear = req.getParameter("syear");    
   String emonth = req.getParameter("emonth");
   String eday = req.getParameter("eday");
   String eyear = req.getParameter("eyear");
   String shr = req.getParameter("start_hr");      
   String smin = req.getParameter("start_min");    
   String sampm = req.getParameter("start_ampm");  
   String ehr = req.getParameter("end_hr");      
   String emin = req.getParameter("end_min");    
   String eampm = req.getParameter("end_ampm");     
   String recurr = req.getParameter("recurr");
   String guests = req.getParameter("guests");
   String course = req.getParameter("course");
   String oldCourse = req.getParameter("oldCourse");
   String fb = req.getParameter("fb");
   String per = req.getParameter("per");

   String ssampm = "AM";
   String seampm = "AM";
   String guest1 = "";             // guest types
   String guest2 = "";
   String guest3 = "";
   String guest4 = "";
   String guest5 = "";
   String guest6 = "";
   String guest7 = "";
   String guest8 = "";
   String guest9 = "";
   String guest10 = "";
   String guest11 = "";
   String guest12 = "";
   String guest13 = "";
   String guest14 = "";
   String guest15 = "";
   String guest16 = "";
   String guest17 = "";
   String guest18 = "";
   String guest19 = "";
   String guest20 = "";
   String guest21 = "";
   String guest22 = "";
   String guest23 = "";
   String guest24 = "";
   String guest25 = "";
   String guest26 = "";
   String guest27 = "";
   String guest28 = "";
   String guest29 = "";
   String guest30 = "";
   String guest31 = "";
   String guest32 = "";
   String guest33 = "";
   String guest34 = "";
   String guest35 = "";
   String guest36 = "";
   String color = "";

   int s_min = 0;
   int e_min = 0;
      
   if (sampm.equals ( "12" )) {      // sampm & eampm are either '00' or '12'
      ssampm = "PM";
   }

   if (eampm.equals ( "12" )) {
      seampm = "PM";
   }

   try {
      s_min = Integer.parseInt(smin);
      e_min = Integer.parseInt(emin);
   }
   catch (NumberFormatException e) {
      // ignore error - let verify catch it
   }

   //
   //  Validate minute values
   //
   if ((s_min < 0) || (s_min > 59)) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>Start Minute parameter must be in the range of 00 - 59.");
      out.println("<BR>You entered:" + s_min);
      out.println("<BR>Please try again.");
      out.println("<br><br><font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</input></form></font>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   if ((e_min < 0) || (e_min > 59)) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>End Minute parameter must be in the range of 00 - 59.");
      out.println("<BR>You entered:" + e_min);
      out.println("<BR>Please try again.");
      out.println("<br><br><font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</input></form></font>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   //  indicate parm specified for those that were
   //
   if (req.getParameter("guest1") != null) {
      guest1 = req.getParameter("guest1");
   }
   if (req.getParameter("guest2") != null) {
      guest2 = req.getParameter("guest2");
   }
   if (req.getParameter("guest3") != null) {
      guest3 = req.getParameter("guest3");
   }
   if (req.getParameter("guest4") != null) {
      guest4 = req.getParameter("guest4");
   }
   if (req.getParameter("guest5") != null) {
      guest5 = req.getParameter("guest5");
   }
   if (req.getParameter("guest6") != null) {
      guest6 = req.getParameter("guest6");
   }
   if (req.getParameter("guest7") != null) {
      guest7 = req.getParameter("guest7");
   }
   if (req.getParameter("guest8") != null) {
      guest8 = req.getParameter("guest8");
   }
   if (req.getParameter("guest9") != null) {
      guest9 = req.getParameter("guest9");
   }
   if (req.getParameter("guest10") != null) {
      guest10 = req.getParameter("guest10");
   }
   if (req.getParameter("guest11") != null) {
      guest11 = req.getParameter("guest11");
   }
   if (req.getParameter("guest12") != null) {
      guest12 = req.getParameter("guest12");
   }
   if (req.getParameter("guest13") != null) {
      guest13 = req.getParameter("guest13");
   }
   if (req.getParameter("guest14") != null) {
      guest14 = req.getParameter("guest14");
   }
   if (req.getParameter("guest15") != null) {
      guest15 = req.getParameter("guest15");
   }
   if (req.getParameter("guest16") != null) {
      guest16 = req.getParameter("guest16");
   }
   if (req.getParameter("guest17") != null) {
      guest17 = req.getParameter("guest17");
   }
   if (req.getParameter("guest18") != null) {
      guest18 = req.getParameter("guest18");
   }
   if (req.getParameter("guest19") != null) {
      guest19 = req.getParameter("guest19");
   }
   if (req.getParameter("guest20") != null) {
      guest20 = req.getParameter("guest20");
   }
   if (req.getParameter("guest21") != null) {
      guest21 = req.getParameter("guest21");
   }
   if (req.getParameter("guest22") != null) {
      guest22 = req.getParameter("guest22");
   }
   if (req.getParameter("guest23") != null) {
      guest23 = req.getParameter("guest23");
   }
   if (req.getParameter("guest24") != null) {
      guest24 = req.getParameter("guest24");
   }
   if (req.getParameter("guest25") != null) {
      guest25 = req.getParameter("guest25");
   }
   if (req.getParameter("guest26") != null) {
      guest26 = req.getParameter("guest26");
   }
   if (req.getParameter("guest27") != null) {
      guest27 = req.getParameter("guest27");
   }
   if (req.getParameter("guest28") != null) {
      guest28 = req.getParameter("guest28");
   }
   if (req.getParameter("guest29") != null) {
      guest29 = req.getParameter("guest29");
   }
   if (req.getParameter("guest30") != null) {
      guest30 = req.getParameter("guest30");
   }
   if (req.getParameter("guest31") != null) {
      guest31 = req.getParameter("guest31");
   }
   if (req.getParameter("guest32") != null) {
      guest32 = req.getParameter("guest32");
   }
   if (req.getParameter("guest33") != null) {
      guest33 = req.getParameter("guest33");
   }
   if (req.getParameter("guest34") != null) {
      guest34 = req.getParameter("guest34");
   }
   if (req.getParameter("guest35") != null) {
      guest35 = req.getParameter("guest35");
   }
   if (req.getParameter("guest36") != null) {
      guest36 = req.getParameter("guest36");
   }

   if (req.getParameter("color") != null) {

      color = req.getParameter("color");
   }

   //
   //  verify the required fields (name reqr'ed & at least one guest type - rest are automatic)
   //
   if ((name.equals( "" )) ||
       ((guest1.equals( "" )) && (guest2.equals( "" )) && (guest3.equals( "" )) && (guest4.equals( "" )) &&
        (guest5.equals( "" )) && (guest6.equals( "" )) && (guest7.equals( "" )) && (guest8.equals( "" )) &&
        (guest9.equals( "" )) && (guest10.equals( "" )) && (guest11.equals( "" )) && (guest12.equals( "" )) &&
        (guest13.equals( "" )) && (guest14.equals( "" )) && (guest15.equals( "" )) && (guest16.equals( "" )) &&
        (guest17.equals( "" )) && (guest18.equals( "" )) && (guest19.equals( "" )) && (guest20.equals( "" )) &&
        (guest21.equals( "" )) && (guest22.equals( "" )) && (guest23.equals( "" )) && (guest24.equals( "" )) &&
        (guest25.equals( "" )) && (guest26.equals( "" )) && (guest27.equals( "" )) && (guest28.equals( "" )) &&
        (guest29.equals( "" )) && (guest30.equals( "" )) && (guest31.equals( "" )) && (guest32.equals( "" )) &&
        (guest33.equals( "" )) && (guest34.equals( "" )) && (guest35.equals( "" )) && (guest36.equals( "" )))) {

      invData(out);    // inform the user and return
      return;
   }

   //
   //  Validate new name if it has changed
   //
   boolean error = SystemUtils.scanQuote(name);           // check for single quote

   if (error == true) {

      out.println(SystemUtils.HeadTitle("Data Entry Error"));
      out.println("<BODY><CENTER>");
      out.println("<BR><BR><H3>Invalid Parameter Value Specified</H3>");
      out.println("<BR><BR>Single quotes cannot be part of the Name.");
      out.println("<BR>Please try again.");
      out.println("<br><br><font size=\"2\">");
      out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
      out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
      out.println("</input></form></font>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   //
   //  Scan name for special characters and replace with HTML supported chars (i.e. '>' = &gt)
   //
   name = SystemUtils.filter(name);
   oldName = SystemUtils.filter(oldName);

   //
   //  If name has changed check for dup
   //
   if (!oldName.equals( name )) {    // if name has changed

      try {

         PreparedStatement stmt = con.prepareStatement (
                 "SELECT sdate FROM guestres2 WHERE name = ?");

         stmt.clearParameters();        // clear the parms
         stmt.setString(1, name);       // put the parm in stmt
         rs = stmt.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            dupMem(out);    // member restriction exists - inform the user and return
            stmt.close();
            return;
         }
         stmt.close();
      }
      catch (Exception ignored) {
      }
   }

   //
   //  Prompt user for confirmation
   //
   out.println(SystemUtils.HeadTitle("Update Guest Restriction Confirmation"));
   out.println("<BODY><CENTER><BR>");
   out.println("<br>");
   out.println("<H3>Update Guest Restriction Confirmation</H3><BR>");
   out.println("<BR>Please confirm the following parameters for the restriction:<br><b>" + name + "</b><br><br>");

   out.println("<table border=\"1\" cols=\"2\" bgcolor=\"#F5F5DC\">");

   if (!course.equals( "" )) {

      out.println("<tr><td align=\"right\">");
      out.println("Course Name:&nbsp;&nbsp;");
      out.println("</td><td align=\"left\">");
      out.println("&nbsp;&nbsp;&nbsp;" + course);
      out.println("</td></tr>");
   }

   out.println("<tr><td align=\"right\">");
   out.println("Tees:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");
   out.println("&nbsp;&nbsp;&nbsp;" + fb);
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("Start Date:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");
   out.println("&nbsp;&nbsp;&nbsp;" + smonth + "/" + sday + "/" + syear);
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("End Date:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");
   out.println("&nbsp;&nbsp;&nbsp;" + emonth + "/" + eday + "/" + eyear);
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("Start Time:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");

   if (s_min < 10) {
      out.println("&nbsp;&nbsp;&nbsp;" + shr + ":0" + s_min + "  " + ssampm);
   } else {
      out.println("&nbsp;&nbsp;&nbsp;" + shr + ":" + s_min + "  " + ssampm);
   }
     
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("End Time:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");

   if (e_min < 10) {
      out.println("&nbsp;&nbsp;&nbsp;" + ehr + ":0" + e_min + "  " + seampm);
   } else {
      out.println("&nbsp;&nbsp;&nbsp;" + ehr + ":" + e_min + "  " + seampm);
   }

   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("Recurrence:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");
   out.println("&nbsp;&nbsp;&nbsp;" + recurr);
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\" valign=\"top\">");
   out.println("Guest Types Restricted:&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");

   if (!guest1.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest1 + "<br>");
   }
   if (!guest2.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest2 + "<br>");
   }
   if (!guest3.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest3 + "<br>");
   }
   if (!guest4.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest4 + "<br>");
   }
   if (!guest5.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest5 + "<br>");
   }
   if (!guest6.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest6 + "<br>");
   }
   if (!guest7.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest7 + "<br>");
   }
   if (!guest8.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest8 + "<br>");
   }
   if (!guest9.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest9 + "<br>");
   }
   if (!guest10.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest10 + "<br>");
   }
   if (!guest11.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest11 + "<br>");
   }
   if (!guest12.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest12 + "<br>");
   }
   if (!guest13.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest13 + "<br>");
   }
   if (!guest14.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest14 + "<br>");
   }
   if (!guest15.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest15 + "<br>");
   }
   if (!guest16.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest16 + "<br>");
   }
   if (!guest17.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest17 + "<br>");
   }
   if (!guest18.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest18 + "<br>");
   }
   if (!guest19.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest19 + "<br>");
   }
   if (!guest20.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest20 + "<br>");
   }
   if (!guest21.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest21 + "<br>");
   }
   if (!guest22.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest22 + "<br>");
   }
   if (!guest23.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest23 + "<br>");
   }
   if (!guest24.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest24 + "<br>");
   }
   if (!guest25.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest25 + "<br>");
   }
   if (!guest26.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest26 + "<br>");
   }
   if (!guest27.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest27 + "<br>");
   }
   if (!guest28.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest28 + "<br>");
   }
   if (!guest29.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest29 + "<br>");
   }
   if (!guest30.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest30 + "<br>");
   }
   if (!guest31.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest31 + "<br>");
   }
   if (!guest32.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest32 + "<br>");
   }
   if (!guest33.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest33 + "<br>");
   }
   if (!guest34.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest34 + "<br>");
   }
   if (!guest35.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest35 + "<br>");
   }
   if (!guest36.equals( "" )) {
      out.println("&nbsp;&nbsp;&nbsp;" + guest36 + "<br>");
   }
   out.println("</td></tr>");

   out.println("<tr><td align=\"right\">");
   out.println("Number of Guests Allowed per " +per+ ":&nbsp;&nbsp;");
   out.println("</td><td align=\"left\">");
   out.println("&nbsp;&nbsp;&nbsp;" + guests);
   out.println("</td></tr></table>");

   out.println("<form action=\"/" +rev+ "/servlet/Proshop_editgrest\" method=\"post\" target=\"bot\">");
   out.println("<BR>ARE YOU SURE YOU WANT TO UPDATE THIS RECORD?");
   out.println("<input type=\"hidden\" name=\"rest_name\" value = \"" + name + "\">");
   out.println("<input type=\"hidden\" name=\"oldName\" value = \"" + oldName + "\">");
   out.println("<input type=\"hidden\" name=\"smonth\" value = " + smonth + ">");
   out.println("<input type=\"hidden\" name=\"sday\" value = " + sday + ">");
   out.println("<input type=\"hidden\" name=\"syear\" value = " + syear + ">");
   out.println("<input type=\"hidden\" name=\"emonth\" value = " + emonth + ">");
   out.println("<input type=\"hidden\" name=\"eday\" value = " + eday + ">");
   out.println("<input type=\"hidden\" name=\"eyear\" value = " + eyear + ">");
   out.println("<input type=\"hidden\" name=\"start_hr\" value = " + shr + ">");
   out.println("<input type=\"hidden\" name=\"start_min\" value = " + smin + ">");
   out.println("<input type=\"hidden\" name=\"start_ampm\" value = " + sampm + ">");
   out.println("<input type=\"hidden\" name=\"end_hr\" value = " + ehr + ">");
   out.println("<input type=\"hidden\" name=\"end_min\" value = " + emin + ">");
   out.println("<input type=\"hidden\" name=\"end_ampm\" value = " + eampm + ">");
   out.println("<input type=\"hidden\" name=\"recurr\" value = \"" + recurr + "\">");
   out.println("<input type=\"hidden\" name=\"guests\" value = \"" + guests + "\">");
   out.println("<input type=\"hidden\" name=\"guest1\" value = \"" + guest1 + "\">");
   out.println("<input type=\"hidden\" name=\"guest2\" value = \"" + guest2 + "\">");
   out.println("<input type=\"hidden\" name=\"guest3\" value = \"" + guest3 + "\">");
   out.println("<input type=\"hidden\" name=\"guest4\" value = \"" + guest4 + "\">");
   out.println("<input type=\"hidden\" name=\"guest5\" value = \"" + guest5 + "\">");
   out.println("<input type=\"hidden\" name=\"guest6\" value = \"" + guest6 + "\">");
   out.println("<input type=\"hidden\" name=\"guest7\" value = \"" + guest7 + "\">");
   out.println("<input type=\"hidden\" name=\"guest8\" value = \"" + guest8 + "\">");
   out.println("<input type=\"hidden\" name=\"guest9\" value = \"" + guest9 + "\">");
   out.println("<input type=\"hidden\" name=\"guest10\" value = \"" + guest10 + "\">");
   out.println("<input type=\"hidden\" name=\"guest11\" value = \"" + guest11 + "\">");
   out.println("<input type=\"hidden\" name=\"guest12\" value = \"" + guest12 + "\">");
   out.println("<input type=\"hidden\" name=\"guest13\" value = \"" + guest13 + "\">");
   out.println("<input type=\"hidden\" name=\"guest14\" value = \"" + guest14 + "\">");
   out.println("<input type=\"hidden\" name=\"guest15\" value = \"" + guest15 + "\">");
   out.println("<input type=\"hidden\" name=\"guest16\" value = \"" + guest16 + "\">");
   out.println("<input type=\"hidden\" name=\"guest17\" value = \"" + guest17 + "\">");
   out.println("<input type=\"hidden\" name=\"guest18\" value = \"" + guest18 + "\">");
   out.println("<input type=\"hidden\" name=\"guest19\" value = \"" + guest19 + "\">");
   out.println("<input type=\"hidden\" name=\"guest20\" value = \"" + guest20 + "\">");
   out.println("<input type=\"hidden\" name=\"guest21\" value = \"" + guest21 + "\">");
   out.println("<input type=\"hidden\" name=\"guest22\" value = \"" + guest22 + "\">");
   out.println("<input type=\"hidden\" name=\"guest23\" value = \"" + guest23 + "\">");
   out.println("<input type=\"hidden\" name=\"guest24\" value = \"" + guest24 + "\">");
   out.println("<input type=\"hidden\" name=\"guest25\" value = \"" + guest25 + "\">");
   out.println("<input type=\"hidden\" name=\"guest26\" value = \"" + guest26 + "\">");
   out.println("<input type=\"hidden\" name=\"guest27\" value = \"" + guest27 + "\">");
   out.println("<input type=\"hidden\" name=\"guest28\" value = \"" + guest28 + "\">");
   out.println("<input type=\"hidden\" name=\"guest29\" value = \"" + guest29 + "\">");
   out.println("<input type=\"hidden\" name=\"guest30\" value = \"" + guest30 + "\">");
   out.println("<input type=\"hidden\" name=\"guest31\" value = \"" + guest31 + "\">");
   out.println("<input type=\"hidden\" name=\"guest32\" value = \"" + guest32 + "\">");
   out.println("<input type=\"hidden\" name=\"guest33\" value = \"" + guest33 + "\">");
   out.println("<input type=\"hidden\" name=\"guest34\" value = \"" + guest34 + "\">");
   out.println("<input type=\"hidden\" name=\"guest35\" value = \"" + guest35 + "\">");
   out.println("<input type=\"hidden\" name=\"guest36\" value = \"" + guest36 + "\">");
   out.println("<input type=\"hidden\" name=\"fb\" value=\"" + fb + "\">");
   out.println("<input type=\"hidden\" name=\"per\" value=\"" + per + "\">");
   out.println("<input type=\"hidden\" name=\"color\" value=\"" + color + "\">");
   out.println("<input type=\"hidden\" name=\"course\" value=\"" + course + "\">");
   out.println("<input type=\"hidden\" name=\"oldCourse\" value=\"" + oldCourse + "\">");
      
   out.println("<BR><BR>");
   out.println("<input type=\"submit\" value=\"Yes\" name=\"Yes\">");
   out.println("</form><font size=\"2\">");
      
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"No - Cancel\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");

 }  // wait for confirmation (Yes)


   //*************************************************
   //  removeConf - Request a confirmation for delete
   //*************************************************

 private void removeConf(HttpServletRequest req, PrintWriter out) {


   //
   // Get the name parameter from the hidden input field
   //
   String name = req.getParameter("rest_name");
   String course = req.getParameter("course");
   
   int grest_id = Integer.parseInt(req.getParameter("grest_id"));

   //
   //  Scan name for special characters and replace with HTML supported chars (i.e. '>' = &gt)
   //
   name = SystemUtils.filter(name);


   //
   //  Prompt user for confirmation
   //
   out.println(SystemUtils.HeadTitle("Delete Guest Restriction Confirmation"));
   out.println("<BODY><CENTER><BR>");
   out.println("<p>&nbsp;</p>");
   out.println("<BR><H3>Remove Guest Restriction Confirmation</H3><BR>");
   out.println("<BR>Please confirm that you wish to remove this restriction: <b>" + name + "</b><br>");

   out.println("<form action=\"/" +rev+ "/servlet/Proshop_editgrest\" method=\"post\" target=\"bot\">");
   out.println("<BR>ARE YOU SURE YOU WANT TO DELETE THIS RECORD AND ALL CORRESPONDING SUSPENSIONS?");
   out.println("<BR><BR>");

   out.println("<input type=\"hidden\" name=\"rest_name\" value =\"" + name + "\">");
   out.println("<input type=\"hidden\" name=\"grest_id\" value =\"" + grest_id + "\">");
   out.println("<input type=\"hidden\" name=\"course\" value =\"" + course + "\">");
   out.println("<input type=\"submit\" value=\"Delete\" name=\"Delete\">");
   out.println("</form><font size=\"2\">");

   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"No - Cancel\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");

 }  // wait for confirmation (Yes)


   //*************************************************************************
   //  removeGrest - Remove a restriction from restriction table - received confirmation
   //*************************************************************************

 private void removeGrest(HttpServletRequest req, PrintWriter out, HttpSession sess) {


   Connection con = SystemUtils.getCon(sess);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   // Check Feature Access Rights for current proshop user
   if (!SystemUtils.verifyProAccess(req, "SYSCONFIG_RESTRICTIONS", con, out)) {
       SystemUtils.restrictProshop("SYSCONFIG_RESTRICTIONS", out);
   }
     
   //
   // Get the name parameter from the hidden input field
   //
   String name = req.getParameter("rest_name");
   String course = req.getParameter("course");
   
   int grest_id = Integer.parseInt(req.getParameter("grest_id"));

   //
   // Delete the Restriction from the restriction table
   //
   PreparedStatement stmt = null;
   ResultSet rs = null;
   int count = 0;
      
   try {
      //
      //  Check the name for special characters and translate if ncessary
      //
      stmt = con.prepareStatement (
               "SELECT sdate FROM guestres2 WHERE name = ? AND courseName = ?");

      stmt.clearParameters();        // clear the parms
      stmt.setString(1, name);       // put the parm in stmt
      stmt.setString(2, course);
      rs = stmt.executeQuery();      // execute the prepared stmt

      if (!rs.next()) {                     // if not found

         name = SystemUtils.filter(name);   // translate the name
      }
      stmt.close();              // close the stmt

      //
      //  Delete the rest
      //
      stmt = con.prepareStatement (
               "Delete FROM guestres2 WHERE name = ? AND courseName = ?");

      stmt.clearParameters();               // clear the parms
      stmt.setString(1, name);              // put the parm in stmt
      stmt.setString(2, course);
      count = stmt.executeUpdate();         // execute the prepared stmt

      stmt.close();
      
      if (count > 0) {      // if the restriction was deleted
          //
          //  Delete corresponding suspensions
          //
          stmt = con.prepareStatement (
                  "DELETE FROM rest_suspend WHERE grest_id = ?");
          stmt.clearParameters();
          stmt.setInt(1, grest_id);
          count = stmt.executeUpdate();
          
          stmt.close();
      }
   }
   catch (Exception exc) {

      dbError(out, exc);
      return;
   }

   //
   //  Guest Restriction successfully deleted
   //
   out.println(SystemUtils.HeadTitle("Delete Guest Restriction Confirmation"));
   out.println("<BODY><CENTER><BR>");
   out.println("<p>&nbsp;</p>");
   out.println("<BR><H3>Restriction Record Has Been Removed</H3><BR>");
   out.println("<BR><BR>Thank you, the restriction has been removed from the database.");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");

   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");

 }  // done with delete function


   //*******************************************************************
   //  updateGrest - Update a Restriction from restriction table - received a conf
   //*******************************************************************

 private void updateGrest(HttpServletRequest req, PrintWriter out, HttpSession sess) {


   Connection con = SystemUtils.getCon(sess);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   // Check Feature Access Rights for current proshop user
   if (!SystemUtils.verifyProAccess(req, "SYSCONFIG_RESTRICTIONS", con, out)) {
       SystemUtils.restrictProshop("SYSCONFIG_RESTRICTIONS", out);
   }
     
   //
   // Get the parameters entered
   //
   String name = req.getParameter("rest_name");
   String oldName = req.getParameter("oldName");
   String s_month = req.getParameter("smonth");             //  month (00 - 12)
   String s_day = req.getParameter("sday");                 //  day (01 - 31)
   String s_year = req.getParameter("syear");               //  year (2002 - 20xx)
   String e_month = req.getParameter("emonth");             
   String e_day = req.getParameter("eday");                 
   String e_year = req.getParameter("eyear");               
   String start_hr = req.getParameter("start_hr");         //  start hour (01 - 12)
   String start_min = req.getParameter("start_min");       //  start min (00 - 59)
   String start_ampm = req.getParameter("start_ampm");     //  AM/PM (00 or 12)
   String end_hr = req.getParameter("end_hr");             //   .
   String end_min = req.getParameter("end_min");           //   .
   String end_ampm = req.getParameter("end_ampm");         //   .
   String recurr = req.getParameter("recurr");             //  recurrence
   String sguests = req.getParameter("guests");            //  # of guests (0 - 2)
   String guest1 = req.getParameter("guest1");             //  guest types
   String guest2 = req.getParameter("guest2");
   String guest3 = req.getParameter("guest3");
   String guest4 = req.getParameter("guest4");
   String guest5 = req.getParameter("guest5");
   String guest6 = req.getParameter("guest6");
   String guest7 = req.getParameter("guest7");
   String guest8 = req.getParameter("guest8");
   String guest9 = req.getParameter("guest9");
   String guest10 = req.getParameter("guest10");
   String guest11 = req.getParameter("guest11");
   String guest12 = req.getParameter("guest12");
   String guest13 = req.getParameter("guest13");
   String guest14 = req.getParameter("guest14");
   String guest15 = req.getParameter("guest15");
   String guest16 = req.getParameter("guest16");
   String guest17 = req.getParameter("guest17");
   String guest18 = req.getParameter("guest18");
   String guest19 = req.getParameter("guest19");
   String guest20 = req.getParameter("guest20");
   String guest21 = req.getParameter("guest21");
   String guest22 = req.getParameter("guest22");
   String guest23 = req.getParameter("guest23");
   String guest24 = req.getParameter("guest24");
   String guest25 = req.getParameter("guest25");
   String guest26 = req.getParameter("guest26");
   String guest27 = req.getParameter("guest27");
   String guest28 = req.getParameter("guest28");
   String guest29 = req.getParameter("guest29");
   String guest30 = req.getParameter("guest30");
   String guest31 = req.getParameter("guest31");
   String guest32 = req.getParameter("guest32");
   String guest33 = req.getParameter("guest33");
   String guest34 = req.getParameter("guest34");
   String guest35 = req.getParameter("guest35");
   String guest36 = req.getParameter("guest36");
   String course = req.getParameter("course");             //  course name
   String fb = req.getParameter("fb");                     //  Front/Back indicator
   String per = req.getParameter("per");                   //  Member or Tee Time
   String color = req.getParameter("color");               //  color for the restriction display
   String oldCourse = req.getParameter("oldCourse");

   int smonth = 0;
   int sday = 0;
   int syear = 0;
   int emonth = 0;
   int eday = 0;
   int eyear = 0;
   int s_hr = 0;
   int s_min = 0;
   int s_ampm = 0;
   int e_hr = 0;
   int e_min = 0;
   int e_ampm = 0;
   int guests = 0;

   //
   // Convert the numeric string parameters to Int's
   //
   try {
      smonth = Integer.parseInt(s_month);
      sday = Integer.parseInt(s_day);
      syear = Integer.parseInt(s_year);
      emonth = Integer.parseInt(e_month);
      eday = Integer.parseInt(e_day);
      eyear = Integer.parseInt(e_year);
      s_hr = Integer.parseInt(start_hr);
      s_min = Integer.parseInt(start_min);
      s_ampm = Integer.parseInt(start_ampm);
      e_hr = Integer.parseInt(end_hr);
      e_min = Integer.parseInt(end_min);
      e_ampm = Integer.parseInt(end_ampm);
      guests = Integer.parseInt(sguests);
   }
   catch (NumberFormatException e) {
      // ignore error - let verify catch it
   }

   //
   //  adjust some values for the table
   //
   long sdate = syear * 10000;      // create a date field from input values
   sdate = sdate + (smonth * 100);
   sdate = sdate + sday;             // date = yyyymmdd (for comparisons)

   long edate = eyear * 10000;       // create a date field from input values
   edate = edate + (emonth * 100);
   edate = edate + eday;             // date = yyyymmdd (for comparisons)

   if (s_hr != 12) {                // _hr specified as 01 - 12 (_ampm = 00 or 12)

      s_hr = s_hr + s_ampm;         // convert to military time (12 is always Noon or PM)
   }

   if (e_hr != 12) {                // ditto

      e_hr = e_hr + e_ampm;
   }

   int stime = s_hr * 100;
   stime = stime + s_min;
   int etime = e_hr * 100;
   etime = etime + e_min;

   //
   //  verify the date and time fields
   //
   if ((sdate > edate) || (stime > etime)) {

      invData(out);    // inform the user and return
      return;
   }

   //
   //  Udate the record in the restriction table
   //
   PreparedStatement pstmt = null;
   ResultSet rs = null;
   int count = 0;

   try {
      //
      //  Check the name for special characters and translate if ncessary
      //
      pstmt = con.prepareStatement (
               "SELECT sdate FROM guestres2 WHERE name = ? AND courseName = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, oldName);       // put the parm in stmt
      pstmt.setString(2, oldCourse);
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (!rs.next()) {                     // if not found

         oldName = SystemUtils.filter(oldName);   // translate the name
      }
      pstmt.close();                        // close the stmt

      //
      //  Udate the record in the restriction table
      //
      pstmt = con.prepareStatement (
        "UPDATE guestres2 SET sdate = ?, start_mm = ?, start_dd = ?, start_yy = ?, " +
        "start_hr = ?, start_min = ?, stime = ?, " +
        "edate = ?, end_mm = ?, end_dd = ?, end_yy = ?, " +
        "end_hr = ?, end_min = ?, etime = ?, recurr = ?, num_guests = ?," +
        "guest1 = ?, guest2 = ?, guest3 = ?, guest4 = ?, guest5 = ?, guest6 = ?, guest7 = ?, guest8 = ?, " +
        "courseName = ?, fb = ?, color = ?, " +
        "guest9 = ?, guest10 = ?, guest11 = ?, guest12 = ?, guest13 = ?, guest14 = ?, guest15 = ?, guest16 = ?, " +
        "guest17 = ?, guest18 = ?, guest19 = ?, guest20 = ?, guest21 = ?, guest22 = ?, guest23 = ?, guest24 = ?, " +
        "guest25 = ?, guest26 = ?, guest27 = ?, guest28 = ?, guest29 = ?, guest30 = ?, guest31 = ?, guest32 = ?, " +
        "guest33 = ?, guest34 = ?, guest35 = ?, guest36 = ?, per = ?, name = ? " +
        "WHERE name = ? AND courseName = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setLong(1, sdate);
      pstmt.setInt(2, smonth);
      pstmt.setInt(3, sday);
      pstmt.setInt(4, syear);
      pstmt.setInt(5, s_hr);
      pstmt.setInt(6, s_min);
      pstmt.setInt(7, stime);
      pstmt.setLong(8, edate);
      pstmt.setInt(9, emonth);
      pstmt.setInt(10, eday);
      pstmt.setInt(11, eyear);
      pstmt.setInt(12, e_hr);
      pstmt.setInt(13, e_min);
      pstmt.setInt(14, etime);
      pstmt.setString(15, recurr);
      pstmt.setInt(16, guests);
      pstmt.setString(17, guest1);
      pstmt.setString(18, guest2);
      pstmt.setString(19, guest3);
      pstmt.setString(20, guest4);
      pstmt.setString(21, guest5);
      pstmt.setString(22, guest6);
      pstmt.setString(23, guest7);
      pstmt.setString(24, guest8);
      pstmt.setString(25, course);
      pstmt.setString(26, fb);
      pstmt.setString(27, color);
      pstmt.setString(28, guest9);
      pstmt.setString(29, guest10);
      pstmt.setString(30, guest11);
      pstmt.setString(31, guest12);
      pstmt.setString(32, guest13);
      pstmt.setString(33, guest14);
      pstmt.setString(34, guest15);
      pstmt.setString(35, guest16);
      pstmt.setString(36, guest17);
      pstmt.setString(37, guest18);
      pstmt.setString(38, guest19);
      pstmt.setString(39, guest20);
      pstmt.setString(40, guest21);
      pstmt.setString(41, guest22);
      pstmt.setString(42, guest23);
      pstmt.setString(43, guest24);
      pstmt.setString(44, guest25);
      pstmt.setString(45, guest26);
      pstmt.setString(46, guest27);
      pstmt.setString(47, guest28);
      pstmt.setString(48, guest29);
      pstmt.setString(49, guest30);
      pstmt.setString(50, guest31);
      pstmt.setString(51, guest32);
      pstmt.setString(52, guest33);
      pstmt.setString(53, guest34);
      pstmt.setString(54, guest35);
      pstmt.setString(55, guest36);
      pstmt.setString(56, per);
      pstmt.setString(57, name);
        
      pstmt.setString(58, oldName);
      pstmt.setString(59, oldCourse);

      count = pstmt.executeUpdate();     // execute the prepared stmt

      pstmt.close();
   }
   catch (Exception exc) {

      dbError(out, exc);
      return;
   }

   //
   // Database updated - inform user
   //
   out.println(SystemUtils.HeadTitle("Proshop Edit Guest Restriction"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><BR><H3>Restriction Has Been Updated</H3>");
   out.println("<BR><BR>Thank you, the restriction has been updated in the system database.");
   out.println("<BR><BR><BR>");
   out.println("<font size=\"2\">");

   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Missing or invalid data entered...
 // *********************************************************

 private void invData(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><H3>Input Error</H3><BR>");
   out.println("<BR><BR>Sorry, some data you entered is missing or invalid.<BR>");
   out.println("<BR>Please try again.<BR>");
   out.println("<br><br><font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Member Restriction already exists
 // *********************************************************

 private void dupMem(PrintWriter out) {

   out.println(SystemUtils.HeadTitle("Input Error - Redirect"));
   out.println("<BODY><CENTER><BR>");
   out.println("<p>&nbsp;</p>");
   out.println("<BR><H3>Input Error</H3><BR>");
   out.println("<BR><BR>Sorry, the <b>restriction name</b> you specified already exists in the database.<BR>");
   out.println("<BR>Please change the name to a unique value.<BR>");
   out.println("<BR><BR>");
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"javascript:history.back(1)\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</CENTER></BODY></HTML>");
 }


 // *********************************************************
 // Database Error
 // *********************************************************

 private void dbError(PrintWriter out, Exception e) {

   out.println(SystemUtils.HeadTitle("Database Error"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><BR><H3>Database Access Error</H3>");
   out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
   out.println("<BR>Please try again later.");
   out.println("<BR><BR>Exception:   " + e.getMessage());
   out.println("<BR><BR>If problem persists, contact customer support.");
   out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
   out.println("</CENTER></BODY></HTML>");
 }

}
