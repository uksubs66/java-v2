/***************************************************************************************     
 *   Member_msg:  This servlet will display a system message to all members that login.
 *
 *
 *   called by:  Login
 *
 *   created: 4/14/2003   Bob P.
 *
 *   last updated:      ****** keep this accurate *******
 *
 *       10/14/08   Brooklawn - prompt remote member to verify/change email address if it has bounced (case 1568) - on hold.
 *        6/02/08   Get member timeout value (for display) from SystemUtils.MEMBER_TIMEOUT
 *        5/09/07   Moved daysInAdv call to SystemUtils instead of Login - 
 *                  also DaysAdv array no longer put session
 *        2/15/07   Comment out the member welcome message processing as we don't need it now (save for future).
 *        1/12/07   Add mtype parm to call to Login.daysInAdv.
 *       11/16/06   Do not process MF clubs differently - always go to announce page.
 *       10/20/06   Do not display email message if AGT.
 *       11/17/05   Add message to prompt for email address if none.
 *       11/22/04   Add support for Primary-Only logins from CE.  Only the primary member resides
 *                  in their database so we must prompt for the family member.
 *        7/18/03   Enhancements for Version 3 of the software.
 *                                                               
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.DaysAdv;


public class Member_msg extends HttpServlet {
       

 String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

 //
 // Process the initial call from Login
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();


   Connection con = null;                  // init DB objects
   PreparedStatement pstmt = null;
   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyMem(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      return;
   }


   String club = (String)session.getAttribute("club");   // get user's club
   String caller = (String)session.getAttribute("caller");   // get caller (mfirst, etc.)
   String user = (String)session.getAttribute("user");   // get user's username value
   String message = ""; 
   String name = "";
   String mship = "";
   String mtype = "";
   String wc = "";
   String email = "";
   String email2 = "";
   int count = 0;
   int email_bounced = 0;
   int email2_bounced = 0;

   //
   //  If user provided in parm, then call was from Login after user prompted for actual member name.
   //  This is when the caller only has primary names in their roster and we must prompt for actual member.
   //
   if (req.getParameter("user") != null) {

      user = req.getParameter("user");
      name = req.getParameter("name");
      message = req.getParameter("message");
        
      try {

         //
         //  Get this member's info
         //
         pstmt = con.prepareStatement (
            "SELECT m_ship, m_type, email, count, wc, email2, email_bounced, email2_bounced " +
            "FROM member2b WHERE username = ?");

         pstmt.clearParameters();         // clear the parms
         pstmt.setString(1, user);        // put the username field in statement
         rs = pstmt.executeQuery();       // execute the prepared stmt

         if (rs.next()) {

            mship = rs.getString(1);       // Get mship type
            mtype = rs.getString(2);       // Get member type
            email = rs.getString(3);       // Get email addr
            count = rs.getInt(4);          // Get count
            wc = rs.getString(5);          // w/c pref
            email2 = rs.getString("email2");

            email_bounced = rs.getInt("email_bounced");       
            email2_bounced = rs.getInt("email2_bounced");
         }
           
         pstmt.close();

         count++;          // bump login counter
           
         pstmt = con.prepareStatement (
            "UPDATE member2b SET count = ?, message = ? WHERE username = ?");

         pstmt.clearParameters();           // clear the parms
         pstmt.setInt(1, count);            // put the new count in statement
         pstmt.setString(2, message);       // put in the message displayed
         pstmt.setString(3, user);          // put the username field in statement
         pstmt.executeUpdate();    

         pstmt.close();

      }
      catch (SQLException exc) {
      }

      //
      //  Count the number of users logged in
      //
      Login.countLogin("mem", con);

      //
      //  over-write the name and user fields as they could be different now
      //
      session.setAttribute("user", user);           // save username
      session.setAttribute("name", name);           // save members full name
      session.setAttribute("mship", mship);         // save member's mship type
      session.setAttribute("mtype", mtype);         // save member's mtype
      session.setAttribute("wc", wc);               // save member's w/c pref (for _slot)

      
      //
      //   If Brooklawn and email bounced - inform member
      //
    /*     on Hold!!!
      if (club.equals("brooklawn") && (email_bounced > 0 || email2_bounced > 0)) {

         out.println("<HTML><HEAD><Title>Member Login Page</Title>");
         out.println("</HEAD>");
         out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
         out.println("<hr width=\"40%\">");
         out.println("<BR><H2>Member Access Accepted</H2><BR>");
         out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"6\"><tr><td align=\"center\">");
         out.println("<font size=\"3\">");
         out.println("<BR>Welcome <b>" + name );

         out.println("</b><BR><BR>");
         out.println("Please note that this session will terminate if inactive for more than " + (SystemUtils.MEMBER_TIMEOUT / 60) + " minutes.<BR><BR>");
         out.println("</b><BR><BR>");
         out.println("<h3><b>WARNING: Email Problem!!</b></h3>");
         out.println("We recently tried to send you an email at ");

         if (email_bounced == 1) {

            out.print(email);

         } else {

            out.print(email2);
         }
         out.print(" and it bounced back to us.<br>" +
                   "We've had to temporarily disable sending you any emails until you resolve this problem.");
         out.println("<BR><BR>To correct this, update your email below, or select the 'Settings' tab from the<br>" +
                     "navigation bar on the top of most pages and follow the insructions in the email<br>" +
                     "section next to the word 'Important'.");
         out.println("<br><br>If the current email is correct, simply click 'Continue' below and ForeTees will<br>" +
                 "attempt to continue using the same email.  If you would like to remove the current email<br>" +
                 "address all together, erase it from the field below and click 'Continue'.");

         out.println("<br><br>");
         out.println("Please verify and/or change the email address(es) below.");
         out.print("<br>NOTICE: This will only change your email address in ForeTees, NOT in the website.&nbsp;&nbsp;");
         out.print("Thank you!");
         out.print("<br><br>");

         out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Login\">");
         out.println("<input type=\"hidden\" name=\"message\" value=\"\">");
         out.println("<input type=\"hidden\" name=\"bounced\" value=\"" + ((email_bounced == 1) ? "email" : "email2") + "\">");

         out.println("<b>Email Address " + ((email_bounced == 1) ? "1" : "2") + ":</b>&nbsp;&nbsp;");
         out.println("<input type=\"text\" name=\"email\" value=\"" + ((email_bounced == 1) ? email : email2) + "\" size=\"40\" maxlength=\"50\">");
         out.println("<br><br>");

         out.println("</font></td></tr></table>");
         out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</input></form></font>");
         out.println("</CENTER></BODY></HTML>");               
         out.close();

      } else {
     */
      
         //
         //  Output the response and route to system
         //
         out.println("<HTML><HEAD><Title>Member Login Page</Title>");
         if (!email.equals( "" )) {
            out.println("<meta http-equiv=\"Refresh\" content=\"1; url=/" +rev+ "/member_welcome.htm\">");
         }
         out.println("</HEAD>");
         out.println("<BODY><CENTER><img src=\"/" +rev+ "/images/foretees.gif\"><BR>");
         out.println("<hr width=\"40%\">");
         out.println("<p>&nbsp;</p>");
         out.println("<BR><H2>Member Access Accepted</H2><BR>");
         out.println("<table border=\"2\" bgcolor=\"#F5F5DC\" cellpadding=\"6\"><tr><td align=\"center\">");
         out.println("<BR>Welcome <b>" + name );
         out.println("</b><BR><BR>");
         out.println("Please note that this session will terminate if inactive for more than " + (SystemUtils.MEMBER_TIMEOUT / 60) + " minutes.<BR><BR>");

         if (email.equals( "" ) && !caller.equals( "MEMFIRST" )) {
            out.println("In order for us to send email notifcations when you make or change tee times, you must provide a current, ");
            out.println("working email address.");
            out.println("<br><br>");
            out.println("To provide your email address, click on the <b>'Settings'</b> tab in the navigation bar on top of the next page.");
            out.println("<br><br>");
            out.println("Thank you!");
         }
         out.println("</td></tr></table><br>");
         out.println("<br><br><font size=\"2\">");
         out.println("<form method=\"get\" action=\"/" + rev + "/member_welcome.htm\">");
         out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</input></form></font>");
         out.println("</CENTER></BODY></HTML>");
         out.close();
      //  }

   } else {

      //
      // use the username to get the member's record
      //
      try {

         pstmt = con.prepareStatement (
            "SELECT email, message " +
            "FROM member2b WHERE username = ?");

         pstmt.clearParameters();         // clear the parms
         pstmt.setString(1, user);        // put the username field in statement
         rs = pstmt.executeQuery();       // execute the prepared stmt

         if (rs.next()) {

            email = rs.getString(1);         // email addr
            message = rs.getString(2);       // Get last message displayed at login
         }

      }
      catch (SQLException exc) {
      }

      //
      //   Display the message
      //
      out.println("<HTML>");
      out.println("<HEAD>");
         out.println("<link rel=\"stylesheet\" href=\"/" +rev+ "/web utilities/foretees2.css\" type=\"text/css\"></link>");
         out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">");
         out.println("<meta http-equiv=\"Content-Language\" content=\"en-us\">");
         out.println("<title>\"ForeTees Message Page\"</title>");
      out.println("</head>");

      out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
      out.println("<font face=\"Arial, Helvetica, Sans-serif\">");
      out.println("<CENTER>");

/*
      if (message.equalsIgnoreCase( "msg001" ) || (email.equals( "" ) && !caller.equals( "MEMFIRST" ))) {

         out.println("<table border=\"0\" cellpadding=\"5\" width=\"650\">");
         out.println("<tr>");
         out.println("<td align=\"center\">");
            out.println("<img src=\"/" +rev+ "/images/foretees.gif\" border=0><br><br>");
            out.println("<H2>Notice From ForeTees</H2>");
            out.println("<font size=\"4\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<p><u>Please Read</u></p>");
            out.println("</font>");
            out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\">");
            out.println("<p>");

               out.println("In order for us to send email notifcations when you make or change tee times, you must provide a current, ");
               out.println("working email address.");
               out.println("<br><br>");
               out.println("To provide your email address, click on the <b>'Settings'</b> tab in the navigation bar on top of the next page.");
               out.println("<br><br>");
               out.println("If your email address has already been entered, please verify that it is current and correct.");
               out.println("<br><br>");
               out.println("Thank you!");
            out.println("</p>");
            out.println("</font>");
         out.println("</td>");
         out.println("</tr>");
         out.println("</table>");
      }
*/

      out.println("<br>");
      out.println("<table border=\"0\" cols=\"1\">");
         out.println("<tr>");
         out.println("<td width=\"150\" align=\"center\">");
            out.println("<font size=\"2\">");
            out.println("<form method=\"get\" action=\"/" + rev + "/member_welcome.htm\">");
            out.println("<input type=\"submit\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
            out.println("</input></form></font>");
         out.println("</td>");
         out.println("</tr>");
      out.println("</table>");
      out.println("</center></font></body></html>");
      out.close();
    }        
 }

}
