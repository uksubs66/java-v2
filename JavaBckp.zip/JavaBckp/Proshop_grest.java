/***************************************************************************************     
 *   Proshop_grest:  This servlet will process the 'Guest Restrictions' request from
 *                    the Proshop's Config page.
 *
 *
 *   called by:  proshop menu (to doGet) and Proshop_grest (to doPost from HTML built here)
 *
 *   created: 1/02/2002   Bob P.
 *
 *   last updated:
 *
 *       10/23/08   Add restriction suspension processing (display, add/edit/delete)
 *        8/15/08   Add more years to the start and end dates until we come up with a better method.
 *        8/12/08   Update to limited access user restrictions
 *        7/24/08   Added limited access proshop users checks
 *        1/24/05   Ver 5 - change club2 to club5.
 *       11/15/04   Ver 5 - Add 'Make Copy' option to allow pro to copy an existing rest.
 *        9/18/04   Ver 5 - Change getClub from SystemUtils to common.
 *        3/01/04   Add option to specify Number of Guests per Member or Tee Time.
 *        7/18/03   Enhancements for Version 3 of the software.
 *        9/18/02   Enhancements for Version 2 of the software.
 *
 *
 ***************************************************************************************
 */
    
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

// foretees imports
import com.foretees.common.parmClub;
import com.foretees.common.getClub;

public class Proshop_grest extends HttpServlet {

    
   String zero = "00";
   String rev = SystemUtils.REVLEVEL;       // Software Revision Level (Version)

  
 //**************************************************
 // Process the initial request from Proshop_main
 //**************************************************
 //
 public void doGet(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {
           
   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();
        
   Statement stmt = null;
   ResultSet rs = null;

   HttpSession session = SystemUtils.verifyPro(req, out);             // check for intruder

   if (session == null) {
     
      return;
   }

   Connection con = SystemUtils.getCon(session);                      // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }
   
   // Check Feature Access Rights for current proshop user
   if (!SystemUtils.verifyProAccess(req, "SYSCONFIG_RESTRICTIONS", con, out)) {
       SystemUtils.restrictProshop("SYSCONFIG_RESTRICTIONS", out);
   }
     
   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   //
   //  Check if call is to copy an existing restriction
   //
   if (req.getParameter("copy") != null) {

      doCopy(req, out, con, lottery);        // process the copy request
      return;
   }
   
   if (req.getParameter("susp") != null) {
       
      printSuspensions(req, con, out);       // This is a suspension request (printSuspensions)
      return;
   }
   

   //
   // Define some parms to use in the html
   //
   String name = "";       // name of restriction
   int id = 0;             // restriction id
   int s_hour = 0;         // start time hr
   int s_min = 0;          // start time min
   int e_hour = 0;         // end time hr
   int e_min = 0;          // end time min
   int s_year = 0;         // start year
   int s_month = 0;        // start month
   int s_day = 0;          // start day
   int e_year = 0;         // end year
   int e_month = 0;        // end month
   int e_day = 0;          // end day
   int guests = 0;         // # of guests
   int multi = 0;
       
   String courseName = ""; // name of course
   String fb = "";         // Front/back Indicator
   String s_ampm = "";
   String e_ampm = "";
   String color = "";      // color for restriction displays
   String per = "";

   boolean b = false;

   //
   //  First, see if multi courses for this club
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT multi " +
                             "FROM club5");
      if (rs.next()) {
         multi = rs.getInt(1);
      }
      stmt.close();
   }
   catch (Exception ignore) {
   }

   //
   //  Build the HTML page to display the existing restrictions
   //
   out.println(SystemUtils.HeadTitle("Proshop Guest Restrictions Page"));
   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");

      out.println("<table cellpadding=\"5\" border=\"0\" bgcolor=\"#336633\">");
      out.println("<tr><td align=\"center\">");
      out.println("<font color=\"#FFFFFF\" size=\"3\">");
      out.println("<b>Guest Restrictions</b><br>");
      out.println("</font>");
      out.println("<font color=\"#FFFFFF\" size=\"2\">");
      out.println("<br>To change or remove a restriction, click on the Select button within the restriction.");

      out.println("<br>");
      out.println("</font></td></tr></table><br><br>");

      out.println("<table border=\"2\" cellpadding=\"5\"><tr bgcolor=\"#8B8970\">");
      if (multi != 0) {           // if multiple courses supported for this club
         out.println("<td colspan=\"10\" align=\"center\">");
      } else {
         out.println("<td colspan=\"9\" align=\"center\">");
      }
      out.println("<font size=\"2\">");
      out.println("<p align=\"center\"><b>Active Guest Restrictions</b></p>");
      out.println("</font></td></tr>");
      out.println("<tr bgcolor=\"#8B8970\"><td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Restriction Name</b></p>");
      out.println("</font></td>");
      if (multi != 0) {
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p><b>Course</b></p>");
         out.println("</font></td>");
      }
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Tees</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Start Date</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>End Date</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Start Time</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>End Time</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b># of Guests</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p><b>Per</b></p>");
      out.println("</font></td>");
      out.println("<td align=\"center\">");
      out.println("<font size=\"2\"><p>&nbsp;</p>");      // empty for select button
      out.println("</font></td></tr>");

   //
   //  Get and display the existing restrictions (one table row per restriction)
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT * FROM guestres2 ORDER BY name");

      while (rs.next()) {

         b = true;                     // indicate restrictions exist

         id = rs.getInt("id");
         name = rs.getString("name");
         s_month = rs.getInt("start_mm");
         s_day = rs.getInt("start_dd");
         s_year = rs.getInt("start_yy");
         s_hour = rs.getInt("start_hr");
         s_min = rs.getInt("start_min");
         e_month = rs.getInt("end_mm");
         e_day = rs.getInt("end_dd");
         e_year = rs.getInt("end_yy");
         e_hour = rs.getInt("end_hr");
         e_min = rs.getInt("end_min");
         guests = rs.getInt("num_guests");
         courseName = rs.getString("courseName");
         fb = rs.getString("fb");
         color = rs.getString("color");
         per = rs.getString("per");

         //
         //  some values must be converted for display
         //
         s_ampm = " AM";         // default to AM
         if (s_hour > 12) {
            s_ampm = " PM";
            s_hour = s_hour - 12;                // convert to 12 hr clock value
         }

         if (s_hour == 12) {
            s_ampm = " PM";
         }

         e_ampm = " AM";         // default to AM
         if (e_hour > 12) {
            e_ampm = " PM";
            e_hour = e_hour - 12;                  // convert to 12 hr clock value
         }

         if (e_hour == 12) {
            e_ampm = " PM";
         }

         if (!color.equals( "" )) {        // if specified (hotels only)

            if (color.equals( "Default" )) {

               out.println("<tr bgcolor=\"#F5F5DC\">");
            } else {
               out.println("<tr bgcolor=\"" + color + "\">");
            }
         } else {
            out.println("<tr bgcolor=\"#F5F5DC\">");
         }
         out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_grest\" target=\"bot\">");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +name+ "</p>");
         out.println("</font></td>");
         if (multi != 0) {
            out.println("<td align=\"center\">");
            out.println("<font size=\"2\"><p>" +courseName+ "</b></p>");
            out.println("</font></td>");
         }
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +fb+ "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +s_month+ "/" + s_day + "/" + s_year + "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +e_month+ "/" + e_day + "/" + e_year + "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         if (s_min < 10) {
            out.println("<font size=\"2\"><p>" + s_hour + ":0" + s_min + "  " + s_ampm + "</p>");
         } else {
            out.println("<font size=\"2\"><p>" + s_hour + ":" + s_min + "  " + s_ampm + "</p>");
         }
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         if (e_min < 10) {
            out.println("<font size=\"2\"><p>" + e_hour + ":0" + e_min + "  " + e_ampm + "</b></p>");
         } else {
            out.println("<font size=\"2\"><p>" + e_hour + ":" + e_min + "  " + e_ampm + "</b></p>");
         }
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +guests+ "</p>");
         out.println("</font></td>");
         out.println("<td align=\"center\">");
         out.println("<font size=\"2\"><p>" +per+ "</p>");
         out.println("</font></td>");

         out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");       // pass the restriction id
         out.println("<input type=\"hidden\" maxlength=\"30\" name=\"name\" value=\"" + name + "\">");    // must pass whole name!!!!
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
         out.println("<td align=\"center\">");
         out.println("<p>");
         out.println("<input type=\"submit\" value=\"Select\">");
         out.println("</td></form></tr>");

      }  // end of while loop

      stmt.close();

      if (!b) {
        
         out.println("<p>No Guest Restrictions Currently Exist</p>");
      }
   }
   catch (Exception e2) {

      out.println("<BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR><BR>Exception: " + e2);
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");

   }  // end of try

   //
   //  End of HTML page
   //
   out.println("</table></font>");                   // end of grest table
   out.println("</td></tr></table>");                // end of main page table

   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_announce\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
  
   out.println("</center></font></body></html>");



 }  // end of doGet

 //
 //****************************************************************
 // Process the form request from Proshop_grest page displayed above.
 //
 // Use the name provided to locate the restriction record and then display
 // the record to the user and prompt for edit or delete action. 
 //
 //****************************************************************
 //
 public void doPost(HttpServletRequest req, HttpServletResponse resp)
         throws ServletException, IOException {

   resp.setContentType("text/html");
   PrintWriter out = resp.getWriter();

   Statement stmt = null;
   ResultSet rs = null;
     
   String [] month_table = { "inv", "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
                             "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

   HttpSession session = SystemUtils.verifyPro(req, out);       // check for intruder

   if (session == null) {

      return;
   }

   Connection con = SystemUtils.getCon(session);            // get DB connection

   if (con == null) {

      out.println(SystemUtils.HeadTitle("DB Connection Error"));
      out.println("<BODY><CENTER><BR>");
      out.println("<BR><BR><H3>Database Connection Error</H3>");
      out.println("<BR><BR>Unable to connect to the Database.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR>");
      out.println("<a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
      out.println("</CENTER></BODY></HTML>");
      return;
   }

   // Check Feature Access Rights for current proshop user
   if (!SystemUtils.verifyProAccess(req, "SYSCONFIG_RESTRICTIONS", con, out)) {
       SystemUtils.restrictProshop("SYSCONFIG_RESTRICTIONS", out);
   }
     
   //
   // Get the name parameter from the hidden input field
   //
   String name = req.getParameter("name");  

   //
   //  Scan name for special characters and replace with HTML supported chars (i.e. '>' = &gt)
   //
   //  *** 3/31/04 Do not do this as the name is received from the db via a hidden parm and therefore is not changed.
   //  *** do it below if query fails!!!
   //
//   name = SystemUtils.filter(name);
   String oldName = name;                // save original event name

   boolean copy = false;

   int id = 0;
   long s_date = 0;
   long e_date = 0;
   int s_year = 0;
   int s_month = 0;
   int s_day = 0;
   int e_year = 0;
   int e_month = 0;
   int e_day = 0;
   int shr = 0;
   int smin = 0;
   int ehr = 0;
   int emin = 0;
   int guests = 0;
   int multi = 0;        // multiple course support option
   int index = 0;
   int hotel = 0;
   int i = 0;
   int i2 = 0;

   String templott = (String)session.getAttribute("lottery");        // get lottery support indicator
   int lottery = Integer.parseInt(templott);

   String recur = "";
   String fb = "";
   String courseName = "";
   String courseName2 = "";
   String color = "";
   String per = "";

   if (req.getParameter("course") != null) {

      courseName = req.getParameter("course");
   }

   String oldCourse = courseName;        // save course name in case it changes

   //
   //  parm block to hold the club parameters
   //
   parmClub parm = new parmClub();          // allocate a parm block

   try {

      getClub.getParms(con, parm);        //  get the club parameters (multi, guest types, hotel)
   }
   catch (Exception exc) {
   }

   //
   //  Arrays to hold the course names and guest types
   //
   String [] course = new String [20];                      // max of 20 courses per club
   String [] resguest = new String [parm.MAX_Guests];       // max of 36 guest types per restriction

   if (req.getParameter("susp") != null) {
       
      printSuspensions(req, con, out);       // This is a suspension request (printSuspensions)
      return;
   }
   
   if (req.getParameter("copy") != null) {

      copy = true;            // this is a copy request (from doCopy below)
   }

   //
   // Get the restriction from the restriction table
   //
   try {

      PreparedStatement pstmt = con.prepareStatement (
               "SELECT * FROM guestres2 WHERE name = ?");

      pstmt.clearParameters();        // clear the parms
      pstmt.setString(1, name);       // put the parm in stmt
      rs = pstmt.executeQuery();      // execute the prepared stmt

      if (rs.next()) {

         //
         //  Found the restriction record - get it
         //
         id = rs.getInt("id");
         s_date = rs.getLong("sdate");
         s_month = rs.getInt("start_mm");
         s_day = rs.getInt("start_dd");
         s_year = rs.getInt("start_yy");
         shr = rs.getInt("start_hr");
         smin = rs.getInt("start_min");
         e_date = rs.getLong("edate");
         e_month = rs.getInt("end_mm");
         e_day = rs.getInt("end_dd");
         e_year = rs.getInt("end_yy");
         ehr = rs.getInt("end_hr");
         emin = rs.getInt("end_min");
         recur = rs.getString("recurr");
         guests = rs.getInt("num_guests");
         resguest[0] = rs.getString("guest1");
         resguest[1] = rs.getString("guest2");
         resguest[2] = rs.getString("guest3");
         resguest[3] = rs.getString("guest4");
         resguest[4] = rs.getString("guest5");
         resguest[5] = rs.getString("guest6");
         resguest[6] = rs.getString("guest7");
         resguest[7] = rs.getString("guest8");
         courseName = rs.getString("courseName");
         fb = rs.getString("fb");
         color = rs.getString("color");
         resguest[8] = rs.getString("guest9");
         resguest[9] = rs.getString("guest10");
         resguest[10] = rs.getString("guest11");
         resguest[11] = rs.getString("guest12");
         resguest[12] = rs.getString("guest13");
         resguest[13] = rs.getString("guest14");
         resguest[14] = rs.getString("guest15");
         resguest[15] = rs.getString("guest16");
         resguest[16] = rs.getString("guest17");
         resguest[17] = rs.getString("guest18");
         resguest[18] = rs.getString("guest19");
         resguest[19] = rs.getString("guest20");
         resguest[20] = rs.getString("guest21");
         resguest[21] = rs.getString("guest22");
         resguest[22] = rs.getString("guest23");
         resguest[23] = rs.getString("guest24");
         resguest[24] = rs.getString("guest25");
         resguest[25] = rs.getString("guest26");
         resguest[26] = rs.getString("guest27");
         resguest[27] = rs.getString("guest28");
         resguest[28] = rs.getString("guest29");
         resguest[29] = rs.getString("guest30");
         resguest[30] = rs.getString("guest31");
         resguest[31] = rs.getString("guest32");
         resguest[32] = rs.getString("guest33");
         resguest[33] = rs.getString("guest34");
         resguest[34] = rs.getString("guest35");
         resguest[35] = rs.getString("guest36");
         per = rs.getString("per");

      } else {      // not found - try filtering the name

         name = SystemUtils.filter(name);
         oldName = name;                 // save original name

         pstmt.clearParameters();        // clear the parms
         pstmt.setString(1, name);       // put the parm in stmt
         rs = pstmt.executeQuery();      // execute the prepared stmt

         if (rs.next()) {

            //
            //  Found the restriction record - get it
            //
            id = rs.getInt("id");
            s_date = rs.getLong("sdate");
            s_month = rs.getInt("start_mm");
            s_day = rs.getInt("start_dd");
            s_year = rs.getInt("start_yy");
            shr = rs.getInt("start_hr");
            smin = rs.getInt("start_min");
            e_date = rs.getLong("edate");
            e_month = rs.getInt("end_mm");
            e_day = rs.getInt("end_dd");
            e_year = rs.getInt("end_yy");
            ehr = rs.getInt("end_hr");
            emin = rs.getInt("end_min");
            recur = rs.getString("recurr");
            guests = rs.getInt("num_guests");
            resguest[0] = rs.getString("guest1");
            resguest[1] = rs.getString("guest2");
            resguest[2] = rs.getString("guest3");
            resguest[3] = rs.getString("guest4");
            resguest[4] = rs.getString("guest5");
            resguest[5] = rs.getString("guest6");
            resguest[6] = rs.getString("guest7");
            resguest[7] = rs.getString("guest8");
            courseName = rs.getString("courseName");
            fb = rs.getString("fb");
            color = rs.getString("color");
            resguest[8] = rs.getString("guest9");
            resguest[9] = rs.getString("guest10");
            resguest[10] = rs.getString("guest11");
            resguest[11] = rs.getString("guest12");
            resguest[12] = rs.getString("guest13");
            resguest[13] = rs.getString("guest14");
            resguest[14] = rs.getString("guest15");
            resguest[15] = rs.getString("guest16");
            resguest[16] = rs.getString("guest17");
            resguest[17] = rs.getString("guest18");
            resguest[18] = rs.getString("guest19");
            resguest[19] = rs.getString("guest20");
            resguest[20] = rs.getString("guest21");
            resguest[21] = rs.getString("guest22");
            resguest[22] = rs.getString("guest23");
            resguest[23] = rs.getString("guest24");
            resguest[24] = rs.getString("guest25");
            resguest[25] = rs.getString("guest26");
            resguest[26] = rs.getString("guest27");
            resguest[27] = rs.getString("guest28");
            resguest[28] = rs.getString("guest29");
            resguest[29] = rs.getString("guest30");
            resguest[30] = rs.getString("guest31");
            resguest[31] = rs.getString("guest32");
            resguest[32] = rs.getString("guest33");
            resguest[33] = rs.getString("guest34");
            resguest[34] = rs.getString("guest35");
            resguest[35] = rs.getString("guest36");
            per = rs.getString("per");
         }
      }
      pstmt.close();              // close the stmt

      multi = parm.multi;
      hotel = parm.hotel;

      if (multi != 0) {
         //
         //  Multiple courses - get the names for later
         //
         index = 0;

         while (index< 20) {

            course[index] = "";       // init the course array
            index++;
         }
         index = 0;

         //
         //  Get the names of all courses for this club
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT courseName " +
                                "FROM clubparm2 WHERE first_hr != 0");

         while (rs.next() && index < 20) {

            courseName2 = rs.getString(1);

            course[index] = courseName2;      // add course name to array
            index++;
         }
         stmt.close();
      }
   }                                         
   catch (Exception exc) {

      dbError(out, exc);
      return;
   }

   String ssampm = "AM";     // AM or PM for display (start hour)
   String seampm = "AM";     // AM or PM for display (end hour)
   int sampm = 0;
   int eampm = 0;

   if (shr > 12) {
      
      shr = shr - 12;        // convert to 12 hour value
      ssampm = "PM";         // indicate PM
      sampm = 12;
   }

   if (shr == 12) {
      ssampm = "PM";         // indicate PM
   }

   if (ehr > 12) {

      ehr = ehr - 12;        // convert to 12 hour value
      seampm = "PM";         // indicate PM
      eampm = 12;
   }

   if (ehr == 12) {
      seampm = "PM";         // indicate PM
   }

   String alphaSmonth = month_table[s_month];  // get name for start month
   String alphaEmonth = month_table[e_month];  // get name for end month

   //
   // Database record found - output an edit page
   //
   out.println(SystemUtils.HeadTitle("Proshop Edit Guest Restriction"));

   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font size=\"2\" face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");
              
         out.println("<table cellpadding=\"5\" border=\"1\" bgcolor=\"#336633\" align=\"center\">");
         out.println("<tr><td align=\"center\">");
         out.println("<font color=\"#FFFFFF\" size=\"2\">");
           
         if (copy == false) {
            out.println("<b>Edit Guest Restriction</b><br>");
            out.println("<br>Change the desired information for the restriction below.");
            out.println("<br>Click on <b>Update</b> to submit the changes.");
            out.println("<br>Click on <b>Remove</b> to delete the restriction.");
         } else {
            out.println("<b>Copy Guest Restriction</b><br>");
            out.println("<br>Change the desired information for the restriction below.<br>");
            out.println("Click on <b>Add</b> to create the new restriction.");
            out.println("<br><br><b>NOTE:</b> You must change the name of the restriction.");
         }
         out.println("</font></td></tr></table><br>");

         out.println("<font size=\"2\">");
         out.println("<table border=\"0\" align=\"center\"><tr><td>");
         out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
         out.println("<input type=\"submit\" value=\"Cancel\"style=\"text-decoration:underline; background:#8B8970;\">");
         out.println("</td></tr></table>");
         out.println("</input></form>");
         out.println("</font>");
      
         out.println("<table border=\"1\" bgcolor=\"#F5F5DC\">");
            if (copy == true) {
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_addgrest\" method=\"post\" target=\"bot\">");
               out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");
            } else {
               out.println("<form action=\"/" +rev+ "/servlet/Proshop_editgrest\" method=\"post\" target=\"bot\">");
            }
            
            out.println("<input type=\"hidden\" name=\"grest_id\" value=\"" + id + "\">");
         
            out.println("<tr><td width=\"500\">");
               out.println("<font size=\"2\">");
               out.println("<p align=\"left\">&nbsp;&nbsp;Restriction name:&nbsp;&nbsp;&nbsp;");
               out.println("<input type=\"text\" name=\"rest_name\" value=\"" +name+ "\" size=\"30\" maxlength=\"30\">");
               if (copy == false) {
                  out.println("</input><br>&nbsp;&nbsp;&nbsp;* Must be unique");
               } else {
                  out.println("</input><br>&nbsp;&nbsp;&nbsp;* Must be changed!!");
               }
               out.println("<br><br>");

            if (multi != 0) {

               out.println("&nbsp;&nbsp;Select a Course:&nbsp;&nbsp;");
               out.println("<select size=\"1\" name=\"course\">");

               if (courseName.equals( "-ALL-" )) {             // if same as existing name

                  out.println("<option selected value=\"-ALL-\">ALL</option>");
               } else {
                  out.println("<option value=\"-ALL-\">ALL</option>");
               }
               index = 0;
               courseName2 = course[index];      // get course name from array

               while ((!courseName2.equals( "" )) && (index < 20)) {

                  if (courseName2.equals( courseName )) {             // if same as existing name

                     out.println("<option selected value=\"" + courseName + "\">" + courseName + "</option>");
                  } else {
                     out.println("<option value=\"" + courseName2 + "\">" + courseName2 + "</option>");
                  }
                  index++;
                  courseName2 = course[index];      // get course name from array
               }
               out.println("</select>");
               out.println("<br><br>");

            } else {

               out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
            }
              out.println("&nbsp;&nbsp;Tees:&nbsp;&nbsp;");
                out.println("<select size=\"1\" name=\"fb\">");
                if (fb.equals( "Both" )) {
                   out.println("<option selected value=\"Both\">Both</option>");
                } else {
                   out.println("<option value=\"Both\">Both</option>");
                }
                if (fb.equals( "Front" )) {
                   out.println("<option selected value=\"Front\">Front</option>");
                } else {
                   out.println("<option value=\"Front\">Front</option>");
                }
                if (fb.equals( "Back" )) {
                   out.println("<option selected value=\"Back\">Back</option>");
                } else {
                   out.println("<option value=\"Back\">Back</option>");
                }
              out.println("</select><br><br>");

                  out.println("&nbsp;&nbsp;Start Date:&nbsp;&nbsp;&nbsp;");
                    out.println("Month:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"smonth\">");
                   if (s_month == 1) {
                      out.println("<option selected value=\"01\">JAN</option>");
                   } else {
                      out.println("<option value=\"01\">JAN</option>");
                   }
                   if (s_month == 2) {
                      out.println("<option selected value=\"02\">FEB</option>");
                   } else {
                      out.println("<option value=\"02\">FEB</option>");
                   }
                   if (s_month == 3) {
                      out.println("<option selected value=\"03\">MAR</option>");
                   } else {
                      out.println("<option value=\"03\">MAR</option>");
                   }
                   if (s_month == 4) {
                      out.println("<option selected value=\"04\">APR</option>");
                   } else {
                      out.println("<option value=\"04\">APR</option>");
                   }
                   if (s_month == 5) {
                      out.println("<option selected value=\"05\">MAY</option>");
                   } else {
                      out.println("<option value=\"05\">MAY</option>");
                   }
                   if (s_month == 6) {
                      out.println("<option selected value=\"06\">JUN</option>");
                   } else {
                      out.println("<option value=\"06\">JUN</option>");
                   }
                   if (s_month == 7) {
                      out.println("<option selected value=\"07\">JUL</option>");
                   } else {
                      out.println("<option value=\"07\">JUL</option>");
                   }
                   if (s_month == 8) {
                      out.println("<option selected value=\"08\">AUG</option>");
                   } else {
                      out.println("<option value=\"08\">AUG</option>");
                   }
                   if (s_month == 9) {
                      out.println("<option selected value=\"09\">SEP</option>");
                   } else {
                      out.println("<option value=\"09\">SEP</option>");
                   }
                   if (s_month == 10) {
                      out.println("<option selected value=\"10\">OCT</option>");
                   } else {
                      out.println("<option value=\"10\">OCT</option>");
                   }
                   if (s_month == 11) {
                      out.println("<option selected value=\"11\">NOV</option>");
                   } else {
                      out.println("<option value=\"11\">NOV</option>");
                   }
                   if (s_month == 12) {
                      out.println("<option selected value=\"12\">DEC</option>");
                   } else {
                      out.println("<option value=\"12\">DEC</option>");
                   }
                    out.println("</select>");

                    out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"sday\">");
                   if (s_day == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (s_day == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (s_day == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (s_day == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (s_day == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (s_day == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (s_day == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (s_day == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (s_day == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (s_day == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (s_day == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (s_day == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                   if (s_day == 13) {
                      out.println("<option selected value=\"13\">13</option>");
                   } else {
                      out.println("<option value=\"13\">13</option>");
                   }
                   if (s_day == 14) {
                      out.println("<option selected value=\"14\">14</option>");
                   } else {
                      out.println("<option value=\"14\">14</option>");
                   }
                   if (s_day == 15) {
                      out.println("<option selected value=\"15\">15</option>");
                   } else {
                      out.println("<option value=\"15\">15</option>");
                   }
                   if (s_day == 16) {
                      out.println("<option selected value=\"16\">16</option>");
                   } else {
                      out.println("<option value=\"16\">16</option>");
                   }
                   if (s_day == 17) {
                      out.println("<option selected value=\"17\">17</option>");
                   } else {
                      out.println("<option value=\"17\">17</option>");
                   }
                   if (s_day == 18) {
                      out.println("<option selected value=\"18\">18</option>");
                   } else {
                      out.println("<option value=\"18\">18</option>");
                   }
                   if (s_day == 19) {
                      out.println("<option selected value=\"19\">19</option>");
                   } else {
                      out.println("<option value=\"19\">19</option>");
                   }
                   if (s_day == 20) {
                      out.println("<option selected value=\"20\">20</option>");
                   } else {
                      out.println("<option value=\"20\">20</option>");
                   }
                   if (s_day == 21) {
                      out.println("<option selected value=\"21\">21</option>");
                   } else {
                      out.println("<option value=\"21\">21</option>");
                   }
                   if (s_day == 22) {
                      out.println("<option selected value=\"22\">22</option>");
                   } else {
                      out.println("<option value=\"22\">22</option>");
                   }
                   if (s_day == 23) {
                      out.println("<option selected value=\"23\">23</option>");
                   } else {
                      out.println("<option value=\"23\">23</option>");
                   }
                   if (s_day == 24) {
                      out.println("<option selected value=\"24\">24</option>");
                   } else {
                      out.println("<option value=\"24\">24</option>");
                   }
                   if (s_day == 25) {
                      out.println("<option selected value=\"25\">25</option>");
                   } else {
                      out.println("<option value=\"25\">25</option>");
                   }
                   if (s_day == 26) {
                      out.println("<option selected value=\"26\">26</option>");
                   } else {
                      out.println("<option value=\"26\">26</option>");
                   }
                   if (s_day == 27) {
                      out.println("<option selected value=\"27\">27</option>");
                   } else {
                      out.println("<option value=\"27\">27</option>");
                   }
                   if (s_day == 28) {
                      out.println("<option selected value=\"28\">28</option>");
                   } else {
                      out.println("<option value=\"28\">28</option>");
                   }
                   if (s_day == 29) {
                      out.println("<option selected value=\"29\">29</option>");
                   } else {
                      out.println("<option value=\"29\">29</option>");
                   }
                   if (s_day == 30) {
                      out.println("<option selected value=\"30\">30</option>");
                   } else {
                      out.println("<option value=\"30\">30</option>");
                   }
                   if (s_day == 31) {
                      out.println("<option selected value=\"31\">31</option>");
                   } else {
                      out.println("<option value=\"31\">31</option>");
                   }
                    out.println("</select>");

                    out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"syear\">");
                   if (s_year == 2002) {
                      out.println("<option selected value=\"2002\">2002</option>");
                   } else {
                      out.println("<option value=\"2002\">2002</option>");
                   }
                   if (s_year == 2003) {
                      out.println("<option selected value=\"2003\">2003</option>");
                   } else {
                      out.println("<option value=\"2003\">2003</option>");
                   }
                   if (s_year == 2004) {
                      out.println("<option selected value=\"2004\">2004</option>");
                   } else {
                      out.println("<option value=\"2004\">2004</option>");
                   }
                   if (s_year == 2005) {
                      out.println("<option selected value=\"2005\">2005</option>");
                   } else {
                      out.println("<option value=\"2005\">2005</option>");
                   }
                   if (s_year == 2006) {
                      out.println("<option selected value=\"2006\">2006</option>");
                   } else {
                      out.println("<option value=\"2006\">2006</option>");
                   }
                   if (s_year == 2007) {
                      out.println("<option selected value=\"2007\">2007</option>");
                   } else {
                      out.println("<option value=\"2007\">2007</option>");
                   }
                   if (s_year == 2008) {
                      out.println("<option selected value=\"2008\">2008</option>");
                   } else {
                      out.println("<option value=\"2008\">2008</option>");
                   }
                   if (s_year == 2009) {
                      out.println("<option selected value=\"2009\">2009</option>");
                   } else {
                      out.println("<option value=\"2009\">2009</option>");
                   }
                   if (s_year == 2010) {
                      out.println("<option selected value=\"2010\">2010</option>");
                   } else {
                      out.println("<option value=\"2010\">2010</option>");
                   }
                   if (s_year == 2011) {
                      out.println("<option selected value=\"2011\">2011</option>");
                   } else {
                      out.println("<option value=\"2011\">2011</option>");
                   }
                   if (s_year == 2012) {
                      out.println("<option selected value=\"2012\">2012</option>");
                   } else {
                      out.println("<option value=\"2012\">2012</option>");
                   }
                   if (s_year == 2013) {
                      out.println("<option selected value=\"2013\">2013</option>");
                   } else {
                      out.println("<option value=\"2013\">2013</option>");
                   }
                   if (s_year == 2014) {
                      out.println("<option selected value=\"2014\">2014</option>");
                   } else {
                      out.println("<option value=\"2014\">2014</option>");
                   }
                    out.println("</select><br><br>");
                  out.println("&nbsp;&nbsp;End Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                    out.println("Month:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"emonth\">");
                   if (e_month == 1) {
                      out.println("<option selected value=\"01\">JAN</option>");
                   } else {
                      out.println("<option value=\"01\">JAN</option>");
                   }
                   if (e_month == 2) {
                      out.println("<option selected value=\"02\">FEB</option>");
                   } else {
                      out.println("<option value=\"02\">FEB</option>");
                   }
                   if (e_month == 3) {
                      out.println("<option selected value=\"03\">MAR</option>");
                   } else {
                      out.println("<option value=\"03\">MAR</option>");
                   }
                   if (e_month == 4) {
                      out.println("<option selected value=\"04\">APR</option>");
                   } else {
                      out.println("<option value=\"04\">APR</option>");
                   }
                   if (e_month == 5) {
                      out.println("<option selected value=\"05\">MAY</option>");
                   } else {
                      out.println("<option value=\"05\">MAY</option>");
                   }
                   if (e_month == 6) {
                      out.println("<option selected value=\"06\">JUN</option>");
                   } else {
                      out.println("<option value=\"06\">JUN</option>");
                   }
                   if (e_month == 7) {
                      out.println("<option selected value=\"07\">JUL</option>");
                   } else {
                      out.println("<option value=\"07\">JUL</option>");
                   }
                   if (e_month == 8) {
                      out.println("<option selected value=\"08\">AUG</option>");
                   } else {
                      out.println("<option value=\"08\">AUG</option>");
                   }
                   if (e_month == 9) {
                      out.println("<option selected value=\"09\">SEP</option>");
                   } else {
                      out.println("<option value=\"09\">SEP</option>");
                   }
                   if (e_month == 10) {
                      out.println("<option selected value=\"10\">OCT</option>");
                   } else {
                      out.println("<option value=\"10\">OCT</option>");
                   }
                   if (e_month == 11) {
                      out.println("<option selected value=\"11\">NOV</option>");
                   } else {
                      out.println("<option value=\"11\">NOV</option>");
                   }
                   if (e_month == 12) {
                      out.println("<option selected value=\"12\">DEC</option>");
                   } else {
                      out.println("<option value=\"12\">DEC</option>");
                   }
                    out.println("</select>");

                    out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"eday\">");
                   if (e_day == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (e_day == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (e_day == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (e_day == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (e_day == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (e_day == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (e_day == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (e_day == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (e_day == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (e_day == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (e_day == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (e_day == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                   if (e_day == 13) {
                      out.println("<option selected value=\"13\">13</option>");
                   } else {
                      out.println("<option value=\"13\">13</option>");
                   }
                   if (e_day == 14) {
                      out.println("<option selected value=\"14\">14</option>");
                   } else {
                      out.println("<option value=\"14\">14</option>");
                   }
                   if (e_day == 15) {
                      out.println("<option selected value=\"15\">15</option>");
                   } else {
                      out.println("<option value=\"15\">15</option>");
                   }
                   if (e_day == 16) {
                      out.println("<option selected value=\"16\">16</option>");
                   } else {
                      out.println("<option value=\"16\">16</option>");
                   }
                   if (e_day == 17) {
                      out.println("<option selected value=\"17\">17</option>");
                   } else {
                      out.println("<option value=\"17\">17</option>");
                   }
                   if (e_day == 18) {
                      out.println("<option selected value=\"18\">18</option>");
                   } else {
                      out.println("<option value=\"18\">18</option>");
                   }
                   if (e_day == 19) {
                      out.println("<option selected value=\"19\">19</option>");
                   } else {
                      out.println("<option value=\"19\">19</option>");
                   }
                   if (e_day == 20) {
                      out.println("<option selected value=\"20\">20</option>");
                   } else {
                      out.println("<option value=\"20\">20</option>");
                   }
                   if (e_day == 21) {
                      out.println("<option selected value=\"21\">21</option>");
                   } else {
                      out.println("<option value=\"21\">21</option>");
                   }
                   if (e_day == 22) {
                      out.println("<option selected value=\"22\">22</option>");
                   } else {
                      out.println("<option value=\"22\">22</option>");
                   }
                   if (e_day == 23) {
                      out.println("<option selected value=\"23\">23</option>");
                   } else {
                      out.println("<option value=\"23\">23</option>");
                   }
                   if (e_day == 24) {
                      out.println("<option selected value=\"24\">24</option>");
                   } else {
                      out.println("<option value=\"24\">24</option>");
                   }
                   if (e_day == 25) {
                      out.println("<option selected value=\"25\">25</option>");
                   } else {
                      out.println("<option value=\"25\">25</option>");
                   }
                   if (e_day == 26) {
                      out.println("<option selected value=\"26\">26</option>");
                   } else {
                      out.println("<option value=\"26\">26</option>");
                   }
                   if (e_day == 27) {
                      out.println("<option selected value=\"27\">27</option>");
                   } else {
                      out.println("<option value=\"27\">27</option>");
                   }
                   if (e_day == 28) {
                      out.println("<option selected value=\"28\">28</option>");
                   } else {
                      out.println("<option value=\"28\">28</option>");
                   }
                   if (e_day == 29) {
                      out.println("<option selected value=\"29\">29</option>");
                   } else {
                      out.println("<option value=\"29\">29</option>");
                   }
                   if (e_day == 30) {
                      out.println("<option selected value=\"30\">30</option>");
                   } else {
                      out.println("<option value=\"30\">30</option>");
                   }
                   if (e_day == 31) {
                      out.println("<option selected value=\"31\">31</option>");
                   } else {
                      out.println("<option value=\"31\">31</option>");
                   }
                    out.println("</select>");

                    out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"eyear\">");
                   if (e_year == 2002) {
                      out.println("<option selected value=\"2002\">2002</option>");
                   } else {
                      out.println("<option value=\"2002\">2002</option>");
                   }
                   if (e_year == 2003) {
                      out.println("<option selected value=\"2003\">2003</option>");
                   } else {
                      out.println("<option value=\"2003\">2003</option>");
                   }
                   if (e_year == 2004) {
                      out.println("<option selected value=\"2004\">2004</option>");
                   } else {
                      out.println("<option value=\"2004\">2004</option>");
                   }
                   if (e_year == 2005) {
                      out.println("<option selected value=\"2005\">2005</option>");
                   } else {
                      out.println("<option value=\"2005\">2005</option>");
                   }
                   if (e_year == 2006) {
                      out.println("<option selected value=\"2006\">2006</option>");
                   } else {
                      out.println("<option value=\"2006\">2006</option>");
                   }
                   if (e_year == 2007) {
                      out.println("<option selected value=\"2007\">2007</option>");
                   } else {
                      out.println("<option value=\"2007\">2007</option>");
                   }
                   if (e_year == 2008) {
                      out.println("<option selected value=\"2008\">2008</option>");
                   } else {
                      out.println("<option value=\"2008\">2008</option>");
                   }
                   if (e_year == 2009) {
                      out.println("<option selected value=\"2009\">2009</option>");
                   } else {
                      out.println("<option value=\"2009\">2009</option>");
                   }
                   if (e_year == 2010) {
                      out.println("<option selected value=\"2010\">2010</option>");
                   } else {
                      out.println("<option value=\"2010\">2010</option>");
                   }
                   if (e_year == 2011) {
                      out.println("<option selected value=\"2011\">2011</option>");
                   } else {
                      out.println("<option value=\"2011\">2011</option>");
                   }
                   if (e_year == 2012) {
                      out.println("<option selected value=\"2012\">2012</option>");
                   } else {
                      out.println("<option value=\"2012\">2012</option>");
                   }
                   if (e_year == 2013) {
                      out.println("<option selected value=\"2013\">2013</option>");
                   } else {
                      out.println("<option value=\"2013\">2013</option>");
                   }
                   if (e_year == 2014) {
                      out.println("<option selected value=\"2014\">2014</option>");
                   } else {
                      out.println("<option value=\"2014\">2014</option>");
                   }
                    out.println("</select><br><br>");
                  out.println("&nbsp;&nbsp;Start Time:");
                  out.println("&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"start_hr\">");
                   if (shr == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (shr == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (shr == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (shr == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (shr == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (shr == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (shr == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (shr == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (shr == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (shr == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (shr == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (shr == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
                    if (smin < 10) {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + smin + " name=\"start_min\">");
                    } else {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + smin + " name=\"start_min\">");
                    }
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"start_ampm\">");
                   if (ssampm.equals( "AM" )) {
                      out.println("<option selected value=\"00\">AM</option>");
                   } else {
                      out.println("<option value=\"00\">AM</option>");
                   }
                   if (ssampm.equals( "PM" )) {
                      out.println("<option selected value=\"12\">PM</option>");
                   } else {
                      out.println("<option value=\"12\">PM</option>");
                   }
                    out.println("</select><br><br>");
                  out.println("&nbsp;&nbsp;End Time:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"end_hr\">");
                   if (ehr == 1) {
                      out.println("<option selected selected value=\"01\">1</option>");
                   } else {
                      out.println("<option value=\"01\">1</option>");
                   }
                   if (ehr == 2) {
                      out.println("<option selected value=\"02\">2</option>");
                   } else {
                      out.println("<option value=\"02\">2</option>");
                   }
                   if (ehr == 3) {
                      out.println("<option selected value=\"03\">3</option>");
                   } else {
                      out.println("<option value=\"03\">3</option>");
                   }
                   if (ehr == 4) {
                      out.println("<option selected value=\"04\">4</option>");
                   } else {
                      out.println("<option value=\"04\">4</option>");
                   }
                   if (ehr == 5) {
                      out.println("<option selected value=\"05\">5</option>");
                   } else {
                      out.println("<option value=\"05\">5</option>");
                   }
                   if (ehr == 6) {
                      out.println("<option selected value=\"06\">6</option>");
                   } else {
                      out.println("<option value=\"06\">6</option>");
                   }
                   if (ehr == 7) {
                      out.println("<option selected value=\"07\">7</option>");
                   } else {
                      out.println("<option value=\"07\">7</option>");
                   }
                   if (ehr == 8) {
                      out.println("<option selected value=\"08\">8</option>");
                   } else {
                      out.println("<option value=\"08\">8</option>");
                   }
                   if (ehr == 9) {
                      out.println("<option selected value=\"09\">9</option>");
                   } else {
                      out.println("<option value=\"09\">9</option>");
                   }
                   if (ehr == 10) {
                      out.println("<option selected value=\"10\">10</option>");
                   } else {
                      out.println("<option value=\"10\">10</option>");
                   }
                   if (ehr == 11) {
                      out.println("<option selected value=\"11\">11</option>");
                   } else {
                      out.println("<option value=\"11\">11</option>");
                   }
                   if (ehr == 12) {
                      out.println("<option selected value=\"12\">12</option>");
                   } else {
                      out.println("<option value=\"12\">12</option>");
                   }
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
                    if (emin < 10) {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + emin + " name=\"end_min\">");
                    } else {
                       out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + emin + " name=\"end_min\">");
                    }
                    out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"end_ampm\">");
                   if (seampm.equals( "AM" )) {
                      out.println("<option selected value=\"00\">AM</option>");
                   } else {
                      out.println("<option value=\"00\">AM</option>");
                   }
                   if (seampm.equals( "PM" )) {
                      out.println("<option selected value=\"12\">PM</option>");
                   } else {
                      out.println("<option value=\"12\">PM</option>");
                   }
                    out.println("</select><br><br>");
                    out.println("&nbsp;&nbsp;Recurrence:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"recurr\">");
                if (recur.equalsIgnoreCase( "every day" )) {
                   out.println("<option selected value=\"Every Day\">Every Day</option>");
                } else {
                   out.println("<option value=\"Every Day\">Every Day</option>");
                }
                if (recur.equalsIgnoreCase( "every sunday" )) {
                   out.println("<option selected value=\"Every Sunday\">Every Sunday</option>");
                } else {
                   out.println("<option value=\"Every Sunday\">Every Sunday</option>");
                }
                if (recur.equalsIgnoreCase( "every monday" )) {
                   out.println("<option selected value=\"Every Monday\">Every Monday</option>");
                } else {
                   out.println("<option value=\"Every Monday\">Every Monday</option>");
                }
                if (recur.equalsIgnoreCase( "every tuesday" )) {
                   out.println("<option selected value=\"Every Tuesday\">Every Tuesday</option>");
                } else {
                   out.println("<option value=\"Every Tuesday\">Every Tuesday</option>");
                }
                if (recur.equalsIgnoreCase( "every wednesday" )) {
                   out.println("<option selected value=\"Every Wednesday\">Every Wednesday</option>");
                } else {
                   out.println("<option value=\"Every Wednesday\">Every Wednesday</option>");
                }
                if (recur.equalsIgnoreCase( "every thursday" )) {
                   out.println("<option selected value=\"Every Thursday\">Every Thursday</option>");
                } else {
                   out.println("<option value=\"Every Thursday\">Every Thursday</option>");
                }
                if (recur.equalsIgnoreCase( "every friday" )) {
                   out.println("<option selected value=\"Every Friday\">Every Friday</option>");
                } else {
                   out.println("<option value=\"Every Friday\">Every Friday</option>");
                }
                if (recur.equalsIgnoreCase( "every saturday" )) {
                   out.println("<option selected value=\"Every Saturday\">Every Saturday</option>");
                } else {
                   out.println("<option value=\"Every Saturday\">Every Saturday</option>");
                }
                if (recur.equalsIgnoreCase( "all weekdays" )) {
                   out.println("<option selected value=\"All Weekdays\">All Weekdays</option>");
                } else {
                   out.println("<option value=\"All Weekdays\">All Weekdays</option>");
                }
                if (recur.equalsIgnoreCase( "all weekends" )) {
                   out.println("<option selected value=\"All Weekends\">All Weekends</option>");
                } else {
                   out.println("<option value=\"All Weekends\">All Weekends</option>");
                }
                    out.println("</select><br><br>");

               out.println("&nbsp;&nbsp;Guest Types to be Restricted (select all that apply):<br>");

               //
               //  parm.guest[x] = not null if this was specified in club db table (supported)
               //  resguest[x] = not null if this was specified in restriction
               //
               i2 = 1;
               for (i = 0; i < parm.MAX_Guests; i++) {

                  if (!parm.guest[i].equals( "" )) {          // if supported and

                     out.println("<br>");
                     out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

                     if (!resguest[i].equals( "" )) {        //    already checked

                        out.println("<input type=\"checkbox\" checked name=\"guest" +i2+ "\" value=\"" + parm.guest[i] + "\">&nbsp;&nbsp;" + parm.guest[i]);
                     } else {
                        out.println("<input type=\"checkbox\" name=\"guest" +i2+ "\" value=\"" + parm.guest[i] + "\">&nbsp;&nbsp;" + parm.guest[i]);
                     }
                     i2++;
                  }
               }

               out.println("<br><br>");
                    out.println("&nbsp;&nbsp;Number of Guests Allowed:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"guests\">");
                   if (guests == 0) {
                      out.println("<option selected value=\"0\">0</option>");
                   } else {
                      out.println("<option value=\"0\">0</option>");
                   }
                   if (guests == 1) {
                      out.println("<option selected value=\"1\">1</option>");
                   } else {
                      out.println("<option value=\"1\">1</option>");
                   }
                   if (guests == 2) {
                      out.println("<option selected value=\"2\">2</option>");
                   } else {
                      out.println("<option value=\"2\">2</option>");
                   }
                   if (guests == 3) {
                      out.println("<option selected value=\"3\">3</option>");
                   } else {
                      out.println("<option value=\"3\">3</option>");
                   }
                    out.println("</select>");
                    out.println("&nbsp;&nbsp;Per:&nbsp;&nbsp;");
                    out.println("<select size=\"1\" name=\"per\">");
                   if (per.equals( "Member" )) {
                      out.println("<option selected value=\"Member\">Member</option>");
                   } else {
                      out.println("<option value=\"Member\">Member</option>");
                   }
                   if (per.equals( "Tee Time" )) {
                      out.println("<option selected value=\"Tee Time\">Tee Time</option>");
                   } else {
                      out.println("<option value=\"Tee Time\">Tee Time</option>");
                   }
                   out.println("</select></p><br>");
                      
                  if (hotel > 0) {    // if Hotels supported
                    
                     out.println("<br>&nbsp;&nbsp;Color to make this restriction on the tee sheet:&nbsp;&nbsp;");
                     out.println("<br>&nbsp;&nbsp;(This <b>only</b> pertains to the Hotel Users' tee sheets.)&nbsp;&nbsp;");

                     Common_Config.displayColorsAll(color, out);       // output the color options

                     out.println("<br><br>");
                     out.println("&nbsp;&nbsp;Click here to see the available colors:&nbsp;");
                     out.println("<a href=\"/" +rev+ "/proshop_color.htm\" target=\"_blank\">View Colors</a><br><br>");
                  }

                  out.println("<input type=\"hidden\" name=\"oldName\" value=\"" + oldName + "\"></input>");
                  out.println("<input type=\"hidden\" name=\"oldCourse\" value=\"" + oldCourse + "\"></input>");

                  out.println("<p align=\"center\">");
                  
                  if (copy == false) {
                      out.println("<input type=\"submit\" name=\"Update\" value=\"Update\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                      out.println("<input type=\"submit\" name=\"Remove\" value=\"Remove\">");
                  } else {
                      out.println("<input type=\"submit\" name=\"Add\" value=\"Add\">");
                  }
                  
                  out.println("<br><br><iframe src=\"/" + rev + "/servlet/Proshop_grest?susp&grestid=" + id + "\" id=suspension style=\"width:800px; height:800px\" scrolling=no frameborder=no></iframe>");
                  
   out.println("</p></font></td></tr></form></table>");
   out.println("</td></tr></table>");                       // end of main page table

   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"Cancel\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");

   out.println("</center></font></body></html>");

 }   // end of doPost   


 // ***************************************************************************
 //  Process the copy request - display a selection list of existing rest's
 // ***************************************************************************

 private void doCopy(HttpServletRequest req, PrintWriter out, Connection con, int lottery) {

   Statement stmt = null;
   ResultSet rs = null;

   //
   // Define some parms to use in the html
   //
   String name = "";       // name of restriction

   boolean b = false;

   //
   //  Build the HTML page to display the existing restrictions
   //
   out.println(SystemUtils.HeadTitle("Proshop Guest Restrictions Page"));
   out.println("<body bgcolor=\"#FFFFFF\" text=\"#000000\">");
   SystemUtils.getProshopSubMenu(req, out, lottery);        // required to allow submenus on this page
   out.println("<font face=\"Arial, Helvetica, Sans-serif\"><center>");

   out.println("<table border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");

   out.println("<table cellpadding=\"5\" bgcolor=\"#336633\" border=\"0\" align=\"center\">");
   out.println("<tr><td align=\"center\">");
   out.println("<font color=\"#FFFFFF\" size=\"3\">");
   out.println("<b>Copy a Guest Restriction</b><br>");
   out.println("</font>");
   out.println("<font color=\"#FFFFFF\" size=\"2\">");
   out.println("<b>Instructions:</b>&nbsp;&nbsp;Use this feature to create a new restriction by copying an existing restriction.<br>");
   out.println("Select the restriction you wish to copy from the list below.");
   out.println("</font></td></tr></table>");
   out.println("<br><br>");

   //
   //  Get and display the existing restrictions
   //
   try {

      stmt = con.createStatement();        // create a statement

      rs = stmt.executeQuery("SELECT name FROM guestres2");

      if (rs.next()) {

         b = true;                     // indicate restrictions exist
      }
      stmt.close();

      if (b == true) {

         out.println("<font size=\"2\">");
         out.println("<p>Select the restriction you wish to copy.</p>");

         out.println("<form action=\"/" +rev+ "/servlet/Proshop_grest\" method=\"post\" target=\"bot\">");
         out.println("<input type=\"hidden\" name=\"copy\" value=\"yes\">");     // tell addgrest its a copy
         out.println("<select size=\"1\" name=\"name\">");

         //
         //  Do again to actually get the names
         //
         stmt = con.createStatement();        // create a statement

         rs = stmt.executeQuery("SELECT name FROM guestres2 ORDER BY name");

         while (rs.next()) {

            name = rs.getString("name");

            out.println("<option value=\"" +name+ "\">" +name+ "</option>");

         }  // end of while loop

         stmt.close();

         out.println("</select><br><br>");

         out.println("<input type=\"submit\" name=\"Continue\" value=\"Continue\" style=\"text-decoration:underline; background:#8B8970\">");
         out.println("</form>");

      } else {            // no rest's exist

         out.println("<p><font size=\"2\">No Guest Restrictions Currently Exist</p>");
      }
   }
   catch (Exception exc) {

      out.println("<BR><BR><H1>Database Access Error</H1>");
      out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
      out.println("<BR>Please try again later.");
      out.println("<BR><BR>If problem persists, contact customer support.");
      out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");

   }  // end of try

   //
   //  End of HTML page
   //
   out.println("</td></tr></table>");                // end of main page table
   out.println("<font size=\"2\">");
   out.println("<form method=\"get\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
   out.println("<input type=\"submit\" value=\"Return\" style=\"text-decoration:underline; background:#8B8970\">");
   out.println("</input></form></font>");
   out.println("</center></font></body></html>");
   out.close();
 }

 // *********************************************************
 // Print suspensions table and add/edit suspension form
 // *********************************************************
 private void printSuspensions(HttpServletRequest req, Connection con, PrintWriter out) {
     
     PreparedStatement pstmt = null;
     Statement stmt = null;
     ResultSet rs = null;
     
     int grest_id = 0;            // restriction id
     int id = 0;
     int shourInt = 0;
     int ehourInt = 0;
     int stime = 0;
     int etime = 0;
     int sdate = 0;
     int edate = 0;
     int multi = 0;
     
     String courseName = "";
     String sampm = "";
     String eampm = "";
     String shour = "";
     String smin = "";
     String ehour = "";
     String emin = "";
     String sday = "";
     String smonth = "";
     String syear = "";
     String eday = "";
     String emonth = "";
     String eyear = "";
     
     if (req.getParameter("updateSusp") != null) {
         updateSuspension(req, con, out);
         return;
     }
     
     if (req.getParameter("deleteSusp") != null) {
         deleteSuspension(req, con, out);
         return;
     }
     
     grest_id = Integer.parseInt(req.getParameter("grestid"));

     out.println("<body bgcolor=\"#F5F5DC\" text=\"#000000\">");
     out.println("<table border=\"0\" align=\"center\"><tr><td>");
     out.println("<font face=\"Arial, Helvetica, Sans-serif\" size=\"2\">");
     out.println("<h4 align=\"center\">Active Suspensions</h4>");
     out.println("<table border=\"2\" bordercolor=\"FFFFFF\" cellpadding=\"5\" align=\"center\" style=\"font-size: 10pt; font-family: Arial;\">");

     // Print header row
     out.println("<tr style=\"background-color: #336633; color: white;\">");
     out.println("<td align=\"center\"><b>ID#</b></td>");
     out.println("<td align=\"center\"><b>Course</b></td>");
     out.println("<td align=\"center\"><b>Start Date</b></td>");
     out.println("<td align=\"center\"><b>End Date</b></td>");
     out.println("<td align=\"center\"><b>Start Time</b></td>");
     out.println("<td align=\"center\"><b>End Time</b></td>");
     out.println("<td align=\"center\"><b>Recurrence</b></td>");
     out.println("<td>&nbsp</td>");
     out.println("</tr>");

     // get all suspensions from database
     try {
         pstmt = con.prepareStatement("SELECT * FROM rest_suspend WHERE grest_id = ? ORDER BY id");

         pstmt.clearParameters();
         pstmt.setInt(1, grest_id);

         rs = pstmt.executeQuery();


         String tempTime = "";
         String tempDate = "";

         while (rs.next()) {

             String recurr = getRecurrence(rs, out);

             id = rs.getInt("id");
             courseName = rs.getString("courseName");
             
             
             //
             //  some values must be converted for display
             //
             stime = rs.getInt("stime");
             tempTime = String.valueOf(stime);
             shourInt = Integer.parseInt(tempTime.substring(0, tempTime.length() - 2));
             smin = tempTime.substring(tempTime.length() - 2);

             etime = rs.getInt("etime");
             tempTime = String.valueOf(etime);
             ehourInt = Integer.parseInt(tempTime.substring(0, tempTime.length() - 2));
             emin = tempTime.substring(tempTime.length() - 2);

             sampm = " AM";         // default to AM
             if (shourInt > 12) {
                 sampm = " PM";

                 if (shourInt != 12) {
                     shourInt = shourInt - 12;                // convert to 12 hr clock value
                 }
             }

             eampm = " AM";         // default to AM
             if (ehourInt >= 12) {
                 eampm = " PM";

                 if (ehourInt != 12) {
                     ehourInt = ehourInt - 12;                // convert to 12 hr clock value
                 }
             }

             shour = String.valueOf(shourInt);
             ehour = String.valueOf(ehourInt);


             sdate = rs.getInt("sdate");
             tempDate = String.valueOf(sdate);
             syear = tempDate.substring(0, tempDate.length() - 4);
             smonth = tempDate.substring(4, tempDate.length() - 2);
             sday = tempDate.substring(6);

             edate = rs.getInt("edate");
             tempDate = String.valueOf(edate);
             eyear = tempDate.substring(0, tempDate.length() - 4);
             emonth = tempDate.substring(4, tempDate.length() - 2);
             eday = tempDate.substring(6);

             if (smonth.startsWith("0")) { smonth = smonth.substring(1); }
             if (emonth.startsWith("0")) { emonth = emonth.substring(1); }

             // print a line for each suspension
             out.println("<tr>");
             out.println("<td>" + id + "</td>");
             out.println("<td>" + courseName + "</td>");
             out.println("<td>" + smonth + "/" + sday + "/" + syear + "</td>");
             out.println("<td>" + emonth + "/" + eday + "/" + eyear + "</td>");
             out.println("<td>" + shour + ":" + smin + " " + sampm + "</td>");
             out.println("<td>" + ehour + ":" + emin + " " + eampm + "</td>");
             out.println("<td>" + recurr + "</td>");
             out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_grest?susp\">");
             out.println("<input type=\"hidden\" name=\"grestid\" value=\"" + grest_id + "\">");
             out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">");
             out.println("<td>");
             out.println("<input type=\"submit\" name=\"selectSusp\" value=\"Select\">");
             out.println("<input type=\"submit\" name=\"deleteSusp\" value=\"Delete\" onclick=\"return confirm('Are you sure you want to delete this suspension?')\">");
             out.println("</td>");
             out.println("</form>");
             out.println("</tr>");
         }  // end of while

         pstmt.close();

         out.println("</table>");
         
         
         
         //
         // Print form to add/edit suspensions
         //
         out.println("<br><br>");
         //  parm block to hold the club parameters
         parmClub parm = new parmClub();          // allocate a parm block
         
         int s_date = 0;
         int s_year = 0;
         int s_month = 0;
         int e_date = 0;
         int s_day = 0;
         int e_year = 0;
         int e_month = 0;
         int e_day = 0;
         int s_time = 0;
         int s_hr = 0;
         int s_min = 0;
         int e_time = 0;
         int e_hr = 0;
         int e_min = 0;
         int index = 0;
         
         String s_ampm = "";
         String e_ampm = "";
         String idStr = "";
         String tempTime2 = "";
         String tempDate2 = "";
         String oldCourse = "";
         String courseName2 = "";
         
         String [] selectArr = new String[31];          // Array to hold selection values for form selection boxes
         int [] recurrArr = new int [8];        // index 0 = eo_week value, 1-7 = Sun-Sat values
         String [] course = new String [parm.MAX_Courses];      // max of 20 courses per club
                  
         id = -1;
         
         if (req.getParameter("id") != null && req.getParameter("returning") == null) {
             pstmt = con.prepareStatement (
                   "SELECT * FROM rest_suspend WHERE id = ?");

             id = Integer.parseInt(req.getParameter("id"));
             
             pstmt.clearParameters();        // clear the parms
             pstmt.setInt(1, id);       // put the parm in stmt
             rs = pstmt.executeQuery();      // execute the prepared stmt

             if (rs.next()) {

                 //  Found the restriction record - get it
                 courseName = rs.getString("courseName");
                 s_date = rs.getInt("sdate");
                 s_time = rs.getInt("stime");
                 e_date = rs.getInt("edate");
                 e_time = rs.getInt("etime");
                 
                 recurrArr[0] = rs.getInt("eo_week");
                 recurrArr[1] = rs.getInt("sunday");
                 recurrArr[2] = rs.getInt("monday");
                 recurrArr[3] = rs.getInt("tuesday");
                 recurrArr[4] = rs.getInt("wednesday");
                 recurrArr[5] = rs.getInt("thursday");
                 recurrArr[6] = rs.getInt("friday");
                 recurrArr[7] = rs.getInt("saturday");
             }
             
         } else {       // see if any params were passed with the request
             
             if (req.getParameter("id") != null) {
                 id = Integer.parseInt(req.getParameter("id"));
             }
             if (req.getParameter("course") != null) {
                 courseName = req.getParameter("course");
             }
             if (req.getParameter("sdate") != null) {
                 s_date = Integer.parseInt(req.getParameter("sdate"));
             }
             if (req.getParameter("stime") != null) {
                 s_time = Integer.parseInt(req.getParameter("stime"));
             }
             if (req.getParameter("edate") != null) {
                 e_date = Integer.parseInt(req.getParameter("edate"));
             }
             if (req.getParameter("etime") != null) {
                 e_time = Integer.parseInt(req.getParameter("etime"));
             }             
             if (req.getParameter("eo_week") != null) {
                 recurrArr[0] = Integer.parseInt(req.getParameter("eo_week"));
             }
             if (req.getParameter("sunday") != null) {
                 recurrArr[1] = Integer.parseInt(req.getParameter("sunday"));
             }
             if (req.getParameter("monday") != null) {
                 recurrArr[2] = Integer.parseInt(req.getParameter("monday"));
             }
             if (req.getParameter("tuesday") != null) {
                 recurrArr[3] = Integer.parseInt(req.getParameter("tuesday"));
             }
             if (req.getParameter("wednesday") != null) {
                 recurrArr[4] = Integer.parseInt(req.getParameter("wednesday"));
             }
             if (req.getParameter("thursday") != null) {
                 recurrArr[5] = Integer.parseInt(req.getParameter("thursday"));
             }
             if (req.getParameter("friday") != null) {
                 recurrArr[6] = Integer.parseInt(req.getParameter("friday"));
             }
             if (req.getParameter("saturday") != null) {
                 recurrArr[7] = Integer.parseInt(req.getParameter("saturday"));
             }
             
             pstmt.close();
         }
                      
         // Date/Time conversions
         if (s_time != 0) {
             tempTime2 = String.valueOf(s_time);
             s_hr = Integer.parseInt(tempTime2.substring(0, tempTime2.length() - 2));
             s_min = Integer.parseInt(tempTime2.substring(tempTime2.length() - 2));

             s_ampm = " AM";         // default to AM
             if (s_hr > 12) {
                 s_ampm = "PM";

                 if (s_hr != 12) {
                     s_hr = s_hr - 12;                // convert to 12 hr clock value
                 }
             }
         }
         
         if (e_time != 0) {
             tempTime2 = String.valueOf(e_time);
             e_hr = Integer.parseInt(tempTime2.substring(0, tempTime2.length() - 2));
             e_min = Integer.parseInt(tempTime2.substring(tempTime2.length() - 2));

             e_ampm = " AM";         // default to AM
             if (e_hr >= 12) {
                 e_ampm = "PM";

                 if (e_hr != 12) {
                     e_hr = e_hr - 12;                // convert to 12 hr clock value
                 }
             }
         }

         if (s_date != 0) {
             tempDate2 = String.valueOf(s_date);
             s_year = Integer.parseInt(tempDate2.substring(0, tempDate2.length() - 4));
             s_month = Integer.parseInt(tempDate2.substring(4, tempDate2.length() - 2));
             s_day = Integer.parseInt(tempDate2.substring(6));
         }

         if (e_date != 0) {
             tempDate2 = String.valueOf(e_date);
             e_year = Integer.parseInt(tempDate2.substring(0, tempDate2.length() - 4));
             e_month = Integer.parseInt(tempDate2.substring(4, tempDate2.length() - 2));
             e_day = Integer.parseInt(tempDate2.substring(6));
         }
           
         // Determine whether club has multiple courses
         pstmt = con.prepareStatement("SELECT multi FROM club5");
         
         rs = pstmt.executeQuery();
         
         if (id >= 0) {
             idStr = "&id=" + String.valueOf(id);
         }
         
         out.println("<form method=\"post\" action=\"/" +rev+ "/servlet/Proshop_grest\">");
         out.println("<input type=\"hidden\" name=\"susp\" value=\"true\">");
         out.println("<input type=\"hidden\" name=\"updateSusp\" value=\"true\">");
         if (id >= 0) {
             out.println("<input type=\"hidden\" name=\"id\" value=\"" + String.valueOf(id) + "\">");
         }
         
         if (req.getParameter("grestid") != null) {
             grest_id = Integer.parseInt(req.getParameter("grestid"));
         } else {
             grest_id = -1;
         }
         
         out.println("<input type=\"hidden\" name=\"grestid\" value=\"" + grest_id + "\">");
         
         if (rs.next()) {
             multi = rs.getInt("multi");
         }
         
         if (multi != 0) {

             //
             //  Multiple courses - get the names
             //
             index = 0;

             while (index < parm.MAX_Courses) {

                course[index] = "";       // init the course array
                index++;
             }
             index = 0;

             //
             //  Get the names of all courses for this club
             //
             stmt = con.createStatement();        // create a statement

             rs = stmt.executeQuery("SELECT courseName " +
                                    "FROM clubparm2 WHERE first_hr != 0");

             while (rs.next() && index < parm.MAX_Courses) {

                courseName2 = rs.getString(1);

                course[index] = courseName2;      // add course name to array
                index++;
             }
             stmt.close();
             
            out.println("&nbsp;&nbsp;Select a Course:&nbsp;&nbsp;");
            out.println("<select size=\"1\" name=\"course\">");

            if (courseName.equals( "-ALL-" )) {             // if same as existing name

              out.println("<option selected value=\"-ALL-\">ALL</option>");
            } else {
              out.println("<option value=\"-ALL-\">ALL</option>");
            }
            index = 0;
            courseName2 = course[index];      // get course name from array

            while ((!courseName2.equals( "" )) && (index < parm.MAX_Courses)) {

              if (courseName2.equals( courseName )) {             // if same as existing name

                 out.println("<option selected value=\"" + courseName + "\">" + courseName + "</option>");
              } else {
                 out.println("<option value=\"" + courseName2 + "\">" + courseName2 + "</option>");
              }
              index++;
              courseName2 = course[index];      // get course name from array
            }
            out.println("</select>");
            out.println("<br><br>");

         } else {

            out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
         }
         
         out.println("&nbsp;&nbsp;Start Date:&nbsp;&nbsp;&nbsp;");
         
         // Print start month selection box
         out.println("Month:&nbsp;&nbsp;");
         
         for (int i=0; i<12; i++) {
             if (s_month == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"smonth\">");
              out.println("<option" + selectArr[0] + " value=\"01\">JAN</option>");
              out.println("<option" + selectArr[1] + " value=\"02\">FEB</option>");
              out.println("<option" + selectArr[2] + " value=\"03\">MAR</option>");
              out.println("<option" + selectArr[3] + " value=\"04\">APR</option>");
              out.println("<option" + selectArr[4] + " value=\"05\">MAY</option>");
              out.println("<option" + selectArr[5] + " value=\"06\">JUN</option>");
              out.println("<option" + selectArr[6] + " value=\"07\">JUL</option>");
              out.println("<option" + selectArr[7] + " value=\"08\">AUG</option>");
              out.println("<option" + selectArr[8] + " value=\"09\">SEP</option>");
              out.println("<option" + selectArr[9] + " value=\"10\">OCT</option>");
              out.println("<option" + selectArr[10] + " value=\"11\">NOV</option>");
              out.println("<option" + selectArr[11] + " value=\"12\">DEC</option>");
         out.println("</select>");

         // Print start day selection box
         out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
         
         for (int i=0; i<31; i++) {
             if (s_day == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"sday\">");
              out.println("<option" + selectArr[0] + " value=\"01\">1</option>");
              out.println("<option" + selectArr[1] + " value=\"02\">2</option>");
              out.println("<option" + selectArr[2] + " value=\"03\">3</option>");
              out.println("<option" + selectArr[3] + " value=\"04\">4</option>");
              out.println("<option" + selectArr[4] + " value=\"05\">5</option>");
              out.println("<option" + selectArr[5] + " value=\"06\">6</option>");
              out.println("<option" + selectArr[6] + " value=\"07\">7</option>");
              out.println("<option" + selectArr[7] + " value=\"08\">8</option>");
              out.println("<option" + selectArr[8] + " value=\"09\">9</option>");
              out.println("<option" + selectArr[9] + " value=\"10\">10</option>");
              out.println("<option" + selectArr[10] + " value=\"11\">11</option>");
              out.println("<option" + selectArr[11] + " value=\"12\">12</option>");
              out.println("<option" + selectArr[12] + " value=\"13\">13</option>");
              out.println("<option" + selectArr[13] + " value=\"14\">14</option>");
              out.println("<option" + selectArr[14] + " value=\"15\">15</option>");
              out.println("<option" + selectArr[15] + " value=\"16\">16</option>");
              out.println("<option" + selectArr[16] + " value=\"17\">17</option>");
              out.println("<option" + selectArr[17] + " value=\"18\">18</option>");
              out.println("<option" + selectArr[18] + " value=\"19\">19</option>");
              out.println("<option" + selectArr[19] + " value=\"20\">20</option>");
              out.println("<option" + selectArr[20] + " value=\"21\">21</option>");
              out.println("<option" + selectArr[21] + " value=\"22\">22</option>");
              out.println("<option" + selectArr[22] + " value=\"23\">23</option>");
              out.println("<option" + selectArr[23] + " value=\"24\">24</option>");
              out.println("<option" + selectArr[24] + " value=\"25\">25</option>");
              out.println("<option" + selectArr[25] + " value=\"26\">26</option>");
              out.println("<option" + selectArr[26] + " value=\"27\">27</option>");
              out.println("<option" + selectArr[27] + " value=\"28\">28</option>");
              out.println("<option" + selectArr[28] + " value=\"29\">29</option>");
              out.println("<option" + selectArr[29] + " value=\"30\">30</option>");
              out.println("<option" + selectArr[30] + " value=\"31\">31</option>");
         out.println("</select>");

         // Print start year selection box
         out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
         
         for (int i=0; i<11; i++) {
             if (s_year == 2008 + i) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"syear\">");
            out.println("<option" + selectArr[0] + " value=\"2008\">2008</option>");
            out.println("<option" + selectArr[1] + " value=\"2009\">2009</option>");
            out.println("<option" + selectArr[2] + " value=\"2010\">2010</option>");
            out.println("<option" + selectArr[3] + " value=\"2011\">2011</option>");
            out.println("<option" + selectArr[4] + " value=\"2012\">2012</option>");
            out.println("<option" + selectArr[5] + " value=\"2013\">2013</option>");
            out.println("<option" + selectArr[6] + " value=\"2014\">2014</option>");
            out.println("<option" + selectArr[7] + " value=\"2015\">2015</option>");
            out.println("<option" + selectArr[8] + " value=\"2016\">2016</option>");
            out.println("<option" + selectArr[9] + " value=\"2017\">2017</option>");
            out.println("<option" + selectArr[10] + " value=\"2018\">2018</option>");
         out.println("</select><br><br>");
         
         
         out.println("&nbsp;&nbsp;End Date:&nbsp;&nbsp;&nbsp;&nbsp;");
         
         // Print end month selection box
         out.println("Month:&nbsp;&nbsp;");
         
         for (int i=0; i<12; i++) {
             if (e_month == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"emonth\">");
              out.println("<option" + selectArr[0] + " value=\"01\">JAN</option>");
              out.println("<option" + selectArr[1] + " value=\"02\">FEB</option>");
              out.println("<option" + selectArr[2] + " value=\"03\">MAR</option>");
              out.println("<option" + selectArr[3] + " value=\"04\">APR</option>");
              out.println("<option" + selectArr[4] + " value=\"05\">MAY</option>");
              out.println("<option" + selectArr[5] + " value=\"06\">JUN</option>");
              out.println("<option" + selectArr[6] + " value=\"07\">JUL</option>");
              out.println("<option" + selectArr[7] + " value=\"08\">AUG</option>");
              out.println("<option" + selectArr[8] + " value=\"09\">SEP</option>");
              out.println("<option" + selectArr[9] + " value=\"10\">OCT</option>");
              out.println("<option" + selectArr[10] + " value=\"11\">NOV</option>");
              out.println("<option" + selectArr[11] + " value=\"12\">DEC</option>");
         out.println("</select>");
         
         // Print end day selection box
         out.println("&nbsp;&nbsp;&nbsp;Day:&nbsp;&nbsp;");
         
         for (int i=0; i<31; i++) {
             if (e_day == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"eday\">");
              out.println("<option" + selectArr[0] + " value=\"01\">1</option>");
              out.println("<option" + selectArr[1] + " value=\"02\">2</option>");
              out.println("<option" + selectArr[2] + " value=\"03\">3</option>");
              out.println("<option" + selectArr[3] + " value=\"04\">4</option>");
              out.println("<option" + selectArr[4] + " value=\"05\">5</option>");
              out.println("<option" + selectArr[5] + " value=\"06\">6</option>");
              out.println("<option" + selectArr[6] + " value=\"07\">7</option>");
              out.println("<option" + selectArr[7] + " value=\"08\">8</option>");
              out.println("<option" + selectArr[8] + " value=\"09\">9</option>");
              out.println("<option" + selectArr[9] + " value=\"10\">10</option>");
              out.println("<option" + selectArr[10] + " value=\"11\">11</option>");
              out.println("<option" + selectArr[11] + " value=\"12\">12</option>");
              out.println("<option" + selectArr[12] + " value=\"13\">13</option>");
              out.println("<option" + selectArr[13] + " value=\"14\">14</option>");
              out.println("<option" + selectArr[14] + " value=\"15\">15</option>");
              out.println("<option" + selectArr[15] + " value=\"16\">16</option>");
              out.println("<option" + selectArr[16] + " value=\"17\">17</option>");
              out.println("<option" + selectArr[17] + " value=\"18\">18</option>");
              out.println("<option" + selectArr[18] + " value=\"19\">19</option>");
              out.println("<option" + selectArr[19] + " value=\"20\">20</option>");
              out.println("<option" + selectArr[20] + " value=\"21\">21</option>");
              out.println("<option" + selectArr[21] + " value=\"22\">22</option>");
              out.println("<option" + selectArr[22] + " value=\"23\">23</option>");
              out.println("<option" + selectArr[23] + " value=\"24\">24</option>");
              out.println("<option" + selectArr[24] + " value=\"25\">25</option>");
              out.println("<option" + selectArr[25] + " value=\"26\">26</option>");
              out.println("<option" + selectArr[26] + " value=\"27\">27</option>");
              out.println("<option" + selectArr[27] + " value=\"28\">28</option>");
              out.println("<option" + selectArr[28] + " value=\"29\">29</option>");
              out.println("<option" + selectArr[29] + " value=\"30\">30</option>");
              out.println("<option" + selectArr[30] + " value=\"31\">31</option>");
         out.println("</select>");
         
         // Print end year selection box
         out.println("&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;");
         
         for (int i=0; i<11; i++) {
             if (e_year == 2008 + i) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"eyear\">");
            out.println("<option" + selectArr[0] + " value=\"2008\">2008</option>");
            out.println("<option" + selectArr[1] + " value=\"2009\">2009</option>");
            out.println("<option" + selectArr[2] + " value=\"2010\">2010</option>");
            out.println("<option" + selectArr[3] + " value=\"2011\">2011</option>");
            out.println("<option" + selectArr[4] + " value=\"2012\">2012</option>");
            out.println("<option" + selectArr[5] + " value=\"2013\">2013</option>");
            out.println("<option" + selectArr[6] + " value=\"2014\">2014</option>");
            out.println("<option" + selectArr[7] + " value=\"2015\">2015</option>");
            out.println("<option" + selectArr[8] + " value=\"2016\">2016</option>");
            out.println("<option" + selectArr[9] + " value=\"2017\">2017</option>");
            out.println("<option" + selectArr[10] + " value=\"2018\">2018</option>");
         out.println("</select><br><br>");
         
         
         out.println("&nbsp;&nbsp;Start Time:");
         
         // Print start hour selection box
         out.println("&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
         
         for (int i=0; i<12; i++) {
             if (s_hr == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"start_hr\">");
             out.println("<option" + selectArr[0] + " value=\"01\">1</option>");
             out.println("<option" + selectArr[1] + " value=\"02\">2</option>");
             out.println("<option" + selectArr[2] + " value=\"03\">3</option>");
             out.println("<option" + selectArr[3] + " value=\"04\">4</option>");
             out.println("<option" + selectArr[4] + " value=\"05\">5</option>");
             out.println("<option" + selectArr[5] + " value=\"06\">6</option>");
             out.println("<option" + selectArr[6] + " value=\"07\">7</option>");
             out.println("<option" + selectArr[7] + " value=\"08\">8</option>");
             out.println("<option" + selectArr[8] + " value=\"09\">9</option>");
             out.println("<option" + selectArr[9] + " value=\"10\">10</option>");
             out.println("<option" + selectArr[10] + " value=\"11\">11</option>");
             out.println("<option" + selectArr[11] + " value=\"12\">12</option>");
         out.println("</select>");
         
         out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
            if (s_min < 10) {
               out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + s_min + " name=\"start_min\">");
            } else {
               out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + s_min + " name=\"start_min\">");
            }
            out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
            
         out.println("<select size=\"1\" name=\"start_ampm\">");
           if (s_ampm.equals( "AM" )) {
              out.println("<option selected value=\"am\">AM</option>");
           } else {
              out.println("<option value=\"am\">AM</option>");
           }
           if (s_ampm.equals( "PM" )) {
              out.println("<option selected value=\"pm\">PM</option>");
           } else {
              out.println("<option value=\"pm\">PM</option>");
           }
         out.println("</select><br><br>");
         
         
         out.println("&nbsp;&nbsp;End Time:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; hr &nbsp;&nbsp;");
         
         // Print end hour selection box
         for (int i=0; i<12; i++) {
             if (e_hr == i + 1) {
                 selectArr[i] = " selected";
             } else {
                 selectArr[i] = "";
             }
         }
         out.println("<select size=\"1\" name=\"end_hr\">");
             out.println("<option" + selectArr[0] + " value=\"01\">1</option>");
             out.println("<option" + selectArr[1] + " value=\"02\">2</option>");
             out.println("<option" + selectArr[2] + " value=\"03\">3</option>");
             out.println("<option" + selectArr[3] + " value=\"04\">4</option>");
             out.println("<option" + selectArr[4] + " value=\"05\">5</option>");
             out.println("<option" + selectArr[5] + " value=\"06\">6</option>");
             out.println("<option" + selectArr[6] + " value=\"07\">7</option>");
             out.println("<option" + selectArr[7] + " value=\"08\">8</option>");
             out.println("<option" + selectArr[8] + " value=\"09\">9</option>");
             out.println("<option" + selectArr[9] + " value=\"10\">10</option>");
             out.println("<option" + selectArr[10] + " value=\"11\">11</option>");
             out.println("<option" + selectArr[11] + " value=\"12\">12</option>");
         out.println("</select>");
         
         out.println("&nbsp;&nbsp;&nbsp; min &nbsp;&nbsp;");
            if (e_min < 10) {
               out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=0" + e_min + " name=\"end_min\">");
            } else {
               out.println("<input type=\"text\" size=\"2\" maxlength=\"2\" value=" + e_min + " name=\"end_min\">");
            }
            out.println("&nbsp;(enter 00 - 59)&nbsp;&nbsp;");
            
         out.println("<select size=\"1\" name=\"end_ampm\">");
           if (e_ampm.equals( "AM" )) {
              out.println("<option selected value=\"am\">AM</option>");
           } else {
              out.println("<option value=\"am\">AM</option>");
           }
           if (e_ampm.equals( "PM" )) {
              out.println("<option selected value=\"pm\">PM</option>");
           } else {
              out.println("<option value=\"pm\">PM</option>");
           }
         out.println("</select><br><br>");
         
         
         out.println("<table border=\"0\" cellpadding=\"2\" style=\"font-size: 10pt; font-weight: normal;\">");
         out.println("<tr>");
         out.println("<td valign=\"top\">&nbsp;Recurrence: </td>");
         out.println("<td valign=\"top\">");
         
         String checkedE = "";
         String checkedEO = "";
         
         if (recurrArr[0] != 1) {
             checkedE = "checked";
         } else {
             checkedEO = "checked";
         }
         
         
         out.println("<input type=\"radio\" name=\"eo_week\" value=\"every\" " + checkedE + ">Every<br>");
         out.println("<input type=\"radio\" name=\"eo_week\" value=\"everyother\" " + checkedEO + ">Every other");
         out.println("</td><td>");
         
         String [] checked = new String[7];
         for (int i=0; i<7; i++) {
             if (recurrArr[i+1] == 1) {
                 checked[i] = "checked";
             } else {
                 checked[i] = "";
             }
         }
         out.println("<input type=\"checkbox\" name=\"day1\" value=\"yes\" " + checked[0] + ">Sunday<br>");
         out.println("<input type=\"checkbox\" name=\"day2\" value=\"yes\" " + checked[1] + ">Monday<br>");
         out.println("<input type=\"checkbox\" name=\"day3\" value=\"yes\" " + checked[2] + ">Tuesday<br>");
         out.println("<input type=\"checkbox\" name=\"day4\" value=\"yes\" " + checked[3] + ">Wednesday<br>");
         out.println("<input type=\"checkbox\" name=\"day5\" value=\"yes\" " + checked[4] + ">Thursday<br>");
         out.println("<input type=\"checkbox\" name=\"day6\" value=\"yes\" " + checked[5] + ">Friday<br>");
         out.println("<input type=\"checkbox\" name=\"day7\" value=\"yes\" " + checked[6] + ">Saturday<br>");
         
         out.println("</td></tr></table>");
         
         out.println("<table border=\"0\" cellpadding=\"5\" align=\"center\">");
         out.println("<tr><td>");
         out.println("<br><input type=\"submit\" name=\"updateSubmit\" value=\"Submit\" align=\"center\">");
         out.println("&nbsp;&nbsp;&nbsp;<a href=\"/" + rev + "/servlet/Proshop_grest?susp&grestid=" + grest_id + "\" style=\"text-decoration: none;\"><button type=\"button\">Reset</button></a>");
         out.println("</table>");
         out.println("</form>");
         out.println("</td></tr></table>");
         out.println("<br></body></html>");

     } catch (Exception exc) {
         dbError(out, exc);
     }
 }      // end of printSuspensions
 
 // *********************************************************
 // Add or make changes to a suspension in the database
 // *********************************************************
 private void updateSuspension(HttpServletRequest req, Connection con, PrintWriter out) {
     
     PreparedStatement pstmt = null;
     Statement stmt = null;
     ResultSet rs = null;
     
     boolean daysSelected = false;
     boolean invalidMins = false;
     boolean invalidTime = false;
     boolean invalidDate = false;
     
     int grest_id = 0;            // restriction id
     int id = 0;
     int stime = 0;
     int etime = 0;
     int sdate = 0;
     int edate = 0;
     int count = 0;
     
     String courseName = "";
     String sampm = "";
     String eampm = "";
     String shour = "";
     String smin = "";
     String ehour = "";
     String emin = "";
     String sday = "";
     String smonth = "";
     String syear = "";
     String eday = "";
     String emonth = "";
     String eyear = "";
     
     int [] recurrArr = new int [8];        // index 0 = eo_week value, 1-7 = Sun-Sat values
     
     // If id != null, we know we're updating an existing suspension
     if (req.getParameter("id") != null) {
         id = Integer.parseInt(req.getParameter("id"));
     } else {
         id = -1;
     }
     
     grest_id = Integer.parseInt(req.getParameter("grestid"));
     
     courseName = req.getParameter("course");
     smonth = req.getParameter("smonth");
     sday = req.getParameter("sday");
     syear = req.getParameter("syear");
     emonth = req.getParameter("emonth");
     eday = req.getParameter("eday");
     eyear = req.getParameter("eyear");
     shour = req.getParameter("start_hr");
     smin = req.getParameter("start_min");
     sampm = req.getParameter("start_ampm");
     ehour = req.getParameter("end_hr");
     emin = req.getParameter("end_min");
     eampm = req.getParameter("end_ampm");
     
     if (req.getParameter("eo_week") != null && req.getParameter("eo_week").equalsIgnoreCase("everyother")) {
         recurrArr[0] = 1;
     } else {
         recurrArr[0] = 0;
     }
     
     for (int i=1; i<8; i++) {
         if (req.getParameter("day" + String.valueOf(i)) != null) {
             recurrArr[i] = 1;
             daysSelected = true;        // so we know if any days were selected
         } else {
             recurrArr[i] = 0;
         }
     }
     
     // Construct the correctly formated dates and times for storing in the database
     if (sampm.equalsIgnoreCase("pm")) {
         shour = String.valueOf(Integer.parseInt(shour) + 12);
     }
     if (eampm.equalsIgnoreCase("pm")) {
         ehour = String.valueOf(Integer.parseInt(ehour) + 12);
     }
     
     if (Integer.parseInt(smin) < 0 || Integer.parseInt(smin) > 59 ||
         Integer.parseInt(emin) < 0 || Integer.parseInt(emin) > 59) { invalidMins = true; }
     
     if (smonth.length() == 1) { smonth = "0" + smonth; }
     if (sday.length() == 1) { sday = "0" + sday; }
     if (smin.length() == 1) { smin = "0" + smin; }
     if (emonth.length() == 1) { emonth = "0" + emonth; }
     if (eday.length() == 1) { eday = "0" + eday; }
     if (emin.length() == 1) { emin = "0" + emin; }
     
     stime = Integer.parseInt(shour + smin);
     etime = Integer.parseInt(ehour + emin);
     sdate = Integer.parseInt(syear + smonth + sday);
     edate = Integer.parseInt(eyear + emonth + eday);
     
     // Perform time and date sanity checks
     if (stime >= etime) { invalidTime = true; }
     if (sdate > edate) { invalidDate = true; }
     
     if (!daysSelected || invalidMins || invalidTime || invalidDate) {        // If there was invalid data sent, reject and return them
         
         out.println(SystemUtils.HeadTitle("Invalid Data"));
         out.println("<BODY><CENTER><BR>");
         out.println("<BR><BR><H3>Invalid data entered!</H3>");
         out.println("<BR><BR>The following problems were present in the suspension you submitted:<BR>");
         out.println("<ul>");
         if (!daysSelected) {
             out.println("  <li>Must select at least one day of the week</li>");
         }
         if (invalidMins) { 
             out.println("  <li>Minutes must be between 0 and 59</li>");
         }
         if (invalidTime) {
             out.println("  <li>End time must be later than start time</li>");
         }
         if (invalidDate) {
             out.println("  <li>End date must be later than end date</li>");
         }
         out.println("</ul>");
         out.println("Please correct the above and submit the suspension again.");
         out.println("<form method=\"post\" action=\"/" + rev + "/servlet/Proshop_grest?susp\">");
         out.println("<input type=\"hidden\" name=\"returning\" value=\"true\">");
         if (id >= 0) { out.println("<input type=\"hidden\" name=\"id\" value=\"" + id + "\">"); }
         out.println("<input type=\"hidden\" name=\"grestid\" value=\"" + grest_id + "\">");
         out.println("<input type=\"hidden\" name=\"course\" value=\"" + courseName + "\">");
         out.println("<input type=\"hidden\" name=\"sdate\" value=\"" + sdate + "\">");
         out.println("<input type=\"hidden\" name=\"edate\" value=\"" + edate + "\">");
         out.println("<input type=\"hidden\" name=\"stime\" value=\"" + stime + "\">");
         out.println("<input type=\"hidden\" name=\"etime\" value=\"" + etime + "\">");
         out.println("<input type=\"hidden\" name=\"eo_week\" value=\"" + recurrArr[0] + "\">");
         out.println("<input type=\"hidden\" name=\"sunday\" value=\"" + recurrArr[1] + "\">");
         out.println("<input type=\"hidden\" name=\"monday\" value=\"" + recurrArr[2] + "\">");
         out.println("<input type=\"hidden\" name=\"tuesday\" value=\"" + recurrArr[3] + "\">");
         out.println("<input type=\"hidden\" name=\"wednesday\" value=\"" + recurrArr[4] + "\">");
         out.println("<input type=\"hidden\" name=\"thursday\" value=\"" + recurrArr[5] + "\">");
         out.println("<input type=\"hidden\" name=\"friday\" value=\"" + recurrArr[6] + "\">");
         out.println("<input type=\"hidden\" name=\"saturday\" value=\"" + recurrArr[7] + "\">");
         out.println("<br><input type=\"submit\" value=\"Return\">");
         out.println("</form>");
         out.println("</CENTER></BODY></HTML>");
         
     } else {
         try {
             if (id >= 0) {         // suspension exists, perform an update
                 pstmt = con.prepareStatement("UPDATE rest_suspend SET " +
                         "courseName = ?, stime = ?, etime = ?, sdate = ?, edate = ?, eo_week = ?, sunday = ?, monday = ?, tuesday = ?, wednesday = ?, " +
                         "thursday = ?, friday = ?, saturday = ? " +
                         "WHERE id = ?");
                 pstmt.clearParameters();
                 pstmt.setString(1, courseName);
                 pstmt.setInt(2, stime);
                 pstmt.setInt(3, etime);
                 pstmt.setInt(4, sdate);
                 pstmt.setInt(5, edate);
                 pstmt.setInt(6, recurrArr[0]);
                 for (int i=0; i<7; i++) {
                     pstmt.setInt(7+i, recurrArr[i + 1]);
                 }
                 pstmt.setInt(14, id);
                 count = pstmt.executeUpdate();
             } else {               // new entry
                 pstmt = con.prepareStatement("INSERT INTO rest_suspend " +
                         "(grest_id, courseName, stime, etime, sdate, edate, eo_week, sunday, monday, tuesday, " +
                         "wednesday, thursday, friday, saturday) " +
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                 pstmt.clearParameters();
                 pstmt.setInt(1, grest_id);
                 pstmt.setString(2, courseName);
                 pstmt.setInt(3, stime);
                 pstmt.setInt(4, etime);
                 pstmt.setInt(5, sdate);
                 pstmt.setInt(6, edate);
                 pstmt.setInt(7, recurrArr[0]);
                 for (int i=0; i<7; i++) {
                     pstmt.setInt(8+i, recurrArr[i + 1]);
                 }
                 count = pstmt.executeUpdate();
             }

             String url = "/" + rev + "/servlet/Proshop_grest?susp&grestid=" + grest_id;

             if (count > 0) {           // Update/Insert successful

                 out.println("<body bgcolor=\"#F5F5DC\" text=\"#000000\">");
                 out.println("<font face=\"Arial, Helvetica, Sans-serif\" size=\"2\">");
                 out.println("<h4 align=\"center\">Add/Update Successful!</h4>");
                 out.println("<p align=\"center\">The suspension was added/updated successfully!");
                 out.println("<br><br><a href=\"" + url + "\" style=\"text-decoration: none;\"><button align=\"center\" type=\"button\">Continue</button></a>");
                 out.println("<meta http-equiv=\"Refresh\" content=\"1; url=" + url + "\">"); // auto-refresh every 5 minutes
             } else {                   // Update/Insert unsuccessful

                 out.println("<body bgcolor=\"#F5F5DC\" text=\"#000000\">");
                 out.println("<font face=\"Arial, Helvetica, Sans-serif\" size=\"2\">");
                 out.println("<h4 align=\"center\">Add/Update Failed!</h4>");
                 out.println("<p align=\"center\">The suspension was not added/updated.");
                 out.println("<br><br><a href=\"" + url + "\" style=\"text-decoration: none;\"><button align=\"center\" type=\"button\">Continue</button></a>");
                 out.println("<meta http-equiv=\"Refresh\" content=\"1; url=" + url + "\">"); // auto-refresh every 5 minutes
             }

             pstmt.close();
         } catch (Exception exc) {
             dbError(out, exc);
         }
     }
     
     return;
 }
 
 // *********************************************************
 // Remove the specified member restriction suspension
 // *********************************************************
 private void deleteSuspension(HttpServletRequest req, Connection con, PrintWriter out) {
     
     int id = 0;
     int grest_id = 0;
     int count = 0;
     
     PreparedStatement pstmt = null;
     
     if (req.getParameter("id") != null) {
         
         id = Integer.parseInt(req.getParameter("id"));
         grest_id = Integer.parseInt(req.getParameter("grestid"));

         try {
             // Delete the suspension with matching id from rest_suspend
             pstmt = con.prepareStatement("DELETE FROM rest_suspend WHERE id = ?");
             pstmt.clearParameters();
             pstmt.setInt(1, id);
             count = pstmt.executeUpdate();
             
             String url = "/" + rev + "/servlet/Proshop_grest?susp&grestid=" + grest_id;
             
             if (count > 0) {           // Delete successful

                 out.println("<body bgcolor=\"#F5F5DC\" text=\"#000000\">");
                 out.println("<font face=\"Arial, Helvetica, Sans-serif\" size=\"2\">");
                 out.println("<h4 align=\"center\">Delete Successful!</h4>");
                 out.println("<p align=\"center\">The suspension was deleted successfully!");
                 out.println("<br><br><a href=\"" + url + "\" style=\"text-decoration: none;\"><button align=\"center\" type=\"button\">Continue</button></a>");
                 out.println("<meta http-equiv=\"Refresh\" content=\"1; url=" + url + "\">"); // auto-refresh every 5 minutes
             } else {                   // Delete unsuccessful

                 out.println("<body bgcolor=\"#F5F5DC\" text=\"#000000\">");
                 out.println("<font face=\"Arial, Helvetica, Sans-serif\" size=\"2\">");
                 out.println("<h4 align=\"center\">Delete Failed!</h4>");
                 out.println("<p align=\"center\">The suspension was not deleted.");
                 out.println("<br><br><a href=\"" + url + "\" style=\"text-decoration: none;\"><button align=\"center\" type=\"button\">Continue</button></a>");
                 out.println("<meta http-equiv=\"Refresh\" content=\"1; url=" + url + "\">"); // auto-refresh every 5 minutes
             }
             
         } catch (Exception exc) {
             dbError(out, exc);
         }
     }
     
     return;
 }
 
 // *********************************************************
 // Get the recurrence for a given suspension
 // *********************************************************
 private String getRecurrence(ResultSet rs, PrintWriter out) {
     
     String recurr = "";
     String eo_week = "";
     String lbreak = "";
     
     try {
         if (rs.getInt("eo_week") == 0) {
             eo_week = "Every ";
         } else {
             eo_week = "Every other ";
         }

         if (rs.getInt("sunday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Sunday" + lbreak;
         }
         if (rs.getInt("monday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Monday" + lbreak;
         }
         if (rs.getInt("tuesday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Tuesday" + lbreak;
         }
         if (rs.getInt("wednesday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Wednesday" + lbreak;
         }
         if (rs.getInt("thursday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Thursday" + lbreak;
         }
         if (rs.getInt("friday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Friday" + lbreak;
         }
         if (rs.getInt("saturday") != 0) {
             lbreak = "<br>";
             recurr += eo_week + "Saturday" + lbreak;
         }
     } catch (Exception exc) {
         dbError(out, exc);
     }
     
     return recurr;
 }      // end of getRecurrence


 // *********************************************************
 // Database Error
 // *********************************************************

 private void dbError(PrintWriter out, Exception exc) {

   out.println(SystemUtils.HeadTitle("Database Error"));
   out.println("<BODY><CENTER><BR>");
   out.println("<BR><BR><H3>Database Access Error</H3>");
   out.println("<BR><BR>Sorry, we are unable to access the database at this time.");
   out.println("<BR>Exception: " + exc);
   out.println("<BR>Please try again later.");
   out.println("<BR><BR>If problem persists, contact customer support.");
   out.println("<BR><BR><a href=\"/" +rev+ "/servlet/Proshop_announce\">Home</a>");
   out.println("</CENTER></BODY></HTML>");

 }

}
